

function startRun(camp) {
    const S = baseStats();
    const D = DIFF[OPT.diff] || DIFF[1];
    g = {
        frames: 0, S, D, dyn: { dmg: 1, fireRate: 1, speed: 1, invuln: false },
        weapons: { revolver: { lvl: 1, cd: 10 } }, powerStacks: {}, relics: [],
        hooks: { kill: [], hurt: [], level: [], tick: [] },
        player: { x: W / 2, y: H - 150, r: 9, vx: 0, vy: 0, hp: S.maxHp, iframes: 60, dash: 0, dashVx: 0, dashVy: 0, facing: 1 },
        lastDir: { x: 0, y: -1 },
        balls: [], bullets: [], ebullets: [], pickups: [], fx: [], texts: [], bolts: [],
        beam: null, hoopAngle: 0, xp: 0, level: 1, pending: 0, choices: null, rerolls: 0,
        gold: 0, goldTotal: 0, kills: 0, combo: 0, comboT: 0, shield: 0, shieldT: 0, revives: [],
        timeSlow: 0, dust: 0, buff: null, toasts: [], spawnT: 60, nextElite: 45 * 60, nextBoss: 180 * 60,
        shotCount: 0, ballId: 0, hurtFlash: 0, shake: 0, bombFlash: 0, actives: {},
        capeHits: 0, cape: null, pet: null, event: null, nextEvent: 75 * 60, bossN: 0, lastHurt: 0, maxCombo: 0, hatsDown: 0,
        pistolKills: 0, bossKills: 0, hitstop: 0, streak: null, warn: 0, biome: 0, levelFlash: 0, newBest: false, intro: camp ? 0 : 110,
        score: 0, dps: 60, dmgAcc: 0, dpsT: 0, aimA: -Math.PI / 2, live: false, kind: 'shoot', wi: 0, li: 0, returnTo: 'map', win: false, pay: 0, skyF: 0, camp: camp ? newCamp() : null,
        lvlScore0: 0, lvlGold0: 0, lvlKills0: 0, lvlT0: 0, stage: null,
    };
    if (!save.tipShown) { save.tipShown = 1; persist(); toast('Tip', 'Drag to move. Your gun fires by itself. Level up to pick powers!', '#48dbfb', 360); }
    const r = skillRank;
    changeMaxHp(g, 15 * r('tough'));
    S.dmg *= 1 + 0.08 * r('fire');
    S.fireRate *= 1 + 0.06 * r('trigger');
    S.speed *= 1 + 0.05 * r('boots');
    S.goldMult += 0.1 * r('goldrush');
    S.xpMult *= 1 + 0.08 * r('learner');
    S.magnet += 15 * r('arms');
    S.armor += r('iron');
    S.aoe *= 1 + 0.08 * r('boom'); S.heartHeal *= 1 + 0.15 * r('medic'); S.cooldownMult *= 1 - 0.04 * r('hands');
    S.regen += 0.2 * r('recovery');
    if (r('second')) g.revives.push(0.3);
    g.rerolls = r('reroll');
    if (godMode) { S.dmg *= 6; g.god = true; }
    S.luck += 5 * r('lucky');
    S.crit += 0.03 * r('crit');
    S.bounty = 0.5 * r('bounty');
    S.comboTime += 15 * r('coach');
    S.dropMult += 0.2 * r('drops');
    if (r('pet')) g.pet = { x: g.player.x - 30, y: g.player.y - 30, cd: 30, ang: 0, rank: r('pet') };
    for (const id of ['dash', 'slow', 'cape']) if (r(id)) g.actives[id] = { rank: r(id), cd: 0 };
    if (!camp) { mode = 'play'; andaleVoice(0.05); }
    if (r('starter')) grantRandomRelic(g, 'Starter Relic');
    if (r('armory')) {
        const pool = Object.keys(WEAPONS).filter(id => !g.weapons[id]);
        const id = pick(pool); unlockWeapon(g, id);
        toast('Armory', WEAPONS[id].name + ' equipped', '#ffb142', 150);
    }
    for (let i = 0; i < r('head'); i++) gainLevel(g);
    g.player.hp = g.S.maxHp;
    if (!camp) { toast(BIOMES[0].name, DIFF[OPT.diff].name + ' difficulty', '#ffd32a', 140);
    if (g.pending > 0) openLevelUp(); }
}

// =====================================================================
//  CORE MECHANICS
// =====================================================================
function changeMaxHp(g, delta) {
    g.S.maxHp = Math.max(10, g.S.maxHp + delta);
    if (delta > 0) g.player.hp += delta;
    g.player.hp = Math.min(g.player.hp, g.S.maxHp);
}
function heal(g, v) {
    const p = g.player;
    const before = p.hp;
    p.hp = Math.min(g.S.maxHp, p.hp + v);
    if (p.hp - before >= 1) addText(g, p.x, p.y - 20, '+' + Math.round(p.hp - before), '#2ecc71', 12);
}
function gainGold(g, v) {
    const bonus = 1 + Math.min(0.5, g.combo * 0.01);
    const amt = Math.max(1, Math.round(v * g.S.goldMult * g.D.gold * bonus));
    g.gold += amt; g.goldTotal += amt;
}
function need(l) { return Math.floor(5 + (l - 1) * 4 + Math.pow(l - 1, 1.6) * 0.6); }
function gainXp(g, v) {
    g.xp += v * g.S.xpMult;
    while (g.xp >= need(g.level)) { g.xp -= need(g.level); gainLevel(g); }
    if (g.pending > 0 && mode === 'play') openLevelUp();
}
function gainLevel(g) {
    g.level++; g.pending++;
    for (const h of g.hooks.level) h(g);
}
function toast(title, text, color = '#ffe066', t = 200) {
    if (!g) return;
    g.toasts.push({ title, text, color, t, max: t });
    if (g.toasts.length > 4) g.toasts.shift();
}
function addText(g, x, y, txt, color, size = 10) {
    if (!OPT.dmgnums && /^-?\d+$/.test(txt) && color !== '#ff4757' && color !== '#2ecc71') return;
    if (g.texts.length > 50) g.texts.shift();
    g.texts.push({ x, y, txt, color, size, t: 40 });
}
function addRing(g, x, y, r, color, t = 18) { if (g.fx.length > 500) return; g.fx.push({ kind: 'ring', x, y, r, color, t, max: t }); }
function burst(g, x, y, color, n = 8) {
    const pm = PARTM();
    if (pm <= 0) return;
    n = Math.max(1, Math.round(n * pm));
    for (let i = 0; i < n; i++) {
        if (g.fx.length > 260 * Math.max(0.6, pm)) break;
        const a = rand(0, TAU), s = rand(0.8, 3);
        g.fx.push({ kind: 'p', x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, color, t: randi(14, 26), max: 26, sz: rand(2, 3.6) });
    }
}
const CONF = ['#ff6b6b', '#feca57', '#48dbfb', '#1dd1a1', '#ff9ff3', '#a29bfe'];
function confetti(g, x, y, n) {
    const pm = PARTM();
    if (pm <= 0) return;
    n = Math.min(Math.round(n * pm), Math.max(0, 700 - g.fx.length));   // hard cap so a bomb in a crowd can't flood the particle list
    for (let i = 0; i < n; i++) g.fx.push({ kind: 'p', x, y, vx: rand(-3.5, 3.5), vy: rand(-6, -1), color: pick(CONF), t: randi(40, 70), max: 70, sz: rand(2, 4), grav: 0.14, rect: true });
}

// enemies track the hero: they keep coming (never retreating up the screen), steering sideways and down onto you as you move, then sweep past off the bottom. [top speed, how hard they track you]
const ROAMERS = { basic: [1.6, 0.5], fast: [3.0, 0.8], zig: [1.5, 0.4], armored: [1.3, 0.4], splitter: [1.3, 0.4], shielded: [1.4, 0.4], bomber: [1.8, 0.6], mender: [1.2, 0.3], pinata: [1.5, 0.3], elite: [1.0, 0.3] };
function spawnBall(type, x, y, opt) {
    opt = opt || {};
    const T = BTYPES[type], m = g.camp ? g.camp.m : g.frames / 3600;
    const hpMul = (1 + m * 0.9 + m * m * 0.18) * g.S.ballHpMult * g.D.hp;
    const spd = 1 + Math.min(1.2, m * 0.12);
    const isBossT = type === 'boss' || type === 'boss2' || !!BOSS_TYPES[type];
    const r = opt.r || T.r * (isBossT ? 1 : 0.8);   // ship sprites and hitboxes are 20% smaller
    const b = {
        id: ++g.ballId, type, r,
        x: x !== undefined ? x : rand(r, W - r), y: y !== undefined ? y : -r - 5,
        vx: rand(-0.5, 0.5) * (type === 'fast' ? 1.6 : 1),
        baseVy: T.vy * spd * rand(0.85, 1.15),
        hp: T.hp * hpMul, dmg: T.dmg, xp: T.xp, color: pick(T.colors), phase: rand(0, 600),
        armored: !!T.armored, big: type === 'big' || type === 'elite' || type === 'boss' || type === 'boss2' || BOSS_TYPES[type],
        boss: type === 'boss' || type === 'boss2' || BOSS_TYPES[type], elite: type === 'elite',
        flash: 0, slowT: 0, burnT: 0, burnDps: 0, hoopCd: 0, wasHit: false, dead: false, gone: false,
        gen: opt.gen || 0, age: 0, shootT: randi(40, 110), shieldHp: 0,
        hat: type === 'boss' ? 1 : type === 'boss2' ? 4 : type === 'elite' ? 4 : (opt.hat !== undefined ? opt.hat : randi(0, 3)),
    };
    b.vy = b.baseVy; b.maxHp = b.hp;
    if (type === 'shielded') b.shieldHp = b.hp * 0.7;
    if (b.boss) { b.x = W / 2; b.vx = 1.2; b.spawnT = 120; b.atkT = 150; }
    g.balls.push(b);
    return b;
}
function randomBallType(m) {
    const table = [['basic', 60], ['fast', m > 0.4 ? 20 : 0], ['zig', m > 0.9 ? 15 : 0], ['big', m > 1.4 ? 10 : 0], ['armored', m > 2.2 ? 12 : 0],
        ['pistolero', m > 1.0 ? 9 : 0], ['splitter', m > 1.2 ? 10 : 0], ['dive', m > 1.6 ? 12 : 0], ['bomber', m > 2.0 ? 8 : 0], ['shielded', m > 2.8 ? 10 : 0], ['mender', m > 1.8 ? 7 : 0], ['pinata', m > 0.6 ? 3 : 0], ['golden', 2]];
    let total = 0; for (const t of table) total += t[1];
    let r = Math.random() * total;
    for (const t of table) { r -= t[1]; if (r <= 0) return t[0]; }
    return 'basic';
}

function dealDamage(g, ball, amount, src = {}) {
    if (!ball || ball.dead) return;
    const S = g.S;
    let dmg = amount * S.dmg * g.dyn.dmg;
    if (ball.big) dmg *= S.bigDmg;
    let crit = false;
    if (!src.noCrit && (Math.random() < S.crit || (S.firstHitCrit && !ball.wasHit))) { crit = true; dmg *= S.critMult; }
    if (ball.armored) dmg *= 0.5;
    ball.wasHit = true;
    ball.flash = 3;
    sfx('hit');
    if (ball.shieldHp > 0) {
        ball.shieldHp -= dmg;
        if (ball.shieldHp <= 0) { ball.shieldHp = 0; addRing(g, ball.x, ball.y, ball.r + 10, '#74b9ff', 14); burst(g, ball.x, ball.y, '#74b9ff', 8); sfx('shield'); }
        return;
    }
    if (dmg < 1e6) g.dmgAcc += Math.min(dmg, Math.max(0, ball.hp));
    ball.hp -= dmg;
    if (dmg >= 1) addText(g, ball.x + rand(-6, 6), ball.y - ball.r, String(Math.round(dmg)), crit ? '#ffd32a' : (src.color || '#ffffff'), crit ? 13 : 9);
    if (!src.noProc) {
        if (src.burn || Math.random() < S.burnChance || (crit && S.critBurn)) {
            ball.burnT = Math.round(180 * S.durMult);
            ball.burnDps = Math.max(ball.burnDps, amount * 0.6 * S.burnMult);
        }
        if (Math.random() < S.slowChance) ball.slowT = Math.round(120 * S.durMult);
        if (Math.random() < S.chainChance) chainFrom(g, ball, amount * 0.6);
        if (Math.random() < S.explodeChance || (crit && Math.random() < S.critExplode)) explode(g, ball.x, ball.y, 34 * S.aoe, amount * 0.7, '#ffa502');
        if (S.knock > 0 && !ball.boss) ball.vy -= S.knock;
    }
    if (S.execute > 0 && ball.hp > 0 && !ball.boss && ball.hp < ball.maxHp * S.execute) {
        ball.hp = 0; addText(g, ball.x, ball.y - ball.r - 8, 'EXECUTE', '#ff4757', 10);
    }
    if (ball.hp <= 0) killBall(g, ball, -ball.hp, src);
}

function killBall(g, b, overkill, src = {}) {
    if (b.dead) return;
    b.dead = true; g.kills++;
    g.score += killScore(b); if (g.stage) stageOnKill(b);
    const S = g.S, m = g.camp ? g.camp.m : g.frames / 3600, T = BTYPES[b.type];
    burst(g, b.x, b.y, b.color, b.big ? 16 : 8);
    sfx(b.boss ? 'boss' : 'pop');
    // knocked-off sombrero flies away
    if (OPT.hats) {
        g.hatsDown++;
        if (g.fx.length < 300) g.fx.push({ kind: 'hat', x: b.x, y: b.y - b.r * 0.7, vx: rand(-2, 2), vy: rand(-4.5, -2.5), rot: 0, vr: rand(-0.25, 0.25), s: b.r * 1.15, hat: b.hat, t: 60, max: 60 });
    }
    if (b.type === 'pistolero') g.pistolKills++;
    dropPickup(g, 'xp', b.x, b.y, Math.max(1, Math.round(b.xp * (1 + m * 0.25))));
    let coins = T.coins || 0;
    if (coins) coins = Math.round(coins * S.goldDropMult * ((b.elite || b.boss) ? 1 + S.bounty : 1));
    else if (Math.random() < T.gold * (1 + S.luck / 100) * S.goldDropMult) coins = 1;
    if (S.pinata && Math.random() < 0.05) { coins += 5; addText(g, b.x, b.y, 'PIÑATA!', '#fd79a8', 11); }
    if (coins > 0) {
        const pieces = Math.min(coins, 12), val = coins / pieces;
        for (let i = 0; i < pieces; i++) dropPickup(g, 'gold', b.x + rand(-b.r, b.r), b.y + rand(-b.r, b.r), val);
    }
    if (Math.random() < S.heartDrop * (1 + S.luck / 100)) dropPickup(g, 'heart', b.x, b.y, 1);
    if (Math.random() < 0.012 * (1 + S.luck / 100) * S.dropMult) dropPickup(g, 'power:' + pickPowerup(), b.x, b.y, 1);
    if (S.healOnKill > 0 && Math.random() < S.healOnKill) heal(g, 2);
    g.combo++; g.comboT = Math.round(60 + S.comboTime);
    if (g.combo > g.maxCombo) g.maxCombo = g.combo;
    if (STREAKS[g.combo]) { g.streak = { txt: STREAKS[g.combo], t: 80, max: 80 }; sfx('power'); const sg = STREAK_GOLD[g.combo]; if (sg) { gainGold(g, sg); addText(g, b.x, b.y - 18, '+' + sg + ' gold', '#ffd32a', 12); } }
    if (S.overkill && overkill > 1 && !src.fromOverkill) {
        const n = nearestBall(g, b.x, b.y, 90, b);
        if (n) { g.bolts.push({ x1: b.x, y1: b.y, x2: n.x, y2: n.y, t: 8, color: '#ff6b81' }); dealDamage(g, n, overkill / (S.dmg * g.dyn.dmg), { noProc: true, noCrit: true, fromOverkill: true }); }
    }
    if (b.type === 'big') {
        for (const s of [-1, 1]) {
            const c = spawnBall('basic', b.x + s * 8, b.y);
            c.vx = s * 1.3; c.hp = c.maxHp = c.hp * 0.6;
        }
    }
    if (b.type === 'splitter' && b.gen < 2) {
        for (const s of [-1, 1]) {
            const c = spawnBall('splitter', b.x + s * 8, b.y, { r: Math.max(8, b.r * 0.72), gen: b.gen + 1, hat: b.hat });
            c.vx = s * 1.2; c.hp = c.maxHp = b.maxHp * 0.55; c.color = b.color;
        }
    }
    if (b.type === 'bomber') {
        explode(g, b.x, b.y, 55, 40, '#ff6348');
        const p = g.player;
        if ((p.x - b.x) ** 2 + (p.y - b.y) ** 2 < (55 + p.r) ** 2) hurtPlayer(g, 16, null);
    }
    if (b.elite) {
        if (Math.random() < 0.5) dropPickup(g, 'chest', b.x, b.y, 1);
        dropPickup(g, 'power:' + pickPowerup(), b.x + 10, b.y, 1);
    }
    if (b.boss) {
        g.bossKills++; g.hitstop = 20; g.shake = 22; g.levelFlash = 16;
        grantRandomRelic(g, 'Boss treasure!');
        heal(g, g.S.maxHp * 0.25); for (let i = 0; i < 10; i++) dropPickup(g, 'gold', b.x + rand(-30, 30), b.y + rand(-20, 20), 3);   // victory: heal a quarter and a gold shower
        dropPickup(g, 'chest', b.x - 14, b.y, 1); dropPickup(g, 'chest', b.x + 14, b.y, 1);
        confetti(g, b.x, b.y, 60);
        vib([60, 40, 100]);
        bossFallToast(b);
    }
    if (b.type === 'pinata') { confetti(g, b.x, b.y, 18); addText(g, b.x, b.y - b.r - 8, '¡PIÑATA!', '#fd79a8', 12); }
    for (const h of g.hooks.kill) h(g, b);
}

function dropPickup(g, type, x, y, value) {
    if (g.pickups.length > 260) {
        const same = g.pickups.find(p => p.type === type);
        if (same) { same.value += value; return; }
    }
    g.pickups.push({ type, x, y, value, vx: rand(-1, 1), vy: rand(-1.5, 0), vac: false, t: 0 });
}

function compactBalls(g) {   // in-place filter: same result as .filter() without allocating a new array each frame
    const a = g.balls; let j = 0;
    for (let i = 0; i < a.length; i++) { const b = a[i]; if (!b.dead && !b.gone) a[j++] = b; }
    a.length = j;
}
function nearestBall(g, x, y, maxD, exclude) {
    let best = null, bd = maxD * maxD;
    for (const b of g.balls) {
        if (b.dead || b === exclude || b.y < -b.r) continue;
        const dx = b.x - x, dy = b.y - y, d = dx * dx + dy * dy;
        if (d < bd) { bd = d; best = b; }
    }
    return best;
}
function randomBall(g) {
    const vis = g.balls.filter(b => !b.dead && b.y > 0 && b.y < H);
    return vis.length ? pick(vis) : null;
}
function chainFrom(g, ball, dmg) {
    let from = ball, hit = new Set([ball.id]);
    for (let j = 0; j < 2; j++) {
        let best = null, bd = 100 * 100;
        for (const b of g.balls) {
            if (b.dead || hit.has(b.id)) continue;
            const d = (b.x - from.x) ** 2 + (b.y - from.y) ** 2;
            if (d < bd) { bd = d; best = b; }
        }
        if (!best) break;
        hit.add(best.id);
        g.bolts.push({ x1: from.x, y1: from.y, x2: best.x, y2: best.y, t: 8, color: '#74b9ff' });
        dealDamage(g, best, dmg, { noProc: true, color: '#74b9ff' });
        from = best;
    }
}
function explode(g, x, y, r, dmg, color = '#ffa502') {
    addRing(g, x, y, r, color, 16);
    burst(g, x, y, color, 6);
    for (const b of g.balls.slice()) {
        if (b.dead) continue;
        const rr = r + b.r;
        if ((b.x - x) ** 2 + (b.y - y) ** 2 < rr * rr) dealDamage(g, b, dmg, { noProc: true, color });
    }
}
function strikeBall(g, b, dmg, procs = false) {
    g.bolts.push({ x1: b.x + rand(-20, 20), y1: 0, x2: b.x, y2: b.y, t: 10, color: '#a5d8ff', jag: true });
    dealDamage(g, b, dmg, { noProc: !procs, color: '#a5d8ff' });
}
function strikeRandom(g, dmg) { const b = randomBall(g); if (b) strikeBall(g, b, dmg); }
function cometStrike(g) {
    const b = randomBall(g); if (!b) return;
    g.bolts.push({ x1: b.x - 60, y1: -10, x2: b.x, y2: b.y, t: 12, color: '#ffbe76' });
    dealDamage(g, b, 80, { noProc: true, color: '#ffbe76' });
    explode(g, b.x, b.y, 40 * g.S.aoe, 30, '#ffbe76');
}
function pushAway(g, x, y, r, force) {
    for (const b of g.balls) {
        if (b.dead || b.boss) continue;
        const dx = b.x - x, dy = b.y - y, d = Math.hypot(dx, dy);
        if (d < r + b.r && d > 0) { b.vx += dx / d * force * 0.5; b.vy = Math.min(b.vy, -force * (dy < 0 ? 1 : 0.5)); }
    }
    addRing(g, x, y, r, '#ffeaa7', 14);
}
function rollDice(g) {
    const S = g.S;
    const opts = [
        ['Damage +5%', () => S.dmg *= 1.05], ['Fire rate +5%', () => S.fireRate *= 1.05], ['Speed +5%', () => S.speed *= 1.05],
        ['Max HP +10', () => changeMaxHp(g, 10)], ['Crit +3%', () => S.crit += 0.03], ['Magnet +10', () => S.magnet += 10],
        ['Armor +1', () => S.armor += 1], ['Gold +10%', () => S.goldMult += 0.1],
    ];
    const o = pick(opts); o[1](); toast('Mystery Dice', o[0], '#e056fd', 120);
}
function snakeOil(g) {
    const types = [['Fury', 'Double damage'], ['Haste', '+50% speed'], ['Rapid', 'Double fire rate'], ['Holy', 'Invincible']];
    const t = pick(types);
    g.buff = { type: t[0], t: 600 };
    toast('Snake Oil: ' + t[0], t[1] + ' for 10s', '#00d2d3', 140);
}
function grantRandomRelic(g, title) {
    const pool = RELICS.filter(r => !g.relics.includes(r.id));
    if (!pool.length) { gainGold(g, 50); toast(title || 'Relic', 'All relics found! +50 gold', '#e056fd', 180); return null; }
    const r = pick(pool);
    g.relics.push(r.id);
    r.apply(g);
    sfx('power');
    toast((title ? title + ' ' : '') + r.name, r.desc, '#e056fd', 260);
    return r;
}
function applyPowerupShoot(t) {
    const U = POWERUPS[t]; if (!U) return;
    sfx('power'); toast(U.name, '', U.c, 100);
    if (t === 'magnet') g.pickups.forEach(k => k.vac = true);
    else if (t === 'nuke') {
        for (const b of g.balls.slice()) dealDamage(g, b, 150, { noProc: true, noCrit: true, color: '#ff6b6b' });
        g.bombFlash = 16; g.shake = 14; vib(90);
        for (let i = 0; i < 8; i++) dropPickup(g, 'gold', rand(30, W - 30), rand(70, 300), 2);
        addRing(g, g.player.x, g.player.y, 240, '#ff6b6b', 26); confetti(g, g.player.x, g.player.y, 40);
    }
    else if (t === 'freeze') g.timeSlow = Math.max(g.timeSlow, 240);
    else if (t === 'frenzy') g.buff = { type: 'Rapid', t: 480 };
    else if (t === 'fury') g.buff = { type: 'Fury', t: 480 };
    else if (t === 'haste') g.buff = { type: 'Haste', t: 480 };
    else if (t === 'rush') for (let i = 0; i < 14; i++) dropPickup(g, 'gold', rand(30, W - 30), rand(60, 260), 2);
    else if (t === 'shield') g.shield = Math.max(g.shield, 1);
}

function hurtPlayer(g, raw, ball) {
    const p = g.player, S = g.S;
    if (g.god) { p.hp = S.maxHp; return; }
    if (p.iframes > 0 || p.dash > 0 || g.dyn.invuln) return;
    if (ball && S.thorns > 0) dealDamage(g, ball, S.thorns, { noProc: true, noCrit: true, color: '#b2bec3' });
    if (Math.random() < Math.min(0.6, S.dodge)) { addText(g, p.x, p.y - 22, 'DODGE', '#74b9ff', 11); p.iframes = 20; return; }
    if (g.shield > 0) { g.shield--; g.shieldT = 0; addText(g, p.x, p.y - 22, 'BLOCK', '#ffeaa7', 11); p.iframes = S.iframes; addRing(g, p.x, p.y, 24, '#ffeaa7'); sfx('shield'); return; }
    const m = g.camp ? g.camp.m : g.frames / 3600;
    const d = Math.max(1, raw * (1 + m * 0.15) * S.dmgTaken * g.D.dmg - S.armor);
    p.hp -= d; p.iframes = S.iframes; g.hurtFlash = 12; g.shake = 8; g.lastHurt = g.frames;
    g.combo = Math.max(0, g.combo - 5);
    sfx('hurt'); vib(40);
    addText(g, p.x, p.y - 22, '-' + Math.round(d), '#ff4757', 13);
    for (const h of g.hooks.hurt) h(g, ball);
    if (p.hp <= 0) {
        if (g.revives.length) {
            g.revives.sort((a, b) => b - a);
            const pct = g.revives.shift();
            p.hp = Math.round(S.maxHp * pct); p.iframes = 180;
            for (const b of g.balls.slice()) dealDamage(g, b, 60, { noProc: true, noCrit: true });
            addRing(g, p.x, p.y, 200, '#ffd32a', 30);
            toast('REVIVED!', 'Back in the saddle', '#ffd32a', 180);
            sfx('level');
        } else {
            p.hp = 0; endRun();
        }
    }
}

function useActive(id) {
    if (mode !== 'play' || !g || !g.actives[id] || g.kind === 'convoy') return;
    const a = g.actives[id];
    if (a.cd > 0) return;
    const p = g.player;
    sfx('power');
    if (g.kind !== 'shoot') { useActiveAlt(id, a); a.cd = Math.round(ACTIVES[id].cd(a.rank) * g.S.skillCd); return; }
    if (id === 'cape') {
        const dur = 80 + 25 * (a.rank - 1);
        g.cape = { t: dur, max: dur, rank: a.rank, hits: 0, ang: -Math.PI / 2 + 1.45, hist: [] };
        p.iframes = Math.max(p.iframes, 6);
        if (AC && OPT.sfx) ole(0);
    } else if (id === 'dash') {
        p.dash = 10; p.dashVx = g.lastDir.x * 9; p.dashVy = g.lastDir.y * 9;
        p.iframes = Math.max(p.iframes, 16);
    } else if (id === 'slow') {
        g.timeSlow = 180 + 60 * (a.rank - 1);
        toast('Siesta', 'Balls slowed', '#a29bfe', 90);
    }
    a.cd = Math.round(ACTIVES[id].cd(a.rank) * g.S.skillCd);
}

function endRun(win) {
    if (mode === 'over') return;
    mode = 'over'; g.live = false; g.win = !!win;
    drag = null;
    g.newBest = g.frames > save.bestTime;
    g.pay = payout(g.score); save.gold += g.pay;
    if (g.camp) { g.camp.active = false; const sc = save.camp; g.newBestScore = g.score > sc.bestScore; sc.bestScore = Math.max(sc.bestScore, g.score); sc.runs++; if (win) sc.wins++; }
    else { g.newBestScore = g.score > (save.camp.bestScore || 0); }
    save.bestTime = Math.max(save.bestTime, g.frames);
    save.bestLevel = Math.max(save.bestLevel, g.level);
    const st = save.stats;
    st.runs++; st.kills += g.kills; st.goldEarned += g.goldTotal; st.time += g.frames; st.bosses += g.bossKills;
    st.maxCombo = Math.max(st.maxCombo, g.maxCombo); st.hats += g.hatsDown; st.bestKills = Math.max(st.bestKills, g.kills);
    checkAchievements();
    persist();
}

function checkAchievements() {
    for (const a of ACHS) {
        if (save.ach[a.id]) continue;
        let ok = false;
        try { ok = a.test(g); } catch (e) {}
        if (ok) {
            save.ach[a.id] = 1; save.gold += a.gold; persist();
            sfx('trophy');
            toast('Trophy: ' + a.name, a.desc + '  +' + a.gold + ' gold', '#f9ca24', 220);
        }
    }
}

// =====================================================================
//  LEVEL UP
// =====================================================================
function availablePowers() {
    if (g.kind !== 'shoot') return availableCards();
    return POWERS.filter(p => (g.powerStacks[p.id] || 0) < p.max && p.req(g));
}
function weightedPick(pool) {
    const L = g.S.luck;
    const wt = p => p.rarity === 'common' ? 100 : p.rarity === 'rare' ? 40 + L : 12 + L * 0.6;
    let total = 0; for (const p of pool) total += wt(p);
    let r = Math.random() * total;
    for (const p of pool) { r -= wt(p); if (r <= 0) return p; }
    return pool[pool.length - 1];
}
function makeChoices() {
    let pool = availablePowers();
    const out = [];
    for (let i = 0; i < 2; i++) {
        if (!pool.length) { out.push({ kind: 'filler' }); continue; }
        const p = weightedPick(pool);
        out.push({ kind: 'power', p });
        pool = pool.filter(x => x !== p);
    }
    out.push({ kind: 'relic' });
    return out;
}
function openLevelUp() {
    mode = 'levelup';
    drag = null;
    g.choices = makeChoices();
    g.levelFlash = 14;
    sfx('level');
    confetti(g, g.player.x, g.player.y, 34);
    addRing(g, g.player.x, g.player.y, 90, '#ffd32a', 26);
}
function chooseCard(i) {
    if (mode !== 'levelup' || !g.choices || !g.choices[i]) return;
    const c = g.choices[i];
    sfx('buy');
    if (c.kind === 'power') {
        g.powerStacks[c.p.id] = (g.powerStacks[c.p.id] || 0) + 1;
        c.p.apply(g);
    } else if (c.kind === 'relic') {
        grantRandomRelic(g, 'Relic:');
    } else {
        gainGold(g, 25); heal(g, 25);
    }
    g.pending--;
    if (g.pending > 0) g.choices = makeChoices();
    else { mode = g.live === false ? (g.returnTo || 'map') : 'play'; g.choices = null; g.player.iframes = Math.max(g.player.iframes, 45); }
}
function rerollChoices() {
    if (mode !== 'levelup' || g.rerolls <= 0) return;
    g.rerolls--;
    g.choices = makeChoices();
}

// =====================================================================
//  WEAPONS
// =====================================================================
function shoot(g, x, y, ang, spd, dmg, opt = {}) {
    const S = g.S;
    const b = {
        x, y, vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd,
        r: (opt.r || 3) * S.size, dmg,
        pierce: opt.pierce !== undefined ? opt.pierce : S.pierce,
        bounce: opt.bounce !== undefined ? opt.bounce : S.bounce,
        life: opt.life || 200, kind: opt.kind || 'bullet', color: opt.color || '#ffe066',
        homing: opt.homing || 0, burn: !!opt.burn, canSplit: opt.canSplit !== false,
        hits: new Set(), target: null, retarget: 0,
    };
    g.bullets.push(b);
    return b;
}
function fireGun(g, x, y, ang, spd, dmg, opt = {}) {
    const S = g.S;
    if (S.jitter) ang += rand(-S.jitter, S.jitter);
    shoot(g, x, y, ang, spd, dmg, opt);
    if (S.dupChance > 0 && Math.random() < S.dupChance) shoot(g, x, y, ang + rand(-0.15, 0.15), spd, dmg, opt);
}

function updateWeapons(g) {
    const S = g.S, p = g.player;
    const gunCd = S.cooldownMult / (S.fireRate * g.dyn.fireRate);
    for (const id in g.weapons) {
        const w = g.weapons[id], L = w.lvl;
        if (id === 'hoops') continue;
        w.cd--;
        if (w.cd > 0) continue;
        switch (id) {
            case 'revolver': {
                const dmg = 10 * (1 + 0.22 * (L - 1));
                const n = 1 + Math.floor((L - 1) / 3) + S.extraProj;
                const spread = 0.12 * S.spreadMult;
                for (let i = 0; i < n; i++) {
                    const a = g.aimA + (i - (n - 1) / 2) * spread;
                    fireGun(g, p.x + (i - (n - 1) / 2) * 3, p.y - 14, a, 7.5 * S.projSpeed, dmg, { homing: S.homing });
                }
                if (S.backfire) fireGun(g, p.x, p.y + 12, Math.PI / 2, 7 * S.projSpeed, dmg * 0.7);
                if (S.sideArms) {
                    fireGun(g, p.x - 6, p.y - 8, g.aimA - 0.6, 7 * S.projSpeed, dmg * 0.7);
                    fireGun(g, p.x + 6, p.y - 8, g.aimA + 0.6, 7 * S.projSpeed, dmg * 0.7);
                }
                g.shotCount++;
                sfx('shoot');
                if (S.staticCharge && g.shotCount % 10 === 0) strikeRandom(g, 30 + 5 * L);
                w.cd = Math.max(4, Math.round(22 * gunCd));
                break;
            }
            case 'buckshot': {
                const n = Math.min(14, 3 + L + S.extraProj);
                const fan = 0.9 * S.spreadMult;
                const dmg = 6 * (1 + 0.15 * (L - 1));
                for (let i = 0; i < n; i++) {
                    const a = g.aimA - fan / 2 + fan * (n === 1 ? 0.5 : i / (n - 1));
                    fireGun(g, p.x, p.y - 10, a, 6.5 * S.projSpeed * rand(0.9, 1.1), dmg, { life: 38, color: '#ffb142', r: 2.5, homing: S.homing });
                }
                w.cd = Math.max(8, Math.round(52 * gunCd));
                break;
            }
            case 'lasso': {
                const R = (52 + 6 * L) * S.aoe, dmg = 14 * (1 + 0.25 * (L - 1));
                g.fx.push({ kind: 'lasso', x: p.x, y: p.y, r: R, t: 16, max: 16 });
                for (const b of g.balls.slice()) {
                    if (b.dead) continue;
                    const rr = R + b.r;
                    if ((b.x - p.x) ** 2 + (b.y - p.y) ** 2 < rr * rr) dealDamage(g, b, dmg, { color: '#d4a373' });
                }
                w.cd = Math.round(85 * S.cooldownMult);
                break;
            }
            case 'chili': {
                const n = Math.min(7, L), dmg = 15 * (1 + 0.2 * (L - 1));
                for (let i = 0; i < n; i++) shoot(g, p.x, p.y - 8, g.aimA + rand(-0.8, 0.8), 4.2, dmg, { homing: 0.12, burn: true, color: '#e74c3c', r: 4, life: 170, pierce: 0, bounce: 0, kind: 'chili' });
                w.cd = Math.round(65 * S.cooldownMult);
                break;
            }
            case 'thunder': {
                const n = Math.min(8, L), dmg = 26 * (1 + 0.22 * (L - 1));
                const vis = shuffle(g.balls.filter(b => !b.dead && b.y > 0 && b.y < H));
                for (let i = 0; i < Math.min(n, vis.length); i++) strikeBall(g, vis[i], dmg, true);
                if (vis.length) sfx('thunder');
                w.cd = Math.round(95 * S.cooldownMult);
                break;
            }
            case 'cactus': {
                const n = 8 + 2 * L, dmg = 8 * (1 + 0.15 * (L - 1));
                const off = rand(0, TAU);
                for (let i = 0; i < n; i++) shoot(g, p.x, p.y, off + i * TAU / n, 5 * S.projSpeed, dmg, { life: Math.round(45 * S.aoe), color: '#2ecc71', r: 2.5 });
                w.cd = Math.round(100 * S.cooldownMult);
                break;
            }
            case 'dynamite': {
                const n = 1 + Math.floor((L - 1) / 3);
                for (let i = 0; i < n; i++) {
                    const tgt = randomBall(g);
                    const tx = tgt ? tgt.x : p.x + rand(-60, 60), ty = tgt ? tgt.y + tgt.vy * 28 : p.y - 200;
                    const b = shoot(g, p.x, p.y - 6, 0, 0, 30 * (1 + 0.25 * (L - 1)), { kind: 'dyn', color: '#ff7675', r: 3.5, life: 999 });
                    b.t = 28; b.vx = (tx - p.x) / 28; b.vy = (ty - p.y) / 28; b.radius = (34 + 4 * L) * S.aoe;
                }
                w.cd = Math.round(110 * S.cooldownMult);
                break;
            }
            case 'sunbeam': {
                g.beam = { t: Math.round(40 * S.durMult), max: Math.round(40 * S.durMult), w: (12 + 3 * L) * S.aoe, dmg: 5 * (1 + 0.25 * (L - 1)) };
                w.cd = Math.round(170 * S.cooldownMult);
                break;
            }
            case 'tumbleweed': {
                const n = 1 + Math.floor((L - 1) / 3);
                for (let i = 0; i < n; i++) {
                    const a = g.aimA + (Math.random() < 0.5 ? -1 : 1) * rand(0.3, 1.0);
                    shoot(g, p.x, p.y, a, 4, 12 * (1 + 0.2 * (L - 1)), { kind: 'tumble', r: 7, pierce: 999, bounce: 3 + L + S.bounce, life: 360, color: '#c8a165', canSplit: false });
                }
                w.cd = Math.round(85 * S.cooldownMult);
                break;
            }
            case 'trumpet': {
                const Rg = (95 + 8 * L) * S.aoe, dmg = 16 * (1 + 0.22 * (L - 1)), half = 0.5 + 0.03 * L;
                g.fx.push({ kind: 'cone', x: p.x, y: p.y, r: Rg, half, t: 18, max: 18 });
                for (const b of g.balls.slice()) {
                    if (b.dead) continue;
                    const dx = b.x - p.x, dy = b.y - p.y, d = Math.hypot(dx, dy);
                    if (d > Rg + b.r || dy > b.r * 0.5) continue;
                    const ang = Math.atan2(dx, -dy);
                    if (Math.abs(ang) < half + b.r / Math.max(d, 1)) {
                        dealDamage(g, b, dmg, { color: '#f9ca24' });
                        if (!b.boss) b.vy = Math.min(b.vy, -2.5);
                    }
                }
                sfx('trumpet');
                w.cd = Math.round(120 * S.cooldownMult);
                break;
            }
            case 'skulls': {
                const n = 1 + Math.floor(L / 2), dmg = 14 * (1 + 0.2 * (L - 1));
                for (let i = 0; i < n; i++) shoot(g, p.x + rand(-10, 10), p.y - 8, g.aimA + (i - (n - 1) / 2) * 0.7 + rand(-0.2, 0.2), 2.6 * S.projSpeed, dmg, { homing: 0.07, pierce: 3, color: '#dfe6e9', r: 5, life: 200, bounce: 0, canSplit: false });
                w.cd = Math.round(78 * S.cooldownMult);
                break;
            }
            case 'boomerang': {
                const n = 1 + Math.floor((L - 1) / 3) + (L >= 8 ? 1 : 0);
                for (let i = 0; i < n; i++) {
                    const a = g.aimA + (i - (n - 1) / 2) * 0.55;
                    const bl = shoot(g, p.x, p.y - 8, a, 5.5 * S.projSpeed, 13 * (1 + 0.22 * (L - 1)), { kind: 'boom', r: 6, pierce: 999, bounce: 0, life: 300, color: '#e17055', canSplit: false });
                    bl.out = 34 + 4 * L;
                }
                w.cd = Math.round(95 * S.cooldownMult);
                break;
            }
        }
    }
    // Orbiting hoops (continuous)
    if (g.weapons.hoops) {
        const L = g.weapons.hoops.lvl, n = Math.min(8, L + 1), R = (34 + L * 2) * S.aoe, dmg = 7 * (1 + 0.2 * (L - 1));
        g.hoopAngle += 0.07;
        for (let i = 0; i < n; i++) {
            const a = g.hoopAngle + i * TAU / n;
            const hx = p.x + Math.cos(a) * R, hy = p.y + Math.sin(a) * R;
            for (const b of g.balls) {
                if (b.dead || b.hoopCd > 0) continue;
                const rr = 9 + b.r;
                if ((b.x - hx) ** 2 + (b.y - hy) ** 2 < rr * rr) { b.hoopCd = 15; dealDamage(g, b, dmg, { color: '#2ecc71' }); }
            }
        }
    }
    // Sunbeam (active beam)
    if (g.beam) {
        g.beam.t--;
        if (g.beam.t % 5 === 0) {
            for (const b of g.balls.slice()) {
                if (b.dead || b.y > p.y) continue;
                if (Math.abs(b.x - p.x) < g.beam.w / 2 + b.r) dealDamage(g, b, g.beam.dmg, { color: '#fdcb6e', noProc: Math.random() < 0.7 });
            }
        }
        if (g.beam.t <= 0) g.beam = null;
    }
}

function updateBullets(g) {
    const S = g.S, p = g.player;
    for (let i = g.bullets.length - 1; i >= 0; i--) {
        const b = g.bullets[i];
        if (b.kind === 'dyn') {
            b.x += b.vx; b.y += b.vy; b.t--;
            if (b.t <= 0) { explode(g, b.x, b.y, b.radius, b.dmg, '#ff7675'); g.bullets.splice(i, 1); }
            continue;
        }
        if (b.kind === 'boom') {
            if (b.out > 0) { b.out--; b.vx *= 0.95; b.vy *= 0.95; }
            else {
                const dx = p.x - b.x, dy = p.y - b.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
                if (d < 14) { g.bullets.splice(i, 1); continue; }
                b.vx += dx / d * 0.5; b.vy += dy / d * 0.5;
                const sp = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
                if (sp > 8) { b.vx = b.vx / sp * 8; b.vy = b.vy / sp * 8; }
            }
        }
        if (b.homing > 0) {
            if (--b.retarget <= 0 || !b.target || b.target.dead) { b.target = nearestBall(g, b.x, b.y, 260); b.retarget = 8; }
            if (b.target) {
                const spd = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
                const cur = Math.atan2(b.vy, b.vx), want = Math.atan2(b.target.y - b.y, b.target.x - b.x);
                let diff = want - cur;
                while (diff > Math.PI) diff -= TAU;
                while (diff < -Math.PI) diff += TAU;
                const na = cur + clamp(diff, -b.homing, b.homing);
                b.vx = Math.cos(na) * spd; b.vy = Math.sin(na) * spd;
            }
        }
        b.x += b.vx; b.y += b.vy; b.life--;
        if (b.bounce > 0) {
            if (b.x < 0 || b.x > W) { b.vx *= -1; b.x = clamp(b.x, 0, W); b.bounce--; }
            if (b.kind === 'tumble' && (b.y < 0 || b.y > H) && b.bounce > 0) { b.vy *= -1; b.y = clamp(b.y, 0, H); b.bounce--; }
        }
        if (b.life <= 0 || b.x < -20 || b.x > W + 20 || b.y < -20 || b.y > H + 20) { g.bullets.splice(i, 1); continue; }
        if ((b.kind === 'tumble' || b.kind === 'boom') && g.frames % 20 === 0) b.hits.clear();
        let dead = false;
        for (const ball of g.balls) {
            if (ball.dead || b.hits.has(ball.id)) continue;
            const rr = ball.r + b.r;
            const dx = ball.x - b.x, dy = ball.y - b.y;
            if (dx * dx + dy * dy < rr * rr) {
                b.hits.add(ball.id);
                dealDamage(g, ball, b.dmg, { burn: b.burn, color: b.kind === 'chili' ? '#ff7f50' : undefined });
                if (b.canSplit && S.splitChance > 0 && Math.random() < S.splitChance && g.bullets.length < 400) {
                    const a = Math.atan2(b.vy, b.vx), spd = Math.hypot(b.vx, b.vy);
                    for (const s of [-0.5, 0.5]) {
                        const c = shoot(g, b.x, b.y, a + s, spd, b.dmg * 0.5, { color: b.color, r: 2, pierce: 0, life: 50, canSplit: false });
                        c.hits = new Set(b.hits);
                    }
                }
                b.pierce--;
                if (b.pierce < 0) { dead = true; break; }
            }
        }
        if (dead) g.bullets.splice(i, 1);
    }
    // enemy bullets
    for (let i = g.ebullets.length - 1; i >= 0; i--) {
        const e = g.ebullets[i];
        e.x += e.vx * (g.timeSlow > 0 ? 0.4 : 1); e.y += e.vy * (g.timeSlow > 0 ? 0.4 : 1);
        if (e.x < -20 || e.x > W + 20 || e.y < -20 || e.y > H + 20) { g.ebullets.splice(i, 1); continue; }
        const rr = e.r + p.r;
        if ((e.x - p.x) ** 2 + (e.y - p.y) ** 2 < rr * rr) {
            g.ebullets.splice(i, 1);
            hurtPlayer(g, e.dmg, null);
            if (mode !== 'play') return;
        }
    }
}

// =====================================================================
//  MAIN UPDATE
// =====================================================================
function computeDyn(g) {
    const S = g.S, p = g.player, low = p.hp / S.maxHp;
    const d = { dmg: 1, fireRate: 1, speed: 1, invuln: false };
    if (S.lowHpDmg && low < 0.3) d.dmg *= 1 + S.lowHpDmg;
    if (S.adrenaline && low < 0.5) d.fireRate *= 1.25;
    if (S.comboMaster) d.dmg *= 1 + Math.min(0.3, g.combo * 0.02);
    if (S.midas) d.dmg *= 1 + Math.min(0.5, g.goldTotal / 25 * 0.01);
    if (g.buff) {
        if (g.buff.type === 'Fury') d.dmg *= 2;
        if (g.buff.type === 'Haste') d.speed *= 1.5;
        if (g.buff.type === 'Rapid') d.fireRate *= 2;
        if (g.buff.type === 'Holy') d.invuln = true;
    }
    g.dyn = d;
}

const EVENTS = {
    swarm:     { name: 'FIESTA SWARM!',   col: '#ff9ff3' },
    pinata:    { name: 'PIÑATA RAIN!',    col: '#feca57' },
    stampede:  { name: 'BIG BALL STAMPEDE!', col: '#ff7675' },
};
function startEvent() {
    const t = pick(['swarm', 'pinata', 'stampede']);
    g.event = { type: t, t: 480, max: 480, name: EVENTS[t].name, col: EVENTS[t].col };
    toast(EVENTS[t].name, 'Random event!', EVENTS[t].col, 150);
    sfx('boss');
}
function updateEvent() {
    const e = g.event;
    if (!e) return;
    const cap = g.balls.length < 140;
    const m = g.frames / 3600;
    if (e.type === 'swarm' && e.t % 16 === 0 && cap) spawnBall(Math.random() < 0.5 ? 'fast' : 'basic');
    else if (e.type === 'pinata' && e.t % 20 === 0 && cap) spawnBall('golden');
    else if (e.type === 'stampede' && e.t === e.max - 1) for (let i = 0; i < 3; i++) { const b = spawnBall('big', 60 + i * 120, -30 - (i % 2) * 40); b.hp = b.maxHp = b.maxHp * 0.7; }
    if (--e.t <= 0) g.event = null;
}

function updateShoot() {
    const S = g.S, p = g.player;
    g.frames++;
    const m = g.camp ? g.camp.m : g.frames / 3600;
    computeDyn(g);

    // --- movement ---
    const spd = S.speed * g.dyn.speed;
    let mx = 0, my = 0;
    if (keys.left) mx--; if (keys.right) mx++; if (keys.up) my--; if (keys.down) my++;
    if (p.dash > 0) {
        p.x += p.dashVx; p.y += p.dashVy; p.dash--;
        if (g.frames % 2 === 0) g.fx.push({ kind: 'ghost', x: p.x, y: p.y, t: 12, max: 12, facing: p.facing });
    } else if (mx || my) {
        const l = Math.hypot(mx, my);
        p.vx = mx / l * spd; p.vy = my / l * spd;
        p.x += p.vx; p.y += p.vy;
    } else if (drag) {
        const dx = drag.tx - p.x, dy = drag.ty - p.y, d = Math.hypot(dx, dy);
        const s = Math.min(d, spd * 1.7);
        if (d > 0.5) { p.vx = dx / d * s; p.vy = dy / d * s; p.x += p.vx; p.y += p.vy; } else { p.vx = p.vy = 0; }
    } else { p.vx *= 0.8; p.vy *= 0.8; }
    p.x = clamp(p.x, 14, W - 14);
    p.y = clamp(p.y, 80, H - 40);
    const mv = Math.hypot(p.vx, p.vy);
    if (mv > 0.4) g.lastDir = { x: p.vx / mv, y: p.vy / mv };
    if (Math.abs(p.vx) > 0.3) p.facing = Math.sign(p.vx);

    // --- cosmetic trail ---
    const tr = save.cos.eq.trail;
    if (tr && PARTM() > 0 && g.frames % Math.max(1, Math.round(3 / PARTM())) === 0 && g.fx.length < 280) {
        const tx = p.x + rand(-10, 10), ty = p.y + 22;
        if (tr === 1) g.fx.push({ kind: 'p', x: tx, y: ty, vx: rand(-0.3, 0.3), vy: rand(0.3, 1), color: pick(['#ffffff', '#fff3a0', '#aef']), t: 24, max: 24, sz: rand(1.5, 3) });
        else if (tr === 2) g.fx.push({ kind: 'p', x: tx, y: ty, vx: rand(-0.4, 0.4), vy: rand(0.8, 1.8), color: pick(['#ff7a1a', '#ffb142', '#ffe066']), t: 22, max: 22, sz: rand(3, 5) });
        else if (tr === 3) g.fx.push({ kind: 'p', x: tx, y: ty, vx: rand(-1, 1), vy: rand(0.2, 1.2), color: pick(CONF), t: 34, max: 34, sz: rand(2, 3.5), grav: 0.04, rect: true });
        else if (tr === 4) g.fx.push({ kind: 'p', x: tx, y: ty, vx: rand(-0.4, 0.4), vy: rand(0.4, 1), color: '#ff6b81', t: 36, max: 36, sz: rand(8, 12), ch: '♥' });
    }

    // --- timers ---
    if (p.iframes > 0) p.iframes--;
    if (S.regen > 0) p.hp = Math.min(S.maxHp, p.hp + S.regen / 60);
    if (S.maxShield > 0 && g.shield < S.maxShield) { if (++g.shieldT >= 900) { g.shield++; g.shieldT = 0; } }
    if (g.comboT > 0) { if (--g.comboT <= 0) g.combo = 0; }
    if (g.timeSlow > 0) g.timeSlow--;
    if (g.dust > 0) g.dust--;
    if (g.buff && --g.buff.t <= 0) g.buff = null;
    if (g.hurtFlash > 0) g.hurtFlash--;
    if (g.bombFlash > 0) g.bombFlash--;
    if (g.levelFlash > 0) g.levelFlash--;
    if (g.shake > 0) g.shake--;
    if (g.streak && --g.streak.t <= 0) g.streak = null;
    if (g.warn > 0) g.warn--;
    for (const id in g.actives) if (g.actives[id].cd > 0) g.actives[id].cd--;
    for (const h of g.hooks.tick) h(g);

    // --- biome / achievements ---
    const bi = g.camp ? g.biome : biomeIdx(g.frames);
    if (bi !== g.biome) { g.biome = bi; toast(BIOMES[bi].name, 'New altitude reached!', '#ffd32a', 160); confetti(g, p.x, p.y, 20); }
    if (g.frames % 30 === 0) checkAchievements();

    // --- spawning ---
    if (g.camp) campShootSpawn(m);
    else {
    if (--g.spawnT <= 0) {
        if (g.balls.length < 140) spawnBall(randomBallType(m));
        g.spawnT = Math.max(9, 52 - m * 7) * rand(0.7, 1.3) * 2 / g.D.spawn;   // half as many enemies
    }
    if (g.frames >= g.nextElite) { spawnBall('elite'); g.nextElite += 45 * 60; toast('Elite ball incoming!', '', '#8e44ad', 100); }
    if (g.frames >= g.nextBoss - 180 && !g.bossWarned) { g.bossWarned = true; g.warn = 180; sfx('boss'); }
    if (g.frames >= g.nextBoss) {
        g.nextBoss += 180 * 60; g.bossWarned = false;
        if (!g.balls.some(b => b.boss && !b.dead)) {
            g.bossN++;
            if (g.bossN % 2 === 1) { spawnBall('boss'); toast('BOSS: El Gran Globo', 'Pop it for treasure!', '#ff4757', 200); }
            else { spawnBall('boss2'); toast('BOSS: El Sombrero Gigante', 'Watch the spread shots!', '#74b9ff', 200); }
        }
    }
    if (g.frames >= g.nextEvent && !g.event && !g.balls.some(b => b.boss && !b.dead)) { startEvent(); g.nextEvent = g.frames + randi(70, 100) * 60; }
    updateEvent();

    }
    // --- weapons & bullets ---
    updateWeapons(g);
    updateBullets(g);
    if (mode !== 'play') return;

    // --- matador cape: a sweeping swing that reflects balls and bullets, ¡Olé! gold ---
    if (g.cape) {
        const C = g.cape, R = 66 + 10 * C.rank, ox = p.x, oy = p.y - 20, half = 0.62;
        C.t--; p.iframes = Math.max(p.iframes, 2);
        const prev = C.ang, u = 1 - C.t / C.max;
        C.ang = -Math.PI / 2 + 1.45 * Math.cos(u * TAU);   // right -> left -> right
        const dir = Math.sign(C.ang - prev) || 1;
        C.hist.push(C.ang); if (C.hist.length > 9) C.hist.shift();
        const inArc = (x, y, r) => {
            const dx = x - ox, dy = y - oy, d = Math.hypot(dx, dy);
            if (d > R + r) return false;
            let df = Math.atan2(dy, dx) - C.ang; while (df > Math.PI) df -= TAU; while (df < -Math.PI) df += TAU;
            return Math.abs(df) < half + r / Math.max(d, 22);
        };
        for (const b of g.balls) {
            if (b.dead || b.capeCd > 0 || !inArc(b.x, b.y, b.r)) continue;
            b.capeCd = 22; C.hits++; g.capeHits++;
            if (!b.boss) { b.vy = -5.5; b.vx = clamp(dir * 4.5, -5, 5); }
            dealDamage(g, b, 16.5 * (1 + 0.5 * (C.rank - 1)), { noProc: true, noCrit: true, color: '#ff4757' });
            gainGold(g, 2); g.combo++; g.comboT = Math.round(60 + S.comboTime); if (g.combo > g.maxCombo) g.maxCombo = g.combo;
            addText(g, b.x, b.y - b.r - 10, '¡OLÉ!', '#ff4757', 13);
            burst(g, b.x, b.y, '#ff4757', 6); addRing(g, b.x, b.y, 22, '#ff4757', 10); sfx('shield');
        }
        for (let i = g.ebullets.length - 1; i >= 0; i--) {
            const e = g.ebullets[i];
            if (inArc(e.x, e.y, e.r)) {
                g.ebullets.splice(i, 1); C.hits++; g.capeHits++;
                shoot(g, e.x, e.y, Math.atan2(-1, dir * 0.6), 6, 13.5, { color: '#ff4757', r: 3.5, pierce: 2, canSplit: false });
                addText(g, e.x, e.y - 8, '¡OLÉ!', '#ff4757', 12); addRing(g, e.x, e.y, 16, '#ff4757', 10);
            }
        }
        if (C.t <= 0) {
            if (C.hits >= 3) { const bonus = C.hits * 3; gainGold(g, bonus); toast('¡OLÉ!', C.hits + ' deflects  +' + bonus + ' gold', '#ff4757', 110); if (AC && OPT.sfx) ole(0); }
            g.cape = null;
        }
    }

    // --- pet ---
    if (g.pet) {
        const pt = g.pet;
        pt.ang += 0.04;
        const tx = p.x + Math.cos(pt.ang) * 34, ty = p.y - 30 + Math.sin(pt.ang * 2) * 10;
        pt.x += (tx - pt.x) * 0.12; pt.y += (ty - pt.y) * 0.12;
        if (--pt.cd <= 0) {
            const tg = nearestBall(g, pt.x, pt.y, 320);
            if (tg) {
                const a = Math.atan2(tg.y - pt.y, tg.x - pt.x);
                shoot(g, pt.x, pt.y, a, 6, 7 * (1 + 0.6 * (pt.rank - 1)), { pierce: 0, r: 2.5, color: '#ff9f43', homing: 0.08, life: 120, canSplit: false });
                pt.cd = 42 - 7 * pt.rank;
            } else pt.cd = 15;
        }
    }

    // --- balls ---
    const bsm = S.ballSpeedMult * (g.timeSlow > 0 ? 0.3 : 1) * (g.dust > 0 ? 0.5 : 1);
    for (const b of g.balls) {
        if (b.dead) continue;
        b.age++;
        if (b.hoopCd > 0) b.hoopCd--;
        if (b.capeCd > 0) b.capeCd--;
        if (b.flash > 0) b.flash--;
        let sm = bsm;
        if (b.slowT > 0) { b.slowT--; sm *= 0.5; }
        if (b.burnT > 0) {
            b.burnT--;
            if (b.burnT % 20 === 0) { dealDamage(g, b, b.burnDps / 3, { noProc: true, noCrit: true, color: '#e67e22' }); if (b.dead) continue; }
            if (b.burnT === 0) b.burnDps = 0;
        }
        if (b.type === 'gran') updateGran(b, sm);
        else if (b.boss) {
            b.x += b.vx * sm;
            if (b.y < 120) b.y += 0.6;
            if (b.x < b.r || b.x > W - b.r) { b.vx *= -1; b.x = clamp(b.x, b.r, W - b.r); }
            if (--b.spawnT <= 0) { b.spawnT = 100; spawnBall(Math.random() < 0.5 ? 'fast' : 'basic', b.x, b.y + b.r); }
            if (b.type === 'boss2' && --b.atkT <= 0 && b.y > 60) {
                b.atkT = 95;
                const base = Math.atan2(p.y - b.y, p.x - b.x);
                for (let k = -2; k <= 2; k++) g.ebullets.push({ x: b.x, y: b.y + b.r * 0.5, vx: Math.cos(base + k * 0.28) * 2.3, vy: Math.sin(base + k * 0.28) * 2.3, r: 4.5, dmg: 12 });
                sfx('ebullet');
            }
        } else {
            if (b.type === 'pistolero') {
                if (b.y > 150 && b.age < 1500) b.baseVy = 0.04;
                else if (b.age >= 1500) b.baseVy = 1.6;
                if (b.y > 20 && --b.shootT <= 0) {
                    b.shootT = 105;
                    const a = Math.atan2(p.y - b.y, p.x - b.x);
                    g.ebullets.push({ x: b.x, y: b.y, vx: Math.cos(a) * 2.4, vy: Math.sin(a) * 2.4, r: 4, dmg: 9 });
                    sfx('ebullet');
                }
                b.x += Math.sin((g.frames + b.phase) * 0.03) * 0.8 * sm;
            } else if (b.type === 'dive') {
                b.vx = clamp(b.vx + clamp((p.x - b.x) * 0.002, -0.05, 0.05), -2.2, 2.2);
            } else if (b.type === 'mender') {   // pulses healing into hurt neighbours every 2 s
                if (b.y > 10 && --b.shootT <= 0) {
                    b.shootT = 120;
                    for (const o of g.balls) {
                        if (o === b || o.dead || o.hp >= o.maxHp) continue;
                        const ddx = o.x - b.x, ddy = o.y - b.y;
                        if (ddx * ddx + ddy * ddy < 12100) { o.hp = Math.min(o.maxHp, o.hp + o.maxHp * 0.12); addText(g, o.x, o.y - o.r - 6, '+', '#55efc4', 11); }
                    }
                    addRing(g, b.x, b.y, 110, '#55efc4', 18);
                }
            } else if (b.type === 'fast') {   // jinks: sudden sideways bursts, so it is hard to line up
                if (b.jinkT === undefined) b.jinkT = 40 + randi(0, 40);
                if (b.y > 10 && --b.jinkT <= 0) { b.jinkT = 55 + randi(0, 45); b.vx = (Math.random() < 0.5 ? -1 : 1) * rand(2.2, 3.2); }
                b.vx *= 0.985;
            } else if (b.type === 'golden') {   // skittish: slips sideways away from you when you get close, so the coins have to be earned
                const dx = b.x - p.x, dy = p.y - b.y;
                if (dy > 0 && dy < 300 && Math.abs(dx) < 130) b.vx = clamp(b.vx + Math.sign(dx || (b.phase > 3 ? 1 : -1)) * 0.14, -3, 3);
                else b.vx *= 0.99;
            } else if (b.type === 'big') {   // stomps: stops, winds up, then slams the ground with a shockwave that hurts if you are close
                if (b._stomp === undefined && b.y > 190) { b._stomp = 50; b.baseVy = 0.05; }
                if (b._stomp > 0 && --b._stomp === 0) {
                    addRing(g, b.x, b.y, 130, '#e17055', 22); sfx('boom'); b.baseVy = BTYPES.big.vy * 1.4; b.vy = 2.2;
                    if ((p.x - b.x) ** 2 + (p.y - b.y) ** 2 < (130 + p.r) ** 2) { hurtPlayer(g, 9, b); if (mode !== 'play') return; }
                }
            } else if (b.type === 'elite') {   // fires a fan of three aimed shots
                if (b.y > 20 && --b.shootT <= 0) {
                    b.shootT = 150;
                    const a = Math.atan2(p.y - b.y, p.x - b.x);
                    for (let k = -1; k <= 1; k++) g.ebullets.push({ x: b.x, y: b.y + b.r * 0.4, vx: Math.cos(a + k * 0.3) * 2.1, vy: Math.sin(a + k * 0.3) * 2.1, r: 4.5, dmg: 8 });
                    sfx('ebullet');
                }
            }
            const rm = b.boss ? null : ROAMERS[b.type];
            if (rm) {
                if (b._v0 === undefined) { b._v0 = b.baseVy; b.off = rand(-90, 90); }
                const tx = p.x + b.off + Math.sin((g.frames + b.phase) * 0.02) * 40, ty = p.y, dx = tx - b.x, dy = ty - b.y, d = Math.hypot(dx, dy) || 1, sp = rm[0];
                if (b.y < p.y - 20 && b.y > 5) {   // above you: swing onto your line and press down on you
                    b.vx += (dx / d * sp - b.vx) * 0.03 * (0.3 + rm[1]);
                    b.baseVy = Math.max(b._v0, dy / d * sp);
                } else if (b.y >= p.y - 20) b.baseVy = Math.max(b._v0, 0.9);   // past you: carry on off the bottom, never back up
            }
            b.vy += (b.baseVy - b.vy) * 0.04;
            b.x += b.vx * sm;
            if (b.type === 'zig') b.x += Math.sin((g.frames + b.phase) * 0.05) * 1.4 * sm;
            b.y += b.vy * sm;
            if (b.x < b.r) { b.x = b.r; b.vx = Math.abs(b.vx); }
            if (b.x > W - b.r) { b.x = W - b.r; b.vx = -Math.abs(b.vx); }
            if (b.y > H + b.r + 10) b.gone = true;
        }
        const rr = b.r + p.r;
        if ((b.x - p.x) ** 2 + (b.y - p.y) ** 2 < rr * rr) {
            hurtPlayer(g, b.dmg, b);
            if (mode !== 'play') return;
        }
    }
    compactBalls(g);

    // --- pickups ---
    for (let i = g.pickups.length - 1; i >= 0; i--) {
        const k = g.pickups[i];
        k.t++;
        const dx = p.x - k.x, dy = p.y - k.y, d = Math.sqrt(dx * dx + dy * dy);
        if (k.vac || d < S.magnet) {
            const s = k.vac ? 9 : 6;
            k.x += dx / (d || 1) * s; k.y += dy / (d || 1) * s;
        } else {
            k.vx *= 0.95; k.vy = Math.min(1.1, k.vy + 0.05);
            k.x += k.vx; k.y += k.vy;
        }
        if (d < p.r + 10) {
            if (k.type === 'xp') gainXp(g, k.value);
            else if (k.type === 'gold') { gainGold(g, k.value); sfx('coin'); }
            else if (k.type === 'heart') heal(g, 20 * S.heartHeal);
            else if (k.type === 'chest') grantRandomRelic(g, 'Chest:');
            else if (k.type.startsWith('power:')) applyPowerup(k.type.slice(6));
            g.pickups.splice(i, 1);
            if (mode !== 'play') return;
            continue;
        }
        if (k.y > H + 20) g.pickups.splice(i, 1);
    }

    // --- fx ---
    for (let i = g.fx.length - 1; i >= 0; i--) {
        const f = g.fx[i];
        if (f.kind === 'p') { f.x += f.vx; f.y += f.vy; const dr = f.grav ? 0.985 : 0.94; f.vx *= dr; f.vy = f.vy * dr + (f.grav || 0); }
        else if (f.kind === 'hat') { f.x += f.vx; f.y += f.vy; f.vy += 0.22; f.rot += f.vr; }
        if (--f.t <= 0) g.fx.splice(i, 1);
    }
    for (let i = g.texts.length - 1; i >= 0; i--) { const t = g.texts[i]; t.y -= 0.6; if (--t.t <= 0) g.texts.splice(i, 1); }
    for (let i = g.bolts.length - 1; i >= 0; i--) if (--g.bolts[i].t <= 0) g.bolts.splice(i, 1);
    for (let i = g.toasts.length - 1; i >= 0; i--) if (--g.toasts[i].t <= 0) g.toasts.splice(i, 1);
}

function updateScenery(speed, f) {
    for (const c of clouds) {
        c.y += c.s * speed * c.z;
        if (c.y > H + 60) { c.y = -60; c.x = rand(-60, W + 20); c.w = rand(50, 130); }
    }
    for (const s of starsBg) { s.y += s.s * speed * 0.15; if (s.y > H) { s.y = 0; s.x = rand(0, W); } }
    for (const m of motes) { m.y -= m.s * 0.6; m.x += Math.sin((menuT + m.r * 50) * 0.02) * 0.2; if (m.y < -10) { m.y = H + 10; m.x = rand(0, W); } }
    if (OPT.gfx >= 2) {
        if (f > 9000 && f < 16200 && lightning.t <= 0 && Math.random() < 0.006) {
            lightning.t = 14;
            let x = rand(40, W - 40), y = 0; lightning.pts = [[x, y]];
            while (y < H * 0.7) { x += rand(-22, 22); y += rand(24, 44); lightning.pts.push([x, y]); }
            if (mode === 'play') sfx('thunder');
        }
        if (f > 16200 && Math.random() < 0.012 && shooters.length < 3) shooters.push({ x: rand(60, W + 60), y: rand(0, H * 0.4), vx: -rand(5, 8), vy: rand(3, 5), t: 26 });
    }
    if (lightning.t > 0) lightning.t--;
    for (let i = shooters.length - 1; i >= 0; i--) { const s = shooters[i]; s.x += s.vx; s.y += s.vy; if (--s.t <= 0) shooters.splice(i, 1); }
}

function step() {
    menuT++;
    if (mode === 'play') {
        if (g.intro > 0) g.intro--;
        else if (g.hitstop > 0) { g.hitstop--; g.shake = Math.max(g.shake, 0); }
        else updateGame();
        updateScenery(1.6, g.camp ? skyFrame() : g.frames);
    }
    else if (mode === 'cutscene' && cs) { cs.t++; updateScenery(2.2, 0); try { csSfx(); } catch (e) {} }
    else if (g && (mode === 'levelup' || mode === 'pause' || mode === 'over' || (mode === 'options' && optsReturn === 'pause'))) {
        if (mode === 'levelup') for (let i = g.toasts.length - 1; i >= 0; i--) if (--g.toasts[i].t <= 0) g.toasts.splice(i, 1);
        updateScenery(0.2, g.frames);
    }
    else updateScenery(1.0, 0);
}