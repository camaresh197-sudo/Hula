
// =====================================================================
//  COSMETICS
// =====================================================================
const HAT_STYLES = [
    { brim: '#efe5cd', crown: '#f7f0de', band: '#8a1322', trim: '#c9a24a' },
    { brim: '#262626', crown: '#3a3a3a', band: '#bdc3c7', trim: '#ecf0f1' },
    { brim: '#b5281c', crown: '#e74c3c', band: '#f1c40f', trim: '#ffffff' },
    { brim: '#e2e2e2', crown: '#ffffff', band: '#27ae60', trim: '#e74c3c' },
    { brim: '#d4a017', crown: '#ffe066', band: '#8e44ad', trim: '#ffffff' },
    { rainbow: true },
];
const COS = {
    hat: [{ name: 'Classic', cost: 0 }, { name: 'Charro', cost: 150 }, { name: 'Fiesta', cost: 200 }, { name: 'Blanco', cost: 250 }, { name: 'Golden', cost: 600 }, { name: 'Rainbow', cost: 900 }],
    hoop: [
        { name: 'Jade', cost: 0, c: ['#1e8449', '#2ecc71', '#f1c40f'] }, { name: 'Pink', cost: 120, c: ['#ad1457', '#ff4fa3', '#ffe0f0'] },
        { name: 'Ember', cost: 180, c: ['#b33a00', '#ff7a1a', '#ffe066'] }, { name: 'Frost', cost: 180, c: ['#1b6ca8', '#74d7ff', '#ffffff'] },
        { name: 'Prism', cost: 500, c: null },
    ],
    trail: [{ name: 'None', cost: 0 }, { name: 'Sparkle', cost: 100 }, { name: 'Flame', cost: 200 }, { name: 'Confetti', cost: 300 }, { name: 'Hearts', cost: 400 }],
};
function hoopColors() {
    const d = COS.hoop[save.cos.eq.hoop];
    if (d && d.c) return d.c;
    const h = (Math.floor(menuT * 1.5 / 15) * 15) % 360;
    return [hsl2hex(h, 70, 35), hsl2hex(h, 85, 55), hsl2hex((h + 60) % 360, 90, 75)];
}

// =====================================================================
//  DATA: WEAPONS
// =====================================================================
const WEAPONS = {
    revolver:   { name: 'Revolver',        color: '#ffe066' },
    buckshot:   { name: 'Buckshot',        color: '#ffb142' },
    hoops:      { name: 'Orbiting Hoops',  color: '#2ecc71' },
    lasso:      { name: 'Lasso Whip',      color: '#d4a373' },
    chili:      { name: 'Homing Chilis',   color: '#e74c3c' },
    thunder:    { name: 'Thunder Call',    color: '#74b9ff' },
    cactus:     { name: 'Cactus Nova',     color: '#27ae60' },
    dynamite:   { name: 'Dynamite',        color: '#ff7675' },
    sunbeam:    { name: 'Sunbeam',         color: '#fdcb6e' },
    tumbleweed: { name: 'Tumbleweed',      color: '#c8a165' },
    trumpet:    { name: 'Mariachi Trumpet',color: '#f9ca24' },
    boomerang:  { name: 'Chorizo Boomerang', color: '#e17055' },
    skulls:     { name: 'Calavera Spirits', color: '#dfe6e9' },
};
const MAX_WEAPON_LVL = 8;

// =====================================================================
//  DATA: ATTACK POWERS
// =====================================================================
function unlockWeapon(g, id) { if (!g.weapons[id]) g.weapons[id] = { lvl: 1, cd: 30 }; }
function levelWeapon(g, id) { const w = g.weapons[id]; if (w) w.lvl = Math.min(MAX_WEAPON_LVL, w.lvl + 1); }
const owns = id => g => !!g.weapons[id];
const canLevel = id => g => !!g.weapons[id] && g.weapons[id].lvl < MAX_WEAPON_LVL;
const lacks = id => g => !g.weapons[id];

function P(id, name, rarity, desc, apply, opt = {}) {
    return { id, name, rarity, desc, apply, max: opt.max || 1, req: opt.req || (() => true), weapon: opt.weapon || null, unlock: !!opt.unlock };
}

const POWERS = [
    // --- new weapons ---
    P('w_buckshot',   'Buckshot',        'rare', 'NEW WEAPON: blasts a short-range fan of pellets.',              g => unlockWeapon(g, 'buckshot'),   { req: lacks('buckshot'), unlock: true }),
    P('w_hoops',      'Orbiting Hoops',  'rare', 'NEW WEAPON: spare hula hoops circle you and smack balls.',      g => unlockWeapon(g, 'hoops'),      { req: lacks('hoops'), unlock: true }),
    P('w_lasso',      'Lasso Whip',      'rare', 'NEW WEAPON: a spinning lasso lashes everything nearby.',         g => unlockWeapon(g, 'lasso'),      { req: lacks('lasso'), unlock: true }),
    P('w_chili',      'Homing Chilis',   'rare', 'NEW WEAPON: fiery chilis seek targets and set them ablaze.',     g => unlockWeapon(g, 'chili'),      { req: lacks('chili'), unlock: true }),
    P('w_thunder',    'Thunder Call',    'rare', 'NEW WEAPON: lightning strikes random balls.',                    g => unlockWeapon(g, 'thunder'),    { req: lacks('thunder'), unlock: true }),
    P('w_cactus',     'Cactus Nova',     'rare', 'NEW WEAPON: bursts of cactus needles in every direction.',      g => unlockWeapon(g, 'cactus'),     { req: lacks('cactus'), unlock: true }),
    P('w_dynamite',   'Dynamite',        'rare', 'NEW WEAPON: tosses dynamite that explodes on arrival.',          g => unlockWeapon(g, 'dynamite'),   { req: lacks('dynamite'), unlock: true }),
    P('w_sunbeam',    'Sunbeam',         'epic', 'NEW WEAPON: fires a scorching beam straight up.',                g => unlockWeapon(g, 'sunbeam'),    { req: lacks('sunbeam'), unlock: true }),
    P('w_tumbleweed', 'Tumbleweed',      'rare', 'NEW WEAPON: bouncing tumbleweeds roll through balls.',           g => unlockWeapon(g, 'tumbleweed'), { req: lacks('tumbleweed'), unlock: true }),
    P('w_trumpet',    'Mariachi Trumpet','rare', 'NEW WEAPON: a brass blast cone that damages and shoves balls up.', g => unlockWeapon(g, 'trumpet'),   { req: lacks('trumpet'), unlock: true }),
    P('w_boomerang',  'Chorizo Boomerang','rare','NEW WEAPON: a spicy sausage that flies out and comes back.',      g => unlockWeapon(g, 'boomerang'),  { req: lacks('boomerang'), unlock: true }),
    P('w_skulls',     'Calavera Spirits','rare', 'NEW WEAPON: ghostly skulls drift out and haunt the nearest balls.', g => unlockWeapon(g, 'skulls'), { req: lacks('skulls'), unlock: true }),
    // --- weapon upgrades ---
    P('u_revolver',   'Fan the Hammer',  'common', 'Revolver +1 level: more damage, +1 bullet every 3 levels.', g => levelWeapon(g, 'revolver'),   { req: canLevel('revolver'), max: 7, weapon: 'revolver' }),
    P('u_buckshot',   'Double Barrel',   'common', 'Buckshot +1 level: more pellets and damage.',                g => levelWeapon(g, 'buckshot'),   { req: canLevel('buckshot'), max: 7, weapon: 'buckshot' }),
    P('u_hoops',      'Hoop Dreams',     'common', 'Orbiting Hoops +1 level: another hoop and more damage.',    g => levelWeapon(g, 'hoops'),      { req: canLevel('hoops'), max: 7, weapon: 'hoops' }),
    P('u_lasso',      'Longer Rope',     'common', 'Lasso Whip +1 level: bigger reach and more damage.',        g => levelWeapon(g, 'lasso'),      { req: canLevel('lasso'), max: 7, weapon: 'lasso' }),
    P('u_chili',      'Ghost Pepper',    'common', 'Homing Chilis +1 level: one more chili, more damage.',      g => levelWeapon(g, 'chili'),      { req: canLevel('chili'), max: 7, weapon: 'chili' }),
    P('u_thunder',    'Storm Chaser',    'common', 'Thunder Call +1 level: one more strike, more damage.',      g => levelWeapon(g, 'thunder'),    { req: canLevel('thunder'), max: 7, weapon: 'thunder' }),
    P('u_cactus',     'Prickly Pear',    'common', 'Cactus Nova +1 level: more needles and damage.',            g => levelWeapon(g, 'cactus'),     { req: canLevel('cactus'), max: 7, weapon: 'cactus' }),
    P('u_dynamite',   'Bigger Boom',     'common', 'Dynamite +1 level: bigger blasts, more sticks.',            g => levelWeapon(g, 'dynamite'),   { req: canLevel('dynamite'), max: 7, weapon: 'dynamite' }),
    P('u_sunbeam',    'High Noon',       'common', 'Sunbeam +1 level: wider, hotter beam.',                     g => levelWeapon(g, 'sunbeam'),    { req: canLevel('sunbeam'), max: 7, weapon: 'sunbeam' }),
    P('u_tumbleweed', 'Dust Devil',      'common', 'Tumbleweed +1 level: more bounces, more weeds.',            g => levelWeapon(g, 'tumbleweed'), { req: canLevel('tumbleweed'), max: 7, weapon: 'tumbleweed' }),
    P('u_trumpet',    'Brass Section',   'common', 'Mariachi Trumpet +1 level: wider, longer, louder blast.',   g => levelWeapon(g, 'trumpet'),    { req: canLevel('trumpet'), max: 7, weapon: 'trumpet' }),
    P('u_boomerang',  'Spicy Return',    'common', 'Chorizo Boomerang +1 level: more damage, extra sausage.',   g => levelWeapon(g, 'boomerang'),  { req: canLevel('boomerang'), max: 7, weapon: 'boomerang' }),
    P('u_skulls',     'Restless Spirits','common', 'Calavera Spirits +1 level: more skulls and damage.',         g => levelWeapon(g, 'skulls'),     { req: canLevel('skulls'), max: 7, weapon: 'skulls' }),
    // --- combat modifiers ---
    P('sharp',     'Sharpened Rounds', 'common', 'All damage +15%.',                                  g => { g.S.dmg *= 1.15; }, { max: 5 }),
    P('quick',     'Quick Draw',       'common', 'Gun fire rate +12%.',                               g => { g.S.fireRate *= 1.12; }, { max: 5 }),
    P('hotlead',   'Hot Lead',         'common', 'Projectile speed +20% and damage +5%.',             g => { g.S.projSpeed *= 1.2; g.S.dmg *= 1.05; }, { max: 3 }),
    P('chamber',   'Extra Chamber',    'epic',   'Guns fire +1 extra projectile.',                    g => { g.S.extraProj += 1; }, { max: 3 }),
    P('pierce',    'Piercing Shot',    'rare',   'Projectiles pierce +1 ball.',                       g => { g.S.pierce += 1; }, { max: 3 }),
    P('deadeye',   'Deadeye',          'common', 'Critical chance +8%.',                              g => { g.S.crit += 0.08; }, { max: 4 }),
    P('headhunt',  'Headhunter',       'rare',   'Critical damage +50%.',                             g => { g.S.critMult += 0.5; }, { max: 3 }),
    P('bigiron',   'Big Iron',         'common', 'Projectiles 25% bigger and damage +8%.',            g => { g.S.size *= 1.25; g.S.dmg *= 1.08; }, { max: 3 }),
    P('incend',    'Incendiary',       'common', '15% chance on hit to set balls on fire.',           g => { g.S.burnChance += 0.15; }, { max: 3 }),
    P('frost',     'Frost Bite',       'common', '15% chance on hit to slow balls.',                  g => { g.S.slowChance += 0.15; }, { max: 3 }),
    P('chain',     'Chain Lightning',  'rare',   '10% chance on hit to arc to a nearby ball.',        g => { g.S.chainChance += 0.10; }, { max: 3 }),
    P('boomtip',   'Explosive Tips',   'rare',   '10% chance on hit to explode.',                     g => { g.S.explodeChance += 0.10; }, { max: 3 }),
    P('splitter',  'Splitter',         'rare',   '15% chance a bullet splits in two on hit.',         g => { g.S.splitChance += 0.15; }, { max: 3 }),
    P('ricochet',  'Ricochet',         'common', 'Projectiles bounce off the side walls +1 time.',    g => { g.S.bounce += 1; }, { max: 2 }),
    P('execute',   'Executioner',      'epic',   'Instantly pop non-boss balls below 8% HP (stacks).', g => { g.S.execute = Math.min(0.24, g.S.execute + 0.08); }, { max: 3 }),
    P('giant',     'Giant Slayer',     'common', '+30% damage to big balls, elites and bosses.',      g => { g.S.bigDmg += 0.3; }, { max: 3 }),
    P('overdrive', 'Overdrive',        'rare',   'All weapon cooldowns -10%.',                        g => { g.S.cooldownMult *= 0.9; }, { max: 4 }),
    P('backfire',  'Backfire',         'common', 'Revolver also shoots straight down.',               g => { g.S.backfire = true; }),
    P('sidearms',  'Side Arms',        'rare',   'Revolver also fires two diagonal shots.',           g => { g.S.sideArms = true; }),
    P('homing',    'Homing Rounds',    'rare',   'Revolver and Buckshot bullets curve toward balls.', g => { g.S.homing += 0.04; }, { max: 2 }),
    P('hose',      'Bullet Hose',      'rare',   'Gun fire rate +30%, damage -10%.',                  g => { g.S.fireRate *= 1.3; g.S.dmg *= 0.9; }, { max: 2 }),
    P('glass',     'Glass Cannon',     'epic',   'Damage +40%, max HP -25%.',                         g => { g.S.dmg *= 1.4; changeMaxHp(g, -Math.round(g.S.maxHp * 0.25)); }),
    P('adren',     'Adrenaline',       'common', 'Below 50% HP, fire rate +25%.',                     g => { g.S.adrenaline = true; }),
    P('bleed',     'Bleeding Edge',    'rare',   'Critical hits always set balls on fire.',           g => { g.S.critBurn = true; }),
    P('static',    'Static Charge',    'rare',   'Every 10th revolver volley calls a lightning bolt.', g => { g.S.staticCharge = true; }),
    P('scatter',   'Scattergun',       'rare',   '+2 gun projectiles, wider spread, damage -15%.',    g => { g.S.extraProj += 2; g.S.spreadMult *= 1.6; g.S.dmg *= 0.85; }),
    P('combo',     'Combo Master',     'rare',   'Quick kills build combo: +2% damage each (max 30%).', g => { g.S.comboMaster = true; }),
    P('overkill',  'Overkill',         'rare',   'Excess damage on a kill splashes to a nearby ball.', g => { g.S.overkill = true; }),
    P('area',      'Area Expert',      'common', 'Area effects and orbits +25% bigger.',              g => { g.S.aoe *= 1.25; }, { max: 3 }),
    P('fuse',      'Long Fuse',        'common', 'Burn, slow and beam durations +30%.',               g => { g.S.durMult *= 1.3; }, { max: 2 }),
    P('critmass',  'Critical Mass',    'epic',   'Critical hits have a 25% chance to explode.',       g => { g.S.critExplode += 0.25; }, { max: 2 }),
];

// =====================================================================
//  DATA: RELICS (granted at random)
// =====================================================================
function R(id, name, desc, apply) { return { id, name, desc, apply }; }
const RELICS = [
    R('horseshoe', 'Lucky Horseshoe',   'Luck +20: rarer powers and more gold drops.',      g => { g.S.luck += 20; }),
    R('badge',     "Sheriff's Badge",   'Armor +3 (less damage from every hit).',           g => { g.S.armor += 3; }),
    R('fang',      'Rattlesnake Fang',  '10% chance to heal 2 HP on each kill.',            g => { g.S.healOnKill += 0.1; }),
    R('watch',     'Cracked Pocket Watch', 'Balls fall 10% slower.',                        g => { g.S.ballSpeedMult *= 0.9; }),
    R('tooth',     'Golden Tooth',      'Gold gained +30%.',                                g => { g.S.goldMult += 0.3; }),
    R('pan',       "Prospector's Pan",  'Balls drop gold 50% more often.',                  g => { g.S.goldDropMult *= 1.5; }),
    R('owl',       'Owl Feather',       'XP gained +20%.',                                  g => { g.S.xpMult *= 1.2; }),
    R('flask',     'Tequila Flask',     'Max HP +30, move speed -5%.',                      g => { changeMaxHp(g, 30); g.S.speed *= 0.95; }),
    R('spur',      'Silver Spur',       'Move speed +15%.',                                 g => { g.S.speed *= 1.15; }),
    R('pelt',      'Coyote Pelt',       'Dodge chance +8%.',                                g => { g.S.dodge += 0.08; }),
    R('totem',     'Thunderbird Totem', 'Every 5s, lightning strikes a ball for 40.',       g => { g.hooks.tick.push(g => { if (g.frames % 300 === 0) strikeRandom(g, 40); }); }),
    R('phoenix',   'Phoenix Feather',   'Revive once at 50% HP.',                           g => { g.revives.push(0.5); }),
    R('lodestone', 'Lodestone',         'Pickup magnet range +40.',                         g => { g.S.magnet += 40; }),
    R('cursed',    'Cursed Coin',       'Gold +60%, but you take 15% more damage.',         g => { g.S.goldMult += 0.6; g.S.dmgTaken *= 1.15; }),
    R('moonshine', 'Moonshine Jug',     'Damage +25%, max HP -15.',                         g => { g.S.dmg *= 1.25; changeMaxHp(g, -15); }),
    R('bandolier', 'Bandolier',         'Gun fire rate +15%.',                              g => { g.S.fireRate *= 1.15; }),
    R('nail',      'Rusty Nail',        'Balls that hit you take 30 damage.',               g => { g.S.thorns += 30; }),
    R('holywater', 'Holy Water',        'Regenerate 0.5 HP per second.',                    g => { g.S.regen += 0.5; }),
    R('poster',    'Wanted Poster',     'Balls have 20% more HP but drop double gold.',     g => { g.S.ballHpMult *= 1.2; g.S.goldDropMult *= 2; }),
    R('saguaro',   'Saguaro Heart',     'Max HP +20 and fully heal now.',                   g => { changeMaxHp(g, 20); g.player.hp = g.S.maxHp; }),
    R('tinstar',   'Tin Star Shield',   'A shield blocks one hit, recharging every 15s.',   g => { g.S.maxShield += 1; g.shield += 1; }),
    R('dustjar',   'Dust Storm Jar',    'Every 20s, a dust storm slows all balls for 3s.',  g => { g.hooks.tick.push(g => { if (g.frames % 1200 === 0) { g.dust = 180; toast('Dust storm!', '', '#d4a373', 90); } }); }),
    R('dice',      'Mystery Dice',      'Each level up, a random stat improves.',           g => { g.hooks.level.push(rollDice); }),
    R('necklace',  'Chili Necklace',    'Burn chance +15% and burns deal +50%.',            g => { g.S.burnChance += 0.15; g.S.burnMult *= 1.5; }),
    R('globe',     'Mountain Snow Globe', 'Slow chance +15%.',                              g => { g.S.slowChance += 0.15; }),
    R('hourglass', 'Hourglass of Sand', 'Active skill cooldowns -20%.',                     g => { g.S.skillCd *= 0.8; }),
    R('ace',       "Gambler's Ace",     'Crit chance +10% and crit damage +25%.',           g => { g.S.crit += 0.1; g.S.critMult += 0.25; }),
    R('compass',   'Broken Compass',    'Guns fire +2 projectiles, but aim wobbles.',       g => { g.S.extraProj += 2; g.S.jitter += 0.22; }),
    R('vulture',   'Vulture Skull',     'Kills have a 3% chance to drop a heart.',          g => { g.S.heartDrop += 0.03; }),
    R('map',       'Gold Nugget Map',   'Gain 20 gold every level up.',                     g => { g.hooks.level.push(g => gainGold(g, 20)); }),
    R('bell',      'Old Mission Bell',  'When hurt, blast nearby balls away.',              g => { g.hooks.hurt.push(g => { pushAway(g, g.player.x, g.player.y, 90, 5); g.player.iframes += 20; }); }),
    R('medbag',    'Medicine Bag',      'Hearts heal twice as much.',                       g => { g.S.heartHeal *= 2; }),
    R('belt',      'Dynamite Belt',     'When hurt, explode for 60 damage around you.',     g => { g.hooks.hurt.push(g => explode(g, g.player.x, g.player.y, 80 * g.S.aoe, 60, '#ff7675')); }),
    R('wolf',      'Wolf Howl Pendant', 'Below 30% HP, damage +50%.',                       g => { g.S.lowHpDmg += 0.5; }),
    R('eagle',     'Eagle Eye Glass',   'Projectile speed +30% and crit +5%.',              g => { g.S.projSpeed *= 1.3; g.S.crit += 0.05; }),
    R('pinata',    'Piñata',            '5% of popped balls burst into 5 gold coins.',      g => { g.S.pinata = true; }),
    R('canteen',   'Bottomless Canteen', 'Heal 10 HP every level up.',                      g => { g.hooks.level.push(g => heal(g, 10)); }),
    R('lantern',   'Ghost Town Lantern', 'Invincibility after a hit lasts 50% longer.',     g => { g.S.iframes = Math.round(g.S.iframes * 1.5); }),
    R('snakeoil',  'Snake Oil',         'Every 30s, a random 10s buff: Fury, Haste, Rapid or Holy.', g => { g.hooks.tick.push(g => { if (g.frames % 1800 === 0) snakeOil(g); }); }),
    R('mirror',    'Twin Mirror',       '10% chance each gun shot is duplicated.',          g => { g.S.dupChance += 0.1; }),
    R('chime',     'Prairie Wind Chime', 'Every 10s, all pickups fly to you.',              g => { g.hooks.tick.push(g => { if (g.frames % 600 === 0) g.pickups.forEach(p => p.vac = true); }); }),
    R('horn',      'Bison Horn',        'Hits knock balls back upward.',                    g => { g.S.knock += 1.5; }),
    R('juice',     'Cactus Juice',      'Regenerate 1 HP/s, but max HP -10.',               g => { g.S.regen += 1; changeMaxHp(g, -10); }),
    R('midas',     'Midas Glove',       'Damage +1% per 25 gold earned this run (max 50%).', g => { g.S.midas = true; }),
    R('clockwork', 'Clockwork Heart',   'Gain +5 max HP every 60 seconds.',                 g => { g.hooks.tick.push(g => { if (g.frames % 3600 === 0) { changeMaxHp(g, 5); toast('Clockwork Heart', '+5 max HP', '#e056fd', 90); } }); }),
    R('bullseye',  'Bullseye Target',   'Your first hit on every ball is a critical.',      g => { g.S.firstHitCrit = true; }),
    R('bones',     'Rerolling Bones',   '+2 rerolls for level-up choices.',                 g => { g.rerolls += 2; }),
    R('blackcat',  'Black Cat Tail',    'Each level up: 50% a free relic, 50% lose 5 max HP.', g => { g.hooks.level.push(g => { if (Math.random() < 0.5) grantRandomRelic(g, 'Black Cat: lucky!'); else { changeMaxHp(g, -5); toast('Black Cat: unlucky', '-5 max HP', '#636e72', 120); } }); }),
    R('rod',       'Lightning Rod',     'Chain lightning chance +15%.',                     g => { g.S.chainChance += 0.15; }),
    R('comet',     'Comet Charm',       'Every 8s, a comet smashes a ball for 80 and explodes.', g => { g.hooks.tick.push(g => { if (g.frames % 480 === 0) cometStrike(g); }); }),
    // --- deluxe relics ---
    R('gsombrero', 'Golden Sombrero',   'Every 10th kill showers you with gold.',           g => { g.hooks.kill.push((g, b) => { if (g.kills % 10 === 0) for (let i = 0; i < 3; i++) dropPickup(g, 'gold', b.x + rand(-8, 8), b.y, 3); }); }),
    R('maracas',   'Maracas',           'Every 7s, a shockwave around you deals 25 damage.', g => { g.hooks.tick.push(g => { if (g.frames % 420 === 0) { explode(g, g.player.x, g.player.y, 95 * g.S.aoe, 25, '#f9ca24'); sfx('trumpet'); } }); }),
    R('churro',    'Churro Stash',      'Max HP +15 and regenerate 0.3 HP/s.',              g => { changeMaxHp(g, 15); g.S.regen += 0.3; }),
    R('neon',      'Cantina Neon Sign', 'Your combo timer lasts 1.5s longer.',              g => { g.S.comboTime += 90; }),
    R('armadillo', 'Armadillo Shell',   'Armor +2, move speed -5%.',                        g => { g.S.armor += 2; g.S.speed *= 0.95; }),
    R('cactusjuice', 'Cactus Juice',    'Regenerate 0.3 HP/s and 3% chance to heal on each kill.', g => { g.S.regen += 0.3; g.S.healOnKill += 0.03; }),
    R('gunbelt',     'Silver Gunbelt',  'Crit chance +10% and crit damage +25%.',           g => { g.S.crit += 0.1; g.S.critMult += 0.25; }),
    R('rainstick',   'Rainstick',       'Every 12s, all balls slow to a crawl for 2s.',     g => { g.hooks.tick.push(g => { if (g.frames > 0 && g.frames % 720 === 0) { g.timeSlow = Math.max(g.timeSlow, 120); toast('Rainstick!', 'Balls slow down', '#74b9ff', 70); } }); }),
    R('pinatastick', 'Piñata Stick',    'Each kill has a 3% chance to drop a power-up.',    g => { g.hooks.kill.push((g, b) => { if (Math.random() < 0.03) dropPickup(g, 'power:' + pickPowerup(), b.x, b.y, 1); }); }),
    R('luckyseven',  'Lucky Seven',     'Every 7th kill explodes for 30 damage.',           g => { g.hooks.kill.push((g, b) => { if (g.kills % 7 === 0) explode(g, b.x, b.y, 55 * g.S.aoe, 30, '#fdcb6e'); }); }),
    R('bighat',      'Big Straw Hat',   'Max HP +10 and armor +1.',                         g => { changeMaxHp(g, 10); g.S.armor += 1; }),
];

// =====================================================================
//  DATA: SKILLS (permanent, bought with gold)
// =====================================================================
const SKILLS = [
    { id: 'tough',    name: 'Toughness',     max: 5, base: 25,  desc: '+15 max HP per rank' },
    { id: 'fire',     name: 'Firepower',     max: 5, base: 30,  desc: '+8% damage per rank' },
    { id: 'trigger',  name: 'Trigger Finger',max: 5, base: 30,  desc: '+6% gun fire rate per rank' },
    { id: 'boots',    name: 'Swift Boots',   max: 3, base: 25,  desc: '+5% move speed per rank' },
    { id: 'goldrush', name: 'Gold Rush',     max: 5, base: 35,  desc: '+10% gold per rank' },
    { id: 'learner',  name: 'Fast Learner',  max: 5, base: 35,  desc: '+8% XP per rank' },
    { id: 'arms',     name: 'Long Arms',     max: 3, base: 20,  desc: '+15 pickup magnet per rank' },
    { id: 'iron',     name: 'Iron Skin',     max: 3, base: 50,  desc: '+1 armor per rank' },
    { id: 'recovery', name: 'Recovery',      max: 3, base: 45,  desc: '+0.2 HP/s regen per rank' },
    { id: 'second',   name: 'Second Wind',   max: 1, base: 200, desc: 'Revive once per run at 30% HP' },
    { id: 'reroll',   name: 'Reroll',        max: 3, base: 60,  desc: '+1 level-up reroll per run' },
    { id: 'head',     name: 'Head Start',    max: 3, base: 70,  desc: 'Start each run with +1 level' },
    { id: 'starter',  name: 'Starter Relic', max: 1, base: 150, desc: 'Start each run with a random relic' },
    { id: 'lucky',    name: 'Lucky Charm',   max: 3, base: 40,  desc: '+5 luck per rank (rarer powers)' },
    { id: 'dash',     name: 'Dash',          max: 3, base: 60,  desc: 'ACTIVE: invincible dash (ranks cut cooldown)' },
    { id: 'slow',     name: 'Siesta',        max: 3, base: 80,  desc: 'ACTIVE: slow all balls to a crawl' },
    { id: 'crit',     name: 'Critical Eye',  max: 3, base: 40,  desc: '+3% crit chance per rank' },
    { id: 'armory',   name: 'Armory',        max: 1, base: 180, desc: 'Start each run with a random extra weapon' },
    { id: 'bounty',   name: 'Bounty Hunter', max: 3, base: 50,  desc: '+50% gold from elites and bosses per rank' },
    { id: 'pet',      name: 'Buzzard Buddy', max: 3, base: 90,  desc: 'A friendly buzzard shoots foes for you' },
    { id: 'drops',    name: 'Fiesta Luck',   max: 3, base: 60,  desc: '+20% power-up drop chance per rank' },
    { id: 'cape',     name: 'Matador Cape',  max: 3, base: 80,  desc: 'ACTIVE (R): red cape reflects balls and shots. ¡Olé!' },
    { id: 'boom',     name: 'Big Boom',      max: 3, base: 55,  desc: '+8% blast and area size per rank' },
    { id: 'medic',    name: 'Medic Kit',     max: 3, base: 50,  desc: '+15% healing from hearts per rank' },
    { id: 'hands',    name: 'Quick Hands',   max: 3, base: 65,  desc: '-4% weapon cooldowns per rank' },
    { id: 'coach',    name: 'Combo Coach',   max: 3, base: 45,  desc: 'Combo timer +0.25s per rank' },
];
const skillRank = id => save.skills[id] || 0;
const skillCost = s => Math.round(s.base * Math.pow(1.7, skillRank(s.id)));

const ACTIVES = {
    dash: { name: 'Dash',   icon: '»', color: '#74b9ff', cd: r => Math.round(240 * (1 - 0.18 * (r - 1))) },
    cape: { name: 'Cape',   icon: '◆', color: '#ff4757', cd: r => Math.round(600 * (1 - 0.15 * (r - 1))) },
    slow: { name: 'Siesta', icon: '◷', color: '#a29bfe', cd: r => Math.round(1200 * (1 - 0.15 * (r - 1))) },
};

// =====================================================================
//  DATA: BALLS, POWER-UPS, BIOMES, ACHIEVEMENTS
// =====================================================================
const BTYPES = {
    basic:    { r: 11, hp: 16,   vy: 1.15, dmg: 10, xp: 1,  gold: 0.22, colors: ['#ff6b6b', '#4ecdc4', '#ffe66d', '#a29bfe', '#ff9ff3'] },
    fast:     { r: 8,  hp: 9,    vy: 2.3,  dmg: 8,  xp: 1,  gold: 0.2,  colors: ['#55efc4'] },
    zig:      { r: 10, hp: 16,   vy: 1.0,  dmg: 10, xp: 2,  gold: 0.25, colors: ['#fd79a8'] },
    big:      { r: 21, hp: 70,   vy: 0.7,  dmg: 18, xp: 5,  gold: 0.5,  colors: ['#e17055'] },
    armored:  { r: 13, hp: 40,   vy: 0.9,  dmg: 14, xp: 3,  gold: 0.35, colors: ['#95a5a6'], armored: true },
    golden:   { r: 10, hp: 24,   vy: 1.7,  dmg: 6,  xp: 3,  gold: 0,    coins: 8,   colors: ['#f1c40f'] },
    pistolero:{ r: 12, hp: 30,   vy: 0.7,  dmg: 10, xp: 4,  gold: 0.4,  colors: ['#e67e22'] },
    splitter: { r: 15, hp: 40,   vy: 0.8,  dmg: 10, xp: 3,  gold: 0.3,  colors: ['#1abc9c'] },
    dive:     { r: 9,  hp: 14,   vy: 1.9,  dmg: 12, xp: 2,  gold: 0.2,  colors: ['#ff6348'] },
    shielded: { r: 14, hp: 36,   vy: 0.8,  dmg: 12, xp: 4,  gold: 0.4,  colors: ['#54a0ff'] },
    bomber:   { r: 12, hp: 26,   vy: 1.0,  dmg: 14, xp: 3,  gold: 0.3,  colors: ['#4b4b5a'] },
    elite:    { r: 25, hp: 320,  vy: 0.5,  dmg: 25, xp: 25, gold: 0,    coins: 20,  colors: ['#8e44ad'] },
    mender:   { r: 12, hp: 28,   vy: 0.8, dmg: 8,  xp: 4,  gold: 0.35, colors: ['#00b894'] },
    pinata:   { r: 14, hp: 34,   vy: 1.1, dmg: 6,  xp: 4,  gold: 0,    coins: 10,  colors: ['#fd79a8', '#fdcb6e', '#74b9ff'] },
    boss:     { r: 42, hp: 1800, vy: 0,    dmg: 35, xp: 80, gold: 0,    coins: 100, colors: ['#c0392b'] },
    boss2:    { r: 46, hp: 2600, vy: 0,    dmg: 40, xp: 120,gold: 0,    coins: 150, colors: ['#2980b9'] },
};
const POWERUPS = {
    magnet: { c: '#48dbfb', g: 'M', name: 'Magnet!' },
    nuke:   { c: '#ff6b6b', g: '✸', name: 'Piñata Bomb!', rare: 0.25 },
    freeze: { c: '#a5d8ff', g: '*', name: 'Freeze!' },
    frenzy: { c: '#feca57', g: '»', name: 'Frenzy!' },
    shield: { c: '#ffeaa7', g: '◈', name: 'Shield!' },
    fury:   { c: '#ff6348', g: 'F', name: 'Fury!' },
    haste:  { c: '#7bed9f', g: 'H', name: 'Haste!' },
    rush:   { c: '#f9ca24', g: '$', name: 'Gold Shower!' },
};
const BIOMES = [
    { at: 0,     name: 'Desert Dawn',   top: '#3b8fd9', mid: '#8fcdf5', bot: '#ffc98a' },
    { at: 3600,  name: 'Cloud Line',    top: '#4aa3df', mid: '#bfe3fb', bot: '#eef7ff' },
    { at: 9000,  name: 'Thunderhead',   top: '#1d2233', mid: '#3d4660', bot: '#6b738c' },
    { at: 16200, name: 'Stratosphere',  top: '#0b0d26', mid: '#1c2a5c', bot: '#40337a' },
    { at: 25200, name: 'Fiesta Galaxy', top: '#12041f', mid: '#3a0f5c', bot: '#8e2a7a' },
    { at: 34200, name: 'Black Hole Boogie', top: '#020006', mid: '#14052b', bot: '#4a0d52' },
];
function biomeIdx(f) { let i = 0; for (let k = 0; k < BIOMES.length; k++) if (f >= BIOMES[k].at) i = k; return i; }
const STREAKS = { 5: 'NICE!', 10: 'PISTOLERO!', 25: 'MUY BIEN!', 50: 'LEGENDARIO!', 100: 'EL MÁXIMO!', 200: 'DIOS MÍO!', 300: 'INMORTAL!' };
const STREAK_GOLD = { 10: 2, 25: 5, 50: 12, 100: 30, 200: 60, 300: 100 };   // combo milestones now pay out

const ACHS = [
    { id: 'first',   name: 'First Blood',      desc: 'Pop your first ball',                gold: 5,   test: g => g.kills >= 1 },
    { id: 'p100',    name: 'Century',          desc: 'Pop 100 balls in one run',           gold: 20,  test: g => g.kills >= 100 },
    { id: 'p500',    name: 'Pop Star',         desc: 'Pop 500 balls in one run',           gold: 60,  test: g => g.kills >= 500 },
    { id: 'lv10',    name: 'Seasoned',         desc: 'Reach level 10',                     gold: 25,  test: g => g.level >= 10 },
    { id: 'lv20',    name: 'Legendary Rider',  desc: 'Reach level 20',                     gold: 80,  test: g => g.level >= 20 },
    { id: 't3',      name: 'Three Minute Man', desc: 'Survive for 3:00',                   gold: 30,  test: g => g.frames >= 10800 },
    { id: 't6',      name: 'Sky High',         desc: 'Survive for 6:00',                   gold: 80,  test: g => g.frames >= 21600 },
    { id: 'boss',    name: 'Globo Popper',     desc: 'Defeat a boss',                      gold: 50,  test: g => g.bossKills >= 1 },
    { id: 'combo25', name: 'On Fire',          desc: 'Reach a 25 combo',                   gold: 30,  test: g => g.maxCombo >= 25 },
    { id: 'relic5',  name: 'Collector',        desc: 'Hold 5 relics at once',              gold: 30,  test: g => g.relics.length >= 5 },
    { id: 'clean',   name: 'Untouchable',      desc: 'Go 60s without taking damage',       gold: 40,  test: g => g.frames >= 3600 && g.frames - g.lastHurt >= 3600 },
    { id: 'hatter',  name: 'Hat Trick',        desc: 'Knock off 50 sombreros in one run',  gold: 25,  test: g => g.hatsDown >= 50 },
    { id: 'pistol',  name: 'Quick Draw',       desc: 'Pop 10 Pistoleros in one run',       gold: 30,  test: g => g.pistolKills >= 10 },
    { id: 'rich',    name: 'Moneybags',        desc: 'Earn 1000 gold across all runs',     gold: 50,  test: g => save.stats.goldEarned >= 1000 },
    { id: 'ole',     name: 'Matador',          desc: 'Deflect 20 balls with the cape in one run', gold: 40, test: g => g.capeHits >= 20 },
    { id: 'lv30',    name: 'Mythic Rider',     desc: 'Reach level 30',                     gold: 120, test: g => g.level >= 30 },
    { id: 'p1500',   name: 'Globo Apocalypse', desc: 'Pop 1500 balls in one run',          gold: 120, test: g => g.kills >= 1500 },
    { id: 't10',     name: 'Marathon Rider',   desc: 'Survive for 10:00',                  gold: 150, test: g => g.frames >= 36000 },
    { id: 'combo100',name: 'Unstoppable',      desc: 'Reach a 100 combo',                  gold: 80,  test: g => g.maxCombo >= 100 },
    { id: 'relic10', name: 'Hoarder',          desc: 'Hold 10 relics at once',             gold: 80,  test: g => g.relics.length >= 10 },
    { id: 'boss3',   name: 'Boss Rush',        desc: 'Defeat 3 bosses in one run',         gold: 100, test: g => g.bossKills >= 3 },
    { id: 'nm',      name: 'Nightmare Fuel',   desc: 'Survive 3:00 on Nightmare',          gold: 150, test: g => OPT.diff === 3 && g.frames >= 10800 },
];