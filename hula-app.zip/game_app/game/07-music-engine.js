
const AHM = [9, 11, 0, 2, 4, 5, 8], BPD = [11, 0, 3, 4, 6, 7, 9];   // A harmonic minor (funeral march) and B phrygian dominant (wrath)
const DARKSTY = new Set(['unease', 'dirge', 'wrath', 'vigil', 'omen']);
// the ending's score follows the story: celebration (finale) -> unease (lanterns die) -> dirge (the toast) -> wrath (the chase and revenge) -> vigil -> omen
const SONG_UNEASE = mkSong([
    { name: 'u-A', prog: 'Am Am F E7 Am Am Dm E7', scale: AM, lo: 62, hi: 79, seed: 501, rhy: RH_MID, lead: 'gtr', fin: 3, hype: 0 },
    { name: 'u-B', prog: 'Am F Dm E7 Am F E7 E7', scale: AM, lo: 64, hi: 81, seed: 503, rhy: RH_MID, lead: 'violin', fin: 2, hype: 1 },
]);
const SONG_DIRGE = mkSong([
    { name: 'd-A', prog: 'Am Am Dm Am F E7 Am Am', scale: AHM, lo: 60, hi: 79, seed: 511, rhy: RH_MID, lead: 'horn', fin: 2, hype: 1 },
    { name: 'd-B', prog: 'Dm Am E7 Am Dm Am E7 E7', scale: AHM, lo: 62, hi: 81, seed: 513, rhy: RH_MID, lead: 'choir', fin: 1, hype: 2 },
]);
const SONG_WRATH = mkSong([
    { name: 'w-A', prog: 'Bm C Bm C Em F#7 Bm Bm', scale: BPD, lo: 62, hi: 84, seed: 521, rhy: RH_BOSS, lead: 'horn', hype: 2 },
    { name: 'w-B', prog: 'G F#7 Bm Em G F#7 Bm F#7', scale: BPD, lo: 65, hi: 88, seed: 523, rhy: RH_BOSS, lead: 'duet', hype: 3 },
]);
const SONG_VIGIL = mkSong([
    { name: 'g1', prog: 'Am F C E7 Am Dm E7 Am', scale: AM, lo: 62, hi: 77, seed: 531, rhy: RH_MID, lead: 'gtr', fin: 3, hype: 0 },
    { name: 'g2', prog: 'F C Dm Am F C E7 E7', scale: AM, lo: 64, hi: 79, seed: 533, rhy: RH_MID, lead: 'violin', fin: 2, hype: 0 },
]);
const SONG_OMEN = mkSong([
    { name: 'o-1', prog: 'Am Bb Am Bb Am Bb E7 E7', scale: APH, lo: 60, hi: 77, seed: 541, rhy: RH_MID, lead: 'choir', fin: 3, hype: 0 },
    { name: 'o-2', prog: 'Am Bb Dm Bb Am Bb E7 E7', scale: APH, lo: 62, hi: 79, seed: 543, rhy: RH_MID, lead: 'violin', fin: 2, hype: 1 },
    { name: 'o-3', prog: 'Dm Bb Am E7 Dm Bb E7 E7', scale: APH, lo: 64, hi: 81, seed: 545, rhy: RH_MID, lead: 'horn', fin: 1, hype: 2 },
]);
TRACKS.unease = { song: SONG_UNEASE, mel: null, e: 0.2, kind: 'seq', sty: 'unease' };
TRACKS.dirge = { song: SONG_DIRGE, mel: null, e: 0.24, kind: 'seq', sty: 'dirge' };
TRACKS.wrath = { song: SONG_WRATH, mel: null, e: 0.092, kind: 'seq', sty: 'wrath' };
TRACKS.vigil = { song: SONG_VIGIL, mel: null, e: 0.26, kind: 'seq', sty: 'vigil' };
TRACKS.omen = { song: SONG_OMEN, mel: null, e: 0.21, kind: 'seq', sty: 'omen' };
TRACKS.map = { song: SONG_MAP, mel: null, e: 0.15, kind: 'seq', sty: 'map' };
TRACKS.victory = { song: SONG_VICTORY, mel: null, e: 0.105, kind: 'seq', sty: 'victory' };
TRACKS.finale = { song: SONG_FINALE, mel: null, e: 0.115, kind: 'seq', sty: 'finale' };
TRACKS.race = { song: SONG_RACE, mel: null, e: 0.098, kind: 'seq', sty: 'race' };
TRACKS.rpg  = { song: SONG_RPG,  mel: null, e: 0.136, kind: 'seq', sty: 'rpg' };
TRACKS.boss = { song: SONG_BOSS, mel: null, e: 0.088, kind: 'seq', sty: 'boss' };
// ---- cutscene scores: every cutscene scene gets a song of its own (they reuse the engine's rhythm sections, but each has its own key, chords, tune and tempo) ----
const SONG_C_FIESTA = mkSong([
    { name: 'cf-A', prog: 'G C G D G C D G', scale: GM, lo: 67, hi: 86, seed: 601, rhy: RH_MID, lead: 'accord', hype: 1 },
    { name: 'cf-B', prog: 'Em C G D Em C D D', scale: GM, lo: 69, hi: 88, seed: 603, rhy: RH_FAST, lead: 'violin', hype: 1 },
]);
const SONG_C_THEFT = mkSong([
    { name: 'ct-A', prog: 'Am Bb Am E7 Am Bb Dm E7', scale: APH, lo: 60, hi: 79, seed: 611, rhy: RH_MID, lead: 'gtr', hype: 0 },
    { name: 'ct-B', prog: 'Dm Bb Am E7 Dm Bb E7 E7', scale: APH, lo: 62, hi: 81, seed: 613, rhy: RH_MID, lead: 'violin', hype: 1 },
]);
const SONG_C_FALL = mkSong([
    { name: 'cl-A', prog: 'Dm Am Bb A Dm Gm A A', scale: DM, lo: 58, hi: 77, seed: 621, rhy: RH_MID, lead: 'choir', hype: 1 },
    { name: 'cl-B', prog: 'Gm Dm A Dm Bb Gm A A', scale: DM, lo: 60, hi: 79, seed: 623, rhy: RH_MID, lead: 'horn', hype: 2 },
]);
const SONG_C_HERO = mkSong([
    { name: 'ch-A', prog: 'Dm Bb C Dm Gm Bb A Dm', scale: DM, lo: 65, hi: 88, seed: 631, rhy: RH_FAST, lead: 'trump', hype: 2 },
    { name: 'ch-B', prog: 'Bb C Dm A Bb C A A', scale: DM, lo: 67, hi: 91, seed: 633, rhy: RH_FAST, lead: 'duet', hype: 3 },
]);
const SONG_C_CLIMB = mkSong([
    { name: 'cc-A', prog: 'Em Em F Em Am Em F B7', scale: EPH, lo: 60, hi: 79, seed: 641, rhy: RH_MID, lead: 'choir', hype: 0 },
    { name: 'cc-B', prog: 'Em F Em B7 Em F Am B7', scale: EPH, lo: 64, hi: 84, seed: 643, rhy: RH_MID, lead: 'horn', hype: 1 },
    { name: 'cc-C', prog: 'C B7 Em F C B7 Em B7', scale: EPH, lo: 67, hi: 88, seed: 645, rhy: RH_BOSS, lead: 'duet', hype: 2 },
]);
const SONG_C_MISSION = mkSong([
    { name: 'cm-A', prog: 'Dm Dm Bb A Dm Gm Bb A', scale: DM, lo: 62, hi: 81, seed: 651, rhy: RH_MID, lead: 'horn', hype: 1 },
    { name: 'cm-B', prog: 'Bb A Gm A Bb C A A', scale: DM, lo: 65, hi: 84, seed: 653, rhy: RH_MID, lead: 'duet', hype: 2 },
]);
const SONG_C_PURSUIT1 = mkSong([
    { name: 'p1-A', prog: 'Am Am F G Am F E7 E7', scale: AM, lo: 69, hi: 88, seed: 661, rhy: RH_FAST, lead: 'horn', hype: 1 },
    { name: 'p1-B', prog: 'F G Am C F G E7 E7', scale: AM, lo: 72, hi: 91, seed: 663, rhy: RH_FAST, lead: 'duet', hype: 2 },
]);
const SONG_C_PURSUIT2 = mkSong([
    { name: 'p2-A', prog: 'Em F Em F Am B7 Em B7', scale: EPH, lo: 67, hi: 88, seed: 671, rhy: RH_BOSS, lead: 'trump', hype: 2 },
    { name: 'p2-B', prog: 'C B7 Em F C B7 Em Em', scale: EPH, lo: 69, hi: 91, seed: 673, rhy: RH_FAST, lead: 'duet', hype: 3 },
]);
const SONG_C_RECKON = mkSong([
    { name: 'cr-A', prog: 'Am Bb Am Bb Dm Bb E7 E7', scale: APH, lo: 60, hi: 79, seed: 681, rhy: RH_MID, lead: 'accord', hype: 1 },
    { name: 'cr-B', prog: 'Dm Am Bb Am Dm Bb E7 E7', scale: APH, lo: 62, hi: 81, seed: 683, rhy: RH_MID, lead: 'violin', hype: 2 },
]);
const SONG_C_ARMADA = mkSong([
    { name: 'ca-A', prog: 'Bm C Bm F#7 Bm C F#7 F#7', scale: BPD, lo: 60, hi: 81, seed: 691, rhy: RH_BOSS, lead: 'choir', hype: 1 },
    { name: 'ca-B', prog: 'G F#7 Bm Em G C F#7 F#7', scale: BPD, lo: 64, hi: 86, seed: 693, rhy: RH_BOSS, lead: 'horn', hype: 2 },
]);
const SONG_C_SHOWDOWN = mkSong([
    { name: 'cs-A', prog: 'Em Em F B7 Em F Am B7', scale: EPH, lo: 64, hi: 88, seed: 701, rhy: RH_BOSS, lead: 'horn', hype: 2 },
    { name: 'cs-B', prog: 'C F B7 Em C F B7 B7', scale: EPH, lo: 69, hi: 93, seed: 703, rhy: RH_BOSS, lead: 'duet', hype: 3 },
]);
TRACKS.c_fiesta = { song: SONG_C_FIESTA, mel: null, e: 0.115, kind: 'seq', sty: 'finale' };
TRACKS.c_theft = { song: SONG_C_THEFT, mel: null, e: 0.2, kind: 'seq', sty: 'unease' };
TRACKS.c_fall = { song: SONG_C_FALL, mel: null, e: 0.24, kind: 'seq', sty: 'dirge' };
TRACKS.c_hero = { song: SONG_C_HERO, mel: null, e: 0.105, kind: 'seq', sty: 'victory' };
TRACKS.c_climb = { song: SONG_C_CLIMB, mel: null, e: 0.21, kind: 'seq', sty: 'omen' };
TRACKS.c_mission = { song: SONG_C_MISSION, mel: null, e: 0.15, kind: 'seq', sty: 'map' };
TRACKS.c_pursuit1 = { song: SONG_C_PURSUIT1, mel: null, e: 0.092, kind: 'seq', sty: 'race' };
TRACKS.c_pursuit2 = { song: SONG_C_PURSUIT2, mel: null, e: 0.08, kind: 'seq', sty: 'race' };
TRACKS.c_reckon = { song: SONG_C_RECKON, mel: null, e: 0.136, kind: 'seq', sty: 'rpg' };
TRACKS.c_armada = { song: SONG_C_ARMADA, mel: null, e: 0.092, kind: 'seq', sty: 'wrath' };
TRACKS.c_showdown = { song: SONG_C_SHOWDOWN, mel: null, e: 0.084, kind: 'seq', sty: 'boss' };
const CUT_TRACKS = {   // scene index -> track, for the opening (CUT) and each act intro
    open: ['c_fiesta', 'c_theft', 'c_fall', 'c_hero', 'c_climb', 'c_mission'],
    1: ['c_pursuit1', 'c_pursuit2'], 2: ['c_reckon'], 3: ['c_armada', 'c_showdown'],
};
function cutTrack() {
    const L = CSL(), k = L === CUT ? 'open' : L === ACT_CUTS[1] ? 1 : L === ACT_CUTS[2] ? 2 : L === ACT_CUTS[3] ? 3 : null;
    return k == null ? null : (CUT_TRACKS[k][cs.i] || null);
}

function kick(dl, v) { if (smpHit('kick', dl, v, 0.17)) return; note(150, 0.2, 'sine', v, dl, musGain, { slide: -105 }); noiseHit(dl, v * 0.3, 'lowpass', 1400, 0.012); }   // body + beater click
function snare(dl, v) { if (smpHit('snare', dl, v, 0.07)) return; noiseHit(dl, v, 'bandpass', 1900, 0.1); noiseHit(dl, v * 0.55, 'highpass', 4200, 0.17); note(190, 0.09, 'triangle', v * 0.7, dl, musGain, { slide: -60 }); }   // crack + wire tail + shell
function hat(dl, v) { if (smpHit('hat', dl, v, 0.04)) return; noiseHit(dl, v * (0.85 + Math.random() * 0.3), 'highpass', 7200 + Math.random() * 1000, 0.03); }
function tom(dl, f, v) { if (smpHit('tom', dl, v, 0.14, { rate: f / 110 })) return; note(f, 0.22, 'sine', v, dl, musGain, { slide: -f * 0.45 }); }
function bassNote(m, dur, v, dl) { if (smpNote('bass', m, dur, v, 0.17, dl)) return; note(mf(m), dur, 'triangle', v, dl, musGain, { slide: -2 }); note(mf(m), dur * 0.8, 'sawtooth', v * 0.22, dl, musGain); }
function leadVoice(kind, m, dur, dl, ch) {
    if (kind === 'horn' || kind === 'trump') { trumpV(m, dur, 0.05, dl); trumpV(harmonyOf(m, ch), dur, 0.03, dl); }
    else if (kind === 'violin') violV(m, dur, 0.048, dl);
    else if (kind === 'duet') { trumpV(m, dur, 0.04, dl); violV(m, dur, 0.035, dl); trumpV(harmonyOf(m, ch), dur, 0.024, dl); }
    else if (kind === 'gtr') { pluck(m, Math.max(0.1, dur), 0.11, dl); pluck(m + 12, 0.1, 0.03, dl); }
    else if (kind === 'accord') { if (smpNote('accordion', m, dur, 0.04, 0.04, dl)) return; note(mf(m), dur, 'sawtooth', 0.04, dl, musGain, { att: 0.03 }); note(mf(m) * 1.006, dur, 'square', 0.026, dl, musGain, { att: 0.03 }); note(mf(m - 12), dur, 'sawtooth', 0.022, dl, musGain, { att: 0.04 }); }
    else if (kind === 'choir') { if (smpNote('choir', m, dur, 0.04, 0.04, dl, { att: 0.1 })) return; for (const k of [0, 4, 7]) note(mf(m + k - 12), dur, 'sawtooth', 0.02, dl, musGain, { att: 0.1, vib: true }); note(mf(m), dur, 'triangle', 0.04, dl, musGain, { att: 0.1, vib: true }); }
}
function melodyAt(B, s, dl, E, vmul) {
    const m = B.m[s]; if (!(m > 0)) return;
    let holds = 0; while (s + 1 + holds < 16 && (B.m[s + 1 + holds] === -1 || (B.m[s + 1 + holds] === 0 && holds < 3))) holds++;
    let dur = (1 + holds) * E * 0.9, at = Math.max(0, dl + (Math.random() - 0.5) * 0.008);   // a few ms of human timing
    // brass-style grace note: slide up into a held note from the nearest chord tone below it
    if (holds >= 1 && s > 0 && (B.lead === 'horn' || B.lead === 'trump' || B.lead === 'duet') && Math.random() < 0.3) {
        const pcs = B.ch.v.map(x => x % 12);
        for (let d = 1; d <= 4; d++) if (pcs.includes((m - d) % 12)) { trumpV(m - d, 0.07, 0.035, at); at += 0.055; dur -= 0.055; break; }
    }
    leadVoice(B.lead, m, dur, at, B.ch);
}
// ---- arrangement toolkit for the generated tracks (race, rpg, boss, finale, map, victory) ----
function riser(dl, dur, v) {   // filtered-noise sweep that lifts the ear into the next section
    if (!AC || !noiseBuf) return;
    if (smpHas('riser') && smpHit('riser', dl, v, 0.04, { rate: SMP.riser[0].buf.duration / dur })) return;   // stretched to the section length
    const t = AC.currentTime + dl, src = AC.createBufferSource(), bp = AC.createBiquadFilter(), gn = AC.createGain();
    src.buffer = noiseBuf; src.loop = true; bp.type = 'bandpass'; bp.Q.value = 1.2;
    bp.frequency.setValueAtTime(400, t); bp.frequency.exponentialRampToValueAtTime(7000, t + dur);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(v, t + dur * 0.95); gn.gain.linearRampToValueAtTime(0.0001, t + dur + 0.03);
    src.connect(bp); bp.connect(gn); gn.connect(musGain); src.start(t, Math.random() * 0.3, dur + 0.06); src.onended = () => gn.disconnect();
}
function impact(dl, v) {   // downbeat hit for a new section: sub boom + cymbal wash
    if (smpHit('impact', dl, v, 0.1)) return;
    note(72, 0.8, 'sine', v, dl, musGain, { slide: -42 });
    noiseHit(dl, v * 0.5, 'lowpass', 900, 0.45); noiseHit(dl, v * 0.3, 'highpass', 4200, 1.0);
}
function glock(m, dur, v, dl, pan) {   // bright vihuela / glockenspiel ping for sparkle lines
    if (smpNote('bell', m, dur, v, 0.02, dl, { pan })) return;
    const f = mf(m);
    note(f, dur, 'sine', v, dl, musGain, { att: 0.002, pan });
    note(f * 2.01, dur * 0.5, 'sine', v * 0.35, dl, musGain, { att: 0.002, pan });
}
function padChord(ch, dur, v, dl, cut) {   // slow-swelling detuned string pad, voices fanned across the stereo field
    if (smpHas('pad')) { ch.v.forEach((n, i) => smpNote('pad', n, dur, v, 0.009, dl, { pan: (i - (ch.v.length - 1) / 2) * 0.4, att: dur * 0.28 })); return; }
    ch.v.forEach((n, i) => {
        const pan = (i - (ch.v.length - 1) / 2) * 0.4;
        note(mf(n), dur, 'sawtooth', v, dl, musGain, { att: dur * 0.28, vib: true, lp: [cut, cut, 0], pan });
        note(mf(n) * 1.007, dur, 'sawtooth', v * 0.8, dl, musGain, { att: dur * 0.34, lp: [cut, cut, 0], pan: -pan });
    });
}
function seqLayer(B, s, dl, E, hv) {   // what turns the bare groove into an arrangement: pad, sparkle, bass approach, transitions, shouts
    const ch = B.ch, h = B.hype, sty = ACT.sty, brk = B.sec.endsWith('break') || B.sec.endsWith('intro') || B.sec === 'f-bridge';
    // 1. string pad under every bar; fuller where the track thins out, darker for the boss
    if (s === 0) padChord(ch, E * 16, (0.009 + 0.004 * h) * (brk ? 1.6 : 1), dl, sty === 'boss' ? 2.5 : sty === 'rpg' ? 3 : 4.5);
    // 2. offbeat sparkle in the gaps of the melody; the pattern shifts every bar so it never loops audibly
    if (h >= 1 && sty !== 'boss' && sty !== 'finale' && !DARKSTY.has(sty) && s % 4 === 1 && !(B.m[s] > 0) && Math.random() < 0.6) {
        const idx = ((s >> 1) + B.i * 2) % ch.v.length, pan = (B.i % 2 ? 0.38 : -0.38) * (s % 4 === 1 ? 1 : -1);
        glock(ch.v[idx] + (h >= 2 ? 24 : 12), E * 2.2, (sty === 'map' || sty === 'rpg' ? 0.014 : 0.02) * (0.85 + h * 0.1), dl, pan);
    }
    // 3. chromatic approach into the next chord's root (a walking-bass touch)
    if (s === 15 && !B.end && sty !== 'boss' && B.nx.r !== ch.r) bassNote(B.nx.r + (B.nx.r > ch.r ? -1 : 1), E * 0.9, 0.1 * hv, dl);
    // 4. transitions: riser through the last bar of a section, impact on the first bar of a big one
    if (B.end && s === 0 && h >= 1 && B.n >= 4 && !(B.sec.startsWith('v-') && (B.sec === 'v-tag' || B.sec === 'v-B' || B.sec === 'v-F' || B.nx.hold)) && ACT.sty !== 'stage') riser(dl, E * 16, 0.035 + 0.012 * h);
    if (B.first && s === 0 && h >= 2 && !B.sec.startsWith('v-')) impact(dl, 0.1);
    // 5. shouts: a mariachi grito over the big sections, a low growl for the boss
    if (B.first && s === 8 && h >= 2 && Math.random() < 0.55) { if (sty === 'boss') ay(dl, 120, 0.5); else if (sty === 'race' || sty === 'finale' || sty === 'map') grito(dl); }
}
// ---- victory song: how the sections join. Every join gets a fill that grows toward the next section, a bass pickup, an arrival hit, and a ring-out (a held chord that decays across the bar line) so nothing stops dead ----
function victoryFlow(B, s, dl, E, ch, hy) {
    if (!B.sec.startsWith('v-')) return;   // (the hero's theme shares the style but keeps its own arrangement)
    const SG = ACT.song, bi = SG.indexOf(B), NB = SG[(bi + 1) % SG.length], hold = !!B.hold, sec = hold ? B.of : B.sec, pos = B.i, fin = !!B.fin2, pre = !!NB.hold;   // hold: the half bar after a section where the last word and the chord ring out; pre: the bar just before it
    const half = B.n >= 8 && pos === B.n / 2 - 1 && !hold;   // the middle of an 8-bar section: a small breath
    // 1. the fill that leads into the next section: through the last bar, or, where a word is held, through the second half of the hold bar
    const FILL = { 'v-intro': 0.6, 'v-A': 1.0, 'v-B': fin ? 0.25 : 0.55, 'v-F': 0.25, 'v-C': 1.0, 'v-tag': 0.0 }, fs = FILL[sec] || 0, sx = hold ? s + 8 : s;
    if ((hold || (B.end && !pre)) && fs > 0 && !B.last) {
        if (sx === 6 || sx === 8) tom(dl, 130 - (sx - 6) * 10, (0.07 + 0.02 * fs) * Math.min(1, fs + 0.3));
        if (sx === 10 && fs >= 0.8) tom(dl, 112, 0.08 * fs);
        if (sx >= 12) { snare(dl, (0.03 + (sx - 12) * 0.014) * fs); if (fs >= 1 && sx % 2 === 1) tom(dl, 100 - (sx - 12) * 6, 0.07 * fs); }
        if (sx === 14 && fs >= 1.2) { snare(dl + E * 0.5, 0.075); }
    } else if (half && s >= 14) { snare(dl, 0.03 + (s - 14) * 0.015); }
    // 2. bass pickup: the next section's root lands a sixteenth early
    if (((hold && s === 6) || (B.end && !pre && s === 14)) && !B.last && NB.ch.r !== ch.r) bassNote(NB.ch.r, E * 1.6, 0.15, dl);
    // 3. arrival on the first bar of a new section: a crash and a trumpet stab, bigger where the music gets bigger
    if (B.first && s === 0 && sec !== 'v-intro') {
        const big = sec === 'v-B' || sec === 'v-F' ? (fin ? 1.0 : 0.8) : sec === 'v-C' ? 0.7 : sec === 'v-A' ? 0.4 : 0.3;
        if (big >= 0.7) { cymbal(dl, 0.03 * big); clap(dl, 0.05 * big); ch.v.forEach(n => trumpV(n + 12, E * 4, 0.03 * big, dl)); }
        if (sec === 'v-B' || sec === 'v-F' || sec === 'v-C' || sec === 'v-tag') impact(dl, fin ? 0.12 : 0.09);
    }
    // 4. rhythm variety so a section breathes instead of looping: a push on the "and" of beat three every other bar
    if (hy >= 1 && pos % 2 === 1 && s === 10 && !B.end && !hold) kick(dl, 0.1);
    if (hy >= 2 && pos % 4 === 3 && s === 6 && !B.end && !hold) { hat(dl, 0.05); hat(dl + E * 0.5, 0.04); }
    // 5. the hold bar: the chord rings under the held word (trumpets swell in, a cymbal washes) and carries into the next section
    if (hold && s === 0 && !B.last) { ch.v.forEach(n => trumpV(n, E * 7, 0.028, dl)); ch.v.forEach(n => trumpV(n + 12, E * 6, 0.018, dl)); if (sec !== 'v-tag') cymbal(dl, 0.03); }   // the chord swells under the held word and is gone by the downbeat, so nothing smears into the next section
    // 6. the very last hold: everything lands together as the word is held, then the chord, the bass and the voice ring out to nothing
    if (B.last) {
        if (s === 0) { impact(dl, 0.12); cymbal(dl, 0.07); clap(dl, 0.07); kick(dl, 0.18); strum(ch, dl, true, 0.1); ch.v.forEach(n => trumpV(n + 12, E * 38, 0.05, dl)); ch.v.forEach(n => trumpV(n, E * 34, 0.04, dl)); bassNote(ch.r, E * 28, 0.2, dl); }
        if (s === 4) strum(ch, dl, false, 0.05);
    }
}
function seqStep(st, dl) {
    const SG = ACT.song, nb = SG.length, bi = Math.floor(st / 16) % nb, s = st % 16, B = SG[bi], ch = B.ch, E = MUS_E, hv = 0.9 + Math.random() * 0.2;
    if (ACT.sty === 'stage' && st >= nb * 16) return;   // the musical's numbers play once, then the band is silent (the scene decides when it ends)
    if (s === 0 && B.first && !DARKSTY.has(ACT.sty) && ACT.sty !== 'stage') cymbal(dl, 0.05);
    const quiet = B.lead === 'gtr' || B.lead === 'violin' && B.sec.endsWith('break');
    if (ACT.sty === 'race') {   // driving four-on-the-floor mariachi-surf, 152 bpm
        if (s % 4 === 0 && !quiet) kick(dl, 0.17);
        if (s === 4 || s === 12) { snare(dl, 0.07); clap(dl, 0.04); }
        hat(dl, s % 2 === 0 ? 0.03 : 0.045);
        if (s % 2 === 0) bassNote(s % 8 === 6 ? ch.f : ch.r + (s % 4 === 2 ? 12 : 0), E * 1.8, 0.17 * hv, dl);
        if (s % 4 === 2) strum(ch, dl, true, 0.05 * hv);
        if (s === 15 && B.end) { for (let k = 0; k < 4; k++) snare(dl + k * E * 0.25, 0.04 + k * 0.01); }
        if (B.hype >= 2 && s % 2 === 1) violV(ch.v[(s >> 1) % ch.v.length] + 24, E * 1.4, 0.012, dl);
        if (B.sec === 'r-break' && B.i >= 2 && s % 2 === 1) clap(dl, 0.03 + 0.01 * B.i);
    } else if (ACT.sty === 'rpg') {   // lurching danza macabra: boom-chick with tom rolls, 110 bpm
        if (s === 0 || s === 8) kick(dl, 0.2); if (s === 6 || s === 14) tom(dl, 95, 0.14);
        if (s === 4 || s === 12) { snare(dl, 0.06); noiseHit(dl, 0.05, 'highpass', 5000, 0.08); }
        if (s % 4 === 0) { const root = s === 0 || s === 8; bassNote(root ? ch.r : ch.f, E * 3.2, 0.2 * hv, dl); }
        if (s === 2 || s === 6 || s === 10 || s === 14) strum(ch, dl, (s >> 2) % 2 === 0, 0.042 * hv);
        hat(dl, s % 2 ? 0.014 : 0.026);
        if (s === 0) ch.v.forEach(n => note(mf(n - 12), E * 15, 'triangle', 0.03, dl, musGain, { att: 0.2 }));
        if (B.hype >= 1 && s % 4 === 3 && Math.random() < 0.5) note(mf(ch.v[1] + 24), E * 1.5, 'sine', 0.025, dl, musGain, { vib: true });
        if (B.end && s >= 12) tom(dl, 130 - (s - 12) * 15, 0.12);
    } else if (ACT.sty === 'map') {   // level select: a steady war-room march, 100 bpm; menacing but inviting, built to loop
        const intro = B.hype === 0, big = B.hype >= 2;
        if (s === 0 || s === 8 || (big && s === 10)) kick(dl, intro ? 0.1 : 0.15);
        if ((s === 4 || s === 12) && !intro) { snare(dl, 0.045); }
        if (s === 12 && big) clap(dl, 0.03);
        hat(dl, s % 2 === 0 ? 0.018 : 0.012);
        if (s % 2 === 0) bassNote(s % 8 === 0 ? ch.r : s % 8 === 6 ? ch.f : ch.r + 12, E * 1.6, (intro ? 0.11 : 0.15) * hv, dl);   // pulsing ostinato
        if (s === 2 || s === 10) strum(ch, dl, s === 2, (intro ? 0.024 : 0.036) * hv);
        if (s === 0) { ch.v.forEach(n => note(mf(n - 12), E * 16, 'triangle', 0.03, dl, musGain, { att: 0.4 })); note(mf(ch.r - 12), E * 16, 'sawtooth', intro ? 0.03 : 0.045, dl, musGain, { att: 1.0 }); }
        if (big && s === 8) note(mf(ch.r + 13), E * 6, 'sine', 0.022, dl, musGain, { att: 0.2, vib: true });   // a cold half-step shiver
        if (B.sec === 'm-intro' && B.end && s >= 12) snare(dl, 0.03 + (s - 12) * 0.012);   // drum fill into the tune
        if ((B.sec === 'm-A' || B.sec === 'm-A2') && B.end && s === 10) { ay(dl, 170, 0.2); ay(dl + E * 2.2, 185, 0.2); ay(dl + E * 4.4, 200, 0.5); }
        if (B.sec === 'm-turn' && B.end && s >= 12) { snare(dl, 0.035 + (s - 12) * 0.012); }
    } else if (ACT.sty === 'title') {   // the title theme: a bouncy ranchera polka, 120 bpm: oom-pah bass, offbeat strums, and a band that fills out as the song goes on
        const hy = B.hype;
        if (s % 4 === 0) { beatLog.push({ t: AC.currentTime + dl, a: s === 0 ? 1 : s === 8 ? 0.7 : 0.45 }); if (beatLog.length > 8) beatLog.shift(); }
        if (s === 0 && B.cue && CUEFN[B.cue]) { CUEFN[B.cue](dl); shoutLog.push({ t: AC.currentTime + dl, k: B.cue }); if (shoutLog.length > 6) shoutLog.shift(); }
        if (hy === 0 && B.sec === 't-intro') { if (s === 0 && B.i >= 2) kick(dl, 0.15); if (s === 8 && B.i >= 2) tom(dl, 100, 0.1); if (B.i === 3 && s >= 12) snare(dl, 0.03 + (s - 12) * 0.012); if (s === 0) ch.v.forEach(n => trumpV(n + 12, E * 5, 0.03, dl)); }
        else if (B.sec === 't-break') { if (s % 4 === 0) kick(dl, 0.07); if (s % 4 === 2) strum(ch, dl, (s >> 2) % 2 === 0, 0.035 * hv); if (B.i === 3 && s >= 8) snare(dl, 0.025 + (s - 8) * 0.008); }
        else { if (s % 8 === 0) kick(dl, 0.15 + 0.02 * hy); if (s === 4 || s === 12) { snare(dl, 0.05 + 0.01 * hy); clap(dl, 0.04); } hat(dl, s % 2 ? 0.02 : 0.034); }
        if (!(hy === 0 || B.sec === 't-break') || B.sec === 't-intro' && B.i >= 2) { if (s % 4 === 0) bassNote(s % 8 === 0 ? ch.r : ch.f, E * 2.3, (hy >= 1 ? 0.19 : 0.14) * hv, dl); if (hy >= 1 && s % 4 === 2) strum(ch, dl, (s >> 2) % 2 === 0, 0.052 * hv); }
        if (hy >= 2 && (s === 0 || s === 8)) ch.v.forEach(n => trumpV(n + 12, E * 2.4, 0.024, dl));
        if (hy >= 3 && s % 2 === 0) violV(ch.v[(s >> 1) % ch.v.length] + 24, E * 1.6, 0.012, dl);
        if (hy >= 2 && s % 4 === 3 && Math.random() < 0.5) glock(ch.v[(s >> 2) % ch.v.length] + 24, E * 2, 0.016, dl, s % 8 === 3 ? -0.3 : 0.3);
        if (B.end && s >= 12 && hy >= 1) snare(dl, 0.04 + (s - 12) * 0.012);
        if (B.end && B.sec === 't-C' && s === 0) { strum(ch, dl, true, 0.09); ch.v.forEach(n => trumpV(n, 1.4, 0.04, dl)); }
    } else if (ACT.sty === 'victory') {   // party-mariachi fanfare, ~143 bpm: it builds from a bare call to a full band
        const hy = B.hype, own = false, thin = !!B.last, gd = !own && !(thin && s > 0);   // own: sections whose drums are written by hand in victoryFlow; thin: the very last bar lets go so the chord can ring (the hold bars keep the groove going under the held word)
        if (hy === 0) { if (s === 0) kick(dl, 0.17); if (s === 8) tom(dl, 95, 0.12); if (s === 12 || s === 14) tom(dl, 120, 0.09); }   // the call: sparse, a drum hit on each downbeat
        else if (s % 4 === 0 && gd) kick(dl, 0.14 + 0.02 * hy);
        if (hy >= 1 && (s === 4 || s === 12) && gd) { snare(dl, 0.05 + 0.01 * hy); if (hy >= 2) clap(dl, 0.05); }
        if (gd) { if (hy >= 1) hat(dl, s % 2 ? 0.026 : 0.04); else if (s % 4 === 2) shaker(dl, 0.04); }
        if (hy >= 3 && s % 2 === 1 && gd) hat(dl, 0.022);   // the peak gets running sixteenths
        if (s % 4 === 0 && (hy >= 1 || s === 0) && !(own && s % 8) && !(thin && s % 8)) bassNote(s % 8 === 0 ? ch.r : ch.f, E * 3, (hy === 0 ? 0.15 : 0.19) * hv, dl);
        if (s % 4 === 2 && hy >= 1 && !own && !thin) strum(ch, dl, (s >> 2) % 2 === 0, 0.055 * hv);
        if (hy === 0 && s === 0) strum(ch, dl, true, 0.07 * hv);
        if (s === 0 || (s === 8 && hy >= 1)) ch.v.forEach(n => trumpV(n + 12, E * (hy === 0 ? 7 : 2.6), hy === 0 ? 0.04 : 0.03, dl));
        if (hy >= 2 && s % 2 === 0) note(mf(ch.v[(s >> 1) % ch.v.length] + 24), E * 1.5, 'sine', 0.03, dl, musGain);
        if (hy >= 3 && s === 4) ch.v.forEach(n => trumpV(n + 24, E * 2, 0.02, dl));   // trumpets double an octave up at the peak
        if (s === 0 && VIC_LYR[B.sec]) VIC_LYR[B.sec].forEach(([bar, syls]) => { if (bar === B.i) singLine(dl, E, syls, B.sec === 'v-B' || B.sec === 'v-F' || B.sec === 'v-tag' ? 1.0 : 0.85); });   // the words, sung
        if (B.sec === 'v-B' || B.sec === 'v-F') {   // the chorus hits land with the syllables: "Jeff is GAY" (s4) / "so GAY" (s10), and each "hey"
            const F2 = B.sec === 'v-F', pair = F2 ? B.i <= 2 : (B.i === 0 || B.i === 1 || B.i === 4 || B.i === 5 || B.i === 6), hey = F2 ? B.i === 3 : (B.i === 2 || B.i === 3 || B.i === 7);
            if (pair && (s === 4 || s === 10)) { clap(dl, 0.07); tom(dl, 130, 0.08); }
            if (pair && s === 8) tom(dl, 100, 0.1);
            if (hey && (B.sec === 'v-F' || B.i !== 3) && s % 2 === 0 && s < 8) tom(dl, 105 + s * 6, 0.09);
        }
        if (B.sec === 'v-tag' && B.i === 0 && (s === 4 || s === 16 % 16)) clap(dl, 0.06);
        victoryFlow(B, s, dl, E, ch, hy);
    } else if (ACT.sty === 'finale') {   // warm, triumphant fiesta polka that swells and modulates up
        const soft = B.hype === 0;
        if (s % 8 === 0 && !soft) kick(dl, 0.14);
        if ((s === 4 || s === 12) && B.hype >= 1) { snare(dl, 0.05); clap(dl, 0.035); }
        if (s % 4 === 2) hat(dl, soft ? 0.008 : 0.014);   // sparse, soft ticks instead of sixteenth-note hats
        if (s % 4 === 0) bassNote(s % 8 === 0 ? ch.r : ch.f, E * 3, (soft ? 0.14 : 0.19) * hv, dl);
        if (s % 4 === 2) strum(ch, dl, (s >> 2) % 2 === 0, (soft ? 0.03 : 0.05) * hv);
        if (s === 0) ch.v.forEach(n => note(mf(n - 12), E * 15, 'triangle', soft ? 0.03 : 0.045, dl, musGain, { att: 0.15 }));
        if (B.hype >= 2 && s === 0 && B.first) { ch.v.forEach(n => trumpV(n, E * 4, 0.035, dl)); cymbal(dl, 0.05); }
        if (B.hype >= 3 && s === 0 && B.i % 4 === 0) ch.v.forEach(n => trumpV(n + 12, E * 3, 0.026, dl));   // one lift every four bars, not a second chord layer under the tune
        if (B.end && s >= 12 && !soft) snare(dl, 0.04 + (s - 12) * 0.012);
        if (B.sec === 'f-coda' && B.i === B.n - 1 && s === 0) { strum(ch, dl, true, 0.1); ch.v.forEach(n => { trumpV(n, 2.2, 0.045, dl); trumpV(n + 12, 2.2, 0.03, dl); }); note(mf(ch.r), 2.2, 'triangle', 0.28, dl, musGain); noiseHit(dl, 0.07, 'highpass', 3500, 0.8); }
    } else if (ACT.sty === 'unease') {   // the lanterns go out: a lone nylon guitar picks the chords, a music box rings far above, a cold half-step hangs in the air
        if (s === 0) { kick(dl, 0.06); bassNote(ch.r, E * 6, 0.12 * hv, dl); }
        if (s === 8 && B.hype >= 1) bassNote(ch.f, E * 6, 0.08 * hv, dl);
        if (s % 2 === 0 && !(B.m[s] > 0)) pluck(ch.v[((s >> 1) + (B.i % 2)) % ch.v.length], 0.5, 0.03, dl);
        if (s === 0 && B.i % 2 === 0) glock(ch.v[2] + 24, E * 10, 0.016, dl, 0.3);
        if (s === 0 && B.i % 4 === 3) note(mf(ch.r + 13), E * 14, 'sine', 0.018, dl, musGain, { att: 0.8, vib: true });
    } else if (ACT.sty === 'dirge') {   // the toast: a slow funeral march, muffled drum, tolling bell, low brass and choir
        if (s === 0 || s === 8) tom(dl, 70, 0.15);
        if (s === 12) snare(dl, 0.02);
        if (s === 0) { bassNote(ch.r, E * 7, 0.2 * hv, dl); glock(ch.r + 36, E * 12, 0.03, dl, 0.2); strum(ch, dl, true, 0.03 * hv); }
        if (s === 8) bassNote(ch.f, E * 7, 0.15 * hv, dl);
        if (B.hype >= 2 && (s === 4 || s === 12)) ch.v.forEach(n => smpNote('choir', n, E * 3, 0.02, 0.04, dl, { att: 0.08 }) || note(mf(n), E * 3, 'triangle', 0.012, dl, musGain, { att: 0.08 }));
    } else if (ACT.sty === 'wrath') {   // the chase and the revenge: galloping drums, pounding bass, choir stabs and brass over a phrygian-dominant minor
        if ([0, 3, 6, 8, 11, 14].includes(s)) kick(dl, 0.2);
        if (s === 4 || s === 12) { snare(dl, 0.1); clap(dl, 0.04); }
        if (s % 4 === 2) tom(dl, 90 + (s >> 2) * 8, 0.1);
        if (s % 2 === 0) bassNote(s % 4 === 2 ? ch.f : ch.r, E * 1.7, 0.16 * hv, dl);
        if (s % 4 === 2) strum(ch, dl, s % 8 === 2, 0.05 * hv);
        if (s === 0) ch.v.forEach(n => smpNote('choir', n, E * 8, 0.03, 0.04, dl, { att: 0.05 }) || note(mf(n), E * 8, 'sawtooth', 0.02, dl, musGain, { att: 0.05 }));
        if (s === 0 && B.hype >= 3) ch.v.forEach(n => trumpV(n + 12, E * 3, 0.026, dl));
        if (B.end && s >= 12) snare(dl, 0.05 + (s - 12) * 0.015);
    } else if (ACT.sty === 'vigil') {   // the vigil: one guitar, a few bells, and a long pad. Nothing else.
        if (s === 0) bassNote(ch.r, E * 10, 0.08 * hv, dl);
        if (s % 2 === 0 && !(B.m[s] > 0)) pluck(ch.v[(s >> 1) % ch.v.length] + (s % 8 === 6 ? 12 : 0), 0.6, 0.028, dl);
        if (s === 0 && B.i % 2 === 1) glock(ch.v[0] + 36, E * 12, 0.018, dl, -0.3);
    } else if (ACT.sty === 'omen') {   // the long road: a slow heartbeat under a cold drone that swells with each section
        if (s === 0) { kick(dl, 0.09); note(mf(ch.r - 12), E * 16, 'triangle', 0.05, dl, musGain, { att: 0.8 }); }
        if (s === 3) kick(dl, 0.05);
        if (B.hype >= 1 && s === 8) bassNote(ch.r, E * 6, 0.1 * hv, dl);
        if (B.hype >= 1 && s % 2 === 1) violV(ch.v[(s >> 1) % ch.v.length] + 24, E * 1.4, 0.01 + 0.004 * B.hype, dl);
        if (B.hype >= 2 && s % 4 === 0) tom(dl, 75, 0.1);
        if (B.hype >= 2 && s === 0) ch.v.forEach(n => trumpV(n, E * 5, 0.022, dl));
    } else if (ACT.sty === 'stage') {   // the musical: a small pit band under the sung lines (and the band sings them: see muSing)
        const MUT = !!(ACT.mute && ACT.mute[B.i]), F = MUT ? 'mute' : ACT.feel, hy = B.hype, lastB = !!B.last;   // a muted bar is a rest for a spoken bit: only a low drone stays
        if (s === 0) (ACT.lines || []).forEach(l => { if (l.sing && l.bar === B.i) muSing(l, dl, E); });
        { const hk = ACT.hookEv && ACT.hookEv[B.i * 16 + s]; if (hk && !lastB && !MUT) leadVoice(B.lead, hk[0], hk[1] * E * 0.95, dl, ch);   // the countermelody answers in the gaps between sung lines
          if (s === 0 && ACT.pad && F !== 'creep' && !MUT && !lastB) ACT.pad[B.i].forEach(n => smpNote('choir', n, E * 15, 0.03, 0.04, dl, { att: 0.3 }) || note(mf(n), E * 15, 'triangle', 0.016 * (1 + 0.2 * hy), dl, musGain, { att: 0.3, vib: true }));   // a voice-led choir pad under every bar
          if (s === 14 && ACT.appr && ACT.appr[B.i] && F !== 'creep' && (F !== 'rise' || hy >= 1) && !MUT && !lastB) bassNote(ACT.appr[B.i], E * 2, 0.07 * hv, dl); }   // the bass walks into the next chord
        if (F === 'ballad') {   // the why: a slow Em ballad, guitar arpeggios and a soft pulse
            if (s === 0 && B.i % 2 === 0) kick(dl, 0.07);
            if (s === 0) bassNote(ch.r, E * 7, 0.12 * hv, dl); if (s === 8) bassNote(ch.f, E * 6, 0.09 * hv, dl);
            if (s % 4 === 0 && !lastB) pluck(ch.v[(s >> 2) % ch.v.length] + (s % 8 === 4 ? 12 : 0), 0.55, 0.04 * hv, dl);
            if (s % 4 === 2) shaker(dl, 0.016);
            if (B.i === 3 || B.i === 7) { if (s === 12) tom(dl, 90, 0.05); }
        } else if (F === 'drift') {   // the tangent: a lazy, rolling groove that never quite lands where you expect it
            if (s === 0) kick(dl, 0.1); if (s === 10) kick(dl, 0.06);
            if (s === 8) clap(dl, 0.025);
            if (s === 0 || s === 6 || s === 10) bassNote(s === 6 ? ch.f : ch.r, E * 4, 0.1 * hv, dl);
            if (s === 4 || s === 12) strum(ch, dl, s === 4, 0.035 * hv);
            if (s % 8 === 2) hat(dl, 0.02);
            if (s === 0 && B.i % 4 === 3) ch.v.forEach(n => note(mf(n + 12), E * 14, 'sine', 0.014, dl, musGain, { att: 0.5, vib: true }));   // a dreamy swell every fourth bar
        } else if (F === 'mute') {
            if (s === 0) note(mf(ch.r - 12), E * 16, 'triangle', 0.035, dl, musGain, { att: 0.4 });
        } else if (F === 'creep') {   // the stash: a nervous heartbeat, a cold drone, then the chant over stabbing choir
            if (s === 0) { kick(dl, 0.09); note(mf(ch.r - 12), E * 16, 'triangle', 0.05, dl, musGain, { att: 0.5 }); }
            if (s === 3) kick(dl, 0.05);
            if (s % 4 === 2 && B.i >= 3) hat(dl, 0.02);
            if (B.i >= 3 && !lastB) { if (s === 0) ch.v.forEach(n => smpNote('choir', n, E * 6, 0.03, 0.04, dl, { att: 0.05 }) || note(mf(n), E * 6, 'sawtooth', 0.02, dl, musGain, { att: 0.05 })); if (s === 8) tom(dl, 78, 0.1); if (s === 12) tom(dl, 70, 0.07); }
            if (B.i === 5 && s >= 12) snare(dl, 0.03 + (s - 12) * 0.012);
        } else {   // 'rise' (the breaking): it starts bare and keeps adding until the whole band is raging
            if (hy >= 1 && s % 8 === 0) kick(dl, 0.1 + 0.03 * hy);
            if (hy >= 2 && s % 4 === 0) kick(dl, 0.14);
            if (hy >= 2 && (s === 4 || s === 12)) { snare(dl, 0.06); clap(dl, 0.03 * hy); }
            if (hy >= 1) hat(dl, s % 2 ? 0.012 : 0.026);
            if (s === 0 || (hy >= 1 && s === 8)) bassNote(ch.r, E * 5, (0.12 + 0.03 * hy) * hv, dl);
            if (hy >= 1 && s % 4 === 2) strum(ch, dl, (s >> 2) % 2 === 0, (0.03 + 0.01 * hy) * hv);
            if (hy >= 2 && s % 2 === 0 && s % 8 !== 0 && !lastB) bassNote(s % 4 === 2 ? ch.f : ch.r, E * 1.6, 0.045 * hv, dl);   // a driving eighth-note bass underneath the rising violin
            if (hy === 0 && s === 0) pluck(ch.v[0] + 12, 0.7, 0.05, dl);
            if (hy >= 3 && s === 0) { ch.v.forEach(n => trumpV(n + 12, E * 8, 0.03, dl)); if (B.i >= (ACT.mk ? ACT.mk.rage0 : 29)) { impact(dl, 0.09); cymbal(dl, 0.05); } }
            if (hy >= 3 && s % 2 === 0 && B.i >= (ACT.mk ? ACT.mk.rage0 : 29) && B.i <= (ACT.mk ? ACT.mk.rage1 : 31)) tom(dl, 110 - (s >> 1) * 4, 0.07);
            if (B.i === (ACT.mk ? ACT.mk.fill : 24) && s >= 10) snare(dl, 0.03 + (s - 10) * 0.012);   // the drum fill into I AM THE HERO
        }
        if (lastB && s === 0) { impact(dl, 0.1); cymbal(dl, 0.06); strum(ch, dl, true, 0.08); ch.v.forEach(n => trumpV(n + 12, E * 26, 0.04, dl)); bassNote(ch.r, E * 22, 0.18, dl); }   // the last chord rings out
    } else {   // boss: double-time pounding, 170 bpm
        if (s % 4 === 0 || (s === 10 && B.hype >= 2)) kick(dl, 0.22);
        if (s === 4 || s === 12) { snare(dl, 0.09); clap(dl, 0.05); }
        hat(dl, 0.04 - (s % 2) * 0.015);
        bassNote(s % 4 === 3 ? ch.f : ch.r, E * 0.95, 0.15 * hv, dl);
        if (s % 4 === 2) strum(ch, dl, s % 8 === 2, 0.055 * hv);
        if (B.hype >= 1 && s % 2 === 0) note(mf(ch.v[(s >> 1) % ch.v.length] + 12), E * 1.3, 'sawtooth', 0.02, dl, musGain);
        if (s === 0 && B.hype >= 2) ch.v.forEach(n => trumpV(n, E * 3, 0.03, dl));
        if (B.hype >= 3 && (s === 8)) ch.v.forEach(n => trumpV(n + 12, E * 2.4, 0.024, dl));
        if (B.end && B.hype >= 1 && s >= 12) { snare(dl, 0.05 + (s - 12) * 0.015); noiseHit(dl, 0.03 + 0.01 * (s - 12), 'bandpass', 2400, 0.08); }
        if (B.sec === 'b-break' && s % 4 === 0) note(mf(ch.r - 12), E * 3, 'sawtooth', 0.04, dl, musGain, { att: 0.05 });
    }
    if (!quiet || B.lead === 'gtr' || B.lead === 'violin') melodyAt(B, s, dl, E);
    seqLayer(B, s, dl, E, hv);
    if (B.end && B.sec.endsWith('C') && B.i === B.n - 1 && s === 0) { strum(ch, dl, true, 0.09); ch.v.forEach(n => trumpV(n, 1.2, 0.04, dl)); }
}
function musicWant() {
    if (mode === 'songmenu') return songTest || 'menu';
    if (mode === 'cutscene' && typeof cs !== 'undefined' && muIs()) return cs.list[cs.i].track;   // the musical (secret theater): each number is its own track
    if (mode === 'cutscene' && typeof cs !== 'undefined' && cs && cs.list !== END_CUTS) { const ck = cutTrack(); if (ck) return ck; }
    if (mode === 'cutscene' && typeof cs !== 'undefined' && cs && cs.list === END_CUTS) { return ({ 'THE LEDGER': 'vigil', 'THE PROMISE': 'vigil', 'THE LANTERNS GO OUT': 'unease', 'THE LAST BOTTLE': 'unease', 'THE TOAST': 'dirge', 'THE CHASE': 'wrath', 'THE REVENGE': 'wrath', 'THE OFFER': 'vigil', 'THE REFUSAL': 'wrath', 'THE LAUGH': 'wrath', 'THE PLUNDER': 'unease', 'THE PORTRAIT': 'unease', 'THE CROWNING': 'dirge', 'THE REHEARSAL': 'wrath', 'THE WHY': 'vigil', 'THE TANGENT': 'vigil', 'THE STASH': 'vigil', 'THE BREAKING': 'vigil' })[END_CUTS[cs.i].title] || 'finale'; }
    if (mode === 'map') return 'map';
    if (typeof g !== 'undefined' && g && (mode === 'clear' || (mode === 'over' && g.win))) return 'victory';
    if (mode === 'menu' || mode === 'shop' || mode === 'wardrobe' || mode === 'trophies' || mode === 'stats' || mode === 'wshop' || mode === 'cutmenu' || mode === 'musmenu' || (mode === 'options' && optsReturn === 'menu')) return 'menu';
    if (typeof g !== 'undefined' && g && g.camp && (g.live || mode === 'clear' || mode === 'over')) {
        return ['game', 'race', 'rpg', 'boss'][g.wi || 0];
    }
    return 'game';
}

// ---- sound effects for the cutscenes (called every frame from step(); cs.t is in frames) ----
const CS_VOL = 0.3;   // cutscene effects sit well under the music
let csBus = null;
function csBusNode() { if (!csBus || csBus.ctx !== AC) { const lp = AC.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3800; lp.connect(musGain); csBus = lp; csBus.ctx = AC; } return csBus; }
let csHushed = false;
let CS_MUL = 1;   // ending cutscene: its ambient effects sit well under the song
function nz(v, type, f, dur, dl) { noiseHit(dl || 0, v * CS_VOL * CS_MUL * 0.7, type, Math.min(f, 3500), dur); }
function csSfx() {
    if (!AC || !cs) return;
    const bus = csBusNode(), note = (f, d, ty, v, dl, dest, o) => window.note(f, d, ty, v * CS_VOL * CS_MUL, dl, dest || bus, o);
    const t = cs.t, i = cs.i, ending = cs.list === END_CUTS, ev = (n) => t === n;
    CS_MUL = ending ? (i < 2 ? 1.1 : i >= 7 ? 0.9 : 0.3) : 1;
    if (muIs() && OPT.music && AC.state === 'running' && musTrack === CSL()[cs.i].track) cs.t = Math.max(0, Math.floor((musStep * MUS_E - (musNext - AC.currentTime)) * 60));   // the musical runs on the band's clock, so what you see stays locked to what you hear
    if (ending || cs.list === ACT_CUTS[3] || muIs()) csSpeak();
    if (muIs()) return;
    if (ending && AC && musGain) {   // the song drops out for the Baron's death, then returns with the armada
        if (i < 2 && t === 1 && !csHushed) { csHushed = true; musGain.gain.setTargetAtTime(0.0001, AC.currentTime, 0.35); }
        if (i === 2 && t === 1 && csHushed) { csHushed = false; applyVol(); musStep = 0; musNext = AC.currentTime + 0.1; musT0 = musNext; }
    }
    if (!ending) {   // act intro scenes
        const act = cs.list === ACT_CUTS[1] ? 1 : cs.list === ACT_CUTS[2] ? 2 : cs.list === ACT_CUTS[3] ? 3 : 0;
        if (act === 1 && i === 1) { if (ev(18)) { nz(0.28, 'bandpass', 900, 1.0); note(110, 1.3, 'sawtooth', 0.14, 0, null, { slide: 520 }); } if (t % 8 === 0) note(70 + (t % 24), 0.1, 'sawtooth', 0.035, 0); }
        if (act === 1 && i === 0) { if (ev(3) || ev(40)) { nz(0.12, 'lowpass', 500, 0.6); note(70, 0.5, 'sawtooth', 0.12, 0); } if (t % 18 === 0 && t > 30) note(110 + (t % 5) * 14, 0.2, 'sawtooth', 0.05, 0, null, { slide: 60 }); }
        if (act === 2 && i === 0) { if (ev(10) || ev(120)) { nz(0.2, 'bandpass', 800, 0.5); note(55, 0.9, 'sawtooth', 0.14, 0, null, { slide: -20 }); } if (t % 30 === 0) note(380, 0.25, 'triangle', 0.05, 0); }
        if (act === 3) { if (i === 0 && (ev(10) || ev(100))) { nz(0.12, 'lowpass', 400, 1); note(48, 1, 'sawtooth', 0.1, 0); } if (i === 1 && ev(30)) { note(70, 1.2, 'sawtooth', 0.2, 0, null, { slide: -25 }); nz(0.25, 'lowpass', 500, 1.2); } if (i === 1 && ev(110)) { note(660, 0.15, 'triangle', 0.1, 0); note(990, 0.25, 'triangle', 0.1, 0.12); } }
        return;
    }
    const T = ending ? END_CUTS[i].title : '';
    switch (ending ? ({ 'THE LAST POP': 'pop', 'THE FALL': 'death', 'THE ARMADA FALLS': 1, 'THE GOLDEN SOMBRERO': 2, 'THE LONG WAY DOWN': 3, 'THE ROAD HOME': 4, 'THE PLAZA AWAKENS': 5 }[T] ?? 'dark') : i) {
        case 'pop': {
            const k = clamp(t / 240, 0, 1);
            if (t % 3 === 0 && t < 235) nz(0.05 + 0.2 * k, 'lowpass', 160 + 300 * k, 0.1);
            if (t % Math.max(14, Math.round(44 - 28 * k)) === 0 && t < 235) note(48, 0.18, 'sine', 0.28, 0);
            if (t === 20) note(300, 6, 'sawtooth', 0.045, 0, null, { slide: 1500 });
            if (t >= 215 && t < 245 && t % 4 === 0) nz(0.1, 'highpass', 3000 + (t - 215) * 120, 0.15);
            break; }
        case 'dark': {
            if (T === 'THE LAST BOTTLE' && t === 70) { nz(0.1, 'bandpass', 1800, 1.2); ghostWail(0, 150, 1.6, 0.6, { glide: 0.75 }); }
            if (T === 'THE TOAST') [60, 105, 150, 195, 235].forEach(t0 => { if (t === t0) { ghostWail(0, 300 + (t0 % 3) * 40, 1.4, 0.7, { glide: 0.68 }); nz(0.12, 'lowpass', 700, 0.5); } });
            if (T === 'THE REVENGE') { if (t % 130 === 0) { nz(0.5, 'lowpass', 600, 1.4); note(40, 1.6, 'sine', 0.4, 0); } if (t === 80 || t === 130) { ghostWail(0, 260, 1.2, 0.8, { v: 'A', glide: 0.6, fs: 0.9 }); } if (t % 20 === 0) nz(0.05, 'bandpass', 900, 0.4); }
            if (T === 'THE OFFER' && t === 40) [1760, 2349, 2637].forEach((f, q) => note(f, 2.4, 'sine', 0.035, q * 0.15));
            if (T === 'THE REFUSAL') { if (t === 36) note(120, 0.5, 'sine', 0.1, 0); if (t === 46) { speakSyn(0, [['A', 230, 5, 520, 1.1], ['I', 600, 9, 980, 1.2, undefined, true]], 1.0, { cv: true, fs: 0.82, tilt: 1.3, breath: 0.15, vib: 30, wander: 20, jit: 200, verb: 0.7, dip: 0.3, rasp: 0.3, lp: 5200 }); nz(0.2, 'highpass', 3000, 1.6); } if (t === 84) { ghostWail(0, 700, 1.8, 0.8, { v: 'I', glide: 0.4, fs: 0.9 }); nz(0.25, 'bandpass', 2500, 1.4); } if (t > 90 && t < 220 && t % 7 === 0) nz(0.1, 'bandpass', 3500 - t * 6, 0.1); if (t === 214) { note(48, 2.2, 'sine', 0.5, 0); nz(0.4, 'lowpass', 600, 0.8); } }
            if (T === 'THE PLUNDER') { if (t === 20) { nz(0.12, 'bandpass', 2500, 0.3); ghostWail(0, 330, 0.9, 0.7, { v: 'A', glide: 0.7, fs: 1.1 }); } [34, 55, 76, 98, 121, 145, 170].forEach((t0, q) => { if (t === t0) { note(2500 + q * 90, 0.3, 'triangle', 0.05, 0); note(3300 + q * 90, 0.2, 'triangle', 0.03, 0.04); } }); }
            if (T === 'THE PORTRAIT' && t === 100) { nz(0.15, 'lowpass', 500, 0.3); note(60, 0.5, 'sine', 0.2, 0); }
            if (T === 'THE CROWNING' && t === 150) { note(196, 2.6, 'sawtooth', 0.03, 0); [784, 988, 1175].forEach((f, q) => note(f, 2, 'sine', 0.04, q * 0.1)); }
            if (T === 'THE REHEARSAL' && t === 130) { ghostWail(0, 420, 1.2, 0.7, { v: 'A', glide: 0.45 }); nz(0.1, 'bandpass', 2000, 0.6); }
            break; }
        case 'death': {
            if (t === 1) { nz(0.9, 'lowpass', 2500, 0.5); note(55, 1.8, 'sine', 0.55, 0); note(38, 2.4, 'sine', 0.4, 0); nz(0.4, 'highpass', 4000, 0.7); }
            if (t === 6) note(900, 2.2, 'sine', 0.14, 0, null, { slide: -780 });
            if (t === 14) note(400, 1.8, 'triangle', 0.06, 0, null, { slide: -300 });
            if (t > 20 && t < 150 && t % 9 === 0) nz(0.12, 'bandpass', 1500 - t * 6, 0.18);
            if (t === 112) { note(392, 2.4, 'sine', 0.11, 0, null, { slide: 120 }); note(311, 2.6, 'sine', 0.08, 0.1); }
            if (t === 160) [1568, 2093, 2637, 3136].forEach((f, q) => note(f, 1.2, 'sine', 0.07, q * 0.12));
            break; }
        case 0: if (ev(2) || ev(55) || ev(110)) { nz(0.35, 'lowpass', 700, 0.6); note(90, 0.4, 'sawtooth', 0.15, 0, null, { slide: -50 }); } if (!ending && t > 25 && t < 220 && t % 3 === 0) note(1400 - t * 4, 0.12, 'sine', 0.025, 0); if (ev(190)) { nz(0.3, 'bandpass', 1500, 0.5); } break;
        case 1: if (t % 40 === 5) { nz(0.18, 'lowpass', 500, 0.6); note(100 - (t % 120) * 0.3, 0.5, 'sawtooth', 0.1, 0, null, { slide: -40 }); } if (t % 40 === 20) note(1000, 0.6, 'sine', 0.03, 0, null, { slide: -700 }); if (ev(150)) nz(0.4, 'lowpass', 400, 1.2); break;
        case 2: if (ev(5)) { note(1200, 0.7, 'sine', 0.05, 0, null, { slide: 800 }); noiseHit(0, 0.05, 'highpass', 6000, 0.7); } if (ev(60)) { [880, 1175, 1568, 2093].forEach((f, k) => note(f, 0.6, 'sine', 0.05, k * 0.09)); } if (!ending && t > 80 && t % 24 === 0) note(1800 + (t % 5) * 200, 0.25, 'sine', 0.03, 0); break;
        case 3: if (t % 90 === 0) nz(0.12, 'bandpass', 600 + (t % 3) * 300, 1.5); if (t % 70 === 30) { nz(0.12, 'lowpass', 350, 1.2); note(55, 1.2, 'sawtooth', 0.12, 0, null, { slide: -10 }); } if (t % 55 === 20) note(1600, 0.3, 'sine', 0.025, 0, null, { slide: -900 }); break;
        case 4: if (!ending && t % 6 === 0) { note(55 + (t % 12), 0.08, 'sawtooth', 0.06, 0); } if (t % 60 === 10) { note(520, 0.12, 'square', 0.06, 0); note(520, 0.18, 'square', 0.06, 0.14); } if (t % 45 === 0) nz(0.1, 'bandpass', 900, 0.6); break;
        case 5: if (!ending && t % 12 === 0) note(1100 + (t % 36) * 8, 0.04, 'square', 0.04, 0); if (t % 20 === 6) nz(0.07, 'bandpass', 4800, 0.05); if (t % 80 === 0) note(180, 0.6, 'sine', 0.05, 0, null, { slide: -80 }); if (ev(150)) { note(520, 0.3, 'triangle', 0.07, 0); note(780, 0.4, 'triangle', 0.07, 0.1); } break;
        case 6: if (ev(8)) { nz(0.18, 'lowpass', 900, 0.15); note(150, 0.15, 'square', 0.1, 0); note(120, 0.2, 'square', 0.1, 0.12); } if (t % 50 === 20) nz(0.05, 'bandpass', 1200, 0.5); if (t % 130 === 60) { note(2000, 0.1, 'triangle', 0.05, 0); note(2400, 0.2, 'triangle', 0.05, 0.08); } break;
        case 7: if (!ending && t % 30 === 0) { note(1760 + (t % 4) * 220, 0.35, 'sine', 0.035, 0); } if (t % 75 === 12) note(1200, 0.5, 'sine', 0.025, 0, null, { slide: 400 }); break;
        case 8: if (ev(10)) note(440, 0.9, 'sine', 0.05, 0); if (ev(60)) note(660, 0.9, 'sine', 0.05, 0); if (ev(130)) { [0, 1, 2].forEach(k => nz(0.1, 'bandpass', 2500, 0.08, k * 0.35)); } if (ev(210)) { nz(0.3, 'highpass', 3500, 0.5); note(880, 0.3, 'triangle', 0.08, 0); } break;
        case 9: if (t % 55 === 15) { nz(0.3, 'bandpass', 1300, 0.12); note(180, 0.1, 'square', 0.15, 0, null, { slide: -90 }); } if (t % 55 === 22 && t > 60) { for (let k = 0; k < 5; k++) note(1800 + k * 300 + (t % 7) * 40, 0.08, 'triangle', 0.045, k * 0.04); } if (t % 110 === 100) note(1500, 0.3, 'sine', 0.06, 0); break;
        case 10: if (t % 32 === 0) nz(0.1, 'bandpass', 3000, 0.18); if (t % 64 === 8) { nz(0.18, 'bandpass', 1800, 0.9); } if (t % 40 === 20) note(1500, 0.14, 'triangle', 0.04, 0); if (t % 45 === 30) note(300 + (t % 3) * 80, 0.2, 'sawtooth', 0.03, 0, null, { slide: 120 }); break;
        case 11: { const ph = (t * 0.02) % 1, per = Math.floor(t * 0.02);   // match csFireworks: 4 launchers, phase offset 0.27
            for (let k = 0; k < 4; k++) { const p0 = (t * 0.02 + k * 0.27) % 1, p1 = ((t - 1) * 0.02 + k * 0.27) % 1;
                if (p1 > p0) note(500, 0.5, 'sine', 0.035, 0, null, { slide: 1100 });   // launch whistle at the phase wrap
                if (p1 < 0.15 && p0 >= 0.15) { nz(0.28, 'lowpass', 500, 0.5); note(70, 0.35, 'sine', 0.22, 0, null, { slide: -40 }); nz(0.1, 'highpass', 5000, 0.5); } }
            if (t % 7 === 0 && t > 40) nz(0.03, 'highpass', 7000, 0.04); break; }
        case 12: if (t % 40 === 0) { [0, 1, 2].forEach(k => note(2400 + (((t / 40) | 0) * 230 + k * 330) % 900, 0.07, 'sine', 0.035, k * 0.09)); } if (t % 90 === 45) { note(1800, 0.12, 'triangle', 0.03, 0); note(2200, 0.18, 'triangle', 0.03, 0.1); } if (t % 100 === 30) nz(0.04, 'lowpass', 600, 1.2); break;
        case 13: if (ev(8)) { note(130, 1.2, 'sine', 0.12, 0); note(196, 1.2, 'sine', 0.08, 0); nz(0.08, 'bandpass', 1200, 0.6); } if (t % 120 === 100) note(1568, 1, 'sine', 0.035, 0); break;
        case 14: if (ev(5) || ev(70)) { nz(0.25, 'bandpass', 1400, 1.2); nz(0.1, 'highpass', 4500, 0.9); } if (t % 28 === 0) note(1500 + (t % 4) * 150, 0.14, 'triangle', 0.04, 0); if (t % 60 === 30) { nz(0.15, 'highpass', 5000, 0.2); } break;
    }
}

// ---- the voice cues, rebuilt on the speech synthesizer (real consonants, gliding vowels). Timings follow SYLT so the menu hero's mouth still matches ----
const SV = 0.85;
function arriba(dl) { if (cue('arriba', dl)) return;   // "¡A-rri-ba! ¡A-rri-ba!"
    shout(dl, 'Arriba!', 'cry', [['A', 190, 0.8], ['R', 215], ['I', 260, 0.9], ['B', 270], ['A', 290, 1.2]], { mood: 'cheer', vol: SV });
    shout(dl + 0.56, 'Arriba!', 'cry', [['A', 230, 0.8], ['R', 255], ['I', 320, 0.9], ['B', 330], ['A', 340, 2.2]], { mood: 'cheer', vol: SV });
}
function grito(dl) { if (cue('grito', dl)) return;    // "¡Aaaay-ya-ya-ya-yaaay!"
    shoutRaw(dl, [['A', 330, 1.6], ['I', 480, 1.4], ['Y', 520, 0.8], ['A', 470, 0.9], ['Y', 430, 0.8], ['A', 400, 0.9], ['Y', 380, 0.8], ['A', 360, 0.9], ['A', 330, 1.6], ['I', 300, 2.4]], 'cry', 0.9, 'cheer');
}
function andaleVoice(dl) { if (cue('andale', dl)) return;   // "¡An-DA-le!"
    shout(dl, 'Andale!', 'cry', [['A', 180, 0.7], ['N', 200, 0.8], ['D', 240], ['A', 310, 1.4], ['L', 260], ['EH', 210, 1.2]], { mood: 'cheer', vol: 0.95 });
    crowd(dl + 0.3, 1.8, 0.6);
}
function porque(dl) { if (cue('porque', dl)) return;   // "¿Por-qué?" with a rising question tone
    shout(dl, 'Por que?', 'cry', [['P', 190], ['O', 200, 0.8], ['R', 205, 1.2], ['K', 215], ['EH', 250, 0.9], ['EH', 380, 1.6]], { mood: 'plead', vol: SV });
}
function si(dl) { if (cue('si', dl)) return;       // bright "¡Sí!"
    shout(dl, 'Si!', 'cry', [['S', 270, 0.8], ['I', 280, 1.4], ['I', 320, 0.8]], { mood: 'cheer', vol: SV });
}
function ole(dl) { if (cue('ole', dl)) return;      // "¡O-LÉ!" with the crowd
    shout(dl, 'Ole!', 'cry', [['O', 200, 1.3], ['L', 230], ['EH', 250, 1.4], ['EH', 340, 1.6]], { mood: 'cheer', vol: SV });
    crowd(dl + 0.1);
}
function toro(dl) { if (cue('toro', dl)) return;     // "¡TO-ro!" ... then "¡Olé!"
    shout(dl, 'Toro!', 'cry', [['T', 200], ['O', 235, 1.4], ['R', 225, 0.8], ['O', 170, 1.7]], { mood: 'rage', vol: SV });
    ole(dl + 0.95);
}
function noprob(dl) { if (cue('noprob', dl)) return;   // "No pro-ble-mo!" (relaxed) + a little cheer
    shout(dl, 'Noh problemo.', 'guitar', [['N', 150, 0.9], ['O', 160, 1.3], ['P', 165], ['R', 175, 0.8], ['O', 180, 1.0], ['B', 185], ['L', 190], ['EH', 190, 1.0], ['M', 190], ['O', 165, 1.8]], { mood: 'chill', vol: 0.8 });
    crowd(dl + 0.85, 1.6, 0.6);
}
function spell(dl) { if (cue('spell', dl)) return;    // bubbly "Spell-ing is fun!"
    shout(dl, 'Spelling is fun!', 'kid', [['S', 430, 0.7], ['P', 440], ['EH', 470, 0.9], ['L', 480], ['IH', 520, 0.9], ['N', 520], ['IH', 560, 0.9], ['Z', 560], ['F', 600], ['AH', 650, 1.4], ['N', 640], ['I', 700, 2.4]], { mood: 'cheer', range: 0.8, vol: 0.7 });
    [1568, 1976, 2349, 2637].forEach((f, i) => tone(f, 0.18, 'triangle', 0.05, 0, dl + 0.95 + i * 0.07, musGain));
}
function frijol(dl) { if (cue('frijol', dl)) return;   // "¡Fri-JO-les!"
    shout(dl, 'Frijoles!', 'cry', [['F', 200], ['R', 210], ['I', 215, 0.9], ['H', 215], ['O', 230, 1.4], ['L', 200], ['EH', 180, 1.0], ['S', 170]], { mood: 'cheer', vol: SV });
    for (let i = 0; i < 4; i++) shaker(dl + 0.1 + i * 0.1, 0.07);
}
function ay(dl, f, len) {   // a low, rough "¡Ay!" (ah → ee, falling)
    shoutRaw(dl, [['A', f * 1.1, 0.8], ['I', f * 0.8, Math.max(1, len / 0.14)]], 'cry', 0.8, 'rage');
}
const MX_PHRASES = ['Arriba!', 'Andale!', 'Orale!', 'Que padre!', 'Viva Mexico!', 'Ajua!', 'Hijole!', 'Fiesta!', 'Que chido!', 'Echale ganas!', 'Ay caramba!', 'Muy bien!', 'Vamonos!', 'Eso es!', 'Ni modo!', 'Dale, dale, dale!', 'Que viva la fiesta!', 'Ay, compadre!'];
let mxLast = -1;
CUEFN.arriba = arriba; CUEFN.grito = grito; CUEFN.toro = toro; CUEFN.ole = ole; CUEFN.noprob = noprob; CUEFN.spell = spell; CUEFN.frijol = frijol; CUEFN.andale = andaleVoice; CUEFN.porque = porque; CUEFN.si = si;

const shoutLog = [];
let ACT = TRACKS.menu, musTrack = 'menu';

function harmonyOf(m, ch) {
    const pcs = ch.v.map(n => n % 12).concat(ch.r % 12);
    for (let d = 3; d <= 5; d++) if (pcs.includes(((m - d) % 12 + 12) % 12)) return m - d;
    return m - 3;
}

// menu-song voices: the same mariachi band as the game song (trumpets in thirds, violins, vihuela, guitarron) on a brisk 4/4 polka-ranchera groove
function trumpV(m, dur, v, dl) { if (smpNote('trumpet', m, dur, v, 0.05, dl, { pan: -0.22 })) return; const f = mf(m); note(f, dur, 'sawtooth', v, dl, musGain, { att: 0.02, vib: true, lp: [2.5, 9, 0.09], pan: -0.22 }); note(f, dur, 'square', v * 0.4, dl, musGain, { att: 0.02, pan: -0.22 }); }   // brass 'blat': cutoff opens just after the attack
function violV(m, dur, v, dl) { if (smpNote('violin', m, dur, v, 0.048, dl, { pan: 0.28, att: 0.04 })) return; note(mf(m), dur, 'sawtooth', v, dl, musGain, { att: 0.06, vib: true, lp: [3.5, 7, 0.18], pan: 0.28 }); note(mf(m) * 1.004, dur, 'sawtooth', v * 0.5, dl, musGain, { att: 0.07, vib: true, lp: [3.5, 7, 0.18], pan: 0.28 }); note(mf(m + 12), dur, 'triangle', v * 0.4, dl, musGain, { att: 0.08, vib: true, pan: 0.28 }); }   // second, slightly detuned string = ensemble
function pluck(m, dur, v, dl) { if (smpNote('guitar', m, dur, v, 0.11, dl, { pan: -0.15 })) return; note(mf(m), dur, 'triangle', v, dl, musGain, { att: 0.003, pan: -0.15 }); note(mf(m), dur * 0.5, 'square', v * 0.3, dl, musGain, { lp: [14, 2.5, dur * 0.5], pan: -0.15 }); }   // bright pick attack that mellows
const beatLog = [];   // {t,s}: audio time of each quarter-note beat, so the menu hero can dance on it
let musT0 = 0;
function strum(ch, delay, down, v) {
    const notes = down ? ch.v : ch.v.slice().reverse();
    if (smpHas('guitar')) { notes.forEach((n, i) => smpNote('guitar', n, down ? 0.24 : 0.15, v * (down ? 1 : 0.8), 0.05 * Math.sqrt(notes.length), delay + i * 0.011, { pan: (i / Math.max(1, notes.length - 1) - 0.5) * 0.5 })); return; }
    notes.forEach((n, i) => {
        const pan = (i / Math.max(1, notes.length - 1) - 0.5) * 0.5;   // strings spread left to right across the strum
        note(mf(n), 0.14, 'square', v * 0.6, delay + i * 0.011, musGain, { lp: [14, 2.5, 0.12], pan });
        note(mf(n), 0.18, 'triangle', v, delay + i * 0.011, musGain, { pan });
    });
}
let MUS_E = TRACKS.menu.e;
const ARP = [[0,1,2,3,2,1], [0,2,1,3,2,1], [3,2,1,0,1,2], [0,1,2,1,2,3], [0,2,3,2,1,0]];
const STRUMV = [[1,2,4,5], [1,2,3,5], [1,3,4,5]];
function musicStep(st, dl) {
    if (ACT.kind === 'seq') { seqStep(st, dl); return; }
    const SG = ACT.song, MELODY = ACT.mel;
    const nb = SG.length, bi = Math.floor(st / 6) % nb, slot = st % 6;
    const B = SG[bi], N = SG[(bi + 1) % nb], ch = B.ch, inst = B.inst, odd = bi % 2 === 1, out = musGain;
    const hv = 0.9 + Math.random() * 0.2;   // humanize
    if (slot === 0 && B.cue && CUEFN[B.cue]) CUEFN[B.cue](dl);

    // guitarrón: root / fifth, hemiola (3-feel) on odd bars, walking approach notes
    const bassSlots = inst === 'break' ? [0] : inst === 'ballad' ? [0, 3] : (odd ? [0, 2, 4] : [0, 3]);
    if (B.i === 0 && slot === 0) cymbal(dl, 0.045);   // cymbal crash on each new section
    if (B.end && B.i >= 3 && slot === 0 && inst !== 'break') riser(dl, MUS_E * 6, 0.04);   // lift into the next section
    if (bassSlots.includes(slot)) {
        const n = slot === 0 ? ch.r : ch.f;
        if (!smpNote('bass', n, 0.3, 0.2 * hv, 0.17, dl, { dest: out })) {
            note(mf(n), 0.3, 'triangle', 0.2 * hv, dl, out, { slide: -3 });
            note(mf(n + 12), 0.12, 'sine', 0.06, dl, out);
        }
    }
    if (slot === 5 && !odd && inst !== 'break' && Math.random() < 0.4) { const an = N.ch.r + (Math.random() < 0.6 ? -1 : 1); smpNote('bass', an, 0.14, 0.14, 0.17, dl, { dest: out }) || note(mf(an), 0.14, 'triangle', 0.14, dl, out); }

    // vihuela / guitar strums (pattern depends on the section)
    if (inst === 'solo') {
        if (slot === 2 || slot === 5) strum(ch, dl, slot === 2, 0.03);
    } else if (inst === 'break') {
        if (B.i >= 6) strum(ch, dl, slot % 2 === 1, 0.03 + 0.012 * (B.i - 6));
        else if (slot === 2 || slot === 5) strum(ch, dl, slot === 2, 0.035);
    } else if (inst === 'ballad') {
        if (slot === 0 || slot === 3) strum(ch, dl, slot === 0, 0.025);
    } else {
        const ss = odd ? [1, 3, 5] : STRUMV[(bi * 7 + 3) % 3];
        if (ss.includes(slot)) strum(ch, dl, slot % 2 === 1, 0.05 * hv);
    }
    if (B.i % 8 === 7 && slot === 5 && inst !== 'break') { strum(ch, dl + MUS_E * 0.5, false, 0.035); strum(ch, dl + MUS_E * 0.75, true, 0.03); }

    // shaker and claps
    shaker(dl, (bassSlots.includes(slot) ? 0.06 : 0.032) * (inst === 'break' ? 1.4 : inst === 'ballad' ? 0.3 : 1));
    if (inst === 'break' && B.i >= 2 && (slot === 2 || slot === 5)) clap(dl, 0.06);
    if (inst === 'break' && B.i === 7 && slot >= 3) clap(dl, 0.04 + 0.01 * slot);   // snare-roll style build

    // string pad under the violin sections
    if ((inst === 'violin' || inst === 'duet' || inst === 'ballad' || inst === 'accordion') && slot === 0) ch.v.forEach(n => smpNote('pad', n - 12, MUS_E * 6, 0.035, 0.03, dl, { dest: out, att: 0.12 }) || note(mf(n - 12), MUS_E * 6, 'triangle', 0.035, dl, out, { att: 0.12 }));

    // guitar solo: arpeggios, with trumpet answers
    if (inst === 'solo' || inst === 'ballad') {
        const vs = inst === 'ballad' ? 0.55 : 1;
        const ct = ch.v.concat(ch.v[0] + 12), pat = ARP[(bi * 3 + 1) % 5], n = ct[pat[slot] % ct.length] + (slot === 5 && B.i % 4 === 3 ? 12 : 0);
        if (!smpNote('guitar', n, 0.4, 0.1 * hv * vs, 0.11, dl, { dest: out })) {
            note(mf(n), 0.24, 'triangle', 0.1 * hv * vs, dl, out);
            note(mf(n), 0.14, 'square', 0.03 * vs, dl, out);
        }
        if (inst === 'solo' && B.i % 4 === 3 && slot === 4) ch.v.forEach(x => smpNote('trumpet', x, 0.22, 0.035, 0.05, dl, { dest: out }) || note(mf(x), 0.22, 'sawtooth', 0.035, dl, out, { att: 0.02, vib: true }));
    }

    // melody voices
    const m = MELODY[bi * 6 + slot];
    if (m > 0 && inst !== 'solo' && inst !== 'break') {
        let holds = 0;
        while (MELODY[bi * 6 + slot + 1 + holds] === -1) holds++;
        const dur = (1 + holds) * MUS_E * 0.97, loud = inst === 'coda' ? 1.25 : 1;
        if (inst === 'trumpet' || inst === 'coda' || inst === 'duet') {
            const grace = (Math.random() < 0.22 && MELODY[bi * 6 + slot - 1] !== -1) ? 0.045 : 0;
            const k = inst === 'duet' ? 0.8 : 1, d0 = dl + grace;
            if (smpHas('trumpet')) {
                if (grace) smpNote('trumpet', m + 2, grace, 0.04, 0.05, dl, { dest: out, pan: -0.22 });
                smpNote('trumpet', m, inst === 'duet' ? dur : Math.min(dur, Math.max(0.16, dur * 0.62)), 0.05 * k * loud, 0.05, d0, { dest: out, pan: -0.22, att: 0.008 });
                smpNote('trumpet', harmonyOf(m, ch), inst === 'duet' ? dur : Math.min(dur, Math.max(0.16, dur * 0.62)), 0.038 * k * loud, 0.05, d0, { dest: out, pan: -0.22, att: 0.008 });
            } else {
            if (grace) note(mf(m + 2), grace, 'sawtooth', 0.04, dl, out);
            note(mf(m), dur, 'sawtooth', 0.05 * k * loud, d0, out, { att: 0.02, vib: true });
            note(mf(m), dur, 'square', 0.02 * k * loud, d0, out, { att: 0.02 });
            note(mf(harmonyOf(m, ch)), dur, 'sawtooth', 0.038 * k * loud, d0, out, { att: 0.025, vib: true });
            }
        }
        if (inst === 'violin' || inst === 'duet' || inst === 'ballad') {
            const k = inst === 'duet' ? 0.85 : inst === 'ballad' ? 0.95 : 1, at = inst === 'ballad' ? 0.12 : 0.07;
            if (smpHas('violin')) smpNote('violin', m, dur, 0.045 * k, 0.048, dl, { dest: out, pan: 0.28, att: at }); else {
            note(mf(m), dur, 'sawtooth', 0.045 * k, dl, out, { att: at, vib: true });
            note(mf(m + 12), dur, 'triangle', 0.02 * k, dl, out, { att: at + 0.02, vib: true });
            }
        }
        if (inst === 'accordion' && smpHas('accordion')) { smpNote('accordion', m, dur, 0.04, 0.04, dl, { dest: out, att: 0.03 }); smpNote('accordion', harmonyOf(m, ch), dur, 0.02, 0.04, dl, { dest: out, att: 0.04 }); }
        else if (inst === 'accordion') {   // reedy: detuned saw + square + octave, with a breathing swell
            note(mf(m), dur, 'sawtooth', 0.04, dl, out, { att: 0.03 });
            note(mf(m) * 1.006, dur, 'square', 0.026, dl, out, { att: 0.03 });
            note(mf(m - 12), dur, 'sawtooth', 0.022, dl, out, { att: 0.04 });
            note(mf(harmonyOf(m, ch)), dur, 'square', 0.02, dl, out, { att: 0.04 });
        }
    }
    // end-of-section guitar run
    if (B.end && inst !== 'break' && slot >= 3) {
        const ct = ch.v.concat(ch.v[0] + 12);
        [0, 0.5].forEach((hf, j) => { const rn = ct[Math.max(0, ct.length - 1 - ((slot - 3) * 2 + j))] + 12; smpNote('guitar', rn, 0.2, 0.07, 0.11, dl + hf * MUS_E, { dest: out }) || note(mf(rn), 0.1, 'triangle', 0.07, dl + hf * MUS_E, out); });
    }
    // upbeat trumpet stabs: a sharp third-stacked chord on the 'and' of the bar, every fourth bar
    if ((inst === 'trumpet' || inst === 'coda') && B.i % 4 === 3 && (slot === 2 || slot === 5)) ch.v.slice(0, 2).forEach((x, j) => smpNote('trumpet', x + 12, 0.11, 0.045, 0.05, dl, { dest: out, pan: -0.22 + j * 0.2, att: 0.006 }) || note(mf(x + 12), 0.11, 'sawtooth', 0.04, dl, out, { att: 0.006, lp: [3, 9, 0.05] }));
    // big final chord
    if (inst === 'coda' && B.i === 7 && slot === 0) { strum(ch, dl, true, 0.09); strum(ch, dl + 0.05, false, 0.07); }
}
function startMusic() {
    if (musTimer || !AC) return;
    musNext = AC.currentTime + 0.1; musT0 = musNext;
    musTimer = setInterval(() => {
        if (!AC || !OPT.music || AC.state !== 'running') { if (AC) musNext = Math.max(musNext, AC.currentTime); return; }   // the Voice Lab silences the band so the words can be heard
        // the menu has its own song; the original plays once you hit RIDE (cutscene, runs, pause, results)
        const want = musicWant();
        if (want !== musTrack) { musTrack = want; ACT = TRACKS[want]; MUS_E = ACT.e; musStep = 0; musNext = AC.currentTime + 0.12; musT0 = musNext; }
        if (musNext < AC.currentTime - 0.25) musNext = AC.currentTime + 0.05;   // fell far behind: skip ahead rather than burst-play
        while (musNext < AC.currentTime + 0.4) {
            musicStep(musStep, Math.max(0, musNext - AC.currentTime));
            musNext += MUS_E; musStep++;
            if (musStep % 16 === 8 && ACT.song && ACT.song[Math.floor(musStep / 16) % ACT.song.length].half) musStep += 8;   // a half bar (a held word's ring-out): play eight steps (two whole beats, so the next section stays on the beat), then move on
        }
    }, 100);
}
function vib(ms) { if (OPT.haptics && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) {} } }