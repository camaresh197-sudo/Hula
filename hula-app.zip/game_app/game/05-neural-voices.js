// ---- CUTSCENE VOICES: every spoken cutscene line uses the built-in synth. The pre-rendered Piper clips that used to live here were removed to save space; these stubs keep csSpeak/csLineStart unchanged.
const neuralHas = ln => false;
const neuralFit = (ln, pl) => {};
const neuralPlay = l => false;
// ---- NEURAL VICTORY-SONG VOICE (whole lines). Each verse line is ONE continuous clip: an English Piper voice reads the whole line, the words are aligned to the beats, and Praat PSOLA bends the speech
//      onto the melody (two octaves below the written notes, the band's key) and holds each vowel for its note, so the words keep their natural flow. The "Jeff is gay" lines stay on the synth.
//      Key = 'word:midi word:midi ...' for the line -> [seconds, seconds before the first beat, mp3]. Made by gen_lines.py/songline.py (not in the project).
const NSONG = {"jakes:71 mom:74 plays:71 with:67 jeff:69 all:66 day:62":[3.438,0.12,"@@B110@@"],"to:64 make:67 jeff:72 feel:67 way:69 less:66 gay:74":[4.464,0.044,"@@B111@@"],"gay:69 gay:72 gay:71 gay:69 jeff's:69 so:69 gay:74":[3.505,0.044,"@@B112@@"],"gay:67 gay:71 gay:74 gay:74":[2.46,0.044,"@@B113@@"],"fun:71 for:71 all:74 come:74 on:71 hey:74":[3.176,0.04,"@@B118@@"],"jake:67 is:71 baked:74 jeff:71 wants:71 to:67 bate:64":[3.518,0.12,"@@B143@@"],"he'll:67 fuck:71 jake:74 on:71 their:67 next:71 date:64":[3.428,0.03,"@@B145@@"],"jeff:67 has:72 done:67 that:72 most:69 the:66 day:74":[3.672,0.15,"@@B147@@"],"what:64 a:64 shame:69 that:72 jake:69 is:69 straight:74":[4.214,0.04,"@@B148@@"]};
const NSONG_HYB = 0;   // how much of the synth is layered under each neural line (0 = neural only)
let NSONG_ON = true; try { NSONG_ON = localStorage.getItem('hulaVaquero_nsong') !== '0'; } catch (e) {}
const NSONG_BUF = {}; let nsongStarted = false;
function nsongPreload() {   // decode all song lines once audio exists, so the first verse already has them
    if (nsongStarted || !AC) return; nsongStarted = true;
    Object.keys(NSONG).forEach(k => { try { const bin = atob(NSONG[k][2]), u = new Uint8Array(bin.length); for (let j = 0; j < bin.length; j++) u[j] = bin.charCodeAt(j); AC.decodeAudioData(u.buffer).then(b => { NSONG_BUF[k] = b; }, () => { NSONG_BUF[k] = false; }); } catch (err) { NSONG_BUF[k] = false; } });
}
function nsongLine(dl, syls, vol) {   // true when a neural clip was scheduled for this whole lyric line
    if (!NSONG_ON || !AC) return false; nsongPreload();
    const key = syls.map(s => s[0].toLowerCase() + ':' + s[3]).join(' '), b = NSONG_BUF[key]; if (!b) return false;
    const src = AC.createBufferSource(), g = AC.createGain(), send = AC.createGain(); src.buffer = b; g.gain.value = 1.9 * vol; src.connect(g); g.connect(speechBus());
    send.gain.value = 0.1; g.connect(send); send.connect(speechVerb());
    const t0 = AC.currentTime + Math.max(0, dl - NSONG[key][1] + 0.01); src.start(t0); src.onended = () => { g.disconnect(); send.disconnect(); };
    nsongDuck(t0, t0 + b.duration);
    return true;
}
// the band dips under each sung word so the lyrics come through: ~-5 dB on the music bus while a word sounds, easing back between words
let nsDuckRel = 0;
function nsongDuck(t0, t1) {
    if (!OPT.music || !musGain || csHushed) return; const base = 1, p = musGain.gain;
    try {
        if (nsDuckRel > 0 && nsDuckRel >= AC.currentTime) p.cancelScheduledValues(nsDuckRel);
        if (t0 > nsDuckRel + 0.001) p.setTargetAtTime(base * 0.55, t0, 0.03);
        p.setTargetAtTime(base, t1, 0.15); nsDuckRel = t1;
    } catch (e) {}
}