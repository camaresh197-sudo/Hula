
// =====================================================================
//  HERO HD: same vaquero, ~10x the drawn detail. Static art is painted once into cached
//  layers (legs, boots, poncho/gear, head, sombrero); only arms and hoop animate per frame.
// =====================================================================
function hvLayer(name, x0, y0, x1, y1, sq, extra, fn) {   // paint a layer once (hero units -> pixels), then blit it
    const SR = Math.min(RES, 6), key = name + '|' + sq + '|' + SR + '|' + extra;
    if (HV.size > 120) HV.clear();
    const e = cachedDraw(HV, key, -x0 * sq, -y0 * sq, (x1 - x0) * sq, (y1 - y0) * sq, SR, () => { ctx.scale(sq, sq); fn(); });
    ctx.drawImage(e.cv, x0, y0, x1 - x0, y1 - y0);
}
const dot = (x, y, r, c) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); };
const ln = (x0, y0, x1, y1, w, c) => { ctx.strokeStyle = c; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); };
function stud(x, y, r, base, hi) {   // metal stud: rim, face, highlight
    dot(x, y, r, 'rgba(0,0,0,0.45)'); dot(x, y, r * 0.82, base); dot(x - r * 0.2, y - r * 0.25, r * 0.45, hi); dot(x - r * 0.35, y - r * 0.4, r * 0.15, '#fff');
}

// ---- legs: charro trousers with weave, concho seam, greca embroidery, flared hem ----
function hvLegs() {
    const R = mulberry(11);
    for (const L of [{ x: -5.6, w: 5, y1: 17.2 }, { x: 0.6, w: 5, y1: 16.2 }]) {
        const poly = () => { ctx.beginPath(); ctx.moveTo(L.x, 1); ctx.lineTo(L.x + L.w, 1); ctx.lineTo(L.x + L.w + 0.8, L.y1); ctx.lineTo(L.x - 0.8, L.y1); ctx.closePath(); };
        ctx.fillStyle = lg(L.x, 0, L.x + L.w, 0, [[0, '#1d2740'], [0.35, '#3f5180'], [0.55, '#51659a'], [1, '#222d4a']]); poly(); ctx.fill();
        ctx.save(); poly(); ctx.clip();
        ctx.lineWidth = 0.12;   // woven twill
        for (let y = 1; y < L.y1; y += 0.45) { ctx.strokeStyle = (y * 10 | 0) % 2 ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.12)'; ctx.beginPath(); ctx.moveTo(L.x - 1, y); ctx.lineTo(L.x + L.w + 1, y + 0.5); ctx.stroke(); }
        for (let x = L.x; x < L.x + L.w + 1; x += 0.5) ln(x, 1, x + 0.2, L.y1, 0.1, 'rgba(0,0,0,0.1)');
        for (let k = 0; k < 75; k++) dot(L.x + R() * L.w, 1 + R() * (L.y1 - 1), 0.1, R() < 0.5 ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.15)');   // fibres
        ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.beginPath(); ctx.moveTo(L.x + L.w - 1.2, 1); ctx.lineTo(L.x + L.w, 1); ctx.lineTo(L.x + L.w + 0.8, L.y1); ctx.lineTo(L.x + L.w - 0.6, L.y1); ctx.fill();   // inner shade
        for (const ky of [5, 9, 13]) { ctx.strokeStyle = 'rgba(0,0,0,0.22)'; ctx.lineWidth = 0.25; ctx.beginPath(); ctx.moveTo(L.x + 0.3, ky); ctx.quadraticCurveTo(L.x + L.w / 2, ky + 0.7, L.x + L.w - 0.3, ky + 0.2); ctx.stroke(); }   // knee/shin creases
        ctx.restore();
        for (let k = 0; k < 12; k++) stud(L.x + L.w - 0.45 + k * 0.05, 1.8 + k * 1.3, 0.45, '#b9b9b9', '#f4f4f4');   // concho seam
        for (let k = 0; k < 7; k++) {   // greca diamonds
            const gy = 2.4 + k * 2.1; ctx.fillStyle = '#e2b13c'; ctx.beginPath(); ctx.moveTo(L.x + 0.9, gy - 0.5); ctx.lineTo(L.x + 1.4, gy); ctx.lineTo(L.x + 0.9, gy + 0.5); ctx.lineTo(L.x + 0.4, gy); ctx.fill();
            dot(L.x + 0.9, gy, 0.12, '#7d1f17');
        }
        ln(L.x - 0.8, L.y1 - 1.6, L.x + L.w + 0.8, L.y1 - 1.6, 0.35, '#e2b13c'); ln(L.x - 0.8, L.y1 - 0.9, L.x + L.w + 0.8, L.y1 - 0.9, 0.2, '#f1e6c8');   // hem trim
        ctx.strokeStyle = 'rgba(255,240,200,0.55)'; ctx.lineWidth = 0.2; ctx.setLineDash([0.4, 0.35]); ctx.beginPath(); ctx.moveTo(L.x - 0.8, L.y1 - 0.4); ctx.lineTo(L.x + L.w + 0.8, L.y1 - 0.4); ctx.stroke(); ctx.setLineDash([]);
        ln(L.x + 0.2, 1, L.x - 0.5, L.y1, 0.2, 'rgba(255,255,255,0.18)');
    }
}
// ---- boot: tooled leather, spur, medallion, stitching ----
function hvBoot(leather) {
    const R = mulberry(23), dk = shade(leather, -0.4), lt = shade(leather, 0.25), md = shade(leather, -0.15);
    ctx.fillStyle = lg(-2.6, 0, 2.6, 0, [[0, dk], [0.3, md], [0.45, lt], [1, dk]]);
    ctx.beginPath(); ctx.moveTo(-2.4, 0); ctx.lineTo(2.4, 0); ctx.lineTo(2.7, 3.6); ctx.lineTo(-2.7, 3.6); ctx.closePath(); ctx.fill();
    ctx.fillStyle = dk; ctx.beginPath(); ctx.moveTo(-2.4, 0); ctx.quadraticCurveTo(0, 1.2, 2.4, 0); ctx.lineTo(2.4, -0.5); ctx.lineTo(-2.4, -0.5); ctx.closePath(); ctx.fill();
    for (const sx of [-1, 1]) { ctx.strokeStyle = lt; ctx.lineWidth = 0.35; ctx.beginPath(); ctx.moveTo(sx * 2.2, -0.45); ctx.quadraticCurveTo(sx * 2.5, -1.1, sx * 1.7, -1.3); ctx.stroke(); dot(sx * 2.2, -0.9, 0.12, '#f1c40f'); }   // pull straps
    ctx.fillStyle = lg(0, 3, 0, 7, [[0, lt], [0.5, leather], [1, dk]]);
    ctx.beginPath(); ctx.moveTo(-2.8, 3.3); ctx.lineTo(2.8, 3.3); ctx.bezierCurveTo(4.8, 3.5, 6.2, 4.6, 6.1, 6.0); ctx.quadraticCurveTo(6.0, 6.9, 5.0, 6.9); ctx.lineTo(-2.8, 6.9); ctx.closePath(); ctx.fill();
    ctx.fillStyle = shade(leather, -0.18); ctx.beginPath(); ctx.ellipse(4.5, 5.4, 1.7, 1.35, 0.3, 0, TAU); ctx.fill();
    for (let k = 0; k < 120; k++) { const x = -2.6 + R() * 5.3, y = k < 40 ? R() * 3.5 : 3.4 + R() * 3.2; dot(x, y, 0.1 + R() * 0.07, R() < 0.5 ? 'rgba(0,0,0,0.22)' : 'rgba(255,230,190,0.2)'); }   // leather grain
    for (let k = 0; k < 14; k++) { const a = k / 14 * TAU; dot(4.5 + Math.cos(a) * 1.15, 5.4 + Math.sin(a) * 0.9, 0.11, '#25160b'); }   // toe perforations
    for (let k = 0; k < 6; k++) { const a = k / 6 * TAU + 0.3; ctx.fillStyle = shade(leather, 0.35); ctx.beginPath(); ctx.ellipse(4.5 + Math.cos(a) * 0.5, 5.4 + Math.sin(a) * 0.4, 0.25, 0.14, a, 0, TAU); ctx.fill(); }   // medallion petals
    dot(4.5, 5.4, 0.2, '#f1c40f');
    ctx.fillStyle = '#25160b'; ctx.beginPath(); ctx.moveTo(-2.9, 6.5); ctx.lineTo(5.3, 6.5); ctx.quadraticCurveTo(6.4, 6.5, 6.1, 7.4); ctx.lineTo(-2.9, 7.4); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#1a0f07'; ctx.fillRect(-2.9, 6.9, 2.6, 1.1);
    for (let k = 0; k < 6; k++) dot(-2.5 + k * 0.42, 7.7, 0.1, '#8a7a5a');   // heel nails
    for (let k = 0; k < 8; k++) ln(-1.6 + k * 0.9, 6.55, -1.4 + k * 0.9, 7.3, 0.16, 'rgba(255,224,160,0.35)');   // welt stitches
    ctx.strokeStyle = 'rgba(255,224,160,0.7)'; ctx.lineWidth = 0.3; ctx.setLineDash([0.7, 0.55]);
    ctx.beginPath(); ctx.moveTo(-1.7, 0.6); ctx.lineTo(-1.8, 3.3); ctx.moveTo(1.7, 0.6); ctx.lineTo(1.8, 3.3); ctx.moveTo(-2.5, 3.9); ctx.quadraticCurveTo(2.5, 3.5, 5.2, 4.7); ctx.moveTo(-2.5, 5.9); ctx.lineTo(3.8, 6.2); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#f1c40f'; ctx.beginPath(); for (let k = 0; k < 10; k++) { const an = k * TAU / 10 - Math.PI / 2, rr = k % 2 ? 0.4 : 1.0; ctx.lineTo(Math.cos(an) * rr, 1.8 + Math.sin(an) * rr); } ctx.fill();
    ctx.fillStyle = '#7d1f17'; ctx.beginPath(); for (let k = 0; k < 10; k++) { const an = k * TAU / 10 - Math.PI / 2, rr = k % 2 ? 0.2 : 0.5; ctx.lineTo(Math.cos(an) * rr, 1.8 + Math.sin(an) * rr); } ctx.fill();
    for (let k = 0; k < 4; k++) { ctx.fillStyle = '#e2b13c'; ctx.beginPath(); ctx.moveTo(1.3 + k * 0.0, 0.7 + k * 0.7); ctx.lineTo(1.7, 1.0 + k * 0.7); ctx.lineTo(1.3, 1.3 + k * 0.7); ctx.lineTo(0.9, 1.0 + k * 0.7); ctx.fill(); }   // shaft inlays
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fillRect(-0.9, 0.5, 0.7, 2.6);
    ctx.fillStyle = 'rgba(255,255,255,0.22)'; ctx.beginPath(); ctx.ellipse(3.4, 4.7, 1.1, 0.4, 0.3, 0, TAU); ctx.fill();
    // spur: strap, shank, spiked rowel
    ln(-2.9, 5.4, -3.6, 6.1, 0.35, '#8a8a8a'); ln(-2.9, 6.3, -3.6, 6.1, 0.35, '#8a8a8a'); ln(-3.6, 6.1, -4.6, 6.3, 0.35, '#c9c9c9');
    for (let k = 0; k < 8; k++) { const a = k * TAU / 8; ln(-4.9, 6.35, -4.9 + Math.cos(a) * 0.85, 6.35 + Math.sin(a) * 0.85, 0.18, '#dcdcdc'); }
    dot(-4.9, 6.35, 0.28, '#b8b8b8'); dot(-5.0, 6.25, 0.1, '#fff');
}
// ---- poncho + bandolier + holster + belt + lasso ----
function hvTorso() {
    const R = mulberry(37), body = () => { ctx.beginPath(); ctx.moveTo(-4, -18); ctx.lineTo(4, -18); ctx.lineTo(10.8, 2.4); ctx.lineTo(-10.8, 2.4); ctx.closePath(); };
    ctx.fillStyle = lg(-10, -18, 10, 3, [[0, '#ef5d4c'], [0.5, '#c0392b'], [1, '#6f1b14']]); body(); ctx.fill();
    ctx.save(); body(); ctx.clip();
    for (let y = -18; y < 2.4; y += 0.3) { ctx.strokeStyle = (y * 10 | 0) % 2 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.09)'; ctx.lineWidth = 0.1; ctx.beginPath(); ctx.moveTo(-12, y); ctx.lineTo(12, y); ctx.stroke(); }   // weft threads
    for (let x = -11; x < 11; x += 0.3) ln(x, -18, x * 1.2, 3, 0.08, 'rgba(0,0,0,0.07)');   // warp threads
    const band = (y, h, c) => { ctx.fillStyle = c; ctx.fillRect(-12, y, 24, h); ln(-12, y, 12, y, 0.15, 'rgba(0,0,0,0.3)'); ln(-12, y + h, 12, y + h, 0.15, 'rgba(255,255,255,0.25)'); };
    band(-4.4, 2, '#f1c40f'); band(-8.2, 1.7, '#27ae60'); band(-12, 1.3, '#2980b9'); band(-15.2, 0.8, '#f1e6c8');
    for (let r = 0; r < 4; r++) for (let k = -11; k < 12; k += 1.7) {   // woven diamond rows
        const cx = k + (r % 2) * 0.85, cy = -3.5 - r * 3.9; if (r === 1) continue;
        ctx.fillStyle = r % 2 ? '#fff6d8' : '#16a085'; ctx.beginPath(); ctx.moveTo(cx, cy - 0.6); ctx.lineTo(cx + 0.5, cy); ctx.lineTo(cx, cy + 0.6); ctx.lineTo(cx - 0.5, cy); ctx.fill();
        dot(cx, cy, 0.14, '#7d1f17');
    }
    ctx.strokeStyle = '#fff6d8'; ctx.lineWidth = 0.22; ctx.beginPath(); for (let k = -12; k < 13; k += 1.2) { ctx.lineTo(k, -6.1 - ((k / 1.2 | 0) % 2) * 0.7); } ctx.stroke();   // zigzag
    ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.beginPath(); ctx.moveTo(-3, -17); ctx.lineTo(-2, 2.4); ctx.lineTo(-5, 2.4); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.13)'; ctx.beginPath(); ctx.moveTo(3, -17); ctx.lineTo(7, 2.4); ctx.lineTo(4.4, 2.4); ctx.closePath(); ctx.fill();
    for (let k = 0; k < 150; k++) dot(-9 + R() * 18, -17 + R() * 19, 0.1, R() < 0.5 ? 'rgba(255,255,255,0.14)' : 'rgba(0,0,0,0.16)');
    ctx.restore();
    ctx.fillStyle = '#f1e6c8'; ctx.fillRect(-10.8, 2.2, 21.6, 1.9);
    for (let k = -10.2; k <= 10.2; k += 1.2) { ctx.fillStyle = k % 2.4 < 1.2 ? '#c0392b' : '#27ae60'; ctx.fillRect(k - 0.3, 2.4, 0.6, 1.3); }
    for (let k = -10.6; k <= 10.6; k += 0.9) { ctx.strokeStyle = '#f1e6c8'; ctx.lineWidth = 0.18; ctx.beginPath(); ctx.moveTo(k, 4.1); ctx.lineTo(k + (R() - 0.5) * 0.3, 5.1 + R() * 0.7); ctx.stroke(); }   // tassel fringe
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(-10.8, 4.1, 21.6, 0.4);
    ctx.fillStyle = '#2b0d09'; ctx.beginPath(); ctx.moveTo(-3.2, -18.2); ctx.lineTo(3.2, -18.2); ctx.lineTo(0, -14); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#f5f1e8'; ctx.beginPath(); ctx.moveTo(-2.4, -18.2); ctx.lineTo(2.4, -18.2); ctx.lineTo(0, -15.2); ctx.closePath(); ctx.fill();
    ln(-1.6, -18, -0.2, -15.6, 0.15, 'rgba(0,0,0,0.25)'); ln(1.6, -18, 0.2, -15.6, 0.15, 'rgba(0,0,0,0.25)');
    // bandolier: strap, stitch edges, 14 brass rounds with caps and shine
    ctx.strokeStyle = '#3d2610'; ctx.lineWidth = 2.6; ctx.lineCap = 'butt'; ctx.beginPath(); ctx.moveTo(-6.5, -15.5); ctx.lineTo(7, -0.5); ctx.stroke();
    ctx.strokeStyle = '#5a3a1c'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(-6.5, -15.5); ctx.lineTo(7, -0.5); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,224,160,0.55)'; ctx.lineWidth = 0.15; ctx.setLineDash([0.4, 0.3]); ctx.beginPath(); ctx.moveTo(-6.9, -15.3); ctx.lineTo(6.6, -0.2); ctx.moveTo(-6.1, -15.7); ctx.lineTo(7.4, -0.8); ctx.stroke(); ctx.setLineDash([]);
    for (let k = 0; k < 14; k++) {
        const t = (k + 0.5) / 14, x = -6.5 + 13.5 * t, y = -15.5 + 15 * t;
        ctx.fillStyle = '#2a1808'; ctx.fillRect(x - 0.55, y - 1.4, 1.1, 2.7);
        ctx.fillStyle = lg(x - 0.4, 0, x + 0.4, 0, [[0, '#a07a1e'], [0.4, '#f5d76e'], [1, '#8a6414']]); ctx.fillRect(x - 0.4, y - 1.2, 0.8, 1.7);
        ctx.fillStyle = '#c47a3a'; ctx.beginPath(); ctx.moveTo(x - 0.4, y - 1.2); ctx.lineTo(x, y - 1.9); ctx.lineTo(x + 0.4, y - 1.2); ctx.fill();
        dot(x - 0.15, y - 0.5, 0.1, '#fff');
    }
    // holster
    ctx.fillStyle = '#3d2410'; roundRect(5.2, -2.6, 5, 7.4, 1.4); ctx.fill();
    ctx.fillStyle = lg(5.2, 0, 10.2, 0, [[0, '#6b4426'], [0.5, '#8a5a30'], [1, '#4a2c14']]); roundRect(5.4, -2.4, 4.6, 7, 1.2); ctx.fill();
    for (let k = 0; k < 18; k++) dot(5.7 + R() * 4, -2 + R() * 6.4, 0.1, R() < 0.5 ? 'rgba(0,0,0,0.25)' : 'rgba(255,230,190,0.2)');
    ctx.strokeStyle = 'rgba(255,224,160,0.6)'; ctx.lineWidth = 0.2; ctx.setLineDash([0.4, 0.3]); roundRect(5.7, -2.1, 4, 6.4, 1); ctx.stroke(); ctx.setLineDash([]);
    for (const [rx, ry] of [[5.9, -1.9], [9.5, -1.9], [5.9, 3.7], [9.5, 3.7]]) stud(rx, ry, 0.35, '#c9c9c9', '#fff');
    ctx.fillStyle = '#e8dcc0'; roundRect(6.6, -6.2, 2.6, 4.2, 0.8); ctx.fill();
    ctx.fillStyle = lg(6.6, 0, 9.2, 0, [[0, 'rgba(255,255,255,0.4)'], [1, 'rgba(120,90,50,0.35)']]); roundRect(6.6, -6.2, 2.6, 4.2, 0.8); ctx.fill();
    for (let a = 0; a < 4; a++) for (let b = 0; b < 3; b++) { ctx.fillStyle = (a + b) % 2 ? 'rgba(90,60,30,0.28)' : 'rgba(255,255,255,0.18)'; ctx.fillRect(6.8 + b * 0.6, -5.9 + a * 0.9, 0.5, 0.8); }   // checkered grip
    dot(7.9, -4.1, 0.3, '#f1c40f'); dot(7.82, -4.18, 0.1, '#fff');
    // cartridge belt
    ctx.fillStyle = '#2f1c0c'; ctx.fillRect(-10.8, 0.4, 21.6, 1.9); ctx.fillStyle = '#4a2c14'; ctx.fillRect(-10.8, 0.5, 21.6, 0.5);
    for (let k = -10; k <= 10; k += 1.6) { ctx.fillStyle = '#d9a52a'; ctx.fillRect(k - 0.3, 0.7, 0.6, 1.2); ctx.fillStyle = '#c47a3a'; ctx.fillRect(k - 0.3, 0.7, 0.6, 0.3); dot(k - 0.1, 1.3, 0.1, '#fff'); }
    for (let k = -10.6; k <= 10.6; k += 0.8) dot(k, 2.15, 0.07, 'rgba(255,224,160,0.5)');
    ctx.fillStyle = lg(-1.6, 0.4, 1.6, 2.3, [[0, '#ffe066'], [0.5, '#c9962a'], [1, '#8a6414']]); roundRect(-1.7, 0.2, 3.4, 2.3, 0.5); ctx.fill();   // belt buckle
    ctx.strokeStyle = '#7d5a10'; ctx.lineWidth = 0.18; roundRect(-1.4, 0.5, 2.8, 1.7, 0.4); ctx.stroke();
    ctx.fillStyle = '#7d5a10'; ctx.beginPath(); for (let k = 0; k < 10; k++) { const an = k * TAU / 10 - Math.PI / 2, rr = k % 2 ? 0.25 : 0.65; ctx.lineTo(Math.cos(an) * rr, 1.35 + Math.sin(an) * rr); } ctx.fill();
    // lasso coil with rope twist
    for (let k = 0; k < 5; k++) { ctx.strokeStyle = k % 2 ? '#c9a55f' : '#e2c98a'; ctx.lineWidth = 0.75; ctx.beginPath(); ctx.ellipse(-7.2, -0.4, 3.0 - k * 0.5, 3.8 - k * 0.65, 0, 0, TAU); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(90,60,20,0.5)'; ctx.lineWidth = 0.14;
    for (let k = 0; k < 24; k++) { const a = k / 24 * TAU; ctx.beginPath(); ctx.moveTo(-7.2 + Math.cos(a) * 2.6, -0.4 + Math.sin(a) * 3.4); ctx.lineTo(-7.2 + Math.cos(a + 0.12) * 3.0, -0.4 + Math.sin(a + 0.12) * 3.8); ctx.stroke(); }
    ln(-4.2, -2, -3.4, -4.8, 0.5, '#c9a55f'); ln(-3.4, -4.8, -4.2, -5.4, 0.4, '#e2c98a');
}
// ---- head: skin texture, hair, expressive eyes, mustache, teeth, bandana, chain ----
function hvHead(ex, faceOnly) {
    const R = mulberry(41), HAIR = '#140b08', mo = ex.mo, mw = ex.mw, brow = ex.brow, bd = ex.bold || 0;
    ctx.lineCap = 'round';
    if (!faceOnly) {
    ctx.fillStyle = '#8a5736'; ctx.fillRect(-2.4, -20.5, 4.8, 3.6);   // neck
    for (let k = -2; k <= 2; k++) ln(k * 0.7, -20, k * 0.8, -17.2, 0.12, 'rgba(60,30,15,0.2)');
    ctx.fillStyle = 'rgba(40,18,8,0.3)'; ctx.beginPath(); ctx.ellipse(0, -18.2, 4.2, 1.6, 0, 0, Math.PI); ctx.fill();
    // bandana with polka dots, folds, knot
    ctx.fillStyle = '#d0182f'; ctx.beginPath(); ctx.moveTo(-3.8, -20.6); ctx.lineTo(3.8, -20.6); ctx.lineTo(0.4, -15.2); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.beginPath(); ctx.moveTo(-3.8, -20.6); ctx.lineTo(3.8, -20.6); ctx.lineTo(3.2, -19.2); ctx.lineTo(-3.2, -19.2); ctx.closePath(); ctx.fill();
    for (let k = 0; k < 10; k++) ln(-3 + k * 0.62, -20.2, -2 + k * 0.45, -16.4 + (k % 3) * 0.5, 0.1, k % 2 ? 'rgba(0,0,0,0.18)' : 'rgba(255,255,255,0.16)');
    for (const d of [[-2.4, -19.4], [-0.8, -19.1], [1.0, -19.2], [2.4, -19.4], [-1.6, -17.9], [0.2, -17.8], [1.8, -18], [-0.5, -16.6], [0.7, -16.2]]) { dot(d[0], d[1], 0.4, '#fff'); dot(d[0] - 0.1, d[1] - 0.1, 0.14, '#ffd6d6'); }
    ctx.fillStyle = '#a8121f'; ctx.beginPath(); ctx.arc(3.9, -20.4, 0.9, 0, TAU); ctx.fill(); dot(3.9, -20.4, 0.3, '#7d0e18');
    // gold chain + engraved medallion
    ctx.strokeStyle = '#f1c40f'; ctx.lineWidth = 0.3; ctx.beginPath(); ctx.moveTo(-4.3, -17.9); ctx.quadraticCurveTo(0, -13.2, 4.3, -17.9); ctx.stroke();
    for (let k = 0; k < 16; k++) { const t = k / 15, x = -4.3 + 8.6 * t, y = -17.9 + 4.7 * (1 - (2 * t - 1) * (2 * t - 1)) * 0.9; ctx.strokeStyle = k % 2 ? '#fff1a6' : '#c9962a'; ctx.lineWidth = 0.2; ctx.beginPath(); ctx.ellipse(x, y, 0.28, 0.17, (t - 0.5) * 1.3, 0, TAU); ctx.stroke(); }
    dot(0, -14.1, 1.45, '#8a6414'); dot(0, -14.1, 1.2, '#ffe066'); for (let k = 0; k < 12; k++) { const a = k / 12 * TAU; ln(Math.cos(a) * 0.4, -14.1 + Math.sin(a) * 0.4, Math.cos(a) * 1.0, -14.1 + Math.sin(a) * 1.0, 0.1, '#a67c10'); }
    dot(0, -14.1, 0.3, '#c9962a'); dot(-0.45, -14.55, 0.2, '#fff');
    // hair mass behind the hat + long locks
    ctx.fillStyle = HAIR; ctx.beginPath(); ctx.ellipse(0, -25.6, 6.6, 5.7, 0, Math.PI, TAU); ctx.fill();
    for (let k = 0; k < 96; k++) { const a = Math.PI + R() * Math.PI, rr = 5.4 + R() * 1.4; ctx.strokeStyle = k % 3 ? '#2a1a12' : '#3c261a'; ctx.lineWidth = 0.18; ctx.beginPath(); ctx.moveTo(Math.cos(a) * 3, -25.6 + Math.sin(a) * 3); ctx.quadraticCurveTo(Math.cos(a) * rr * 0.8, -25.6 + Math.sin(a) * rr * 0.7, Math.cos(a) * rr, -25.6 + Math.sin(a) * rr * 0.85 + 0.3); ctx.stroke(); }
    // ears with helix and canal
    for (const sx of [-1, 1]) {
        ctx.fillStyle = '#8a5736'; ctx.beginPath(); ctx.ellipse(sx * 5.8, -23.2, 1.25, 1.95, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#c98c5f'; ctx.beginPath(); ctx.ellipse(sx * 5.75, -23.3, 0.6, 1.2, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(70,35,18,0.55)'; ctx.lineWidth = 0.15; ctx.beginPath(); ctx.arc(sx * 5.9, -23.2, 1.0, -1.2 + (sx < 0 ? Math.PI : 0), 1.2 + (sx < 0 ? Math.PI : 0)); ctx.stroke();
        dot(sx * 5.65, -23.0, 0.22, 'rgba(60,25,12,0.55)');
    }
    }
    // face
    ctx.fillStyle = rg(-1.8, -26.2, 1, 0, -23.5, 8.2, ex.rig ? [[0, '#dca173'], [0.45, '#bf8359'], [0.74, '#a9714a'], [1, '#a9714a']] : [[0, '#dca173'], [0.45, '#bf8359'], [0.8, '#a9714a'], [1, '#85512f']]);   // 3D face: fade into the surrounding skin tone (no dark ring = no chin-strap edge)
    ctx.beginPath(); ctx.ellipse(0, -23.6, 5.5, 6.3, 0, 0, TAU); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.ellipse(0, -23.6, 5.5, 6.3, 0, 0, TAU); ctx.clip();
    for (let k = 0; k < 280; k++) { const a = R() * TAU, r = Math.sqrt(R()) * 5.4; dot(Math.cos(a) * r, -23.6 + Math.sin(a) * r * 1.1, 0.06 + R() * 0.05, R() < 0.55 ? 'rgba(80,38,18,0.07)' : 'rgba(255,225,190,0.1)'); }   // pores + freckle sheen
    for (let k = 0; k < 18; k++) dot(-1.2 + R() * 2.4, -27.4 + R() * 1.4, 0.07, 'rgba(255,230,200,0.2)');
    ctx.fillStyle = 'rgba(224,90,70,0.03)'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sx * 3.3, -21.7, 1.6, 1.05, 0, 0, TAU); ctx.fill(); }
    if (!ex.rig) for (const sx of [-1, 1]) { ctx.strokeStyle = 'rgba(70,35,18,0.22)'; ctx.lineWidth = 0.22; ctx.beginPath(); ctx.moveTo(sx * 2.4, -21.6); ctx.quadraticCurveTo(sx * 3.4, -20.4, sx * 3.1, -19.3); ctx.stroke(); }   // smile lines
    if (ex.rig) { const g = ctx.createRadialGradient(0, -18.6, 0.2, 0, -18.6, 3.6); g.addColorStop(0, 'rgba(30,14,8,0.16)'); g.addColorStop(1, 'rgba(30,14,8,0)'); ctx.fillStyle = g; ctx.fillRect(-6, -23, 12, 8); }   // soft shadow under the 3D stubble
    else for (let k = 0; k < 150; k++) { const x = -3.3 + R() * 6.6, y = -19.3 + R() * 3.2; if (Math.abs(x) < 1.1 && y < -18.5) continue; dot(x, y, 0.06 + R() * 0.04, 'rgba(25,12,6,0.42)'); }   // stubble
    if (ex.rig) {   // finer skin for the 3D face: pores, forehead lines, crow's feet, ruddy nose, capillaries, sun spots, tired eyes
        const Q = mulberry(5), inFace = (x, y) => (x * x) / 29 + ((y + 23.6) * (y + 23.6)) / 38 < 0.94;
        for (let k = 0; k < 420; k++) { const x = (Q() * 2 - 1) * 5.2, y = -23.6 + (Q() * 2 - 1) * 6; if (inFace(x, y)) dot(x, y, 0.03 + Q() * 0.025, 'rgba(70,32,16,' + (0.05 + Q() * 0.06) + ')'); }
        for (let k = 0; k < 220; k++) { const x = (Q() * 2 - 1) * 5, y = -23.6 + (Q() * 2 - 1) * 5.8; if (inFace(x, y)) dot(x, y, 0.03 + Q() * 0.025, 'rgba(255,226,196,' + (0.05 + Q() * 0.06) + ')'); }
        ctx.lineCap = 'round'; ctx.strokeStyle = 'rgba(80,38,18,0.06)'; ctx.lineWidth = 0.1;
        for (const yy of [-28.3, -27.7, -27.1]) { ctx.beginPath(); ctx.moveTo(-2.8, yy + 0.25); ctx.quadraticCurveTo(0, yy - 0.2, 2.8, yy + 0.25); ctx.stroke(); }   // forehead creases
        for (const sx of [-1, 1]) for (const [dx, dy] of [[0.9, -0.85], [1.15, -0.1], [0.95, 0.7]]) { ctx.strokeStyle = 'rgba(80,38,18,0.07)'; ctx.lineWidth = 0.075; ctx.beginPath(); ctx.moveTo(sx * 3.9, -24.35); ctx.quadraticCurveTo(sx * (3.9 + dx * 0.55), -24.35 + dy * 0.4, sx * (3.9 + dx), -24.35 + dy); ctx.stroke(); }   // crow's feet
        ctx.fillStyle = 'rgba(205,85,62,0.15)'; ctx.beginPath(); ctx.ellipse(0, -22.3, 0.95, 0.75, 0, 0, TAU); ctx.fill();
        for (const sx of [-1, 1]) { ctx.fillStyle = 'rgba(205,85,62,0.1)'; ctx.beginPath(); ctx.ellipse(sx * 0.85, -22.2, 0.55, 0.5, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(90,40,24,0.1)'; ctx.beginPath(); ctx.ellipse(sx * 2.4, -23.45, 1.35, 0.4, 0, 0, TAU); ctx.fill(); }
        ctx.strokeStyle = 'rgba(176,56,44,0.06)'; ctx.lineWidth = 0.05;
        for (const sx of [-1, 1]) for (let k = 0; k < 5; k++) { const a = Q() * 0.8; ctx.beginPath(); ctx.moveTo(sx * (1.1 + Q() * 0.3), -22.2 - Q() * 0.2); ctx.quadraticCurveTo(sx * (1.6 + Q() * 0.4), -21.9 - a * 0.4, sx * (2.1 + Q() * 0.5), -21.6 + (Q() - 0.5) * 0.5); ctx.stroke(); }   // capillaries beside the nose
        for (let k = 0; k < 0; k++) { const x = (Q() * 2 - 1) * 4.2, y = -23.6 + (Q() * 2 - 1) * 4; if (inFace(x, y) && Math.abs(x) > 1.4) { ctx.fillStyle = 'rgba(110,58,28,' + (0.1 + Q() * 0.08) + ')'; ctx.beginPath(); ctx.ellipse(x, y, 0.1 + Q() * 0.12, 0.08 + Q() * 0.1, Q() * 3, 0, TAU); ctx.fill(); } }   // sun spots
    }
    if (ex.rig) {   // baked form shading: soft light and shadow volumes so the skin reads as a modelled face (planes, sockets, cheekbones, jaw), not a flat wash
        const bl = (x, y, rx, ry, rgb, a, rot) => { ctx.save(); ctx.translate(x, y); ctx.rotate(rot || 0); ctx.scale(rx, ry); const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 1); a *= 1.45; g.addColorStop(0, 'rgba(' + rgb + ',' + a + ')'); g.addColorStop(0.55, 'rgba(' + rgb + ',' + (a * 0.5) + ')'); g.addColorStop(1, 'rgba(' + rgb + ',0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, 1, 0, TAU); ctx.fill(); ctx.restore(); };
        const DK = '58,26,12', LT = '255,222,182', RD = '190,80,60';
        bl(0, -28.2, 3.6, 1.3, LT, 0.08); bl(-2.2, -27.6, 1.6, 1.1, LT, 0.04); bl(2.2, -27.6, 1.6, 1.1, LT, 0.04);   // forehead planes
        for (const sx of [-1, 1]) {
            bl(sx * 5.0, -26.8, 1.3, 2.4, DK, 0.1);   // temple hollows
            bl(sx * 2.4, -25.9, 2.0, 0.6, DK, 0.26);   // brow shadow over the eye
            bl(sx * 2.45, -24.4, 1.9, 1.35, DK, 0.09);   // eye socket
            bl(sx * 1.35, -24.0, 0.7, 1.4, DK, 0.17);   // inner corner beside the nose bridge
            bl(sx * 2.5, -23.1, 1.7, 0.55, DK, 0.05);   // under-eye bag
            bl(sx * 3.7, -22.5, 1.6, 1.0, LT, 0.07, -0.4);   // cheekbone highlight
            bl(sx * 4.3, -20.6, 1.3, 2.0, DK, 0.09, sx * 0.2);   // hollow under the cheekbone
            bl(sx * 1.15, -20.9, 0.5, 1.4, DK, 0.16);   // beside the nose
            bl(sx * 1.9, -19.0, 0.7, 1.5, DK, 0.15, sx * 0.3);   // nasolabial fold
            bl(sx * 4.9, -17.8, 1.0, 2.0, DK, 0.24, sx * -0.6);   // jaw edge falling away
            bl(sx * 2.8, -17.2, 1.6, 0.8, DK, 0.08);   // under the jaw corner
            bl(sx * 1.8, -16.4, 1.6, 0.8, DK, 0.18);   // under the chin
        }
        bl(0, -23.6, 0.55, 2.2, LT, 0.2);   // nose bridge
        bl(0, -21.2, 0.8, 0.7, LT, 0.17);   // nose tip
        bl(0, -20.6, 1.0, 0.35, DK, 0.2);   // under the nose
        bl(0, -18.0, 0.9, 0.35, DK, 0.2);   // shadow under the lower lip
        bl(0, -17.1, 1.3, 0.9, LT, 0.14);   // chin
        bl(0, -16.1, 3.0, 0.9, DK, 0.2);   // underside of the chin
        for (const sx of [-1, 1]) bl(sx * 3.5, -21.4, 2.0, 1.3, RD, 0.05);   // warm blood under the cheeks
    }
    ctx.restore();
    if (!ex.rig) { ctx.strokeStyle = 'rgba(40,20,10,0.25)'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.ellipse(0, -23.6, 5.1, 5.9, 0, 0.5, Math.PI - 0.5); ctx.stroke(); }   // jaw-edge shade (the 3D head shades its own edge)
    // sideburns with strands
    if (!faceOnly) {
    ctx.fillStyle = HAIR; ctx.fillRect(-5.6, -27.2, 1.5, 5.4); ctx.fillRect(4.1, -27.2, 1.5, 5.4);
    for (const sx of [-1, 1]) for (let k = 0; k < 14; k++) ln(sx * (4.3 + R() * 1.1), -27 + k * 0.38, sx * (4.4 + R() * 1.2), -26.6 + k * 0.38, 0.1, k % 2 ? '#3c261a' : '#050302');
    }
    // eyes
    for (const sx of [-1, 1]) {
        const x0 = sx * 2.4, y0 = -24.4, ek = 1 + brow * 0.4;
        ctx.fillStyle = 'rgba(70,35,18,0.28)'; ctx.beginPath(); ctx.ellipse(x0, y0 + 0.1, 1.5, 1.05 * ek, 0, 0, TAU); ctx.fill();   // socket shadow
        if (!ex.rig) {
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.ellipse(x0, y0, 1.38, 1.15 * ek, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(200,120,110,0.25)'; ctx.beginPath(); ctx.ellipse(x0 - sx * 1.1, y0 + 0.05, 0.3, 0.5, 0, 0, TAU); ctx.fill();   // tear duct
        dot(x0, y0, 0.86, '#2e1a0c'); ctx.fillStyle = rg(x0, y0, 0.1, x0, y0, 0.86, [[0, '#8b5a2b'], [0.6, '#6a4220'], [1, '#2e1a0c']]); ctx.beginPath(); ctx.arc(x0, y0, 0.8, 0, TAU); ctx.fill();
        for (let k = 0; k < 16; k++) { const a = k / 16 * TAU; ln(x0 + Math.cos(a) * 0.25, y0 + Math.sin(a) * 0.25, x0 + Math.cos(a) * 0.72, y0 + Math.sin(a) * 0.72, 0.05, k % 2 ? 'rgba(210,160,90,0.5)' : 'rgba(30,15,6,0.5)'); }   // iris fibres
        dot(x0, y0, 0.42, '#0a0503'); dot(x0 - 0.3, y0 - 0.38, 0.22, '#fff'); dot(x0 + 0.28, y0 + 0.3, 0.1, 'rgba(255,255,255,0.7)');
        ctx.strokeStyle = HAIR; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(x0 - 1.55, y0 - 0.3 - brow * 0.3); ctx.quadraticCurveTo(x0, y0 - 1.6 - brow * 0.7, x0 + 1.55, y0 - 0.3 - brow * 0.3); ctx.stroke();   // upper lid
        for (let k = 0; k < 7; k++) { const t = k / 6, lx = x0 - 1.3 + 2.6 * t, ly = y0 - 0.95 - brow * 0.45 - Math.sin(t * Math.PI) * 0.45; ln(lx, ly, lx + (t - 0.5) * 0.5 + sx * 0.18, ly - 0.45, 0.09, HAIR); }   // lashes
        }
        if (!ex.rig) { ctx.strokeStyle = 'rgba(40,20,10,0.4)'; ctx.lineWidth = 0.22; ctx.beginPath(); ctx.moveTo(x0 - 1.1, y0 + 1.1); ctx.quadraticCurveTo(x0, y0 + 1.6, x0 + 1.1, y0 + 1.1); ctx.stroke();
        ctx.strokeStyle = 'rgba(70,35,18,0.25)'; ctx.lineWidth = 0.15; ctx.beginPath(); ctx.moveTo(x0 - 1.2, y0 + 1.7); ctx.quadraticCurveTo(x0, y0 + 2.2, x0 + 1.2, y0 + 1.7); ctx.stroke(); }   // eye bag
        if (!ex.rig) {
        const bu = brow * 1.1; ctx.strokeStyle = HAIR;   // thick brow built from hairs
        for (let k = 0; k < 16; k++) { const t = k / 15, bx = sx * (0.8 + 2.8 * t), by = -26.3 - bu * 0.6 - Math.sin(t * Math.PI) * 0.9 - (1 - t) * 0.1; ctx.lineWidth = 0.17; ctx.beginPath(); ctx.moveTo(bx, by + 0.4); ctx.lineTo(bx + sx * 0.35, by - 0.28 + t * 0.35); ctx.stroke(); }
        }
    }
    // nose
    if (!ex.rig) {
    ctx.strokeStyle = 'rgba(70,35,18,0.32)'; ctx.lineWidth = 0.35; ctx.beginPath(); ctx.moveTo(-0.8, -24.2); ctx.quadraticCurveTo(-1.1, -23.2, -1, -22.5); ctx.moveTo(0.8, -24.2); ctx.quadraticCurveTo(1.1, -23.2, 1, -22.5); ctx.stroke();
    ctx.fillStyle = '#b87a52'; ctx.beginPath(); ctx.ellipse(0, -22.4, 1.2, 0.85, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,225,190,0.4)'; ctx.beginPath(); ctx.ellipse(-0.2, -22.8, 0.45, 0.28, 0, 0, TAU); ctx.fill();
    for (const sx of [-1, 1]) { ctx.fillStyle = 'rgba(40,15,8,0.7)'; ctx.beginPath(); ctx.ellipse(sx * 0.58, -22.1, 0.3, 0.22, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(70,35,18,0.3)'; ctx.lineWidth = 0.15; ctx.beginPath(); ctx.arc(sx * 0.9, -22.3, 0.5, 0.3, 2.2); ctx.stroke(); }
    }
    if (!ex.rig) {
    // mouth: relaxed natural lips; teeth only show when the mouth opens (talking / shouting)
    const my = -20.2, mw2 = 1.55 + mw * 0.55, mb = my + mo * 1.7, op = mo > 0.15;
    const lipsTop = () => { ctx.beginPath(); ctx.moveTo(-mw2, my + 0.05); ctx.quadraticCurveTo(-mw2 * 0.45, my - 0.55, -0.35, my - 0.5); ctx.quadraticCurveTo(0, my - 0.3, 0.35, my - 0.5); ctx.quadraticCurveTo(mw2 * 0.45, my - 0.55, mw2, my + 0.05); ctx.quadraticCurveTo(0, my + 0.25, -mw2, my + 0.05); ctx.closePath(); };
    if (op) {
        const mouth = () => { ctx.beginPath(); ctx.moveTo(-mw2, my + 0.05); ctx.quadraticCurveTo(0, my + 0.25, mw2, my + 0.05); ctx.quadraticCurveTo(mw2 * 0.7, mb, 0, mb + 0.1); ctx.quadraticCurveTo(-mw2 * 0.7, mb, -mw2, my + 0.05); ctx.closePath(); };
        ctx.fillStyle = '#2e0b09'; mouth(); ctx.fill();
        ctx.save(); mouth(); ctx.clip();
        for (let k = -3; k <= 3; k++) { const tx = k * 0.44, tw = 0.41; ctx.fillStyle = '#f4eee0'; roundRect(tx - tw / 2, my + 0.1, tw, Math.min(0.85, mo * 1.2), 0.1); ctx.fill(); ln(tx - tw / 2, my + 0.1, tx - tw / 2, my + 0.9, 0.05, 'rgba(110,85,60,0.5)'); }
        ctx.fillStyle = '#c95a52'; ctx.beginPath(); ctx.ellipse(0, mb, 1.2, 0.5 + mo * 0.3, 0, 0, TAU); ctx.fill();
        ctx.restore();
    }
    ctx.fillStyle = '#a2584a'; lipsTop(); ctx.fill();   // upper lip
    ctx.fillStyle = 'rgba(255,200,180,0.18)'; ctx.beginPath(); ctx.ellipse(0, my - 0.25, mw2 * 0.5, 0.12, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#b46a58'; ctx.beginPath(); ctx.moveTo(-mw2 * 0.92, my + 0.1); ctx.quadraticCurveTo(0, my + 0.35 + mo * 1.7 * 0.9, mw2 * 0.92, my + 0.1); ctx.quadraticCurveTo(mw2 * 0.55, mb + 0.55, 0, mb + 0.62); ctx.quadraticCurveTo(-mw2 * 0.55, mb + 0.55, -mw2 * 0.92, my + 0.1); ctx.closePath(); ctx.fill();   // lower lip
    ctx.strokeStyle = 'rgba(40,12,8,0.8)'; ctx.lineWidth = 0.14; ctx.beginPath(); ctx.moveTo(-mw2 - 0.08, my + 0.08); ctx.quadraticCurveTo(0, my + 0.28, mw2 + 0.08, my + 0.08); ctx.stroke();   // mouth line
    ctx.strokeStyle = 'rgba(80,35,25,0.28)'; ctx.lineWidth = 0.16; ctx.beginPath(); ctx.moveTo(-mw2 * 0.5, mb + 0.9); ctx.quadraticCurveTo(0, mb + 1.15, mw2 * 0.5, mb + 0.9); ctx.stroke();   // chin crease
    }
    if (!ex.rig) {
    ctx.strokeStyle = 'rgba(80,35,25,0.2)'; ctx.lineWidth = 0.14; ctx.beginPath(); ctx.moveTo(-0.3, -21.2); ctx.lineTo(-0.35, -20.8); ctx.moveTo(0.3, -21.2); ctx.lineTo(0.35, -20.8); ctx.stroke();   // philtrum
    // trimmed mustache that sits on the lip (no handlebar)
    const sy = -21.15;
    drawStache(0, sy, 2.2);
    for (const sx of [-1, 1]) for (let k = 0; k < 22; k++) {
        const t = k / 21, bx = sx * (0.15 + t * 2.0), by = sy - 0.08 + Math.sin(t * 2.4) * 0.22;
        ctx.strokeStyle = k % 3 ? '#4a2e1c' : '#8a6a50'; ctx.lineWidth = 0.09; ctx.beginPath(); ctx.moveTo(bx, by + 0.15); ctx.quadraticCurveTo(bx + sx * 0.15, by - 0.05, bx + sx * 0.32, by + 0.08); ctx.stroke();
    }
    }
    ctx.strokeStyle = 'rgba(70,35,18,0.4)'; ctx.lineWidth = 0.3; ctx.beginPath(); ctx.moveTo(0, -17.5); ctx.lineTo(0, -17); ctx.stroke();
    if (!ex.rig) { ctx.strokeStyle = 'rgba(150,60,40,0.7)'; ctx.lineWidth = 0.4; ctx.beginPath(); ctx.moveTo(3.2, -23.4); ctx.lineTo(4.2, -21.6); ctx.stroke(); for (let k = 0; k < 4; k++) ln(3.4 + k * 0.28 - 0.2, -23 + k * 0.45, 3.1 + k * 0.28 + 0.4, -22.7 + k * 0.45, 0.1, 'rgba(240,200,180,0.5)'); }   // scar + stitch marks (the 3D rig builds these as geometry)
    if (!faceOnly) stud(5.75, -21.1, 0.8, '#c9962a', '#ffe066'); ln(5.75, -21.7, 5.75, -22.4, 0.14, '#c9962a');   // earring
}
// ---- sombrero: base art + woven straw texture, braided cord, extra conchos ----
function hvHat(idx) {
    const s = 14.5, st = hatCol(HAT_STYLES[idx % HAT_STYLES.length]), R = mulberry(53), ry = s * 0.27, ch = s * 0.68, cw = s * 0.44;
    drawSombreroRaw(0, 0, s, 0, idx);
    ctx.save(); ctx.beginPath(); ctx.ellipse(0, 0, s, ry, 0, 0, TAU); ctx.clip();
    for (let k = 0; k < 72; k++) { const a = k / 72 * TAU; ctx.strokeStyle = k % 2 ? 'rgba(0,0,0,0.13)' : 'rgba(255,240,200,0.12)'; ctx.lineWidth = 0.12; ctx.beginPath(); ctx.moveTo(Math.cos(a) * s * 0.5, Math.sin(a) * ry * 0.5); ctx.lineTo(Math.cos(a) * s, Math.sin(a) * ry); ctx.stroke(); }   // radial straw
    for (let k = 0; k < 320; k++) { const a = R() * TAU, r = 0.5 + R() * 0.5; ln(Math.cos(a) * s * r, Math.sin(a) * ry * r, Math.cos(a + 0.12) * s * r, Math.sin(a + 0.12) * ry * r, 0.1, R() < 0.5 ? 'rgba(255,235,190,0.18)' : 'rgba(60,40,10,0.14)'); }
    ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.moveTo(-cw, -ry * 0.1); ctx.lineTo(-cw * 0.8, -ch * 0.82); ctx.quadraticCurveTo(0, -ch * 1.15, cw * 0.8, -ch * 0.82); ctx.lineTo(cw, -ry * 0.1); ctx.quadraticCurveTo(0, ry * 0.5, -cw, -ry * 0.1); ctx.closePath(); ctx.clip();
    for (let k = -14; k <= 14; k++) { ln(k * cw * 0.12, -ch * 1.1, k * cw * 0.12 + cw * 0.5, ry * 0.4, 0.1, 'rgba(0,0,0,0.12)'); ln(k * cw * 0.12, -ch * 1.1, k * cw * 0.12 - cw * 0.5, ry * 0.4, 0.1, 'rgba(255,240,200,0.12)'); }   // crown basket weave
    ctx.restore();
    for (let k = 0; k < 14; k++) { const a = 0.25 + (Math.PI - 0.5) * k / 13; conchoDot(Math.cos(a) * s * 0.91, Math.sin(a) * ry * 0.9, 0.62); }
    for (let k = -2; k <= 2; k++) conchoDot(k * cw * 0.36, -ch * 0.28 + Math.abs(k) * 0.3, 0.8);
    for (let k = -9; k <= 9; k++) { const bx = k * cw * 0.1, by = -ch * 0.2 - Math.abs(k) * 0.03; ctx.strokeStyle = st.trim; ctx.lineWidth = 0.14; ctx.beginPath(); ctx.ellipse(bx, by, 0.35, 0.22, 0.6, 0, TAU); ctx.stroke(); }   // braided cord links
    dot(0, -ch * 1.03, s * 0.055, st.trim); dot(-0.15, -ch * 1.05, s * 0.02, '#fff');
}
// ---- animated parts: arms (sleeve, cuffs, gloved hand) and the hoop ----
function hvArm(sx, sy, hx, hy, sleeve) {
    ctx.lineCap = 'round';
    const dx = hx - sx, dy = hy - sy, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, nx = -uy, ny = ux;
    ctx.strokeStyle = 'rgba(0,0,0,0.32)'; ctx.lineWidth = 4.4; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(hx, hy); ctx.stroke();
    ctx.strokeStyle = sleeve; ctx.lineWidth = 3.6; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(hx, hy); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(sx + nx * 1, sy + ny * 1); ctx.lineTo(hx + nx * 1, hy + ny * 1); ctx.stroke();
    for (let k = 0; k < 6; k++) { const t = 0.12 + k * 0.12, x = sx + dx * t, y = sy + dy * t; ln(x - nx * 1.6, y - ny * 1.6, x + nx * 1.6 + ux * 0.4, y + ny * 1.6 + uy * 0.4, 0.15, 'rgba(0,0,0,0.2)'); }   // wrinkles
    for (let k = 0; k < 10; k++) { const t = 0.08 + k * 0.07, x = sx + dx * t + nx * (k % 2 ? 0.7 : -0.7), y = sy + dy * t + ny * (k % 2 ? 0.7 : -0.7); dot(x, y, 0.2, k % 2 ? '#e2b13c' : '#c0392b'); }   // embroidery dots
    const mx = sx + dx * 0.82, my = sy + dy * 0.82;
    ctx.strokeStyle = '#f1c40f'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(mx - nx * 1.7, my - ny * 1.7); ctx.lineTo(mx + nx * 1.7, my + ny * 1.7); ctx.stroke();
    for (let k = -2; k <= 2; k++) dot(mx + nx * k * 0.65, my + ny * k * 0.65, 0.2, '#fff6c8');
    ctx.strokeStyle = '#5a3a1c'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(hx, hy - 0.4, 2.7, Math.PI * 1.05, Math.PI * 1.95); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,224,160,0.6)'; ctx.lineWidth = 0.15; ctx.setLineDash([0.4, 0.3]); ctx.beginPath(); ctx.arc(hx, hy - 0.4, 2.7, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#a9714a'; ctx.beginPath(); ctx.arc(hx, hy - 1, 2.35, 0, TAU); ctx.fill();
    ctx.fillStyle = '#c98c5f'; ctx.beginPath(); ctx.arc(hx - 0.4, hy - 1.5, 1.5, 0, TAU); ctx.fill();
    for (let k = 0; k < 4; k++) { const fx = hx - 1.5 + k, fy = hy - 3.3 - (k === 1 || k === 2 ? 0.4 : 0); ctx.strokeStyle = '#a9714a'; ctx.lineWidth = 0.95; ctx.beginPath(); ctx.moveTo(fx, hy - 1.8); ctx.lineTo(fx, fy); ctx.stroke(); dot(fx, fy, 0.45, '#b8794f'); ln(fx - 0.3, hy - 2.7, fx + 0.3, hy - 2.7, 0.1, 'rgba(60,30,15,0.6)'); dot(fx, fy - 0.1, 0.18, 'rgba(255,225,190,0.5)'); }
    ctx.strokeStyle = '#a9714a'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(hx - 2, hy - 0.8); ctx.lineTo(hx - 3, hy - 2); ctx.stroke(); dot(hx - 3, hy - 2.1, 0.5, '#b8794f');
    ctx.strokeStyle = 'rgba(60,30,15,0.7)'; ctx.lineWidth = 0.12; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(hx, hy - 0.6, 1 + k * 0.3, 0.4, 1.4); ctx.stroke(); }   // palm creases
}
function hvHoop(hc, hcx, hcy, hrx, tilt, phase, front) {
    const a0 = front ? 0 : Math.PI, a1 = front ? Math.PI : TAU;
    ctx.lineCap = 'round'; ctx.lineWidth = 3.9; ctx.strokeStyle = hc[front ? 1 : 0];
    ctx.beginPath(); ctx.ellipse(hcx, hcy, hrx, 5, tilt, a0, a1); ctx.stroke();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,' + (front ? 0.5 : 0.28) + ')'; ctx.beginPath(); ctx.ellipse(hcx, hcy - 0.7, hrx, 4.6, tilt, a0 + 0.15, a1 - 0.15); ctx.stroke();
    ctx.lineWidth = 0.7; ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(hcx, hcy + 0.8, hrx, 5.2, tilt, a0 + 0.1, a1 - 0.1); ctx.stroke();
    ctx.lineWidth = 1.7; ctx.strokeStyle = hc[front ? 0 : 2];
    for (let k = 0; k < 9; k++) { const a = a0 + ((phase * 1.3 + k * 0.36) % Math.PI); if (a > a1) continue; ctx.beginPath(); ctx.ellipse(hcx, hcy, hrx, 5, tilt, a, a + 0.14, false); ctx.stroke(); }   // spinning tape
    if (front) for (let k = 0; k < 6; k++) { const a = (phase * 2 + k * 0.5) % Math.PI, x = hcx + Math.cos(a + Math.PI) * hrx * Math.cos(tilt), y = hcy + Math.sin(a) * 5; dot(x, y, 0.3, 'rgba(255,255,255,0.75)'); }   // glitter
}
function drawVaqueroHD(x, y, s, facing, phase, alpha) {
    const hc = hoopColors(), sq = Math.max(0.3, Math.round(s * 10) / 10), eq = save.cos.eq.hat;
    ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y); ctx.scale(s * facing, s);
    const wob = Math.cos(phase) * 3, tilt = Math.sin(phase) * 0.15, sway = Math.sin(phase) * 1.2;
    const hip = wob * 0.6, lean = -wob * 0.024, bob = Math.sin(phase * 2) * 0.55, hcx = wob * 1.25, hcy = 2 + bob, hrx = 19 + Math.cos(phase) * 0.8;
    if (!VQ.nohoop) {
        hvHoop(hc, hcx, hcy, hrx, tilt, phase, false);
        ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1.5;
        for (let i = -1; i <= 1; i++) { const off = ((phase * 6 + i * 7) % 14 + 14) % 14; ctx.beginPath(); ctx.moveTo(i * 9, 28 + off); ctx.lineTo(i * 9, 34 + off); ctx.stroke(); }
    }
    ctx.save(); ctx.transform(1, 0, -hip / 16, 1, hip * 17 / 16, 0);
    hvLayer('legs', -8, 0, 8, 18, sq, 0, hvLegs);
    ctx.restore();
    const boot = (bx, c, dir) => { ctx.save(); ctx.translate(bx, 15.4); ctx.scale(dir, 1); hvLayer('boot', -6.2, -1.6, 7, 9, sq, c, () => hvBoot(c)); ctx.restore(); };
    boot(-3.5, '#6b4426', -1); boot(3.5, '#7c5232', 1);
    ctx.save(); ctx.translate(hip + sway, bob); ctx.translate(0, 2); ctx.rotate(lean); ctx.translate(0, -2);
    hvLayer('torso', -12.5, -19, 12.5, 6.2, sq, 0, hvTorso);
    hvArm(-4, -15, -12 + Math.cos(phase) * 1.5, -22 - Math.sin(phase) * 2.4, '#f4efe6');
    hvArm(4, -15, 12 + Math.cos(phase) * 1.5, -22 + Math.sin(phase) * 2.4, '#f4efe6');
    const ex = { mo: Math.round(VQ.mo * 4) / 4, mw: Math.round(VQ.mw * 4) / 4, brow: Math.round(VQ.brow * 4) / 4 };
    hvLayer('head', -8.5, -33, 8.5, -12.5, sq, ex.mo + '_' + ex.mw + '_' + ex.brow, () => hvHead(ex));
    const rainbow = HAT_STYLES[eq % HAT_STYLES.length].rainbow;
    ctx.save(); ctx.translate(0, -32.5); ctx.rotate(-lean * 0.9 + sway * 0.02);
    if (rainbow) drawSombreroRaw(0, 0, 14.5, 0, eq); else hvLayer('hat' + eq, -19, -17, 19, 7, sq, eq, () => hvHat(eq));
    ctx.restore();
    ctx.restore();
    if (!VQ.nohoop) hvHoop(hc, hcx, hcy, hrx, tilt, phase, true);
    ctx.restore();
}