
// =====================================================================
//  ACT 3: THE RECKONING  -  top-down arena brawler
// =====================================================================
const RPG_THEMES = {
    plaza:   { a: '#c9b38a', b: '#bda57a', grid: 'rgba(90,70,40,0.25)', obs: 'fountain' },
    cantina: { a: '#8a5a33', b: '#7d4f2b', grid: 'rgba(40,20,5,0.35)',  obs: 'table' },
    orchard: { a: '#3c4a38', b: '#35422f', grid: 'rgba(0,0,0,0.25)',    obs: 'tomb' },
    bone:    { a: '#2b2530', b: '#251f2a', grid: 'rgba(200,180,255,0.08)', obs: 'pillar' },
};
const GEAR = [
    { n: 'Sword', f: g => { g.S.dmg *= 1.1; }, d: 'Damage +10%' },
    { n: 'Leather Vest', f: g => { changeMaxHp(g, 12); g.S.armor += 1; }, d: '+12 HP, +1 DEF' },
    { n: 'Riding Boots', f: g => { g.S.speed *= 1.05; }, d: 'Speed +5%' },
    { n: 'Lucky Amulet', f: g => { g.S.luck += 6; g.S.crit += 0.02; }, d: 'Luck and crit up' },
    { n: 'Iron Gauntlets', f: g => { g.S.dmg *= 1.05; g.S.armor += 1; }, d: 'Damage +5%, +1 DEF' },
];
const GEAR_TIER = ['Rusty', 'Sturdy', 'Fine', 'Master', 'Legendary'];
function grantGear() {
    const it = pick(GEAR), t = Math.min(4, Math.floor(g.camp.m / 1.2 + Math.random() * 1.5));
    it.f(g); g.gear = (g.gear || 0) + 1; sfx('power');
    toast('Loot: ' + GEAR_TIER[t] + ' ' + it.n, it.d, ['#bdc3c7', '#2ecc71', '#3498db', '#9b59b6', '#f1c40f'][t], 150);
}
function rpgRoll() {
    const R = g.rpg, p = g.player; if (mode !== 'play' || g.kind !== 'rpg' || !R || R.stam < 35 || p.dash > 0) return;
    R.stam -= 35; p.dash = 10; p.dashVx = g.lastDir.x * 9; p.dashVy = g.lastDir.y * 9; p.iframes = Math.max(p.iframes, 16); sfx('power');
}
function initRpg(L) {
    if (!g.gearHook) { g.gearHook = 1; g.hooks.kill.push((g, b) => { if (g.kind === 'rpg' && (Math.random() < 0.06 || b.elite || b.boss || b.type === 'totem')) dropPickup(g, 'gear', b.x, b.y, 1); }); }
    const st = g.stage, th = L.theme;
    const R = g.rpg = { walk: 0, stam: 100, focus: 60, volley: 0, atkCd: 0, combo: 0, comboT: 0, spawnT: 50, obs: [], theme: th, slashes: [], goal: L.goal || null, totemCd: 0 };
    st.kills = 0; st.smashed = 0; st.bossSpawned = false;
    const spots = [[90, 190], [270, 190], [90, 380], [270, 380], [180, 285]];
    shuffle(spots);
    const n = th === 'bone' ? 3 : 4;
    for (let i = 0; i < n; i++) R.obs.push({ x: spots[i][0] + rand(-10, 10), y: spots[i][1] + rand(-10, 10), r: th === 'plaza' && i === 0 ? 26 : 17 });
    if (!g.weapons.machete) { unlockWeapon(g, 'machete'); g.weapons.machete.cd = 0; }
    g.player.x = W / 2; g.player.y = H - 170;
    if (L.goal && L.goal.t === 'totem') {
        const ps = [[70, 160], [290, 160], [180, 300]];
        for (let i = 0; i < L.goal.n; i++) {
            const b = spawnBall('totem', ps[i][0], ps[i][1]); b.vy = b.baseVy = 0; b.hp = b.maxHp = Math.max(160, g.dps * 5.5 + 120 * g.camp.lvlDone); b.shootT = 80 + i * 50; b.waveT = 200 + i * 60; b.dmg = 0;
            R.obs = R.obs.filter(o => Math.hypot(o.x - ps[i][0], o.y - ps[i][1]) > 50);
        }
    }
}
function pushOut(o, x, y, r) {
    const dx = x - o.x, dy = y - o.y, d = Math.hypot(dx, dy) || 1, min = o.r + r;
    if (d < min) return [o.x + dx / d * min, o.y + dy / d * min];
    return null;
}
function rpgSpawnType(m) {
    const t = [['basic', 55], ['fast', 22], ['zig', m > 0.7 ? 14 : 0], ['pistolero', m > 0.8 ? 14 : 0], ['big', m > 1.2 ? 10 : 0], ['armored', m > 1.8 ? 10 : 0], ['dive', m > 1.4 ? 10 : 0], ['golden', 2]];
    let tot = 0; for (const x of t) tot += x[1];
    let r = Math.random() * tot; for (const x of t) { r -= x[1]; if (r <= 0) return x[0]; }
    return 'basic';
}
function updateRpg() {
    const S = g.S, p = g.player, R = g.rpg, st = g.stage, m = g.camp.m;
    if (g.clearT > 0) { updateBullets(g); commonFx(); updatePickupsK(0); if (mode !== 'play') return; clearTick(); return; }
    commonTick();
    R.stam = Math.min(100, R.stam + 0.7); R.focus = Math.min(100, R.focus + 0.12);
    if (R.atkCd > 0) R.atkCd--; if (R.comboT > 0) R.comboT--; else R.combo = 0;
    const px0 = p.x, py0 = p.y;
    movePlayerFree(0.9, 70, H - 40);
    for (const o of R.obs) { const r = pushOut(o, p.x, p.y, p.r * 0.8); if (r) { p.x = r[0]; p.y = r[1]; } }
    if (Math.hypot(p.x - px0, p.y - py0) > 0.4) { R.walk += 0.45; if (g.frames % 14 === 0) g.fx.push({ kind: 'p', x: p.x, y: p.y + 16, vx: rand(-0.2, 0.2), vy: rand(0, 0.3), color: 'rgba(255,255,255,0.35)', t: 14, max: 14, sz: 2 }); }
    // ---- spawns & objectives ----
    const alive = g.balls.filter(b => !b.dead && b.type !== 'totem' && !b.boss).length;
    if (st.boss) {
        if (st.t === 1) { g.warn = 110; sfx('boss'); }
        if (st.t === 90 && !st.bossSpawned) {
            st.bossSpawned = true;
            const b = spawnBall('calavera', W / 2, -60); b.boss = true; b.big = true; b.r = 40; b.dmg = 26; b.vy = b.baseVy = 0; b.tt = 0; b.cd1 = 100; b.cd2 = 220; b.cd3 = 0; b.dash = 0; b.windup = 0;
            setBossHp(b, 30, bossFloor(850));
            toast('LA CALAVERA GIGANTE', 'Smash the skull!', '#ff4757', 220);
        }
        if (st.bossSpawned && st.t > 130 && !g.balls.some(b => b.type === 'calavera' && !b.dead)) { stageDone(); return; }
    } else if (R.goal && R.goal.t === 'kill' && st.kills >= R.goal.n) { stageDone(); return; }
    else if (R.goal && R.goal.t === 'totem' && st.smashed >= R.goal.n) { stageDone(); return; }
    const cap = st.boss ? 6 : R.goal && R.goal.t === 'totem' ? 11 : Math.min(24, 9 + Math.round(m * 4));
    if (!st.boss && --R.spawnT <= 0 && alive < cap) {
        const side = randi(0, 2), t = rpgSpawnType(m);
        const r = BTYPES[t].r + 6, pos = side === 0 ? [rand(20, W - 20), 40 - r] : side === 1 ? [-r, rand(80, 380)] : [W + r, rand(80, 380)];
        const b = spawnBall(t, pos[0], pos[1]); b.vy = b.baseVy = 0; b.dmg = Math.round(b.dmg * 0.8 + 2); b.hp = b.maxHp = b.hp * 0.75; b.chase = rand(0.85, 1.15);
        R.spawnT = Math.max(16, 74 - m * 9) * rand(0.75, 1.25) / g.D.spawn;
    }
    // ---- aim, weapons, melee ----
    const tg = nearestBall(g, p.x, p.y, 400);
    g.aimA = tg ? Math.atan2(tg.y - p.y, tg.x - p.x) : Math.atan2(g.lastDir.y, g.lastDir.x);
    if (g.aimA !== g.aimA) g.aimA = -Math.PI / 2;
    if (R.volley > 0) { R.volley--; updateWeapons(g); if (g.frames % 8 === 0) addRing(g, p.x, p.y, 20, '#ffd32a', 8); }
    if (S.whirl && g.frames % 300 === 150) whirl();
    updateBullets(g); if (mode !== 'play') return;
    updatePet();
    // ---- enemies ----
    const bsm = S.ballSpeedMult * (g.timeSlow > 0 ? 0.3 : 1) * (g.dust > 0 ? 0.5 : 1);
    const bl = g.balls;
    for (const b of bl) {
        if (b.dead) continue;
        if (!tickBallStatus(b)) continue;
        let sm = bsm; if (b.slowT > 0) { b.slowT--; sm *= 0.5; }
        if (b.kT > 0) { b.kT--; b.x += b.kx * (b.kT / 14); b.y += b.ky * (b.kT / 14); }
        if (b.type === 'totem') updateTotem(b, sm);
        else if (b.type === 'calavera') updateCalavera(b, sm);
        else {
            const dx = p.x - b.x, dy = p.y - b.y, d = Math.hypot(dx, dy) || 1, T = BTYPES[b.type];
            let sp = (0.55 + (T.vy || 1) * 0.42) * (b.chase || 1) * Math.min(1.5, 1 + m * 0.07);
            if (b.type === 'pistolero') {
                sp = 0.7; const want = d > 170 ? 1 : d < 120 ? -1 : 0;
                b.x += dx / d * sp * want * sm; b.y += dy / d * sp * want * sm;
                b.x += -dy / d * 0.5 * sm;
                if (--b.shootT <= 0 && d < 330) { b.shootT = 100; const a = Math.atan2(dy, dx); g.ebullets.push({ x: b.x, y: b.y, vx: Math.cos(a) * 2.3, vy: Math.sin(a) * 2.3, r: 4, dmg: 8 }); sfx('ebullet'); }
            } else {
                if (b.type === 'zig') { const a = Math.atan2(dy, dx) + Math.sin((g.frames + b.phase) * 0.06) * 0.9; b.x += Math.cos(a) * sp * sm; b.y += Math.sin(a) * sp * sm; }
                else if (b.type === 'dive') { const surge = (g.frames + b.phase) % 150 < 28 ? 3.2 : 0.8; b.x += dx / d * surge * sm; b.y += dy / d * surge * sm; }
                else if (!b.boss) {
                    b.st = b.st || 0; b.cd = (b.cd || 0) - 1;
                    if (b.kT > 0 && b.st === 1) { b.st = 0; b.cd = 50; addText(g, b.x, b.y - b.r - 8, 'STAGGER', '#ffd166', 9); }
                    if (b.st === 0) { b.x += dx / d * sp * sm; b.y += dy / d * sp * sm; if (d < 66 + b.r && b.cd <= 0) { b.st = 1; b.wt = Math.max(16, 30 - m * 1.5); b.dx = dx / d; b.dy = dy / d; } }
                    else if (b.st === 1) { b.wt -= sm; b.dx = dx / d; b.dy = dy / d; if (b.wt <= 0) { b.st = 2; b.lt = 13; b.pd = 0; } }
                    else if (b.st === 2) { b.x += b.dx * 5.6 * sm; b.y += b.dy * 5.6 * sm; if (--b.lt <= 0) { b.st = 3; b.lt = 42; } }
                    else if (--b.lt <= 0) { b.st = 0; b.cd = 50; }
                } else { b.x += dx / d * sp * sm; b.y += dy / d * sp * sm; }
            }
        }
        for (const o of R.obs) { const r = pushOut(o, b.x, b.y, b.r * 0.7); if (r) { b.x = r[0]; b.y = r[1]; } }
        b.x = clamp(b.x, -40, W + 40); b.y = clamp(b.y, -60, H + 40);
    }
    // soft separation so enemies don't stack into one blob
    for (let i = 0; i < bl.length; i++) {
        const a = bl[i]; if (a.dead || a.boss || a.type === 'totem') continue;
        for (let j = i + 1; j < bl.length; j++) {
            const c = bl[j]; if (c.dead || c.boss || c.type === 'totem') continue;
            const dx = c.x - a.x, dy = c.y - a.y, rr = (a.r + c.r) * 0.7, d2 = dx * dx + dy * dy;
            if (d2 < rr * rr && d2 > 0.01) { const d = Math.sqrt(d2), push = (rr - d) * 0.25; a.x -= dx / d * push; a.y -= dy / d * push; c.x += dx / d * push; c.y += dy / d * push; }
        }
    }
    for (const b of bl) {
        if (b.dead || b.dmg <= 0) continue;
        if (!b.boss && b.type !== 'pistolero' && b.st !== 2) continue;
        if (b.st === 2 && p.dash > 0 && !b.pd && Math.hypot(b.x - p.x, b.y - p.y) < b.r + 30) {
            b.pd = 1; g.timeSlow = Math.max(g.timeSlow, 40); R.focus = Math.min(100, R.focus + 30); R.stam = Math.min(100, R.stam + 40); gainGold(g, 3);
            addText(g, p.x, p.y - 30, 'PERFECT DODGE!', '#ffd32a', 12); addRing(g, p.x, p.y, 50, '#ffd32a', 18); continue;
        }
        const rr = b.r * 0.85 + p.r * 0.8;
        if ((b.x - p.x) ** 2 + (b.y - p.y) ** 2 < rr * rr) {
            hurtPlayer(g, b.dmg, b); if (mode !== 'play') return;
            if (!b.boss && p.iframes > 0) { const d = Math.hypot(b.x - p.x, b.y - p.y) || 1; b.kx = (b.x - p.x) / d * 6; b.ky = (b.y - p.y) / d * 6; b.kT = 12; }
        }
    }
    compactBalls(g);
    updateEBullets(0); if (mode !== 'play') return;
    updatePickupsK(0); if (mode !== 'play') return;
    for (let i = R.slashes.length - 1; i >= 0; i--) if (--R.slashes[i].t <= 0) R.slashes.splice(i, 1);
    commonFx(); updateScenery(0.3, 0);
}
function rpgAttack() {
    const R = g.rpg, p = g.player, S = g.S, w = g.weapons.machete;
    if (mode !== 'play' || g.kind !== 'rpg' || !R || R.atkCd > 0) return;
    const L = w ? w.lvl : 1; R.combo = R.comboT > 0 ? (R.combo % 3) + 1 : 1; R.comboT = 38;
    const heavy = R.combo === 3, reach = (46 + 5 * L + (heavy ? 18 : 0)) * S.aoe, half = (heavy ? 1.9 : 1.05 + 0.04 * L) * (1 + S.arc), dmg = 15 * (1 + 0.25 * (L - 1)) * (heavy ? 1.9 : 1);
    const tg = nearestBall(g, p.x, p.y, reach + 70);
    const ang = tg ? Math.atan2(tg.y - p.y, tg.x - p.x) : Math.atan2(g.lastDir.y, g.lastDir.x);
    p.x = clamp(p.x + Math.cos(ang) * (heavy ? 10 : 5), 14, W - 14); p.y = clamp(p.y + Math.sin(ang) * (heavy ? 10 : 5), 70, H - 40);
    R.slashes.push({ x: p.x, y: p.y, a: ang, r: reach, half, t: 9, max: 9 });
    let hit = 0;
    for (const b of g.balls) {
        if (b.dead) continue;
        const dx = b.x - p.x, dy = b.y - p.y, d = Math.hypot(dx, dy);
        if (d > reach + b.r) continue;
        let df = Math.atan2(dy, dx) - ang; while (df > Math.PI) df -= TAU; while (df < -Math.PI) df += TAU;
        if (Math.abs(df) > half + b.r / Math.max(d, 20)) continue;
        dealDamage(g, b, dmg, { color: heavy ? '#ffd32a' : '#dfe6e9' }); hit++;
        if (!b.dead && !b.boss && b.type !== 'totem') { b.kx = dx / (d || 1) * (heavy ? 12 : 7); b.ky = dy / (d || 1) * (heavy ? 12 : 7); b.kT = heavy ? 16 : 12; }
    }
    if (hit) { R.focus = Math.min(100, R.focus + 3 * hit); if (heavy) { g.hitstop = 3; g.shake = Math.max(g.shake, 5); } }
    if (heavy) addText(g, p.x, p.y - 28, 'HEAVY!', '#ffd32a', 11);
    sfx('shield'); R.atkCd = Math.max(6, Math.round((heavy ? 22 : 11) * S.cooldownMult / (S.fireRate * g.dyn.fireRate)));
}
function rpgVolley() {
    const R = g.rpg; if (mode !== 'play' || g.kind !== 'rpg' || !R || R.focus < 40 || R.volley > 0) return;
    R.focus -= 40; R.volley = 150; sfx('power'); toast('GUNSLINGER!', 'Your guns open fire', '#ffd32a', 70);
}
function updateTotem(b, sm) {
    const p = g.player;
    if ((b.shootT -= sm) <= 0) {
        b.shootT = 220; const off = rand(0, TAU), n = 8;
        for (let k = 0; k < n; k++) g.ebullets.push({ x: b.x, y: b.y, vx: Math.cos(off + k * TAU / n) * 1.5, vy: Math.sin(off + k * TAU / n) * 1.5, r: 4, dmg: 7 });
        addRing(g, b.x, b.y, 40, '#bd93f9', 14);
    }
    if ((b.waveT -= sm) <= 0) {
        b.waveT = 340;
        for (let i = 0; i < 2; i++) { const e = spawnBall(Math.random() < 0.5 ? 'basic' : 'fast', b.x + (i ? 26 : -26), b.y + 14); e.vy = e.baseVy = 0; e.hp = e.maxHp = e.hp * 0.75; e.chase = 1; }
    }
}
function updateCalavera(b, sm) {
    const p = g.player, hp = b.hp / b.maxHp;
    b.tt++; if (b.inv > 0) b.inv--;
    if (!b.ph2 && hp < 0.5) { b.ph2 = true; b.inv = 50; g.shake = 14; sfx('boss'); toast('BONE STORM!', 'She spins faster', '#ff4757', 150); g.ebullets.length = 0; }
    const dx = p.x - b.x, dy = p.y - b.y, d = Math.hypot(dx, dy) || 1;
    if (b.dash > 0) { b.dash--; b.x += b.dvx; b.y += b.dvy; }
    else if (b.windup > 0) { b.windup--; if (b.windup === 0) { b.dash = 28; b.dvx = dx / d * 6.2; b.dvy = dy / d * 6.2; } }
    else if (b.inv <= 0) { const sp = (b.ph2 ? 0.7 : 0.5) * sm; b.x += dx / d * sp; b.y += dy / d * sp; }
    b.x = clamp(b.x, b.r, W - b.r); b.y = clamp(b.y, b.r + 40, H - b.r);
    if (b.inv > 0 || b.y < 20) return;
    if ((b.cd1 -= sm) <= 0) {
        b.cd1 = b.ph2 ? 95 : 130; const n = b.ph2 ? 16 : 12, off = rand(0, TAU);
        for (let k = 0; k < n; k++) g.ebullets.push({ x: b.x, y: b.y, vx: Math.cos(off + k * TAU / n) * 1.9, vy: Math.sin(off + k * TAU / n) * 1.9, r: 4, dmg: 10 });
        addRing(g, b.x, b.y, 70, '#dfe6e9', 16); sfx('ebullet');
    }
    if ((b.cd2 -= sm) <= 0) {
        b.cd2 = b.ph2 ? 230 : 300;
        if (g.balls.filter(x => !x.dead && !x.boss).length < 9) for (let i = 0; i < 3; i++) { const e = spawnBall(i === 1 && b.ph2 ? 'pistolero' : 'basic', b.x + (i - 1) * 40, b.y + 30); e.vy = e.baseVy = 0; e.hp = e.maxHp = e.hp * 0.7; e.chase = 1; }
    }
    if (b.tt % 360 === 240 && b.dash <= 0) { b.windup = 40; toast('CHARGE!', '', '#ff9f43', 45); }
    if (b.ph2) { b.cd3 -= sm; if (b.cd3 <= 0) { b.cd3 = 9; b.spin = (b.spin || 0) + 0.45; g.ebullets.push({ x: b.x, y: b.y, vx: Math.cos(b.spin) * 2, vy: Math.sin(b.spin) * 2, r: 3.6, dmg: 8 }); } }
}

// ---------------------------------------------------------------------
//  Drawing
// ---------------------------------------------------------------------
function drawRpgBack() {
    const R = g.rpg, T = RPG_THEMES[R.theme] || RPG_THEMES.plaza;
    ctx.fillStyle = T.a; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = T.b;
    for (let y = 0; y < H; y += 40) for (let x = ((y / 40) % 2) * 40; x < W; x += 80) ctx.fillRect(x, y, 40, 40);
    ctx.strokeStyle = T.grid; ctx.lineWidth = 1; ctx.beginPath();
    for (let y = 0; y <= H; y += 40) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
    for (let x = 0; x <= W; x += 40) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
    ctx.stroke();
    if (R.theme === 'cantina') { ctx.fillStyle = 'rgba(255,190,90,0.07)'; ctx.fillRect(0, 0, W, H); }
    if (R.theme === 'orchard' || R.theme === 'bone') { const gr = ctx.createRadialGradient(W / 2, H / 2, 120, W / 2, H / 2, 440); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,10,0.5)'); ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H); }
    // arena border
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 6; ctx.strokeRect(3, 3, W - 6, H - 6);
    for (const o of R.obs) {
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(o.x + 3, o.y + o.r * 0.75, o.r, o.r * 0.45, 0, 0, TAU); ctx.fill();
        if (T.obs === 'fountain') {
            ctx.fillStyle = '#9aa5ad'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, TAU); ctx.fill();
            ctx.fillStyle = '#5dade2'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r * 0.74, 0, TAU); ctx.fill();
            ctx.fillStyle = '#d6eaf8'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r * 0.22, 0, TAU); ctx.fill();
        } else if (T.obs === 'table') {
            ctx.fillStyle = '#5e3a1a'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, TAU); ctx.fill();
            ctx.fillStyle = '#a0703c'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r * 0.82, 0, TAU); ctx.fill();
            ctx.fillStyle = '#e74c3c'; ctx.beginPath(); ctx.arc(o.x - 4, o.y - 2, 3, 0, TAU); ctx.fill();
        } else if (T.obs === 'tomb') {
            ctx.fillStyle = '#7f8c8d'; roundRect(o.x - 11, o.y - o.r, 22, o.r * 1.7, 9); ctx.fill();
            ctx.fillStyle = '#566265'; ctx.fillRect(o.x - 1.5, o.y - o.r + 5, 3, 11); ctx.fillRect(o.x - 5, o.y - o.r + 8, 10, 3);
        } else {
            ctx.fillStyle = '#d7ccc8'; roundRect(o.x - 12, o.y - o.r, 24, o.r * 1.8, 6); ctx.fill();
            ctx.fillStyle = '#a1887f'; ctx.fillRect(o.x - 12, o.y - o.r + 6, 24, 3); ctx.fillRect(o.x - 12, o.y + 6, 24, 3);
        }
    }
}
function drawRpgFront() {
    const R = g.rpg; if (!R) return;
    for (const k of g.pickups) if (k.type === 'gear') {
        drawGlow(k.x, k.y, 20, '#ffd32a', 0.8); ctx.fillStyle = '#7f8c8d'; roundRect(k.x - 7, k.y - 7, 14, 14, 3); ctx.fill();
        ctx.fillStyle = '#ecf0f1'; ctx.fillRect(k.x - 1, k.y - 6, 2, 9); ctx.fillRect(k.x - 4, k.y - 1, 8, 2); ctx.fillStyle = '#ffd32a'; ctx.fillRect(k.x - 1.5, k.y + 3, 3, 3);
    }
    const lv = 1 + Math.round(g.camp.m * 1.5);
    for (const b of g.balls) {
        if (b.dead || b.boss || b.type === 'totem' || b.type === 'crate') continue;
        const f = clamp(b.hp / b.maxHp, 0, 1); if (f >= 1) continue;
        ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(b.x - 12, b.y - b.r - 9, 24, 4); ctx.fillStyle = f > 0.5 ? '#7bed9f' : f > 0.25 ? '#ffd166' : '#ff6b6b'; ctx.fillRect(b.x - 12, b.y - b.r - 9, 24 * f, 4);
        ctx.fillStyle = '#fff'; ctx.font = 'bold 7px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('Lv' + lv, b.x, b.y - b.r - 11); ctx.textAlign = 'left';
    }
    for (const b of g.balls) if (!b.dead && b.st === 1) {
        ctx.save(); ctx.globalAlpha = 0.5 + 0.4 * Math.sin(menuT * 0.8); ctx.strokeStyle = '#ff4757'; ctx.lineWidth = b.r * 1.2; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + b.dx * 70, b.y + b.dy * 70); ctx.stroke(); ctx.restore();
        ctx.fillStyle = '#ff4757'; ctx.font = 'bold 14px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('!', b.x, b.y - b.r - 12); ctx.textAlign = 'left';
    }
    // hero sheet + stamina and roll button
    const S = g.S;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; roundRect(8, H - 66, 112, 52, 8); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 10px system-ui, sans-serif';
    ctx.fillText(`⚔ ATK ${Math.round(S.dmg * 100)}   🛡 DEF ${S.armor}`, 14, H - 50);
    ctx.fillText(`👢 SPD ${Math.round(S.speed / 3 * 100)}   🎒 ${g.gear || 0}`, 14, H - 36);
    ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.fillRect(14, H - 26, 100, 5); ctx.fillStyle = R.stam >= 35 ? '#48dbfb' : '#636e72'; ctx.fillRect(14, H - 26, R.stam, 5);
    const rb = (bx, by, br, col, lab, fn, fill) => {
        uiButtons.push({ x: bx - br, y: by - br, w: br * 2, h: br * 2, fn });
        ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.fill();
        ctx.strokeStyle = col; ctx.lineWidth = 3.5; ctx.beginPath(); ctx.arc(bx, by, br - 2, -Math.PI / 2, -Math.PI / 2 + TAU * fill); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(lab, bx, by + 3); ctx.textAlign = 'left';
    };
    rb(W - 46, H - 118, 32, R.atkCd > 0 ? '#999' : '#ff6b6b', R.combo && R.comboT > 0 ? 'SLASH ' + R.combo : 'SLASH', rpgAttack, 1);
    rb(W - 110, H - 96, 24, R.focus >= 40 ? '#ffd32a' : '#636e72', R.volley > 0 ? 'FIRING' : 'GUNS', rpgVolley, R.volley > 0 ? R.volley / 150 : R.focus / 100);
    const bx = 150, by = H - 44, br = 24;
    uiButtons.push({ x: bx - br, y: by - br, w: br * 2, h: br * 2, fn: rpgRoll });
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.fill();
    ctx.strokeStyle = R.stam >= 35 ? '#48dbfb' : '#636e72'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(bx, by, br - 2, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 9px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('ROLL', bx, by + 3); ctx.textAlign = 'left';
    for (const s of R.slashes) {
        const u = 1 - s.t / s.max;
        ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.a); ctx.globalAlpha = 1 - u * 0.8;
        ctx.strokeStyle = '#f8f9fa'; ctx.lineWidth = 7 - 4 * u; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.arc(0, 0, s.r * (0.6 + 0.4 * u), -s.half + u * 0.5, s.half - u * 0.2); ctx.stroke();
        ctx.strokeStyle = 'rgba(180,220,255,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, s.r * (0.7 + 0.3 * u), -s.half + u * 0.5, s.half - u * 0.2); ctx.stroke();
        ctx.restore();
    }
}
function drawTotem(b) {
    const x = b.x, y = b.y, r = b.r;
    drawGlow(x, y, r * 2.4, '#a55eea', 0.35 + 0.15 * Math.sin(menuT * 0.1));
    ctx.save(); ctx.translate(x, y); if (b.flash > 0) ctx.globalAlpha = 0.8;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(2, r, r * 0.9, 5, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = b.flash > 0 ? '#fff' : '#5b3a7a'; roundRect(-r * 0.7, -r * 1.2, r * 1.4, r * 2.3, 6); ctx.fill();
    ctx.fillStyle = '#7d4fa3'; roundRect(-r * 0.7, -r * 1.2, r * 0.5, r * 2.3, 5); ctx.fill();
    ctx.fillStyle = '#ffd32a'; ctx.fillRect(-r * 0.7, -r * 0.2, r * 1.4, 3);
    ctx.fillStyle = '#e8ffb0'; ctx.beginPath(); ctx.arc(-5, -r * 0.6, 3.2, 0, TAU); ctx.arc(5, -r * 0.6, 3.2, 0, TAU); ctx.fill();
    ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(-5, -r * 0.6, 1.3, 0, TAU); ctx.arc(5, -r * 0.6, 1.3, 0, TAU); ctx.fill();
    ctx.fillStyle = '#111'; ctx.fillRect(-5, -r * 0.1 - 6, 10, 3);
    ctx.restore();
    const f = clamp(b.hp / b.maxHp, 0, 1);
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(x - 18, y - r - 14, 36, 5); ctx.fillStyle = '#bd93f9'; ctx.fillRect(x - 18, y - r - 14, 36 * f, 5);
}
function drawCalavera(b) {
    const x = b.x, y = b.y, r = b.r;
    drawGlow(x, y, r * 2.4, b.windup > 0 ? '#ff4757' : '#a29bfe', 0.3);
    ctx.save(); ctx.translate(x, y);
    if (b.inv > 0 && Math.floor(b.inv / 4) % 2 === 0) ctx.globalAlpha = 0.5;
    if (b.windup > 0) ctx.translate(rand(-1.5, 1.5), rand(-1.5, 1.5));
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(3, r * 0.9, r, r * 0.3, 0, 0, TAU); ctx.fill();
    const col = b.flash > 0 ? '#ffffff' : '#ecf0f1';
    ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, -4, r * 0.95, 0, TAU); ctx.fill();
    roundRect(-r * 0.55, r * 0.35, r * 1.1, r * 0.55, 8); ctx.fill();
    // the same painted sugar-skull face the ghosts wear, scaled up: cracked and sooty, eyes burn red when it winds up
    { const k = r * 0.95 / 15; ctx.save(); ctx.translate(0, -4 + 12 * k); ctx.scale(k, k); ghostSkull(7, 1, b.windup > 0 ? '#ff4757' : '#8ff7e6', b.tt * 0.08 || 0, 0, b.windup > 0 ? 6 : 1.5 + Math.sin((b.tt || 0) * 0.1)); ctx.restore(); }
    ctx.restore();
}