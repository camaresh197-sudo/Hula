
function whirl() {
    const p = g.player, R = g.rpg, r = 78 * g.S.aoe;
    R.slashes.push({ x: p.x, y: p.y, a: 0, r, half: Math.PI, t: 12, max: 12 });
    for (const b of g.balls) { if (b.dead) continue; const d = Math.hypot(b.x - p.x, b.y - p.y); if (d < r + b.r) { dealDamage(g, b, 24, { color: '#f8f9fa' }); if (!b.dead && !b.boss && b.type !== 'totem' && d > 0) { b.kx = (b.x - p.x) / d * 8; b.ky = (b.y - p.y) / d * 8; b.kT = 12; } } }
    sfx('shield');
}

// =====================================================================
//  EXTRA CUTSCENES: act intros and the ending
// =====================================================================
function csGround(gy, c1, c2) { ctx.fillStyle = c1; ctx.fillRect(0, gy, W, H - gy); ctx.fillStyle = c2; ctx.fillRect(0, gy, W, 5); }
function csConfetti(t, n) {
    for (let i = 0; i < n; i++) {
        const x = (i * 41 + Math.sin(t * 0.03 + i) * 12) % W, y = (t * (0.7 + (i % 4) * 0.3) + i * 53) % 440;
        ctx.fillStyle = CONF[i % CONF.length]; ctx.fillRect(x, y, 4, 3);
    }
}
// =====================================================================
//  THE PURSUIT TOOLKIT: a canyon highway in perspective, a convoy of lantern thieves, and the taco car seen from behind.
//  Used by the Act 2 intro and by "The Road Home".
// =====================================================================
const PR = { hy: 190, bot: 446, hw: 176, k: 14 };   // horizon row, bottom of the art window, road half-width at the bottom, depth scale
const PR_PAL = {
    dawn: { sky: ['#3d63c8', '#8f8ed4', '#f0a5ae', '#ffcf9c'], sunX: 236, haze: '#ffcf9c', far: '#8f7ab8', mid: '#c4685c', midHi: '#f4a47e', near: '#83403a', gA: '#d58d4e', gB: '#cc8248', road: '#4f4b55', roadB: '#49454f', rumA: '#d8483a', rumB: '#f4ead2', line: '#ffd75e', edge: '#f7f1dc', tint: 'rgba(255,170,90,0.10)', stars: 0 },
    dusk: { sky: ['#241f55', '#6f3b8a', '#d65a7c', '#ff9a58', '#ffc07a'], sunX: 118, haze: '#ffc07a', far: '#6a4a8c', mid: '#8c3f56', midHi: '#d0685c', near: '#4a2336', gA: '#a8603a', gB: '#9c5634', road: '#403c4a', roadB: '#3b3744', rumA: '#c8402f', rumB: '#e9d9bb', line: '#ffcf55', edge: '#eadfc6', tint: 'rgba(255,120,70,0.14)', stars: 1 },
};
PR_PAL.canyon = { sky: ['#2d74d6', '#78b6ec', '#fbe0b0', '#ffe3b4'], sunX: 250, haze: '#fbe0b0', far: '#b58a78', mid: '#d97a4e', midHi: '#ffb27c', near: '#8a4a34', gA: '#e6a45c', gB: '#dc9a52', road: '#5a5660', roadB: '#524e58', rumA: '#d8483a', rumB: '#f7efd8', line: '#ffd75e', edge: '#f7f1dc', tint: 'rgba(255,200,120,0.05)', stars: 0 };
PR_PAL.night = { sky: ['#050a1e', '#0e1f4a', '#1d3a78', '#3a5aa0'], sunX: 96, haze: '#3a5aa0', far: '#16254a', mid: '#1c2f5c', midHi: '#4a6aa8', near: '#0b1630', gA: '#2a4a50', gB: '#244248', road: '#2a2d3a', roadB: '#262836', rumA: '#8a2f3a', rumB: '#9ab0d0', line: '#d8c860', edge: '#9fb4d4', tint: 'rgba(20,40,120,0.16)', stars: 1, sc: ['225,238,255', '150,180,255', '90,120,220'], core: '#eef4ff' };
PR_PAL.boss = { sky: ['#2a0a0e', '#5a1414', '#b83a1c', '#ff8a3a'], sunX: 270, haze: '#ff8a3a', far: '#4a1a1a', mid: '#6a2018', midHi: '#d0502a', near: '#2a0c0c', gA: '#5a2a20', gB: '#52241c', road: '#2c2226', roadB: '#281e22', rumA: '#ff7a45', rumB: '#2a1c1c', line: '#ffb030', edge: '#f0d0b0', tint: 'rgba(255,60,20,0.1)', stars: 0, sc: ['255,200,150', '255,120,60', '230,60,30'], core: '#ffd2a0' };
const prBend = t => Math.sin(t * 0.0105) * 0.85 + Math.sin(t * 0.0043 + 1.2) * 0.45;
const prCx = (u, bend) => 180 + bend * Math.pow(1 - u, 1.7) * 105;
const prU = p => 1 / (1 + p / PR.k);
const prY = u => PR.hy + (PR.bot - PR.hy) * u;
const prRows = {};
function prRowCache(P, key) {   // per-row colours (haze-tinted by distance) built once per palette
    if (prRows[key]) return prRows[key];
    const rows = [], H0 = PR.bot - PR.hy;
    for (let y = PR.hy; y < PR.bot; y += 2) {
        const u = (y + 1 - PR.hy) / H0, f = Math.pow(1 - u, 2) * 0.85, p = PR.k * (1 / u - 1), m = (a) => lerpColor(a, P.haze, f);
        rows.push({ y, u, p, g: [m(P.gA), m(P.gB)], ru: [m(P.rumA), m(P.rumB)], rd: [m(P.road), m(P.roadB)], ln: m(P.line), ed: m(P.edge) });
    }
    return prRows[key] = rows;
}
function prSky(P, key) {
    const SR = Math.min(RES, 3), hy = PR.hy;
    return cachedDraw(spriteCache, 'prsky|' + key + '|' + SR, 0, 0, W, hy + 24, SR, () => {
        const gr = ctx.createLinearGradient(0, 0, 0, hy + 2); P.sky.forEach((c, i) => gr.addColorStop(i / (P.sky.length - 1), c));
        ctx.fillStyle = gr; ctx.fillRect(0, 0, W, hy + 24);
        if (P.stars) for (let i = 0; i < 80; i++) { ctx.fillStyle = 'rgba(255,255,255,' + (0.2 + hash2(i, 3) * 0.55).toFixed(2) + ')'; ctx.fillRect(hash2(i, 1) * W, hash2(i, 2) * hy * 0.5, 1.2, 1.2); }
        const sx = P.sunX, sy = hy - 22;
        const bl = ctx.createRadialGradient(sx, sy, 2, sx, sy, 170); const sc = P.sc || ['255,244,200', '255,214,140', '255,170,110']; bl.addColorStop(0, 'rgba(' + sc[0] + ',0.95)'); bl.addColorStop(0.14, 'rgba(' + sc[1] + ',0.55)'); bl.addColorStop(0.5, 'rgba(' + sc[2] + ',0.17)'); bl.addColorStop(1, 'rgba(' + sc[2] + ',0)');
        ctx.fillStyle = bl; ctx.fillRect(0, 0, W, hy + 24);
        ctx.save(); ctx.translate(sx, sy);
        for (let k = 0; k < 11; k++) { const a = -Math.PI / 2 + (k - 5) * 0.24; ctx.fillStyle = 'rgba(255,235,190,0.055)'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a - 0.05) * 440, Math.sin(a - 0.05) * 440); ctx.lineTo(Math.cos(a + 0.05) * 440, Math.sin(a + 0.05) * 440); ctx.fill(); }
        ctx.restore();
        ctx.fillStyle = P.core || '#fff6d6'; ctx.beginPath(); ctx.arc(sx, sy, P.core ? 16 : 24, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.moveTo(0, hy + 24);
        for (let x = 0; x <= W; x += 5) ctx.lineTo(x, hy - (Math.sin(x * 0.031 + 1) * 11 + Math.sin(x * 0.083 + 2) * 6 + Math.sin(x * 0.013) * 13 + Math.sin(x * 0.21) * 1.6 + 27));
        ctx.lineTo(W, hy + 24); ctx.closePath();
        const fm = ctx.createLinearGradient(0, hy - 60, 0, hy + 4); fm.addColorStop(0, P.far); fm.addColorStop(1, P.haze); ctx.fillStyle = fm; ctx.fill();
    });
}
const PR_MESA = Array.from({ length: 15 }, (_, i) => ({ x: i * 36 - 50 + hash2(i, 1.3) * 28, w: 58 + hash2(i, 2.2) * 80, h: 20 + hash2(i, 3.7) * 38 }));
function prMesa(x, yb, w, h, col, hiCol, hz, sunX) {
    const lx = x + w * 0.17, rx = x + w * 0.83, top = yb - h;
    ctx.beginPath(); ctx.moveTo(x, yb); ctx.lineTo(x + w * 0.05, yb - h * 0.5); ctx.lineTo(x + w * 0.11, yb - h * 0.56); ctx.lineTo(lx, top); ctx.lineTo(rx, top); ctx.lineTo(x + w * 0.89, yb - h * 0.54); ctx.lineTo(x + w * 0.95, yb - h * 0.48); ctx.lineTo(x + w, yb); ctx.closePath();
    ctx.fillStyle = col; ctx.fill();
    const litRight = x + w / 2 < sunX;
    ctx.save(); ctx.clip();
    ctx.globalAlpha = 0.55; ctx.fillStyle = hiCol; ctx.fillRect(litRight ? x + w * 0.6 : x, top - 2, w * 0.4, h + 4); ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(70,20,40,0.2)'; ctx.fillRect(litRight ? x : x + w * 0.6, top - 2, w * 0.4, h + 4);
    ctx.strokeStyle = 'rgba(60,20,40,0.16)'; ctx.lineWidth = 1; for (const f of [0.3, 0.55, 0.78]) { ctx.beginPath(); ctx.moveTo(x, yb - h * f); ctx.lineTo(x + w, yb - h * f); ctx.stroke(); }
    const hg = ctx.createLinearGradient(0, top, 0, yb); hg.addColorStop(0, 'rgba(255,200,160,0)'); hg.addColorStop(1, hz); ctx.fillStyle = hg; ctx.fillRect(x, top, w, h);
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,228,185,0.55)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(lx, top + 0.6); ctx.lineTo(rx, top + 0.6); ctx.stroke();
}
function prNear(P, bend) {   // dark foothills with cactus silhouettes, the fastest-parallax layer
    const sh = -bend * 34, yb = PR.hy + 3, hh = x => 5 + 7 * (Math.sin(x * 0.045 + 1) + 1) + 6 * (Math.sin(x * 0.019 + 2) + 1);
    ctx.fillStyle = P.near; ctx.beginPath(); ctx.moveTo(-10, yb);
    for (let x = -10; x <= W + 10; x += 5) ctx.lineTo(x, yb - hh(x - sh));
    ctx.lineTo(W + 10, yb); ctx.closePath(); ctx.fill();
    for (let c = -2; c < 9; c++) { const wx = c * 53 + 14 + (hash2(c, 4) * 18) + (sh % 53), yy = yb - hh(wx - sh) + 1, h = 9 + hash2(c, 8) * 9; ctx.fillStyle = P.near; roundRect(wx - 1.3, yy - h, 2.6, h, 1.3); ctx.fill(); roundRect(wx - 5, yy - h * 0.62, 2.2, h * 0.34, 1.1); ctx.fill(); ctx.fillRect(wx - 5, yy - h * 0.4, 4, 2); roundRect(wx + 2.8, yy - h * 0.74, 2.2, h * 0.36, 1.1); ctx.fill(); ctx.fillRect(wx, yy - h * 0.48, 4, 2); }
}
function prVillage(P, bend) {   // Valle Chiquito on the horizon: rooftops, a church tower, warm windows
    const x0 = prCx(0, bend) - 56, yb = PR.hy + 2;
    ctx.fillStyle = shade(P.near, -0.15);
    const hs = [[0, 16, 9], [17, 12, 12], [30, 18, 8], [49, 10, 14], [60, 14, 20], [76, 16, 10], [93, 12, 8], [106, 12, 11]];
    for (const [dx, w, h] of hs) { ctx.fillRect(x0 + dx, yb - h, w, h); }
    ctx.beginPath(); ctx.moveTo(x0 + 59, yb - 20); ctx.lineTo(x0 + 67, yb - 30); ctx.lineTo(x0 + 75, yb - 20); ctx.fill(); ctx.fillRect(x0 + 66.4, yb - 36, 1.4, 7); ctx.fillRect(x0 + 64.6, yb - 34.6, 5, 1.2);
    for (let i = 0; i < 16; i++) { const [dx, w, h] = hs[i % hs.length], wx = x0 + dx + 2 + (i * 3) % Math.max(2, w - 4), wy = yb - 3 - ((i * 5) % Math.max(2, h - 4)); ctx.fillStyle = 'rgba(255,200,110,' + (0.5 + 0.4 * Math.abs(Math.sin(menuT * 0.05 + i))).toFixed(2) + ')'; ctx.fillRect(wx, wy, 1.8, 1.8); }
    drawGlow(x0 + 56, yb - 6, 60, '#ffb35a', 0.55);
}
function prClouds(P, t) {
    for (let i = 0; i < 6; i++) {
        const x = ((i * 97 + t * (0.1 + i * 0.018)) % (W + 240)) - 120, y = 38 + i * 21 + (i % 2) * 9, w = 70 + (i * 37) % 70;
        ctx.globalAlpha = 0.5; for (const [dy, k, c] of [[0, 1, 'rgba(255,236,230,0.9)'], [2.5, 0.8, 'rgba(255,170,150,0.8)'], [-2, 0.55, 'rgba(255,255,255,0.8)']]) { ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(x, y + dy, w * k, 4.5 * k, 0, 0, TAU); ctx.fill(); }
        ctx.globalAlpha = 1;
    }
    for (let b = 0; b < 4; b++) { const bx = ((b * 83 + t * 0.7) % (W + 80)) - 40, by = 92 + b * 14 + Math.sin(t * 0.04 + b) * 4, fl = Math.sin(t * 0.3 + b * 2) * 2.5; ctx.strokeStyle = 'rgba(40,20,50,0.7)'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(bx - 5, by + fl); ctx.quadraticCurveTo(bx - 2, by - 2 - fl, bx, by); ctx.quadraticCurveTo(bx + 2, by - 2 - fl, bx + 5, by + fl); ctx.stroke(); }
}
function prRoad(P, key, bend, scroll) {
    const rows = prRowCache(P, key);
    for (const r of rows) {
        const hwr = PR.hw * r.u, cx = prCx(r.u, bend), fine = r.u < 0.05, bi = fine ? 0 : (Math.floor((r.p + scroll) / 9) & 1), y = r.y;
        ctx.fillStyle = r.g[bi]; ctx.fillRect(0, y, W, 2);
        const rum = Math.max(1.2, hwr * 0.085);
        ctx.fillStyle = 'rgba(0,0,0,0.1)'; ctx.fillRect(cx - hwr - rum * 3.2, y, hwr * 2 + rum * 6.4, 2);
        ctx.fillStyle = r.ru[bi]; ctx.fillRect(cx - hwr - rum, y, hwr * 2 + rum * 2, 2);
        ctx.fillStyle = r.rd[bi]; ctx.fillRect(cx - hwr, y, hwr * 2, 2);
        if (!fine) { ctx.fillStyle = 'rgba(0,0,0,0.07)'; for (const l of [-0.667, 0, 0.667]) ctx.fillRect(cx + l * hwr - hwr * 0.15, y, hwr * 0.3, 2); }
        const ew = Math.max(0.8, hwr * 0.03); ctx.fillStyle = r.ed; ctx.fillRect(cx - hwr * 0.94, y, ew, 2); ctx.fillRect(cx + hwr * 0.94 - ew, y, ew, 2);
        if (!fine && (Math.floor((r.p + scroll) / 7) & 1) === 0) { const dw = Math.max(0.7, hwr * 0.022); ctx.fillStyle = r.ln; ctx.fillRect(cx - hwr / 3 - dw / 2, y, dw, 2); ctx.fillRect(cx + hwr / 3 - dw / 2, y, dw, 2); }
    }
    const hz = ctx.createLinearGradient(0, PR.hy - 3, 0, PR.hy + 22); hz.addColorStop(0, hexA(P.haze, 0)); hz.addColorStop(0.3, hexA(P.haze, 0.55)); hz.addColorStop(1, hexA(P.haze, 0)); ctx.fillStyle = hz; ctx.fillRect(0, PR.hy - 3, W, 25);
}
// ---------- roadside props (cached sprites, natural size = size at the camera) ----------
function prObjSprite(kind, v) {
    const SR = Math.min(RES, 3), D = {
        sag: { w: 120, h: 230, ox: 60, oy: 214, paint: () => {
            const H0 = 170 + v * 26, tr = (x, y0, y1, w) => { ctx.fillStyle = lg(x - w, 0, x + w, 0, [[0, '#1d5a30'], [0.35, '#4d9a4a'], [0.6, '#3b8040'], [1, '#18482a']]); roundRect(x - w, y1, w * 2, y0 - y1, w); ctx.fill(); ctx.strokeStyle = 'rgba(10,50,25,0.45)'; ctx.lineWidth = 1; for (const f of [-0.55, 0, 0.55]) { ctx.beginPath(); ctx.moveTo(x + f * w, y0); ctx.lineTo(x + f * w, y1 + w); ctx.stroke(); } };
            ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.ellipse(8, 1, 34, 5, 0, 0, TAU); ctx.fill();
            tr(0, 2, -H0, 12);
            const arm = (dir, yy, up) => { ctx.fillStyle = lg(0, yy, dir * 40, yy, [[0, '#2f7a3c'], [1, '#4d9a4a']]); roundRect(Math.min(0, dir * 38), yy - 8, 38, 16, 8); ctx.fill(); tr(dir * 38, yy + 7, yy - up, 8); };
            arm(-1, -H0 * 0.42, 62 + v * 10); arm(1, -H0 * 0.58, 48 - v * 8);
            ctx.fillStyle = 'rgba(255,255,255,0.8)'; for (let k = 0; k < 40; k++) { const y = -4 - ((k * 37) % (H0 - 14)), x = (((k * 53) % 21) - 10); ctx.fillRect(x, y, 1.2, 1.2); }
            ctx.fillStyle = '#ffe8f0'; for (const [x, y] of [[0, -H0 - 6], [-38, -H0 * 0.42 - 70], [38, -H0 * 0.58 - 54]]) { ctx.beginPath(); ctx.arc(x, y, 5, 0, TAU); ctx.fill(); ctx.fillStyle = '#ffd23a'; ctx.beginPath(); ctx.arc(x, y, 2, 0, TAU); ctx.fill(); ctx.fillStyle = '#ffe8f0'; }
        } },
        rock: { w: 170, h: 120, ox: 85, oy: 78, paint: () => {
            ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(6, 3, 66, 9, 0, 0, TAU); ctx.fill();
            const R = mulberry(40 + v * 7), body = (cx, w0, h0, k) => { ctx.beginPath(); ctx.moveTo(cx - w0, 0); ctx.lineTo(cx - w0 * 0.92, -h0 * 0.45); ctx.lineTo(cx - w0 * 0.55, -h0 * 0.92); ctx.lineTo(cx + w0 * 0.1, -h0); ctx.lineTo(cx + w0 * 0.7, -h0 * 0.72); ctx.lineTo(cx + w0, -h0 * 0.2); ctx.lineTo(cx + w0 * 0.96, 0); ctx.closePath();
                ctx.fillStyle = lg(cx - w0, 0, cx + w0, 0, [[0, '#8a4a30'], [0.5, '#c27a52'], [1, '#e0a070']]); ctx.fill(); ctx.save(); ctx.clip(); ctx.fillStyle = 'rgba(70,25,15,0.3)'; ctx.fillRect(cx - w0, -h0, w0 * 0.7, h0); ctx.fillStyle = 'rgba(255,215,160,0.28)'; ctx.beginPath(); ctx.moveTo(cx + w0 * 0.1, -h0); ctx.lineTo(cx + w0 * 0.7, -h0 * 0.72); ctx.lineTo(cx + w0, -h0 * 0.2); ctx.lineTo(cx + w0 * 0.3, -h0 * 0.1); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(50,15,10,0.3)'; ctx.lineWidth = 1; for (let q = 0; q < 6; q++) { ctx.beginPath(); ctx.moveTo(cx - w0 + R() * w0, -R() * h0); ctx.lineTo(cx - w0 + R() * w0 * 2, -R() * h0); ctx.stroke(); } ctx.restore(); };
            body(-26, 46, 58 + v * 12, 0); body(34, 38, 40, 1);
        } },
        tumble: { w: 100, h: 100, ox: 50, oy: 46, paint: () => {
            ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(2, 1, 26, 4, 0, 0, TAU); ctx.fill();
            const R = mulberry(70 + v); ctx.lineCap = 'round'; for (let k = 0; k < 46; k++) { const a = R() * TAU, b = R() * TAU, r = 18 + R() * 8; ctx.strokeStyle = k % 3 ? '#8a6a3a' : '#c8a265'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r, -26 + Math.sin(a) * r * 0.95); ctx.quadraticCurveTo(0, -26, Math.cos(b) * r, -26 + Math.sin(b) * r * 0.95); ctx.stroke(); }
        } },
        dry: { w: 110, h: 100, ox: 55, oy: 64, paint: () => {
            ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(2, 1, 30, 4, 0, 0, TAU); ctx.fill();
            const R = mulberry(90 + v); ctx.lineCap = 'round'; for (let k = 0; k < 18; k++) { const a = -Math.PI / 2 + (k - 8.5) * 0.17, L = 26 + R() * 24; ctx.strokeStyle = ['#7b6b3b', '#a5944f', '#5f7a3a'][k % 3]; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(Math.cos(a) * L * 0.5, Math.sin(a) * L * 0.5 - 4, Math.cos(a) * L, Math.sin(a) * L); ctx.stroke(); }
        } },
        pole: { w: 70, h: 236, ox: 35, oy: 226, paint: () => {
            ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(4, 1, 12, 3, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = lg(-4, 0, 4, 0, [[0, '#4a3322'], [0.5, '#9a7048'], [1, '#3a2818']]); ctx.fillRect(-3.6, -204, 7.2, 206);
            ctx.fillStyle = '#6b4a2c'; ctx.fillRect(-24, -196, 48, 5); ctx.fillRect(-16, -178, 32, 4);
            ctx.strokeStyle = '#4a3322'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(0, -176); ctx.lineTo(-16, -190); ctx.moveTo(0, -176); ctx.lineTo(16, -190); ctx.stroke();
            for (const x of [-20, -7, 7, 20]) { ctx.fillStyle = '#5fb3b3'; ctx.beginPath(); ctx.arc(x, -200, 2.4, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.fillRect(x - 0.8, -202, 0.8, 1.6); }
            ctx.strokeStyle = 'rgba(0,0,0,0.2)'; ctx.lineWidth = 0.8; for (let k = 0; k < 9; k++) { ctx.beginPath(); ctx.moveTo(-3, -190 + k * 22); ctx.lineTo(3, -186 + k * 22); ctx.stroke(); }
        } },
        sign: { w: 150, h: 130, ox: 75, oy: 120, paint: () => {
            ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(6, 1, 48, 4, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = '#5a3b22'; ctx.fillRect(-38, -62, 6, 64); ctx.fillRect(32, -62, 6, 64);
            const bg = [['#f4c542', '#8a3a1a'], ['#ffd23a', '#222'], ['#3a8f5c', '#fff6d6']][v % 3];
            ctx.fillStyle = bg[0]; roundRect(-60, -112, 120, 56, 6); ctx.fill(); ctx.strokeStyle = bg[1]; ctx.lineWidth = 3; roundRect(-57, -109, 114, 50, 4); ctx.stroke();
            ctx.fillStyle = bg[1]; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            if (v % 3 === 0) { ctx.font = '900 25px system-ui, sans-serif'; ctx.fillText('TACOS', 0, -92); ctx.font = '800 12px system-ui, sans-serif'; ctx.fillText('2 KM  ➜', 0, -69); }
            else if (v % 3 === 1) { ctx.font = '900 19px system-ui, sans-serif'; ctx.fillText('¡CUIDADO!', 0, -92); ctx.font = '800 11px system-ui, sans-serif'; ctx.fillText('GLOBOS', 0, -69); }
            else { ctx.font = '900 13px system-ui, sans-serif'; ctx.fillText('VALLE', 0, -98); ctx.fillText('CHIQUITO', 0, -83); ctx.font = '800 11px system-ui, sans-serif'; ctx.fillText('3 KM', 0, -66); }
            ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
        } },
    }[kind];
    return cachedDraw(spriteCache, 'probj|' + kind + '|' + v + '|' + SR, D.ox, D.oy, D.w, D.h, SR, D.paint);
}
const PR_LOOP = 720;
const PR_OBJS = (() => {
    const a = [], kinds = ['sag', 'sag', 'rock', 'tumble', 'dry', 'sag', 'rock'];
    for (let k = 0; k < 15; k++) a.push({ kind: 'pole', z: k * 48, side: -1, lat: 30 });
    for (let k = 0; k < 42; k++) { const h = n => hash2(k, n), kind = kinds[(h(1) * 7) | 0]; a.push({ kind, z: k * 17 + h(2) * 12, side: h(3) < 0.5 ? -1 : 1, lat: (kind === 'tumble' || kind === 'dry' ? 24 : 54) + h(4) * 170, v: (h(5) * 2) | 0 }); }
    a.push({ kind: 'sign', z: 250, side: 1, lat: 40, v: 0 }, { kind: 'sign', z: 560, side: -1, lat: 70, v: 1 });
    return a;
})();
// ---------- vehicles ----------
function prScoutPaint(col, truck) {
    const dk = shade(col, -0.45), md = shade(col, -0.15), lt = shade(col, 0.32);
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(0, 1, 56, 6.5, 0, 0, TAU); ctx.fill();
    for (const sx of [-1, 1]) { ctx.fillStyle = '#121216'; roundRect(sx * 44 - 8, -27, 16, 28, 4); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.09)'; ctx.lineWidth = 1; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.moveTo(sx * 44 - 7, -23 + k * 5); ctx.lineTo(sx * 44 + 7, -23 + k * 5); ctx.stroke(); } }
    if (!truck) {
        ctx.fillStyle = lg(0, -78, 0, -46, [[0, lt], [1, md]]); ctx.beginPath(); ctx.moveTo(-37, -46); ctx.lineTo(-28, -73); ctx.quadraticCurveTo(0, -80, 28, -73); ctx.lineTo(37, -46); ctx.closePath(); ctx.fill();
        ctx.fillStyle = lg(0, -71, 0, -48, [[0, '#b3dbf5'], [0.5, '#5f87aa'], [1, '#2f4a66']]); ctx.beginPath(); ctx.moveTo(-31, -49); ctx.lineTo(-24, -69); ctx.quadraticCurveTo(0, -74, 24, -69); ctx.lineTo(31, -49); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.28)'; ctx.beginPath(); ctx.moveTo(-19, -67); ctx.lineTo(-8, -67); ctx.lineTo(-16, -50); ctx.lineTo(-27, -50); ctx.fill();
    } else {
        ctx.fillStyle = lg(0, -80, 0, -48, [[0, lt], [1, md]]); roundRect(-30, -80, 60, 34, 8); ctx.fill();
        ctx.fillStyle = lg(0, -73, 0, -54, [[0, '#b3dbf5'], [1, '#2f4a66']]); roundRect(-24, -73, 48, 19, 4); ctx.fill();
        ctx.fillStyle = dk; ctx.fillRect(-48, -58, 5, 12); ctx.fillRect(43, -58, 5, 12);
    }
    ctx.fillStyle = lg(0, -51, 0, -8, [[0, lt], [0.28, col], [1, dk]]); roundRect(-48, -51, 96, 42, 10); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.3)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-41, -46); ctx.lineTo(41, -46); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.moveTo(-45, -31); ctx.lineTo(45, -31); ctx.stroke();
    ctx.fillStyle = '#23232b'; roundRect(-47, -16, 94, 11, 4); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.fillRect(-45, -15, 90, 2);
    ctx.fillStyle = '#f4f0dc'; roundRect(-12, -27, 24, 10, 2); ctx.fill(); ctx.fillStyle = '#d33'; ctx.fillRect(-12, -27, 24, 2.5); ctx.fillStyle = '#222'; ctx.font = '700 6px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('GLOBO', 0, -19); ctx.textAlign = 'left';
    for (const sx of [-1, 1]) { ctx.fillStyle = '#5a0f12'; roundRect(sx * 38 - 8, -43, 16, 9, 3); ctx.fill(); ctx.fillStyle = '#b8262c'; roundRect(sx * 38 - 6.5, -41.5, 13, 6, 2); ctx.fill(); }
    ctx.fillStyle = '#4a4a54'; ctx.beginPath(); ctx.ellipse(-26, -6, 4, 2.6, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#111'; ctx.beginPath(); ctx.ellipse(-26, -6, 2.6, 1.6, 0, 0, TAU); ctx.fill();
}
function prScoutSprite(col, truck) { const SR = Math.min(RES, 3); return cachedDraw(spriteCache, 'prcar|' + col + '|' + truck + '|' + SR, 60, 92, 120, 98, SR, () => prScoutPaint(col, truck)); }
function prLantern(x, y, r, col) {
    drawGlow(x, y, Math.max(8, r * 3.6), col, 0.85);
    ctx.fillStyle = '#3a2418'; ctx.fillRect(x - r * 0.45, y - r * 1.2, r * 0.9, r * 0.28);
    ctx.fillStyle = shade(col, -0.2); roundRect(x - r * 0.85, y - r, r * 1.7, r * 2, r * 0.55); ctx.fill();
    ctx.fillStyle = shade(col, 0.6); roundRect(x - r * 0.45, y - r * 0.62, r * 0.9, r * 1.24, r * 0.3); ctx.fill();
}
function prScout(x, y, s, t, i, c, truck) {   // x,y = ground contact, s = scale
    const e = prScoutSprite(c, truck), bob = Math.sin(t * 0.5 + i * 2) * 0.9 * s;
    ctx.drawImage(e.cv, x - e.ox * s, y - e.oy * s + bob, e.w * s, e.h * s);
    const hot = 0.75 + 0.25 * Math.sin(t * 0.3 + i);
    for (const sx of [-1, 1]) drawGlow(x + sx * 38 * s, y - 38 * s + bob, 22 * s + 3, '#ff3b30', hot);
    if (!truck) {
        const hx = x, hy = y - 59 * s + bob;
        ctx.fillStyle = BALLCOLS[i % BALLCOLS.length]; ctx.beginPath(); ctx.arc(hx, hy, 9.5 * s, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.ellipse(hx - 3 * s, hy - 3.5 * s, 3 * s, 2 * s, 0, 0, TAU); ctx.fill();
        drawSombrero(hx, hy - 9 * s, Math.max(3.2, 11 * s), Math.sin(t * 0.2 + i) * 0.07, i + 1);
        for (let k = 0; k < 3; k++) { const lx = (k - 1) * 27 * s, sw = Math.sin(t * 0.13 + k + i) * 3 * s, ly = (-86 - (k === 1 ? 7 : 0)) * s; ctx.strokeStyle = '#3a2418'; ctx.lineWidth = Math.max(0.6, 1.6 * s); ctx.beginPath(); ctx.moveTo(x + lx * 0.7, y - 72 * s + bob); ctx.lineTo(x + lx + sw, y + ly + bob); ctx.stroke(); prLantern(x + lx + sw, y + ly + bob, Math.max(1.4, 6 * s), CONF[(k + i) % CONF.length]); }
    } else {
        for (let k = 0; k < 9; k++) { const lx = ((k * 37) % 80 - 40) * s, ly = (-58 - ((k * 23) % 26)) * s, sw = Math.sin(t * 0.16 + k) * 1.5 * s; prLantern(x + lx + sw, y + ly + bob, Math.max(1.4, 7 * s), CONF[(k + i) % CONF.length]); }
    }
}
// the taco car from behind: a hard shell seen end-on as a U, packed with filling, the hero sitting inside
function prTacoBack() {
    const R = mulberry(5);
    ctx.beginPath(); ctx.moveTo(-66, -68); ctx.lineTo(66, -68); ctx.lineTo(66, -62); ctx.ellipse(0, -62, 66, 52, 0, 0, Math.PI, false); ctx.lineTo(-66, -68); ctx.closePath();
    ctx.fillStyle = lg(-66, 0, 66, 0, [[0, '#b97312'], [0.14, '#e8a52c'], [0.4, '#ffd57a'], [0.7, '#f0b542'], [1, '#a9680f']]); ctx.fill();
    ctx.save(); ctx.clip();
    const sg = ctx.createLinearGradient(0, -62, 0, -8); sg.addColorStop(0, 'rgba(120,60,0,0)'); sg.addColorStop(1, 'rgba(100,50,0,0.5)'); ctx.fillStyle = sg; ctx.fillRect(-70, -70, 140, 64);
    for (let i = 0; i < 130; i++) { const a = R() * Math.PI, d = 40 + R() * 26; ctx.fillStyle = R() < 0.5 ? 'rgba(130,70,10,0.2)' : 'rgba(255,240,170,0.25)'; ctx.beginPath(); ctx.arc(Math.cos(a) * d * 1.02, -62 + Math.sin(a) * d * 0.8, 0.6 + R() * 1.6, 0, TAU); ctx.fill(); }
    ctx.restore();
    ctx.strokeStyle = '#8a5410'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-66, -68); ctx.lineTo(66, -68); ctx.lineTo(66, -62); ctx.ellipse(0, -62, 66, 52, 0, 0, Math.PI, false); ctx.closePath(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-56, -68); ctx.lineTo(56, -68); ctx.lineTo(56, -62); ctx.ellipse(0, -62, 56, 42, 0, 0, Math.PI, false); ctx.lineTo(-56, -68); ctx.closePath();
    ctx.fillStyle = lg(0, -68, 0, -20, [[0, '#5a2d08'], [1, '#8f5212']]); ctx.fill();
    ctx.strokeStyle = 'rgba(40,20,0,0.5)'; ctx.lineWidth = 1.4; ctx.stroke();
}
function prTacoFront() {
    const R = mulberry(9), cav = () => { ctx.beginPath(); ctx.moveTo(-56, -68); ctx.lineTo(56, -68); ctx.lineTo(56, -62); ctx.ellipse(0, -62, 56, 42, 0, 0, Math.PI, false); ctx.lineTo(-56, -68); ctx.closePath(); };
    ctx.save(); cav(); ctx.clip();
    ctx.beginPath(); ctx.moveTo(-58, -12); ctx.lineTo(-58, -50); for (let x = -58; x <= 58; x += 6) ctx.lineTo(x, -56 - Math.sin(x * 0.13 + 1) * 5 - Math.abs(Math.sin(x * 0.35)) * 3); ctx.lineTo(58, -12); ctx.closePath();
    ctx.fillStyle = lg(0, -66, 0, -26, [[0, '#a85a2c'], [1, '#4f220e']]); ctx.fill();
    for (let i = 0; i < 160; i++) { const x = (R() - 0.5) * 112, y = -55 + R() * 40; ctx.fillStyle = R() < 0.5 ? 'rgba(30,10,0,0.4)' : 'rgba(255,170,110,0.25)'; ctx.beginPath(); ctx.arc(x, y, 0.8 + R() * 1.7, 0, TAU); ctx.fill(); }
    ctx.restore();
    for (let i = 0; i < 14; i++) { const x = -48 + i * 7.4 + R() * 3, y = -62 + R() * 5; ctx.strokeStyle = R() < 0.5 ? '#ffd23a' : '#f3a81c'; ctx.lineWidth = 1.6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + R() * 8 - 4, y + 5 + R() * 5); ctx.stroke(); }
    ctx.beginPath(); ctx.moveTo(-62, -64);
    for (let i = 0; i <= 18; i++) { const x = -62 + i * 6.9, y = -66 - (i % 2 ? 11 : 4) - Math.sin(i * 1.9) * 3; ctx.quadraticCurveTo(x - 3.4, y - 3, x, y + (i % 2 ? 3 : 0)); }
    ctx.lineTo(62, -64); ctx.closePath(); ctx.fillStyle = lg(0, -84, 0, -62, [[0, '#9be063'], [0.6, '#52ab40'], [1, '#2f7a35']]); ctx.fill();
    ctx.strokeStyle = 'rgba(20,80,25,0.5)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.strokeStyle = 'rgba(220,255,170,0.5)'; ctx.lineWidth = 0.9; for (let i = 0; i < 12; i++) { const x = -58 + i * 10.5; ctx.beginPath(); ctx.moveTo(x, -66); ctx.quadraticCurveTo(x + 2, -72, x + 1, -78); ctx.stroke(); }
    for (let i = 0; i < 7; i++) { const x = -50 + i * 16.5 + R() * 5, y = -66 - R() * 6; ctx.fillStyle = '#d6291f'; roundRect(x - 3.4, y - 3.4, 6.8, 6.8, 1.6); ctx.fill(); ctx.fillStyle = 'rgba(255,200,190,0.7)'; ctx.fillRect(x - 2.4, y - 2.4, 2.4, 1.4); }
    for (let i = 0; i < 10; i++) { const x = -56 + i * 12.4 + R() * 4, y = -68 - R() * 8; ctx.strokeStyle = '#ffd84a'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 5, y + 4); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(255,245,190,0.7)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(-66, -68.8); ctx.lineTo(-58, -68.8); ctx.moveTo(58, -68.8); ctx.lineTo(66, -68.8); ctx.stroke();
    for (const sx of [-1, 1]) {   // tortilla-chip spoilers
        ctx.fillStyle = lg(0, -100, 0, -66, [[0, '#ffd45a'], [1, '#e0a22a']]); ctx.beginPath(); ctx.moveTo(sx * 60, -66); ctx.lineTo(sx * 80, -98); ctx.lineTo(sx * 74, -64); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#a8680f'; ctx.lineWidth = 1.2; ctx.stroke(); for (let k = 0; k < 6; k++) { ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.fillRect(sx * (64 + R() * 8), -94 + R() * 26, 1.2, 1.2); }
    }
    ctx.fillStyle = '#f2c230'; roundRect(-17, -30, 34, 13, 3); ctx.fill(); ctx.strokeStyle = '#6a4a08'; ctx.lineWidth = 1; ctx.stroke(); ctx.fillStyle = '#2a1c00'; ctx.font = '800 8px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('TACO-1', 0, -20.4); ctx.textAlign = 'left';
    for (const sx of [-1, 1]) {   // chili tail lamps and chrome exhausts
        ctx.fillStyle = '#5a0f12'; ctx.beginPath(); ctx.ellipse(sx * 49, -30, 10, 7, sx * 0.4, 0, TAU); ctx.fill(); ctx.fillStyle = lg(0, -36, 0, -24, [[0, '#ff6a5a'], [1, '#c4272e']]); ctx.beginPath(); ctx.ellipse(sx * 49, -30, 8, 5, sx * 0.4, 0, TAU); ctx.fill();
        ctx.fillStyle = '#2f8a3a'; ctx.beginPath(); ctx.ellipse(sx * 58.5, -35.5, 2.8, 1.6, sx * 0.5, 0, TAU); ctx.fill();
        ctx.fillStyle = lg(-6, 0, 6, 0, [[0, '#6a6a76'], [0.5, '#eceff6'], [1, '#6a6a76']]); ctx.beginPath(); ctx.ellipse(sx * 19, -13, 6.5, 4.5, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#0c0c10'; ctx.beginPath(); ctx.ellipse(sx * 19, -13, 4.2, 2.8, 0, 0, TAU); ctx.fill();
    }
}
function prHero(t) {
    const lean = Math.sin(t * 0.07) * 1.6, flap = Math.sin(t * 0.45) * 0.07;
    ctx.save();
    ctx.beginPath(); ctx.moveTo(-27, -46); ctx.quadraticCurveTo(-25, -78, -9, -83); ctx.lineTo(9, -83); ctx.quadraticCurveTo(25, -78, 27, -46); ctx.closePath();
    ctx.fillStyle = lg(-26, 0, 26, 0, [[0, '#8f2918'], [0.5, '#e24b32'], [1, '#8f2918']]); ctx.fill(); ctx.clip();
    for (let k = 0; k < 4; k++) { ctx.fillStyle = k % 2 ? '#1e1a22' : '#f4c542'; ctx.fillRect(-30, -76 + k * 9, 60, 3.4); }
    ctx.restore();
    ctx.fillStyle = '#b97c4c'; ctx.fillRect(-4.5 + lean * 0.3, -88, 9, 7);
    ctx.fillStyle = '#c98f5e'; ctx.beginPath(); ctx.ellipse(-9.6 + lean, -93, 2.2, 3.2, 0, 0, TAU); ctx.ellipse(9.6 + lean, -93, 2.2, 3.2, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = lg(-10, 0, 10, 0, [[0, '#b97c4c'], [0.5, '#d9a06c'], [1, '#b97c4c']]); ctx.beginPath(); ctx.ellipse(lean, -93, 9.4, 10.6, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1d130e'; ctx.beginPath(); ctx.ellipse(lean, -95.5, 10, 9, 0, Math.PI * 0.95, Math.PI * 2.05); ctx.fill(); ctx.beginPath(); ctx.ellipse(lean, -91, 9.4, 6, 0, 0, Math.PI); ctx.fill();
    ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.moveTo(lean - 7, -85); ctx.lineTo(lean + 7, -85); ctx.lineTo(lean + 5 + Math.sin(t * 0.5) * 3, -77); ctx.lineTo(lean + Math.sin(t * 0.5 + 1) * 2, -80); ctx.lineTo(lean - 5 - Math.sin(t * 0.5 + 2) * 3, -77); ctx.closePath(); ctx.fill();   // bandana tails fluttering
    drawSombrero(lean, -102, 21, flap, 4);
}
function prTaco(x, y, t, o) {   // x,y = ground contact, centre
    const s = o.s || 1, SR = Math.min(RES, 3), sway = Math.sin(t * 0.07) * 0.02, bob = Math.sin(t * 0.55) * 1.3;
    const bk = cachedDraw(spriteCache, 'prtacoB|' + SR, 100, 150, 200, 158, SR, prTacoBack), fr = cachedDraw(spriteCache, 'prtacoF|' + SR, 100, 150, 200, 158, SR, prTacoFront);
    ctx.save(); ctx.translate(x, y + bob * s); ctx.rotate(sway); ctx.scale(s, s);
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(0, 4, 88, 9, 0, 0, TAU); ctx.fill();
    for (const sx of [-1, 1]) {   // rear tyres with tread racing past
        ctx.save(); roundRect(sx * 64 - 12, -46, 24, 50, 7); ctx.fillStyle = '#121216'; ctx.fill(); ctx.clip();
        ctx.strokeStyle = 'rgba(255,255,255,0.1)'; ctx.lineWidth = 2; const off = (t * (o.spin || 4)) % 9; for (let k = -1; k < 7; k++) { ctx.beginPath(); ctx.moveTo(sx * 64 - 12, -46 + k * 9 + off); ctx.lineTo(sx * 64 + 12, -46 + k * 9 + off); ctx.stroke(); }
        ctx.fillStyle = 'rgba(255,255,255,0.1)'; ctx.fillRect(sx * 64 - 9, -44, 3, 46); ctx.restore();
    }
    ctx.drawImage(bk.cv, -bk.ox, -bk.oy, bk.w, bk.h);
    prHero(t);
    ctx.drawImage(fr.cv, -fr.ox, -fr.oy, fr.w, fr.h);
    const hot = 0.8 + 0.2 * Math.sin(t * 0.4);
    for (const sx of [-1, 1]) drawGlow(sx * 49, -30, 36, '#ff3b30', hot);
    if (o.nitro) {
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        for (const sx of [-1, 1]) {
            const fx = sx * 19, fy = -12, L = 26 + Math.random() * 16 * o.nitro;
            let gr = ctx.createRadialGradient(fx, fy + 6, 1, fx, fy + 6, 20 + Math.random() * 5); gr.addColorStop(0, 'rgba(255,255,230,0.95)'); gr.addColorStop(0.35, 'rgba(255,170,60,0.7)'); gr.addColorStop(1, 'rgba(255,90,20,0)'); ctx.fillStyle = gr; ctx.fillRect(fx - 26, fy - 18, 52, 56);
            gr = ctx.createLinearGradient(0, fy, 0, fy + L); gr.addColorStop(0, 'rgba(255,255,220,0.95)'); gr.addColorStop(0.4, 'rgba(255,170,50,0.85)'); gr.addColorStop(1, 'rgba(255,80,20,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(fx - 5, fy); ctx.quadraticCurveTo(fx - 7, fy + L * 0.5, fx, fy + L); ctx.quadraticCurveTo(fx + 7, fy + L * 0.5, fx + 5, fy); ctx.fill();
            for (let j = 0; j < 8; j++) { const age = (t * 2.2 + j * 5 + (sx > 0 ? 3 : 0)) % 28, a = 1 - age / 28; ctx.fillStyle = 'rgba(255,214,130,' + (a * o.nitro).toFixed(2) + ')'; ctx.fillRect(fx + Math.sin(j * 2.3 + sx) * age * 0.9, fy + 6 + age * 1.7, 2.2, 2.2); }
        }
        ctx.restore();
    }
    ctx.restore();
    if (o.dust !== false) for (const sx of [-1, 1]) for (let j = 0; j < 6; j++) {   // road dust kicked out by the rear wheels
        const age = (t * 1.5 + j * 9 + (sx > 0 ? 4 : 0)) % 54, a = age / 54;
        ctx.fillStyle = 'rgba(' + (o.pal === 'dusk' ? '214,170,140' : '236,206,164') + ',' + (0.42 * (1 - a)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(x + sx * (64 + a * 70) * s, y + (6 + a * 22) * s, (5 + a * 24) * s, 0, TAU); ctx.fill();
    }
}
function prSpeedLines(t, k, bend) {
    const vx = prCx(0.04, bend), vy = PR.hy + 4; ctx.lineCap = 'round';
    for (let i = 0; i < 30; i++) {
        const ang = 0.12 * Math.PI + hash2(i, 1.7) * 0.76 * Math.PI + (hash2(i, 2.1) < 0.2 ? Math.PI : 0), ph = (t * 0.045 + hash2(i, 3.3)) % 1, r0 = 70 + ph * ph * 300, r1 = r0 + 24 + ph * 90;
        ctx.strokeStyle = 'rgba(255,248,230,' + (k * (0.05 + 0.2 * ph) * (hash2(i, 5) < 0.5 ? 0.6 : 1)).toFixed(3) + ')'; ctx.lineWidth = 0.8 + ph * 1.8;
        ctx.beginPath(); ctx.moveTo(vx + Math.cos(ang) * r0 * 1.15, vy + Math.sin(ang) * r0 * 0.9); ctx.lineTo(vx + Math.cos(ang) * r1 * 1.15, vy + Math.sin(ang) * r1 * 0.9); ctx.stroke();
    }
}
function csPursuit(t, o) {
    const pk = o.pal || 'dawn', P = PR_PAL[pk], T = t + (o.t0 || 0), bend = prBend(T), scroll = (o.s0 || 0) + (o.dist ? o.dist(t) : t * (o.speed || 3.2)), hy = PR.hy;
    const Y0 = o.y0 == null ? 34 : o.y0; ctx.save(); ctx.beginPath(); ctx.rect(0, Y0, W, 446 - Y0); ctx.clip();
    const sk = o.shake || 0; ctx.translate(180 + Math.sin(t * 2.3) * sk, 240 + Math.cos(t * 3.1) * sk * 0.8); ctx.scale(1.03, 1.03); ctx.translate(-180, -240);
    const sky = prSky(P, pk); ctx.drawImage(sky.cv, 0, 0, W, hy + 24);
    prClouds(P, t);
    const hz = hexA(P.haze, 0.62);
    for (const m of PR_MESA) prMesa(m.x - bend * 12, hy + 2, m.w, m.h, lerpColor(P.mid, P.haze, 0.38), P.midHi, hz, P.sunX);
    for (const m of PR_MESA) if (hash2(m.x, 9) < 0.55) prMesa(m.x * 1.18 - 30 - bend * 24, hy + 3, m.w * 0.8, m.h * 0.7, lerpColor(P.mid, P.haze, 0.12), P.midHi, hz, P.sunX);
    if (o.village) prVillage(P, bend);
    prNear(P, bend);
    prRoad(P, pk, bend, scroll);
    drawGlow(P.sunX - bend * 6, hy + 8, 130, P.haze, 0.5);
    // gather everything that stands on the road, far to near
    const items = [];
    for (const ob of PR_OBJS) { let p = (ob.z - scroll) % PR_LOOP; if (p < 0) p += PR_LOOP; p -= 6; if (p > -2) items.push({ p, ob }); }
    if (o.convoy) o.convoy.forEach((c, i) => {
        const p = c.p(t), lane = c.lane + (c.fix ? 0 : Math.sin(t * 0.021 + i * 1.7) * 0.07);
        items.push({ p, car: c, i: c.id != null ? c.id : i, lane });
        if (!c.nopuff) for (let j = 0; j < 7; j++) { const age = (t * 1.2 + j * 8.4 + i * 3) % 58, a = age / 58; items.push({ p: Math.max(1.5, p - 2.2 - a * 15), puff: { a, lane, side: ((j * 7 + i) % 3 - 1), j } }); }
    });
    items.sort((a, b) => b.p - a.p);
    const poles = items.filter(it => it.ob && it.ob.kind === 'pole'), wire = (a, b, off) => {
        const ua = prU(a.p), ub = prU(b.p), xa = prCx(ua, bend) - (PR.hw + a.ob.lat) * ua + off * ua, xb = prCx(ub, bend) - (PR.hw + b.ob.lat) * ub + off * ub, ya = prY(ua) - 197 * ua, yb = prY(ub) - 197 * ub;
        ctx.strokeStyle = 'rgba(40,22,36,0.7)'; ctx.lineWidth = Math.max(0.5, 1.1 * ub); ctx.beginPath(); ctx.moveTo(xa, ya); ctx.quadraticCurveTo((xa + xb) / 2, (ya + yb) / 2 + 9 * ub, xb, yb); ctx.stroke();
    };
    for (let k = 1; k < poles.length; k++) { if (poles[k].p > 700 || poles[k - 1].p > 700) continue; for (const off of [-20, -7, 7, 20]) wire(poles[k - 1], poles[k], off); }
    for (const it of items) {
        const u = prU(it.p), y = prY(u), bx = prCx(u, bend);
        if (it.ob) {
            const ob = it.ob, v = ob.kind === 'sign' && o.sign != null && ob.z === 250 ? o.sign : ob.v || 0, e = prObjSprite(ob.kind, v), x = bx + ob.side * (PR.hw + ob.lat) * u;
            ctx.globalAlpha = 1 - 0.5 * Math.pow(clamp(it.p / 520, 0, 1), 1.2); ctx.drawImage(e.cv, x - e.ox * u, y - e.oy * u, e.w * u, e.h * u); ctx.globalAlpha = 1;
        } else if (it.car) {
            const c = it.car, x = bx + it.lane * PR.hw * u; ctx.globalAlpha = 1 - 0.35 * Math.pow(clamp(it.p / 260, 0, 1), 1.2);
            if (c.rot || c.ox || c.alpha != null) { ctx.save(); ctx.globalAlpha *= c.alpha == null ? 1 : c.alpha; ctx.translate(x + (c.ox || 0) * u, y); ctx.rotate(c.rot || 0); prScout(0, 0, u * 0.98 * (c.sc || 1), t, it.i, c.color, c.truck); ctx.restore(); } else prScout(x, y, u * 0.98 * (c.sc || 1), t, it.i, c.color, c.truck); ctx.globalAlpha = 1;
        } else {
            const pf = it.puff, x = bx + (pf.lane * PR.hw + pf.side * (14 + pf.a * 50) * 1.2) * u;
            ctx.fillStyle = 'rgba(' + (pk === 'dusk' ? '214,170,140' : '240,212,170') + ',' + (0.5 * (1 - pf.a) * (0.5 + 0.5 * Math.min(1, u * 3))).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(x, y - (4 + pf.a * 18) * u, (7 + pf.a * 24) * u, 0, TAU); ctx.fill();
        }
    }
    if (o.car) prTaco(o.car.x == null ? 180 : o.car.x, o.car.y == null ? 436 : o.car.y, t, o.car);
    if (o.after) o.after(bend, scroll);
    ctx.restore();
    const grd = ctx.createLinearGradient(0, Y0, 0, 446); grd.addColorStop(0, 'rgba(10,6,30,0.28)'); grd.addColorStop(0.25, 'rgba(10,6,30,0)'); grd.addColorStop(0.8, 'rgba(10,6,30,0)'); grd.addColorStop(1, 'rgba(10,6,30,0.32)');
    ctx.fillStyle = P.tint; ctx.fillRect(0, Y0, W, 446 - Y0); ctx.fillStyle = grd; ctx.fillRect(0, Y0, W, 446 - Y0);
    const Y1 = 446; ctx.save(); ctx.beginPath(); ctx.rect(0, Y0, W, Y1 - Y0); ctx.clip(); if (o.lines) prSpeedLines(t, o.lines, bend); const vg = raVignette(); ctx.drawImage(vg.cv, 0, 0, W, H); ctx.restore();
}
const ACT_CUTS = {
    1: [{ sky: 3000, title: 'ACT 2 · THE PURSUIT', text: 'Capitán Globito crashes, but his scouts flee with the festival lanterns in a convoy of speeding cars. Our hero grabs the keys to a certain taco on wheels. Hit the gas!',
        art(t) {
            const k = clamp(t / 90, 0, 1);
            csPursuit(t, { pal: 'dawn', speed: 3.4, shake: 0.5, lines: 0.35, sign: 0,
                convoy: [{ color: '#e74c3c', lane: -0.46, p: t => 46 + t * 0.06 }, { color: '#2e86de', lane: 0.38, p: t => 62 + t * 0.05 }, { color: '#9b59b6', lane: -0.05, p: t => 88 + t * 0.045, truck: true }, { color: '#f39c12', lane: 0.5, p: t => 118 + t * 0.03 }] });
        } },
     { sky: 3000, title: 'ACT 2 · THE PURSUIT', text: 'The taco car roars onto the road, nitro blazing. Plan each move, lasso the lantern trucks one by one, and nobody steals the Fiesta!',
        art(t) {
            const e = Math.pow(clamp(1 - t / 50, 0, 1), 2), nitro = clamp(t / 45, 0, 1);
            csPursuit(t, { pal: 'dawn', t0: 400, s0: 900, speed: 3.4 + 4.2 * nitro, shake: 0.4 + 1.8 * nitro, lines: 0.35 + 0.65 * nitro, sign: 1, car: { s: 1, y: 438 + 170 * e, nitro, spin: 4 + 6 * nitro },
                convoy: [{ color: '#e74c3c', lane: -0.46, p: t => 56 + t * 0.05 }, { color: '#2e86de', lane: 0.38, p: t => 76 + t * 0.04 }, { color: '#9b59b6', lane: -0.05, p: t => 100 + t * 0.03, truck: true }] });
        } }],
    2: [{ sky: 16000, title: 'ACT 3 · THE RECKONING', text: 'The chase ends in the Plaza de los Piñatas on the Night of the Dead. The Baron\'s curse wakes the skeleton piñatas. Our hero trades the wheel for a machete.',
        art(t) {
            drawGlow(280, 110, 120, '#fff6c0', 0.8); ctx.fillStyle = '#fff3b0'; ctx.beginPath(); ctx.arc(280, 110, 40, 0, TAU); ctx.fill();
            csGround(360, '#3a2a4a', '#4d3a62');
            for (let i = 0; i < 7; i++) { const x = 30 + i * 52; ctx.fillStyle = '#6b6580'; roundRect(x - 9, 330 - (i % 3) * 6, 18, 36, 8); ctx.fill(); ctx.fillStyle = '#4a455c'; ctx.fillRect(x - 1, 338 - (i % 3) * 6, 2, 12); }
            for (let i = 0; i < 4; i++) { const x = 60 + i * 80, rise = clamp((t - i * 25) / 60, 0, 1), y = 410 - rise * 50 + Math.sin(t * 0.08 + i) * 3; ctx.fillStyle = '#ecf0f1'; ctx.beginPath(); ctx.arc(x, y, 17, 0, TAU); ctx.fill(); ctx.fillStyle = '#2d3436'; ctx.beginPath(); ctx.arc(x - 6, y - 2, 4, 0, TAU); ctx.arc(x + 6, y - 2, 4, 0, TAU); ctx.fill(); ctx.fillStyle = ['#ff9f43', '#ee5a24'][i % 2]; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.arc(x - 14 + k * 7, y - 16, 4, 0, TAU); ctx.fill(); } }
            const hx = 180, hy = 372; VQ.g = 'hips'; drawVaquero(hx, hy - 12, 1.8, 1, t * 0.2); VQ.g = null;
            const sw = (t % 70) / 70; ctx.save(); ctx.translate(hx + 20, hy - 30); ctx.strokeStyle = 'rgba(255,255,255,' + (1 - sw) + ')'; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(0, 0, 54, -1 + sw * 1.4, -0.3 + sw * 1.4); ctx.stroke(); ctx.restore();
        } }],
    3: [{ sky: 26000, title: 'ACT 4 · THE FINAL SHOWDOWN', text: 'Beyond the clouds hangs the Baron\'s armada, circling the Fiesta Galaxy. At its heart floats El Gran Globo, wearing the Golden Sombrero.',
        art(t) {
            for (const s of starsBg) { ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.fillRect(s.x, (s.y * 0.7 + t * 0.1 * s.s) % 440, s.s, s.s); }
            for (let i = 0; i < 5; i++) { const x = ((i * 110 + t * 0.5) % (W + 100)) - 50, y = 150 + (i % 3) * 60; ctx.fillStyle = 'rgba(30,10,50,0.9)'; ctx.beginPath(); ctx.ellipse(x, y, 34, 14, 0, 0, TAU); ctx.fill(); ctx.fillRect(x - 10, y + 12, 20, 6); drawGlow(x, y + 16, 14, '#ff4757', 0.6); }
            drawGlow(180, 290, 120, '#ffd32a', 0.5); drawSombrero(180, 262, 36, Math.sin(t * 0.04) * 0.08, 4);
            ctx.fillStyle = 'rgba(40,10,60,0.9)'; ctx.beginPath(); ctx.arc(180, 330, 56, 0, TAU); ctx.fill(); drawGlow(180, 330, 90, '#ff2a00', 0.3);
        } },
      { sky: 28500, title: 'ACT 4 · THE FINAL SHOWDOWN', text: '"You cannot pop me, little vaquero!" he roars. Our hero tips his hat and spins his hoop. "Watch me."',
        art(t) {
            for (const s of starsBg) { ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.fillRect(s.x, s.y * 0.7, s.s, s.s); }
            if (Math.sin(t * 0.13) > 0.93) { ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fillRect(0, 0, W, 440); }
            drawVillain(180, 175 + Math.sin(t * 0.05) * 8, 70, t, {});
            drawGlow(180, 390, 70, '#48dbfb', 0.4); VQ.g = 'draw'; drawVaquero(180, 380 - Math.abs(Math.sin(t * 0.08)) * 6, 1.6, 1, t * 0.3); VQ.g = null;
        } }],
};
function csStars(t, n) { for (const s of starsBg) { ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.fillRect(s.x, (s.y * 0.7 + t * 0.05 * s.s) % 440, s.s, s.s); } }
function csLanterns(t, y0) {
    ctx.strokeStyle = '#2d1830'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-10, y0); ctx.quadraticCurveTo(W / 2, y0 + 38, W + 10, y0 + 6); ctx.stroke();
    for (let i = 0; i < 9; i++) { const u = (i + 0.5) / 9, x = u * W, y = y0 + 38 * 2 * u * (1 - u) + 6 * u, sw = Math.sin(t * 0.05 + i * 0.9) * 1.5, col = CONF[i % CONF.length]; drawGlow(x + sw, y + 12, 22, col, 0.7); ctx.fillStyle = col; roundRect(x - 5 + sw, y + 4, 10, 15, 4); ctx.fill(); }
}
function csFireworks(t) {
    for (let k = 0; k < 4; k++) {
        const ph = (t * 0.02 + k * 0.27) % 1, cx = 60 + ((k * 97) % 250), cy = 90 + (k * 53) % 110;
        if (ph < 0.15) { ctx.fillStyle = '#fff'; ctx.fillRect(cx - 1, cy + (0.15 - ph) * 900, 2, 8); continue; }
        const u = (ph - 0.15) / 0.85, col = CONF[k % CONF.length]; ctx.globalAlpha = 1 - u;
        for (let i = 0; i < 18; i++) { const a = i * TAU / 18; ctx.fillStyle = col; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * u * 70, cy + Math.sin(a) * u * 70 + u * u * 30, 2.5, 0, TAU); ctx.fill(); }
        ctx.globalAlpha = 1; drawGlow(cx, cy, 60 * (1 - u), col, 0.4);
    }
}
function csNotes(t) { for (let i = 0; i < 6; i++) { const x = 90 + i * 38 + Math.sin(t * 0.04 + i) * 8, y = 330 - ((t * 0.8 + i * 40) % 190); ctx.fillStyle = 'rgba(255,230,150,' + (1 - (330 - y) / 190) + ')'; ctx.font = 'bold 18px system-ui, sans-serif'; ctx.fillText(i % 2 ? '♪' : '♫', x, y); } }
function csVillagers(t, gy) {
    drawVillager('guitar', 52, gy + 14, 1.05, t, 1); drawVillager('trumpet', 138, gy + 12, 1.0, t, 2); drawVillager('abuela', 232, gy + 14, 1.0, t, 3); drawVillager('dancer', 336, gy + 12, 1.05, t, 4);
    drawVillager('dancer', 72, gy + 46, 1.45, t, 5); drawVillager('kid', 292, gy + 44, 1.35, t, 6);
}
// ---- ending cutscene toolkit: hero poses, spirits, death effects ----
const csRnd = n => { const v = Math.sin(n * 12.9898 + 78.233) * 43758.5453; return v - Math.floor(v); };
const lerp2 = (a, b, u) => a + (b - a) * u;
function hero(x, y, s, facing, phase, o = {}) {   // hula hoop only when o.hoop; o: jump, tilt, sx/sy (squash), mo (mouth), brow, alpha
    const cm = cutMouth('hero'); VQ.x = o.x || null;
    if (!o.lock && cs && cs.spL && cs.spI === cs.i) { const Al = cs.spL.find(l => l.started && cs.t >= l.at - 4 && cs.t <= l.end + 25 && (l.who === 'hero' ? l.ex : l.hx)); if (Al) VQ.x = Al.who === 'hero' ? Al.ex : Al.hx; }   // the line being spoken decides his face: his own lines carry their emotion (ex), the others' lines carry how he reacts to them (hx)
    VQ.sp = cm != null ? cm : 0; VQ.g = o.g || (o.hoop ? 'hula' : 'idle'); VQ.nohoop = !o.hoop; VQ.mo = cm != null ? cm : (o.mo || 0); VQ.brow = o.brow || 0;
    VQ.hf = facing;
    VQ.gt = o.gt != null ? o.gt : null; if (o.fire != null) VQ.fire = o.fire; VQ.joint = o.joint != null ? o.joint : null; VQ.prop = o.prop || null; VQ.sm = o.sm || null; VQ.mouthP = null; VQ.emberP = null;
    const glOn = OPT.hd && OPT.gfx >= 1 && H3.ok === true;
    VQ.tilt = glOn ? (o.tilt || 0) : 0; VQ.jump = glOn ? (o.jump || 0) : 0; VQ.squash = glOn ? Math.max(0, 1 - (o.sy == null ? 1 : o.sy)) : 0;
    ctx.save(); ctx.translate(x, y - (glOn ? 0 : (o.jump || 0)));
    if (o.tilt && !glOn) ctx.rotate(o.tilt);
    if (!glOn && (o.sx || o.sy)) ctx.scale(o.sx == null ? 1 : o.sx, o.sy == null ? 1 : o.sy);
    drawVaquero(0, 0, s, facing, phase, o.alpha == null ? 1 : o.alpha);
    ctx.restore(); VQ.mo = 0; VQ.brow = 0; VQ.g = null; VQ.x = null; VQ.sp = null; VQ.tilt = 0; VQ.jump = 0; VQ.squash = 0;
    const mp = VQ.mouthP, ep = VQ.emberP; if (o.fire != null) VQ.fire = 0; VQ.gt = null; VQ.joint = null; VQ.prop = null; VQ.sm = null;
    return glOn && mp ? { mx: x + mp[0] * s, my: y - mp[1] * s, ex: ep ? x + ep[0] * s : null, ey: ep ? y - ep[1] * s : null } : null;
}
function drawHeroPortrait() {   // every cutscene: a close-up bust of the hero in the corner that replays the on-screen hero's exact state (gesture, timing, lean, expression, speech), so the detailed 3D face is seen everywhere; skipped when the scene already shows him big
    const L = H3Last; if (!L || L.f !== csFrameN || L.eff >= 3.6 || !(OPT.hd && OPT.gfx >= 1 && H3.ok === true)) return;
    const a = clamp(cs.t / 24, 0, 1), fx = 8, fy = 42, fw = 118, fh = 124, S = 6.6;
    ctx.save(); ctx.globalAlpha = a;
    ctx.fillStyle = 'rgba(8,6,18,0.5)'; roundRect(fx, fy + 3, fw, fh, 12); ctx.fill();
    ctx.save(); roundRect(fx, fy, fw, fh, 12); ctx.clip();
    let g = ctx.createRadialGradient(fx + fw / 2, fy + fh * 0.4, 6, fx + fw / 2, fy + fh * 0.5, fw * 0.85); g.addColorStop(0, '#5f4d8c'); g.addColorStop(1, '#171229'); ctx.fillStyle = g; ctx.fillRect(fx, fy, fw, fh);
    const keep = Object.assign({}, VQ), v = L.vq; Object.assign(VQ, v); VQ.jump = v.jump || 0; VQ.squash = v.squash || 0;   // exactly the on-screen animation state (the camera follows his head, so hops and leans stay framed)
    const mp = L.mp, ox = mp ? fx + fw / 2 - mp[0] * S : fx + fw / 2, oy = mp ? fy + fh * 0.6 + mp[1] * S : fy + fh * 0.47 + 23.2 * S;   // camera follows the head: put his mouth at a fixed spot in the frame
    H3PIP = true; drawVaquero(ox, oy, S, L.facing, L.phase, 1); H3PIP = false;
    for (const k in VQ) if (!(k in keep)) delete VQ[k]; Object.assign(VQ, keep);
    g = ctx.createRadialGradient(fx + fw / 2, fy + fh / 2, fw * 0.38, fx + fw / 2, fy + fh / 2, fw * 0.82); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(8,4,20,0.5)'); ctx.fillStyle = g; ctx.fillRect(fx, fy, fw, fh);
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,211,42,0.7)'; ctx.lineWidth = 1.6; roundRect(fx, fy, fw, fh, 12); ctx.stroke();
    ctx.restore();
}
function csFlash(a) { if (a > 0.01) { ctx.fillStyle = 'rgba(255,255,255,' + Math.min(1, a) + ')'; ctx.fillRect(0, 34, W, 412); } }
function csRing(x, y, r, a, col, w) { if (a <= 0.01) return; ctx.save(); ctx.globalAlpha = Math.min(1, a); ctx.strokeStyle = col; ctx.lineWidth = w || 4; ctx.beginPath(); ctx.arc(x, y, Math.max(1, r), 0, TAU); ctx.stroke(); ctx.restore(); }
function csCracks(R, k, t) {   // white-hot fractures spreading over the Baron's armor
    if (k <= 0) return;
    ctx.save(); ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.clip(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (let c = 0; c < 10; c++) {
        const a0 = c * 0.63 + 0.2, reach = R * (0.3 + 0.85 * clamp(k * 1.35 - c * 0.06, 0, 1)); let x = 0, y = 0;
        ctx.beginPath(); ctx.moveTo(0, 0);
        for (let s = 1; s <= 8; s++) { if (Math.hypot(x, y) > reach) break; const a = a0 + (csRnd(c * 9 + s) - 0.5) * 1.0; x += Math.cos(a) * R * 0.15; y += Math.sin(a) * R * 0.15; ctx.lineTo(x, y); }
        ctx.strokeStyle = 'rgba(255,150,40,' + (0.45 + 0.4 * k) + ')'; ctx.lineWidth = R * 0.07; ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,225,' + (0.75 + 0.25 * Math.sin(t * 0.5 + c)) + ')'; ctx.lineWidth = R * 0.022; ctx.stroke();
    }
    ctx.restore(); drawGlow(0, 0, R * (0.35 + k * 0.9), '#ffe6a0', 0.18 + 0.5 * k);
}
// the child spirit from THE WHY: a small round-headed village kid in a white embroidered camisa and a little sombrero
const KID_EX = { calm: { br: 0.35, lid: 0, sm: 0.25, ew: 1 }, worry: { br: 1, lid: 0, sm: -0.35, ew: 1.12 }, cold: { br: -0.4, lid: 0.45, sm: -0.2, ew: 0.95 }, sad: { br: 0.85, lid: 0.2, sm: -0.9, ew: 1.02 }, knowing: { br: 0.5, lid: 0.25, sm: 0.55, ew: 0.98 } }, kidExState = { br: 0.35, lid: 0, sm: 0.25, ew: 1 };
// A see-through ghost has to be translucent as ONE shape: the body is painted solid into a scratch layer, and that layer is blended once at the ghost's opacity,
// so overlapping parts (head over shirt, arms over body) never show through each other.
let ghostLayer = null;
function drawKidGhost(x, y, s, t, seed, o) {
    const a = o.alpha == null ? 0.9 : o.alpha; if (a <= 0.01) return;
    const col = o.col || '#bcd6ff', ph = t * 0.08 + seed * 1.7, bob = Math.sin(t * 0.05 + seed * 1.9) * 4;
    ctx.save(); ctx.translate(x, y + bob); ctx.scale(s * (o.face || 1), s); ctx.globalAlpha = a; drawGlow(0, 4, 50, col, 0.28); ctx.restore();
    if (!ghostLayer) { ghostLayer = document.createElement('canvas'); ghostLayer.width = 170 * 2; ghostLayer.height = 200 * 2; }
    const prev = ctx, g2 = ghostLayer.getContext('2d'); g2.setTransform(1, 0, 0, 1, 0, 0); g2.clearRect(0, 0, ghostLayer.width, ghostLayer.height); g2.setTransform(2, 0, 0, 2, (85 - x) * 2, (95 - y) * 2);
    ctx = g2; try { drawKidGhostBody(x, y, s, t, seed, Object.assign({}, o, { alpha: 1 })); } finally { ctx = prev; }
    ctx.save(); ctx.globalAlpha = a; ctx.drawImage(ghostLayer, x - 85, y - 95, 170, 200); ctx.restore();
}
function drawKidGhostBody(x, y, s, t, seed, o) {
    const a = 1, col = o.col || '#bcd6ff', ph = t * 0.08 + seed * 1.7, bob = Math.sin(t * 0.05 + seed * 1.9) * 4;
    const tk = cutMouth('kid'), jaw = tk != null ? tk : 0, lk = (o.look || 0) * 1.6, blink = ((Math.floor(t) + seed * 37) % 150) < 5, sway = Math.sin(ph) * 0.05;
    ctx.save(); ctx.translate(x, y + bob); ctx.scale(s * (o.face || 1), s); ctx.globalAlpha = a; ctx.rotate(sway);
    // little wisp tail curling out of the shirt
    const N = 10, wv = u => Math.sin(ph + u * 4) * (2 + u * 9), wd = u => 8.5 * (1 - u * 0.85);
    ctx.beginPath(); for (let i = 0; i <= N; i++) { const u = i / N; if (i) ctx.lineTo(wv(u) - wd(u), 20 + u * 34); else ctx.moveTo(-wd(0), 20); }
    for (let i = N; i >= 0; i--) { const u = i / N; ctx.lineTo(wv(u) + wd(u), 20 + u * 34); }
    ctx.closePath(); ctx.fillStyle = lg(0, 18, 0, 56, [[0, 'rgba(225,240,255,0.9)'], [1, 'rgba(160,200,255,0)']]); ctx.fill();
    // stubby arms (one waves a little)
    ctx.lineCap = 'round';
    for (const sx of [-1, 1]) {
        const hx = sx * (17 + Math.sin(ph * 1.2 + sx) * 2.5), hy = 14 + Math.cos(ph * 1.1 + sx) * 3 - (sx > 0 && o.cheer ? 14 : 0);
        ctx.strokeStyle = 'rgb(248,250,255)'; ctx.lineWidth = 5.5; ctx.beginPath(); ctx.moveTo(sx * 8, 7); ctx.lineTo(sx * (8 + (hx * sx - 8) * 0.55), 7 + (hy - 7) * 0.55); ctx.stroke();
        ctx.strokeStyle = 'rgb(240,248,255)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(sx * (8 + (hx * sx - 8) * 0.5), 7 + (hy - 7) * 0.5); ctx.lineTo(hx, hy); ctx.stroke();
        ctx.fillStyle = 'rgb(245,250,255)'; ctx.beginPath(); ctx.ellipse(hx, hy, 3.2, 2.7, 0.5 * sx, 0, TAU); ctx.fill();
    }
    // striped shirt, drawn small so the head reads as a kid's
    ctx.save(); ctx.beginPath(); ctx.moveTo(-6, 2); ctx.quadraticCurveTo(0, 5, 6, 2); ctx.lineTo(10, 22); ctx.quadraticCurveTo(0, 26, -10, 22); ctx.closePath(); ctx.clip();
    ctx.fillStyle = 'rgb(248,250,255)'; ctx.fillRect(-12, 1, 24, 26); for (let k = 0; k < 7; k++) { ctx.fillStyle = ['#e0384b', '#1e9c58', '#ffd32a'][k % 3]; ctx.beginPath(); ctx.moveTo(-6 + k * 2, 3.4); ctx.lineTo(-5 + k * 2, 8.4 + (k % 2)); ctx.lineTo(-4 + k * 2, 3.4); ctx.fill(); }   // embroidered collar
    ctx.strokeStyle = '#e0384b'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-10, 21); ctx.lineTo(10, 21); ctx.stroke(); ctx.strokeStyle = '#1e9c58'; ctx.beginPath(); ctx.moveTo(-10, 23.4); ctx.lineTo(10, 23.4); ctx.stroke();
    ctx.fillStyle = 'rgba(40,30,80,0.18)'; ctx.fillRect(2, 0, 10, 28); ctx.restore();
    // head: big and round
    ctx.fillStyle = rg(-5, -18, 2, 0, -12, 17, [[0, '#ffe9d6'], [1, '#e6c4a6']]); ctx.beginPath(); ctx.arc(0, -12, 15.5, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(70,80,130,0.4)'; ctx.lineWidth = 1; ctx.stroke();
    // ears, then a mop of hair with side-swept bangs, and the blindfold pushed up as a band across it
    for (const sx of [-1, 1]) { ctx.fillStyle = '#ecd0b4'; ctx.beginPath(); ctx.ellipse(sx * 15.3, -9, 2.8, 3.6, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(70,80,130,0.35)'; ctx.lineWidth = 0.8; ctx.stroke(); }
    ctx.fillStyle = '#17121f'; ctx.beginPath(); ctx.moveTo(-15.6, -8); ctx.quadraticCurveTo(-18, -24, -4, -28); ctx.quadraticCurveTo(9, -31, 15.6, -17); ctx.quadraticCurveTo(15.8, -12, 15, -7.5);
    ctx.lineTo(13, -14); ctx.quadraticCurveTo(10, -16.4, 6.5, -17.8); ctx.quadraticCurveTo(2, -14.4, -2.4, -17.2); ctx.quadraticCurveTo(-7, -14.4, -10, -17); ctx.lineTo(-13, -13); ctx.lineTo(-14, -7.6); ctx.closePath(); ctx.fill();   // fringe in jagged locks
    ctx.fillStyle = 'rgba(190,200,255,0.3)'; ctx.beginPath(); ctx.ellipse(-4, -24.5, 5, 1.2, -0.3, 0, TAU); ctx.fill();   // gloss
    // face: modest eyes with a shine, brows, a nub of a nose, rosy cheeks, a small gap-toothed mouth
    // basic expressions (eased): br = brow tilt (+ worried, - flat/stern), lid = upper-lid droop, sm = mouth curve (+ smile, - frown), ew = eye size
    const E = KID_EX[o.ex] || KID_EX.calm, K = kidExState; K.ew = 1; for (const q of ['br', 'lid', 'sm']) K[q] += (E[q] - K[q]) * 0.05;
    for (const sx of [-1, 1]) {
        const ex = sx * 5.2, ey = -9, ry = 4.1 * K.ew;
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.ellipse(ex, ey, 3.7 * (0.9 + 0.1 * K.ew), blink ? 0.6 : ry, 0, 0, TAU); ctx.fill();
        if (!blink) {
            ctx.fillStyle = '#2a2250'; ctx.beginPath(); ctx.arc(ex + lk * 0.6, ey + 0.4 + K.lid * 0.8, 2.5, 0, TAU); ctx.fill(); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ex + lk * 0.6 - 0.8, ey - 0.4, 0.9, 0, TAU); ctx.fill();
            if (K.lid > 0.02) { ctx.save(); ctx.beginPath(); ctx.ellipse(ex, ey, 3.8, ry + 0.1, 0, 0, TAU); ctx.clip(); ctx.fillStyle = '#e9cfb4'; ctx.fillRect(ex - 5, ey - ry - 1, 10, ry * 2 * K.lid * 0.8 + 1); ctx.restore(); }   // heavy lids
        }
        const iy = ey - 6.6 - K.br * 2.2, oy = ey - 6.2 + K.br * 1.4;   // inner and outer brow ends
        ctx.strokeStyle = 'rgba(30,24,44,0.85)'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(ex - sx * 3.4, iy); ctx.quadraticCurveTo(ex, (iy + oy) / 2 - 0.9, ex + sx * 3.4, oy); ctx.stroke();
        ctx.fillStyle = 'rgba(255,130,150,0.5)'; ctx.beginPath(); ctx.ellipse(sx * 9.6, -2.6, 3, 1.9, 0, 0, TAU); ctx.fill();
    }
    ctx.strokeStyle = 'rgba(100,110,170,0.7)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-1.2, -4.8); ctx.quadraticCurveTo(0.8, -3.6, 1.4, -4.6); ctx.stroke();
    if (jaw > 0.08) {   // talking: open mouth, corners follow the mood
        const mh = 1 + jaw * 3.2; ctx.fillStyle = '#3a2250'; ctx.beginPath(); ctx.ellipse(0, -0.2 + mh * 0.2 - K.sm * 0.4, 3.1 + jaw * 1.1 + Math.max(0, K.sm) * 0.8, mh, 0, 0, TAU); ctx.fill();
        if (K.sm > -0.4) { ctx.fillStyle = '#fff'; ctx.fillRect(-1.9, -1.2, 1.7, 1.5); ctx.fillRect(0.4, -1.2, 1.7, 1.5); }
    } else {   // closed: a small curve, smile or frown
        ctx.strokeStyle = '#4a2a55'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(-3.2, -0.6 - K.sm * 0.9); ctx.quadraticCurveTo(0, -0.6 + K.sm * 2.4, 3.2, -0.6 - K.sm * 0.9); ctx.stroke();
    }
    ctx.restore();
}
// the shared sugar-skull face (centre 0,-12, radius 15): paint, eyes, nose, jaw and teeth per villager variant V. Used by every ghost and the giant calavera boss.
function ghostSkull(V, a, col, ph, look, jaw) {
    ctx.fillStyle = rg(-5, -18, 2, 0, -12, 18, [[0, '#fffdf4'], [1, '#e8e1cc']]); ctx.beginPath(); ctx.arc(0, -12, 15, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(60,40,70,0.55)'; ctx.lineWidth = 1; ctx.stroke();
    const lk = (look || 0) * 2, tl = [0, 0.38, 0, -0.32, 0, 0, -0.14, 0.2, 0][V < 0 ? 0 : V];
    for (const sx of [-1, 1]) {
        const ex = sx * 6.2, ey = -13;
        ctx.fillStyle = col;
        if (V === 4) { for (let p = 0; p < 3; p++) { ctx.strokeStyle = 'rgba(20,10,40,0.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(ex + sx * 3.6, ey - 3.4 - p * 0.2); ctx.lineTo(ex + sx * (7 + p * 0.5), ey - 5 - p * 2.4 + p); ctx.stroke(); } }   // lashes
        else if (V === 5) { ctx.fillStyle = 'rgba(120,80,160,0.35)'; ctx.beginPath(); ctx.arc(ex, ey, 7.4, 0, TAU); ctx.fill(); }   // dark sugar-skull eye ring
        else { ctx.globalAlpha = a * 0.5; for (let p = 0; p < 6; p++) { const an = p * TAU / 6 + 0.3; ctx.beginPath(); ctx.ellipse(ex + Math.cos(an) * 7.6, ey + Math.sin(an) * 7.6, 2.2, 1.1, an, 0, TAU); ctx.fill(); } ctx.globalAlpha = a; }   // petal ring
        ctx.globalAlpha = a; ctx.fillStyle = '#1c1030'; ctx.beginPath(); ctx.ellipse(ex, ey, V === 7 ? 3.6 : 4.4, V === 1 ? 4.2 : 5.2, tl * sx, 0, TAU); ctx.fill();
        ctx.fillStyle = col; ctx.beginPath(); ctx.arc(ex + lk, ey + 0.5, 1.9, 0, TAU); ctx.fill();
    }
    ctx.lineWidth = 0.9; ctx.strokeStyle = 'rgba(60,30,90,0.6)'; ctx.fillStyle = 'rgba(60,30,90,0.55)';
    if (V === 0) { for (const sx of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sx * 6.2, -7); ctx.lineTo(sx * 6.2, 2); ctx.stroke(); } }   // mourning tear lines
    if (V === 1) { ctx.strokeStyle = 'rgba(160,40,60,0.8)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-10, -21); ctx.lineTo(-2, -6); ctx.stroke(); for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(-8 + k * 2.6 - 1, -17 + k * 4.5); ctx.lineTo(-8 + k * 2.6 + 1.4, -17 + k * 4.5 - 1.6); ctx.stroke(); } }   // scar with stitches
    if (V === 2) { for (let r = 3; r <= 9; r += 3) { ctx.beginPath(); ctx.arc(0, -24, r, 0.2, Math.PI - 0.2); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(0, -24); ctx.lineTo(0, -15); ctx.moveTo(0, -24); ctx.lineTo(-8, -17); ctx.moveTo(0, -24); ctx.lineTo(8, -17); ctx.stroke(); }   // web on the brow
    if (V === 3) { ctx.fillRect(-1, -26, 2, 7); ctx.fillRect(-3, -24.2, 6, 2); }   // cross
    if (V === 4) { for (const sx of [-1, 1]) { ctx.fillStyle = 'rgba(224,56,100,0.75)'; ctx.beginPath(); ctx.moveTo(sx * 10, -1.5); ctx.bezierCurveTo(sx * 13.5, -5, sx * 8, -6, sx * 10, -2.8); ctx.bezierCurveTo(sx * 12, -6, sx * 6.5, -5, sx * 10, -1.5); ctx.fill(); } }   // hearts on the cheeks
    if (V === 5) { ctx.beginPath(); ctx.moveTo(0, -27); ctx.lineTo(3.4, -22); ctx.lineTo(0, -17); ctx.lineTo(-3.4, -22); ctx.closePath(); ctx.fill(); }   // diamond on the brow
    if (V === 6 || V === 8) { ctx.fillStyle = 'rgba(255,120,150,0.5)'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.arc(sx * 10, -4, 3, 0, TAU); ctx.fill(); } }   // rosy cheeks
    if (V === 7) { ctx.fillStyle = 'rgba(50,40,60,0.45)'; ctx.beginPath(); ctx.ellipse(-8, -6, 4, 2.4, 0.3, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(7, -20, 3.4, 2, -0.4, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(70,50,80,0.7)'; ctx.beginPath(); ctx.moveTo(4, -26); ctx.lineTo(7, -19); ctx.lineTo(4, -16); ctx.stroke(); }   // soot and a crack
    if (V === 8) { ctx.strokeStyle = 'rgba(60,40,80,0.85)'; ctx.lineWidth = 1.1; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.arc(sx * 6.2, -13, 6.6, 0, TAU); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(-0.4, -13); ctx.lineTo(0.4, -13); ctx.stroke(); }   // her glasses
    ctx.fillStyle = '#2a1a3a'; ctx.beginPath(); if (V === 7) { ctx.ellipse(0, -7.4, 1.8, 2.2, 0, 0, TAU); } else { ctx.moveTo(0, -9.5); ctx.lineTo(-2.4, -5.5); ctx.lineTo(2.4, -5.5); ctx.closePath(); } ctx.fill();
    ctx.fillStyle = '#1c1030'; ctx.beginPath(); ctx.ellipse(0, -1 + jaw * 0.4, 8.2, 1.6 + jaw * 0.7, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#fffdf4'; for (let k = -3; k <= 3; k++) { ctx.fillRect(k * 2.2 - 0.9, -2.6, 1.8, 2.2); ctx.fillRect(k * 2.2 - 0.9, -0.4 + jaw * 0.9, 1.8, 2); }
    if (V === 5) { ctx.strokeStyle = 'rgba(40,20,60,0.85)'; ctx.lineWidth = 1.1; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sx * 1.5, -6.6); ctx.quadraticCurveTo(sx * 6, -9, sx * 10, -6.4); ctx.stroke(); } }   // waxed moustache
}
function drawGhost(x, y, s, t, seed, o = {}) {   // a calavera spirit: wisp tail, sugar-skull face, marigold crown, chattering jaw
    if (o.who === 'kid') return drawKidGhost(x, y, s, t, seed, o);
    const a = o.alpha == null ? 0.9 : o.alpha; if (a <= 0.01) return;
    const ph = t * 0.08 + seed * 1.7, bob = Math.sin(t * 0.05 + seed * 1.9) * 4, col = o.col || '#8ff7e6', chat = o.chat == null ? 4 : o.chat;
    ctx.save(); ctx.translate(x, y + bob); ctx.scale(s * (o.face || 1), s); ctx.globalAlpha = a;
    drawGlow(0, -2, 54, col, 0.3);
    // each ghost is somebody: the seed picks a villager (señora, bandido, novia, padre, bailarina, catrín, cocinera, minero), their own face paint, headwear and clothes
    const bar = !!o.baron, abu = o.who === 'abuela', V = bar ? -1 : abu ? 8 : (((Math.round(seed) % 8) + 8) % 8);
    const CL = ['176,198,255', '255,168,148', '250,250,255', '176,154,228', '255,140,190', '150,228,218', '210,236,200', '196,200,214', '170,226,214'][V < 0 ? 0 : V];
    const FLARE = [10, 3, 14, 1, 16, 2, 8, 0, 9][V < 0 ? 0 : V];   // gowns flare, coats and cloaks hang straight
    // flowing tail / garment: ragged hem
    ctx.beginPath(); const N = 16, wv = u => Math.sin(ph + u * 4.5) * (3 + u * 11), wd = u => 17 * (1 - u * 0.82) + FLARE * u * (1 - u * 0.4), hem = (i2, side) => (i2 === N ? Math.sin(i2 * 2.3 + side + ph * 2) * 0 : 0);
    for (let i2 = 0; i2 <= N; i2++) { const u = i2 / N; if (i2) ctx.lineTo(wv(u) - wd(u), 6 + u * 54); else ctx.moveTo(wv(u) - wd(u), 6); }
    for (let i2 = N; i2 >= 0; i2--) { const u = i2 / N; ctx.lineTo(wv(u) + wd(u), 6 + u * 54); }
    ctx.closePath(); ctx.fillStyle = lg(0, 0, 0, 60, [[0, 'rgba(' + CL + ',0.95)'], [0.55, 'rgba(' + CL + ',0.5)'], [1, 'rgba(' + CL + ',0)']]); ctx.fill();
    ctx.save(); ctx.clip();   // clothing detail painted inside the garment
    if (V === 1) { ctx.strokeStyle = 'rgba(120,70,40,0.75)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-14, 6); ctx.lineTo(13, 26); ctx.moveTo(14, 6); ctx.lineTo(-13, 26); ctx.stroke(); ctx.fillStyle = 'rgba(230,200,150,0.9)'; for (let k = 0; k < 5; k++) { ctx.fillRect(-11 + k * 4.2, 9 + k * 3.4, 1.8, 3); ctx.fillRect(11 - k * 4.2, 9 + k * 3.4, 1.8, 3); } }   // bandolier
    if (V === 3) { ctx.fillStyle = 'rgba(70,50,110,0.55)'; ctx.fillRect(-4, 6, 8, 54); ctx.strokeStyle = 'rgba(240,230,255,0.8)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-9, 22); ctx.lineTo(9, 22); ctx.stroke(); ctx.beginPath(); ctx.arc(0, 22, 1.6, 0, TAU); ctx.stroke(); }   // rope belt
    if (V === 4) { for (let k = 0; k < 4; k++) { ctx.fillStyle = ['rgba(224,56,75,0.55)', 'rgba(255,255,255,0.5)', 'rgba(39,174,96,0.5)', 'rgba(224,56,75,0.55)'][k]; ctx.fillRect(-40, 30 + k * 7, 80, 4); } }   // folklorico skirt bands
    if (V === 5) { ctx.fillStyle = 'rgba(30,20,50,0.5)'; ctx.beginPath(); ctx.moveTo(-5, 6); ctx.lineTo(0, 22); ctx.lineTo(5, 6); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.fillRect(-1.2, 8, 2.4, 12); }   // suit front and shirt
    if (V === 6 || V === 8) { ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.moveTo(-9, 12); ctx.lineTo(9, 12); ctx.lineTo(11, 44); ctx.lineTo(-11, 44); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(224,100,130,0.6)'; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(-4 + k * 4, 24 + (k % 2) * 6, 1.3, 0, TAU); ctx.fill(); } }   // apron
    if (V === 7) { ctx.fillStyle = 'rgba(255,140,60,0.5)'; ctx.fillRect(-20, 16, 40, 3); ctx.fillRect(-20, 24, 40, 3); }   // hi-vis stripes
    if (V === 0 || V === 2) { ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.arc(0, 40, 6 + k * 5, 0.1, Math.PI - 0.1); ctx.stroke(); } }   // lace
    ctx.restore();
    // wispy arms, sleeves in the clothing colour
    ctx.lineCap = 'round';
    for (const sx of [-1, 1]) {
        const hx = sx * (27 + Math.sin(ph * 1.3 + sx) * 6), hy = 4 + Math.cos(ph * 1.1 + sx) * 8 - (o.cheer ? 20 + Math.sin(ph * 2 + sx) * 5 : 0);
        ctx.strokeStyle = 'rgba(' + CL + ',0.75)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(sx * 11, 8); ctx.quadraticCurveTo(sx * 24, 14 + (o.cheer ? -10 : 0), hx, hy); ctx.stroke();
        ctx.fillStyle = 'rgba(245,255,252,0.9)'; ctx.beginPath(); ctx.arc(hx, hy, 3.6, 0, TAU); ctx.fill();
    }
    // headwear that sits behind the skull
    ctx.save(); ctx.rotate(Math.sin(ph * 0.9) * 0.05 + (o.tip ? Math.sin(t * 0.1 + seed) * 0.12 : 0));
    if (V === 0 || V === 2) { const L2 = V === 2 ? 52 : 34; ctx.fillStyle = V === 2 ? 'rgba(255,255,255,0.45)' : 'rgba(20,16,36,0.6)'; ctx.beginPath(); ctx.moveTo(0, -29); ctx.bezierCurveTo(-22, -26, -22, -2, -18 + Math.sin(ph) * 2, L2 - 20); for (let k = 0; k < 6; k++) ctx.lineTo(-18 + k * 6 + Math.sin(ph + k) * 1.5, L2 - 20 + (k % 2) * 4); ctx.lineTo(18 + Math.sin(ph) * 2, L2 - 20); ctx.bezierCurveTo(22, -2, 22, -26, 0, -29); ctx.fill(); }   // mantilla / bridal veil
    if (V === 3) { ctx.fillStyle = 'rgba(66,48,104,0.92)'; ctx.beginPath(); ctx.arc(0, -13, 19, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(-18, -8); ctx.lineTo(-22, 8); ctx.lineTo(22, 8); ctx.lineTo(18, -8); ctx.fill(); }   // monk's cowl
    if (V === 4) { ctx.strokeStyle = 'rgba(25,18,34,0.95)'; ctx.lineWidth = 3.4; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sx * 13, -17); ctx.bezierCurveTo(sx * 18, -8, sx * 15, 2, sx * 17, 12 + Math.sin(ph + sx) * 2); ctx.stroke(); } }   // braids
    ctx.restore();
    ghostSkull(V, a, col, ph, o.look, (() => { const tk = cutMouth(o.who || (o.baron ? 'baron' : 'chorus')); return tk != null ? tk * 7 : (0.5 + 0.5 * Math.sin(ph * 2.6)) * chat; })());
    if (bar) { drawStache(0, -4.5, 13); drawSombrero(0, -27, 11, Math.sin(ph) * 0.06, 1); }
    else {   // headwear in front
        ctx.save(); ctx.rotate(Math.sin(ph * 0.9) * 0.05 + (o.tip ? Math.sin(t * 0.1 + seed) * 0.12 : 0));
        if (V === 1) { ctx.fillStyle = 'rgba(70,50,40,0.96)'; ctx.beginPath(); ctx.ellipse(0, -26, 13.5, 4, 0, Math.PI, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(3, -26, 15, 2.2, 0.08, 0, TAU); ctx.fill(); }   // flat cap
        if (V === 5) { ctx.fillStyle = 'rgba(24,20,34,0.96)'; ctx.beginPath(); ctx.ellipse(0, -28, 9, 8, 0, Math.PI, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(0, -27.5, 15, 2.8, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(230,230,240,0.85)'; ctx.fillRect(-9, -29.5, 18, 2); }   // bowler
        if (V === 6) { ctx.fillStyle = 'rgba(214,60,70,0.92)'; ctx.beginPath(); ctx.moveTo(-15, -17); ctx.quadraticCurveTo(0, -35, 15, -17); ctx.lineTo(18, -9); ctx.lineTo(10, -22); ctx.quadraticCurveTo(0, -27, -10, -22); ctx.lineTo(-18, -9); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.8)'; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.arc(-9 + k * 4.5, -25 + Math.abs(k - 2) * 1.4, 0.9, 0, TAU); ctx.fill(); } }   // kerchief
        if (V === 7) { ctx.fillStyle = 'rgba(210,225,245,0.96)'; ctx.beginPath(); ctx.ellipse(0, -26, 14, 8.5, 0, Math.PI, TAU); ctx.fill(); ctx.fillRect(-15.5, -27, 31, 2.6); ctx.fillStyle = 'rgba(255,255,255,0.95)'; ctx.beginPath(); ctx.arc(0, -30, 3, 0, TAU); ctx.fill(); drawGlow(0, -30, 18, '#ffffff', 0.35); }   // hard hat and lamp
        if (V === 8) { ctx.fillStyle = 'rgba(240,238,232,0.97)'; ctx.beginPath(); ctx.arc(0, -29.5, 5.6, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(-4, -26.5, 3.4, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(200,196,188,0.9)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.arc(0, -29.5, 3.2, 0.4, 5); ctx.stroke(); }   // bun
        if (V === 2) { ctx.fillStyle = 'rgba(255,255,255,0.95)'; for (let k = 0; k < 7; k++) { const an = -Math.PI * (0.92 - k * 0.14); ctx.beginPath(); ctx.arc(Math.cos(an) * 12.5, -12 + Math.sin(an) * 14.5, 1.4, 0, TAU); ctx.fill(); } }   // pearl circlet
        if (V === 4) { for (const sx of [-1, 1]) { ctx.fillStyle = 'rgba(224,56,75,0.95)'; ctx.beginPath(); ctx.moveTo(sx * 13, -17); ctx.lineTo(sx * 19, -21); ctx.lineTo(sx * 19, -13); ctx.closePath(); ctx.fill(); } }   // ribbon bows
        ctx.restore();
    }
    ctx.restore();
}
function csEmbers(cx, cy, t, n, spread, col, seed) {   // rising sparks, deterministic per frame
    for (let k = 0; k < n; k++) { const age = (t * 0.9 + k * 31 + seed) % 90, u = age / 90, x = cx + (csRnd(k + seed) - 0.5) * spread + Math.sin(age * 0.09 + k) * 6, y = cy - age * 1.1; ctx.fillStyle = col.replace('A', (0.85 * (1 - u)).toFixed(2)); ctx.beginPath(); ctx.arc(x, y, 1.2 + (1 - u) * 1.5, 0, TAU); ctx.fill(); }
}
function baronPos(tt) { return { x: 180 + Math.sin(tt * 0.045) * 38 * Math.min(1, tt / 80), y: 190 + tt * 1.1 + 0.002 * tt * tt }; }

function csWhy(t, part) {   // THE WHY is told over three scenes (the question, the tangent, the breaking); the scene art is shared
          const gy = 388; csStars(t); csGround(gy, '#12081a', '#201028'); csHouses(t * 0.002, gy, true, t);
          ctx.fillStyle = 'rgba(40,0,16,0.45)'; ctx.fillRect(0, 34, W, 410); drawGlow(250, gy - 80, 160, '#ff3a1a', 0.18);
          const GL3 = OPT.hd && OPT.gfx >= 1 && H3.ok === true, L = cs.spL || [], h1 = L.find(l => l.who === 'hero' && !l.inh && !l.cough && !l.scough && !l.hack), inh = L.find(l => l.inh), cg = L.find(l => l.cough), hk = L.find(l => l.hack), ce = hk ? hk.end : cg ? cg.end : 0;
          const E1 = h1 ? h1.end : 1e9, win = (a, b) => clamp((t - a) / (b - a), 0, 1), sm = x => x * x * (3 - 2 * x), kb = [];
          let rise = 0, drag = 0, hold = 0, fit = 0, cough = 0, wipe = 0, hz = 0, sp = 1e9;
          if (inh && cg) {   // the rip: hand to the lips, one huge slow drag, hold it in, then the fit
              rise = sm(win(E1, E1 + 25)) * (1 - sm(win(cg.at - 4, cg.at + 8)));
              drag = sm(win(inh.at, inh.at + 90)) * (0.82 + 0.18 * win(inh.at, inh.end)) * (1 - sm(win(inh.end - 8, inh.end + 4)));   // one long slow drag that keeps building
              hold = sm(win(inh.end, inh.end + 10)) * (1 - sm(win(cg.at - 4, cg.at + 2)));
              fit = sm(win(cg.at, cg.at + 18)) * (1 - sm(win(ce - 10, ce + 50)));
              wipe = sm(win(ce + 10, ce + 30)) * (1 - sm(win(ce + 70, ce + 100)));
              hz = clamp((t - cg.at) / 200, 0, 1) - clamp((t - ce - 160) / 240, 0, 1);
              cg.plan.env.forEach((e, i) => { if (cg.raw[i] && cg.raw[i][0] === 'K') { const at0 = cg.at + e.t0 * 60; kb.push(at0); const a = (t - at0) / 18; if (a >= 0 && a < 1) cough = Math.max(cough, Math.sin(Math.PI * a)); } });
              if (hk) { const ks = []; hk.plan.env.forEach((e, i) => { if (hk.raw[i] && hk.raw[i][0] === 'K') ks.push(hk.at + e.t0 * 60); }); ks.forEach((at0, i) => { const last = i === ks.length - 1, a = (t - at0) / (last ? 14 : 30); if (last) sp = at0 + 3; if (a >= 0 && a < 1) cough = Math.max(cough, (last ? 1.1 : 0.75 + 0.1 * i) * Math.sin(Math.PI * a)); }); }   // the hack: three deep heaves, then the spit
          }
          L.filter(l => l.toke).forEach(l => { rise = Math.max(rise, sm(win(l.at - 58, l.at - 30)) * (1 - sm(win(l.at - 6, l.at + 24)))); drag = Math.max(drag, sm(win(l.at - 48, l.at - 22)) * (1 - sm(win(l.at - 12, l.at - 2)))); });   // a lazy second toke before the tangent
          const ksb = []; L.forEach(l => { if (!l.scough) return; l.plan.env.forEach((e, i) => { if (l.raw[i] && l.raw[i][0] === 'K') { const at0 = l.at + e.t0 * 60, a = (t - at0) / 14; ksb.push(at0); if (a >= 0 && a < 1) cough = Math.max(cough, 0.7 * Math.sin(Math.PI * a)); } }); });   // a super short cough after each toke
          const hsh0 = k => { const x = Math.sin(k * 12.9898) * 43758.5453; return (x - Math.floor(x)) * 2 - 1; };
          const SN = L.find(l => l.snort); let pk = 0, bg = 0, bnd = 0, chp = 0, bil = 0, rec = 0, sw2 = 0, lg = 0, lc = 0, prop = null, snU = -1;   // the stash: pocket, baggie, pour, chop, rolled bill, snort, recoil, nose rub
          if (SN) { const w2 = (a, b) => sm(win(SN.at + a, SN.at + b)); snU = t - SN.at; pk = w2(0, 25) * (1 - w2(34, 48)); bg = w2(34, 52) * (1 - w2(100, 116)); bnd = w2(55, 100) * (1 - w2(262, 292)); chp = w2(112, 124) * (1 - w2(198, 208)); bil = w2(203, 222) * (1 - w2(260, 274)); rec = w2(256, 272) * (1 - w2(300, 350)); sw2 = w2(292, 306) * (1 - w2(355, 385)); lg = w2(100, 200); lc = w2(224, 262); prop = snU >= 36 && snU < 116 ? 'bag' : snU >= 116 && snU < 204 ? 'card' : snU >= 204 && snU < 276 ? 'bill' : null; wipe = Math.max(wipe, sw2); }
          const rgL = L.find(l => l.rage), wr = (SN ? sm(win(SN.at + 262, SN.at + 320)) : part === 3 ? sm(win(0, 30)) : 0) * (1 - sm(win(rgL ? rgL.at - 80 : 1e9, rgL ? rgL.at - 4 : 1e9 + 200))), tk0 = Math.floor(t / 280), ta0 = t - (tk0 * 280 + 5 + (hsh0(tk0) + 1) * 100), wt = wr * (hsh0(tk0 * 3.1) > -0.25 && ta0 >= 0 && ta0 < 16 ? Math.exp(-ta0 / 3.5) : 0), wl = wt * hsh0(tk0 + 7) * 0.9;   // an occasional twitch, not a constant shake   // wired after the line: twitchy head, bouncing heels, dilated stare
          const bz = Math.max(pk, bg, bnd, chp, bil, rec), post = cg ? sm(win(ce + 20, ce + 140)) : 0;
          if (hz > 0.01) { ctx.fillStyle = 'rgba(196,204,214,' + (0.16 * hz).toFixed(3) + ')'; ctx.fillRect(0, 150, W, 250); }
          let A = null, heat = 0, voicesW = 0; L.forEach(l => { if (l.who !== 'hero') return; if (t >= l.at - 5 && t <= l.end + 20) A = l; if (l.heat) heat = Math.max(heat, l.heat * sm(win(l.at - 5, l.at + 25)) * (1 - sm(win(l.end + 10, l.end + 80)))); if (l.voices) voicesW = Math.max(voicesW, sm(win(l.at, l.at + 30)) * (1 - sm(win(l.end + 20, l.end + 90)))); });
          let ptW = 0; L.forEach(l => { if (l.who === 'hero' && l.ex === 'laugh') ptW = Math.max(ptW, sm(win(l.at - 2, l.at + 10)) * (1 - sm(win(l.at + 55, l.at + 80)))); });   // laughing at the ghost: one brief bent-arm point toward him
          let lf = 0; L.forEach(l => { if (l.who === 'hero' && (l.ex === 'laugh' || l.ex === 'cocky')) lf = Math.max(lf, sm(win(l.at - 3, l.at + 12)) * (1 - sm(win(l.end - 4, l.end + 25)))); });
          const sd = L.find(l => l.rage), stand = !!sd && t >= sd.at - 6, thrown = !!sd && t >= sd.at - 2, kidTalk = L.some(l => l.who === 'kid' && t >= l.at && t <= l.end), baitL = L.find(l => l.bait), near = baitL ? 16 * sm(win(baitL.at, baitL.at + 80)) : 0;
          { const tkT = A && t >= A.at - 2 && t <= A.end + 6 ? 1 : 0; cs.tk = (cs.tk || 0) + (tkT - (cs.tk || 0)) * 0.12; { const mood = A && A.mood, txt = A ? A.say : '', e0 = A ? clamp((t - A.at - 8) / 20, 0, 1) * (1 - clamp((t - A.end + 6) / 20, 0, 1)) : 0, wt = ({ rageh: 1, rage: 1, mock: 1, stonemock: 0.9, plead: 0.9, sad: 0.7, cheer: 1, stoned: 0.55, chill: 0.6, whisper: 0.35, cold: 0.3 })[mood], kd = /looked at your hand/i.test(txt) ? 4 : /hands/i.test(txt) ? 0 : /hat|sombrero/i.test(txt) ? 5 : /\b(I|me|my)\b/.test(txt) && (mood === 'plead' || mood === 'sad' || mood === 'cold' || mood === 'stoned') ? 2 : ({ rageh: 0, rage: 0, mock: 1, stonemock: 1, plead: 2, sad: 2, whisper: 2, cold: 1, stoned: 1, chill: 1, cheer: 1 })[mood]; cs.gk = kd == null ? 1 : kd; cs.gb = e0 * e0 * (3 - 2 * e0) * (kd === 4 ? 1 : wt == null ? 0.7 : wt) * (cs.tk || 0); cs.gz = kd === 4 ? cs.gb : 0; }
          cs.ta = ({ rageh: 0.6, rage: 0.6, mock: 0.9, stonemock: 0.8, plead: 0.3, cheer: 1.3, whisper: 0.2, cold: 0.2, chill: 0.5, stoned: 0.5, sad: 0.2 })[A && A.mood] || 0.6; }
          { const heavy = A && ({ cold: 1, plead: 1, sad: 1, whisper: 1, stoned: 0.7, chill: 0.6 })[A.mood] ; const quiet = !(drag > 0.05 || hold > 0.05 || fit > 0.05 || rise > 0.05); const tgt = quiet && heavy && t >= A.at + 20 && t <= A.end + 40 ? 1 : 0; cs.ln = (cs.ln || 0) + ((tgt ? 1 : 0) - (cs.ln || 0)) * 0.035; }
          const hsh = (k) => { const x = Math.sin(k * 12.9898) * 43758.5453; return (x - Math.floor(x)) * 2 - 1; }, sk = Math.floor(t / 38), su = clamp((t - sk * 38) / 6, 0, 1), dart = (hsh(sk - 1) + (hsh(sk) - hsh(sk - 1)) * su) * clamp(voicesW * 1.6, 0, 1);
          const sh = Math.sin(t * 0.7) * (1.5 + 2 * heat) * (1 + 3 * fit), shr = clamp(t / 200, 0, 1), shx = heat > 0.7 ? Math.sin(t * 1.9) * 0.7 * heat : 0, shy = heat > 0.7 ? Math.cos(t * 2.3) * 0.5 * heat : 0;
          const kl = L.find(l => l.who === 'kid' && t >= l.at - 5 && t <= l.end + 20), kex = kl ? (kl.q ? 'worry' : kl.say.startsWith('There he is') ? 'knowing' : kl.say.startsWith('You are not fine') ? 'sad' : 'cold') : heat > 0.6 ? 'worry' : (A && ({ plead: 1, sad: 1, stoned: 0 })[A.mood]) ? 'sad' : 'calm';
          const kLast = L.filter(l => l.who === 'kid' && l.at - 8 <= t).pop(), kwT = kl ? 1 : (kLast && t <= kLast.end + 130 && !(A && (A.voices || A.ex === 'daydream' || A.ex === 'suspicious'))) ? 0.65 : 0; cs.kw = (cs.kw || 0) + (kwT - (cs.kw || 0)) * 0.08; cs.up = (cs.up || 0) + ((A && A.look === 'up' ? 1 : 0) - (cs.up || 0)) * 0.1; cs.bd = (cs.bd || 0) + ((A && A.bird ? 1 : 0) - (cs.bd || 0)) * 0.25;
          const kTxt = (kl || kLast) ? (kl || kLast).say : '', kidEx = /why/i.test(kTxt) ? 'guilty' : /name|remember/i.test(kTxt) ? 'bewildered' : /hat is the hero|not fine|never were/i.test(kTxt) ? 'betrayed' : /There he is/i.test(kTxt) ? 'afraid' : 'guilty';
          drawGhost(56 + sh - 8 * fit + near, 250 + Math.sin(t * 0.04) * 5, 1.7, t, 3, { who: 'kid', ex: kex, alpha: 0.6, col: '#bcd6ff', look: 1, chat: ((part === 1 && t < 120) || kidTalk) ? 5 : 0 });
          
          if (!GL3) { const k = ease(clamp((t - 100) / 60, 0, 1)); hero(256, gy - 6, 2.1, 1, 0, { g: 'kneel', lock: true, mo: 0.3 + 0.6 * k, brow: 0, tilt: -0.1 * k, sx: 1 }); return; }
          // the ledge: weathered stone slab on a brick wall
          const LY = 370, LY0 = 322, K = 2; ctx.fillStyle = '#2a1c34'; ctx.fillRect(0, LY, W, 90);
          ctx.strokeStyle = 'rgba(0,0,0,0.38)'; ctx.lineWidth = 1; for (let r = 0; r < 5; r++) { const y = LY + 14 + r * 18; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W + 10, y); ctx.stroke(); for (let c2 = 0; c2 < 8; c2++) { const x = 10 + c2 * 48 + (r % 2) * 24; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 18); ctx.stroke(); } }
          ctx.fillStyle = '#4a3558'; ctx.fillRect(0, LY + 8, W, 20); { const tg = ctx.createLinearGradient(0, LY - 18, 0, LY + 8); tg.addColorStop(0, '#7c6190'); tg.addColorStop(1, '#5c4570'); ctx.fillStyle = tg; ctx.fillRect(0, LY - 18, W, 26); } ctx.fillStyle = '#8a6ea0'; ctx.fillRect(0, LY - 18, W, 2); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(0, LY + 28, W, 8);   // deep slab: the top face is wide enough for both feet to stand on
          const FBX = { sad: 'melancholy', plead: 'disappointed', cold: 'bitter', rage: 'defiant', rageh: 'defiant', whisper: 'suspicious', mock: 'condescending', stonemock: 'condescending', cheer: 'grin', chill: 'stoned', stoned: 'stoned' }, Lp = L.filter(l => l.who === 'hero' && l.at - 5 <= t).pop(), lineEx0 = A ? (A.ex || FBX[A.mood] || 'stoned') : kl ? kidEx : Lp ? (Lp.ex || FBX[Lp.mood] || 'stoned') : 'stoned', lineEx = wr > 0.3 && (lineEx0 === 'stoned' || lineEx0 === 'grin' || lineEx0 === 'smirk') ? 'wired' : lineEx0, xn = rec > 0.2 ? 'surprise' : bil > 0.3 ? 'wince' : bnd > 0.3 ? 'focused' : fit > 0.3 ? 'wince' : hold > 0.3 ? 'hold_breath' : drag > 0.2 ? 'smoke_drag' : lineEx, jb = 0.4 + 1.2 * drag + 0.1 * Math.sin(t * 0.4), hatW = L.some(l => l.hat && t >= l.at - 4 && t <= l.end + 30) ? 1 : 0, tw = Math.max(heat * 0.9, voicesW * 0.7, post * 0.25);
          let P = null; const J = stand ? ease(clamp((t - (sd.at - 6)) / 14, 0, 1)) : 0;
          const NX = 235 + shx * K, NY = (stand ? LY - 112 : LY - 80) + shy * K, OX = 250 + shx, OY = (stand ? LY0 - 56 : LY0 - 40) + shy;   // hero drawn at 2x; effects below are authored in the old frame and mapped through this transform
          if (!stand) P = hero(NX, NY, 2.1 * K, 1, 0, { g: 'smoke', lock: true, x: xn, gt: t, joint: thrown || bz > 0.02 || sw2 > 0.02 ? null : jb, prop, sm: { kw: cs.kw, up: cs.up, bird: cs.bd, pt: ptW, tk: cs.tk, ta: cs.ta, ln: cs.ln, gk: cs.gk, gb: cs.gb, gz: cs.gz, rise, drag, hold, fit, c: cough, pk, bg, bend: bnd, chop: chp, bill: bil, rec, bz, wipe: Math.max(wipe, hatW), post, look: dart + wl, tw: Math.max(tw, wt * 0.8) * 0.45, lf, wr: wt } });
          else P = hero(NX, NY, 2.1 * K, -1, 0, { g: 'fireup', lock: true, sm: { tk: cs.tk, ta: cs.ta, kw: cs.kw, up: cs.up, bird: cs.bd }, fire: heat > 0.5 ? 1 : 0.3, x: heat > 0.8 ? 'roar' : lineEx, gt: t, jump: 16 * Math.sin(Math.PI * clamp((t - (sd.at - 6)) / 22, 0, 1)), tilt: 0.1 * heat * Math.sin(t * 0.8) });
          if (P) P = { mx: (P.mx - NX) / K + OX, my: (P.my - NY) / K + OY, ex: P.ex == null ? null : (P.ex - NX) / K + OX, ey: P.ey == null ? null : (P.ey - NY) / K + OY };
          ctx.save(); ctx.translate(NX, NY); ctx.scale(K, K); ctx.translate(-OX, -OY);
          if (P && P.ex != null && !thrown) cs.emb = [P.ex, P.ey];
          // smoke, ember, crackle
          const puff = (x, y, r, a) => { if (a <= 0.01) return; const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(226,228,236,' + a.toFixed(3) + ')'); g.addColorStop(1, 'rgba(226,228,236,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); };
          if (P && P.ex != null) {
              drawGlow(P.ex, P.ey, 9 + 28 * drag, '#ff8a30', 0.25 + 0.55 * drag);
              if (drag > 0.05) { drawGlow(P.mx, P.my, 40 * drag, '#ff9a4a', 0.2 * drag); for (let q = 0; q < 8; q++) { const u = (t * 0.05 + q * 0.37) % 1; ctx.fillStyle = 'rgba(255,' + (150 + q * 12) + ',60,' + (0.85 * (1 - u) * drag).toFixed(2) + ')'; ctx.fillRect(P.ex + Math.sin(q * 7 + t * 0.3) * 7 * u, P.ey - u * 24, 1.8, 1.8); } }
              for (let q = 0; q < 6; q++) { const u = (t * 0.011 + q / 6) % 1; puff(P.ex + Math.sin(t * 0.05 + q * 2 + u * 6) * (3 + u * 14), P.ey - 4 - u * 78, 2.5 + u * 7, 0.2 * (1 - u) * (0.7 + 0.6 * drag)); }
          }
          if (P && voicesW > 0.02) { const ws = ['clap', 'clap', 'hero', 'not me', 'the hat', 'louder', 'smile', 'again', 'his name?']; ctx.save(); ctx.font = 'italic 600 12px sans-serif'; ctx.textAlign = 'center'; ws.forEach((w, i) => { const an = t * 0.012 * (1 + (i % 3) * 0.3) + i * 0.7, r = 38 + 14 * Math.sin(t * 0.02 + i); ctx.globalAlpha = Math.min(0.7, 0.62 * voicesW * (0.6 + 0.4 * Math.sin(t * 0.1 + i * 2))); ctx.fillStyle = i % 4 === 0 ? '#ffb4c0' : '#d9c7ff'; ctx.fillText(w, P.mx + Math.cos(an) * r * 1.25, P.my - 18 + Math.sin(an) * r * 0.6); }); ctx.restore(); }
          if (thrown) { const e0 = cs.emb || [292, 262], age = t - (sd.at - 2), vx = (e0[0] - 190) / 50, x = e0[0] - vx * Math.min(age, 50), y = Math.min(LY0 - 11, e0[1] - 4 * age + 0.13 * age * age), rest = y >= LY0 - 11, fade = rest ? clamp(1 - (age - 62) / 140, 0, 1) : 1;
              if (fade > 0.02) { drawGlow(x, y, 16, '#ff7a28', 0.7 * fade); ctx.fillStyle = 'rgba(255,230,160,' + fade.toFixed(2) + ')'; ctx.fillRect(x - 2, y - 1, 5, 3); if (!rest) for (let q = 0; q < 6; q++) { const u = q / 6; ctx.fillStyle = 'rgba(255,' + (140 + q * 15) + ',60,' + (0.7 * (1 - u)).toFixed(2) + ')'; ctx.fillRect(x + vx * q * 3 + Math.sin(age + q) * 1.5, y + 3 * q * (0.5 - age * 0.01), 2, 2); } } }
          if (P) L.filter(l => l.toke).forEach(l => { const age = t - (l.at - 4); if (age < 0 || age > 300) return; for (let k = 0; k < 4; k++) puff(P.mx + (k - 1.5) * 9 + Math.sin(age * 0.03 + k) * 10, P.my - 6 - age * (0.2 + 0.04 * k) - k * 4, 9 + age * 0.14 + k * 3, 0.34 * (1 - age / 300)); });   // slow, lazy exhale over the stars line
          if (P) ksb.forEach(at0 => { const age = t - at0; if (age < 0 || age > 70) return; for (let k = 0; k < 3; k++) puff(P.mx + (k - 1) * 5 + age * (0.25 + 0.1 * k) * (k % 2 ? -1 : 1) * 0.5, P.my - age * (0.2 + 0.08 * k) - k * 2, (4 + age * 0.2) + k * 1.5, 0.3 * (1 - age / 70)); });
          if (P && hk && t >= sp - 1) { if (!cs.spitO || cs.spitT !== sp) { cs.spitO = [P.mx, P.my]; cs.spitT = sp; } const age = t - sp, o = cs.spitO, vx = -2.3, gx = o[0] + vx * age, gy2 = o[1] - 1.9 * age + 0.06 * age * age;   // the spit: a glistening glob arcs out of his mouth and over the ledge
              if (age < 110 && gy2 < 430) { if (age < 9) { ctx.strokeStyle = 'rgba(215,235,200,0.7)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(o[0], o[1]); ctx.lineTo(gx, gy2); ctx.stroke(); }
                  for (let q = 1; q < 4; q++) { const a3 = Math.max(0, age - q * 2.5); ctx.fillStyle = 'rgba(215,235,200,' + (0.5 - 0.12 * q).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(o[0] + vx * a3, o[1] - 1.9 * a3 + 0.06 * a3 * a3, 1.8, 0, TAU); ctx.fill(); }
                  ctx.fillStyle = 'rgba(222,240,205,0.92)'; ctx.beginPath(); ctx.ellipse(gx, gy2, 4.4, 3.2, 0.3, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.fillRect(gx - 2.2, gy2 - 1.6, 1.8, 1.3); } }
          if (P && cg) {   // every cough throws out a cloud; a slow last exhale hangs over him afterwards
              kb.forEach((at0, i) => { const age = t - at0; if (age < 0 || age > 130) return; const big = i === 0 ? 1.8 : 1; for (let k = 0; k < 4; k++) puff(P.mx + (k - 1.5) * 7 + age * (0.3 + 0.12 * k) * (k % 2 ? -1 : 1) * 0.6, P.my - age * (0.28 + 0.1 * k) - k * 3, (7 + age * 0.3) * (0.6 + 0.4 * big) + k * 2, 0.4 * (1 - age / 130) * Math.min(1, big)); });
              const a2 = t - ce; if (a2 > 0 && a2 < 220) for (let k = 0; k < 5; k++) puff(P.mx + (k - 2) * 12 + Math.sin(a2 * 0.03 + k) * 8, P.my - 8 - a2 * (0.25 + 0.05 * k), 14 + a2 * 0.22 + k * 3, 0.3 * (1 - a2 / 220));
          }
          ctx.restore();
          if (SN && snU > 98 && snU < 330) { const mx0 = NX - 4, my0 = LY - 24, a0 = 0.25 + 0.75 * Math.min(1, (snU - 98) / 14); ctx.save(); ctx.globalAlpha = a0; ctx.fillStyle = '#9aa6b8'; ctx.fillRect(mx0 - 30, my0, 60, 9); ctx.fillStyle = '#2c3446'; ctx.fillRect(mx0 - 29, my0 + 1, 58, 5); ctx.fillStyle = 'rgba(160,190,230,0.25)'; ctx.fillRect(mx0 - 29, my0 + 1, 58, 1); ctx.fillStyle = '#fff'; const x1 = mx0 - 24 + 48 * lc, x2 = mx0 - 24 + 48 * lg; if (x2 > x1) ctx.fillRect(x1, my0 + 2, x2 - x1, 2); if (lg < 1 && snU < 205) { ctx.fillRect(mx0 - 24, my0 + 1, 7 * (1 - lg), 3); } ctx.restore(); }
          if (heat > 0.02) { const gv = ctx.createRadialGradient(W / 2, 300, 80, W / 2, 300, 440); gv.addColorStop(0, 'rgba(120,0,10,0)'); gv.addColorStop(1, 'rgba(150,6,22,' + (0.62 * heat).toFixed(3) + ')'); ctx.fillStyle = gv; ctx.fillRect(0, 0, W, 700); }
}
const END_CUTS = [
    { sky: 28500, title: 'THE LAST POP', fade: '0,0,0', text: '"Impossible!" the Baron shrieks as the hoop spins faster than he can bear. Cracks race across his armor, and the whole sky holds its breath.',
      art(t) {
          csStars(t);
          const k = clamp((t - 30) / 190, 0, 1), amp = k * k * 5;
          ctx.save(); ctx.translate((csRnd(t * 1.7) - 0.5) * amp * 2, (csRnd(t * 2.3) - 0.5) * amp * 2);
          drawGlow(180, 190, 230, '#ff2a00', 0.22 + 0.3 * k);
          ctx.save(); ctx.translate(180, 190 + Math.sin(t * 0.05) * 5); drawVillain(0, 0, 92, t, {}); csCracks(92, k, t); ctx.restore();
          for (let i = 0; i < 5; i++) { const u = (t * 0.03 + i * 0.2) % 1; ctx.fillStyle = 'rgba(255,230,120,' + (0.55 * (1 - u)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(180 + Math.sin(i * 2 + t * 0.1) * 26, 360 - u * 150, 2.5, 0, TAU); ctx.fill(); }   // hoop sparks rising to him
          hero(180, 392, 1.8, 1, t * (0.3 + k * 0.55), { x: 'fierce', g: 'power', hoop: true, brow: 1, mo: 0.2, jump: 0 });
          ctx.restore();
          csFlash((t - 205) / 48);
      } },
    { sky: 28500, title: 'THE FALL', fade: '255,255,255', text: 'With one final pop, El Gran Globo screams, wheezes, and spirals out of the sky like a sad, deflating balloon. His glow gutters out. The stolen sombrero tumbles free.',
      art(t) {
          csStars(t);
          const sh = t < 40 ? (1 - t / 40) * 7 : 0; ctx.save(); ctx.translate((csRnd(t * 3.1) - 0.5) * sh * 2, (csRnd(t * 1.3) - 0.5) * sh * 2);
          const ox = 180, oy = 190;
          // shockwaves and the burst
          csRing(ox, oy, t * 8, 1 - t / 60, '#fff2b0', 6); csRing(ox, oy, (t - 8) * 6, 1 - (t - 8) / 70, '#ff9f43', 3);
          if (t < 50) drawGlow(ox, oy, 60 + t * 6, '#ffd7a0', (1 - t / 50) * 0.9);
          // armor shards
          if (t < 150) for (let k = 0; k < 16; k++) {
              const a = k * 0.39 + csRnd(k) * 0.3, v = 2.4 + csRnd(k + 5) * 4.2, px = ox + Math.cos(a) * v * t * 0.8, py = oy + Math.sin(a) * v * t * 0.8 + 0.06 * t * t;
              ctx.save(); ctx.translate(px, py); ctx.rotate(t * (0.05 + csRnd(k + 9) * 0.12) * (k % 2 ? 1 : -1)); ctx.globalAlpha = clamp(1 - t / 150, 0, 1);
              ctx.fillStyle = k % 3 ? '#4a0d12' : '#aeb6c0'; ctx.strokeStyle = '#ff7a1a'; ctx.lineWidth = 1.4; const q = 5 + csRnd(k + 2) * 9;
              ctx.beginPath(); ctx.moveTo(-q, -q * 0.4); ctx.lineTo(q * 0.8, -q * 0.7); ctx.lineTo(q * 0.4, q * 0.8); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
          }
          // the deflating Baron: shrinks with a wobble, spirals down trailing smoke and embers
          if (t < 250) {
              for (let k = 0; k < 26; k++) {
                  const tt = t - k * 5; if (tt < 24) continue; const p = baronPos(tt), age = (t - tt) / 130;
                  ctx.fillStyle = 'rgba(70,60,70,' + (0.4 * (1 - age)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(p.x + Math.sin(k) * 5, p.y + 6, 7 + age * 18, 0, TAU); ctx.fill();
                  if (k % 2 === 0) { ctx.fillStyle = 'rgba(255,140,40,' + (0.8 * (1 - age)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(p.x + Math.cos(k * 2) * 12, p.y + 8 + age * 20, 2.2, 0, TAU); ctx.fill(); }
              }
              const f = ease(clamp(t / 30, 0, 1)), R = (92 - 62 * f) * (1 + Math.sin(t * 0.35) * 0.05 * f) * (t > 150 ? clamp(1 - (t - 150) / 120, 0.4, 1) : 1), p = baronPos(Math.max(0, t));
              ctx.save(); ctx.translate(t < 24 ? ox : p.x, t < 24 ? oy : p.y); ctx.rotate(t * 0.02 * f + Math.sin(t * 0.3) * 0.15 * f);
              ctx.globalAlpha = (t > 90 ? 0.62 + 0.38 * Math.sin(t * 0.55) : 1) * clamp(1 - (t - 200) / 50, 0, 1); drawVillain(0, 0, R, t * 0.6, {}); ctx.restore();
          }
          // the Golden Sombrero is flung free and tumbles
          { const f = ease(clamp(t / 60, 0, 1)), sx = ox + 72 * f - Math.max(0, t - 60) * 0.12, sy = oy - 115 * f + Math.max(0, t - 60) * 0.22;
            drawGlow(sx, sy, 80, '#ffd32a', 0.8); csEmbers(sx, sy + 18, t, 6, 30, 'rgba(255,225,120,A)', 3); drawSombrero(sx, sy, 38, Math.sin(t * 0.09) * 0.45 * (1 - f * 0.4), 4); }
          // the Baron's ghost climbs out and fades away with a wail
          { const g0 = baronPos(110), gt = t - 110, ga = clamp(gt / 25, 0, 1) * (1 - clamp((gt - 90) / 60, 0, 1));
            if (gt > 0 && ga > 0) { const gy = g0.y - gt * 1.25; drawGhost(g0.x + Math.sin(gt * 0.05) * 22, gy, 1.7, t, 4, { baron: true, alpha: ga * 0.8, cheer: true, chat: 7, col: '#ffb0a0' });
                for (let k = 0; k < 8; k++) { const u = ((gt - 70) / 80 + k * 0.1); if (u > 0 && u < 1) { ctx.fillStyle = 'rgba(255,240,200,' + (0.9 * (1 - u)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(g0.x + Math.sin(k * 3) * 30, gy - u * 50, 2, 0, TAU); ctx.fill(); } } } }
          // our hero, reeling from the blast then looking up
          { const rec = t < 30 ? -0.14 * (1 - t / 30) : 0; hero(180, 392, 1.8, 1, t * 0.05, { x: t > 40 ? 'triumph' : 'wince', g: t > 40 ? 'power' : 'recoil', brow: 1, mo: t > 40 ? 0.7 : 0.2, tilt: rec, jump: t < 14 ? Math.sin(t / 14 * Math.PI) * 14 : 0 }); }
          ctx.restore();
          csFlash(1 - t / 22);
      } },
    { sky: 27000, title: 'THE ARMADA FALLS', sfx: 1, text: 'Without their master, the Baron\'s armada loses its glow. One by one the dark airships sputter, burn, and sink into the clouds below.',
      art(t) {
          csStars(t);
          for (let i = 0; i < 7; i++) {
              const fall = Math.max(0, t - i * 16), x = 28 + i * 50 + Math.sin(t * 0.03 + i) * 8 + fall * 0.1 * (i % 2 ? 1 : -1), y = 100 + (i % 3) * 44 + fall * 0.7 + fall * fall * 0.0022, hit = 330 + (i % 3) * 14;
              if (y > hit + 50) continue;
              if (y > hit) { const e = (y - hit) / 50; drawGlow(x, hit, 30 + e * 70, '#ff9f43', 1 - e); csRing(x, hit, e * 60, 1 - e, '#ffd27a', 3); continue; }
              for (let k = 0; k < 7; k++) { const age = k * 6, tt = Math.max(0, fall - age), yy = 100 + (i % 3) * 44 + tt * 0.7 + tt * tt * 0.0022 - 4, xx = 28 + i * 50 + Math.sin((t - age) * 0.03 + i) * 8 + tt * 0.1 * (i % 2 ? 1 : -1);
                  if (fall > 0) { ctx.fillStyle = 'rgba(60,50,60,' + (0.4 * (1 - k / 7)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(xx, yy - k * 4, 4 + k * 2.4, 0, TAU); ctx.fill(); } }
              ctx.save(); ctx.translate(x, y); ctx.rotate(fall * 0.011 * (i % 2 ? 1 : -1));
              if (fall > 0) drawGlow(0, 0, 36 + fall * 0.18, '#ff7a1a', clamp(fall / 60, 0, 0.8));
              ctx.fillStyle = 'rgba(30,10,50,0.96)'; ctx.beginPath(); ctx.ellipse(0, 0, 32, 13, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(70,30,90,0.9)'; ctx.beginPath(); ctx.ellipse(0, -5, 18, 7, 0, 0, TAU); ctx.fill();
              ctx.fillStyle = fall > 0 ? '#ff7a1a' : 'rgba(255,60,40,' + (0.5 + 0.4 * Math.sin(t * 0.2 + i)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(0, 4, 4, 0, TAU); ctx.fill(); ctx.restore();
          }
          hero(180, 392, 1.7, 1, t * 0.05, { x: 'awe', g: 'visor', brow: 0.6, mo: 0.15 });
      } },
    { sky: 5000, title: 'THE GOLDEN SOMBRERO', sfx: 2, text: 'The Golden Sombrero glides gently down. Our hero leaps, snatches it from the air, and the whole Fiesta Galaxy lights up in gold.',
      art(t) {
          const hy = 392, jt = clamp((t - 118) / 48, 0, 1), jump = Math.sin(jt * Math.PI) * 96, land = clamp((t - 166) / 30, 0, 1);
          const desc = 100 + Math.min(t, 143) * 0.8, hand = hy - jump - 100 - 8 * land;
          let sy = t < 118 ? desc : lerp2(desc, hand, ease((t - 118) / 26)); if (t > 166) sy = hy - 108 - ease(land) * 24 + Math.sin(t * 0.05) * 3;
          ctx.save(); ctx.translate(180, sy); ctx.rotate(t * 0.004); for (let k = 0; k < 16; k++) { ctx.rotate(TAU / 16); ctx.fillStyle = 'rgba(255,226,120,' + (0.12 + 0.12 * land) + ')'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(300, -10); ctx.lineTo(300, 10); ctx.fill(); } ctx.restore();
          drawGlow(180, sy, 120 + land * 70, '#ffd32a', 0.9); if (t > 143) for (let k = 0; k < 3; k++) csRing(180, sy, ((t - 143) * 5 + k * 40) % 220, 1 - (((t - 143) * 5 + k * 40) % 220) / 220, '#ffe48a', 3);
          drawSombrero(180, sy, 46, Math.sin(t * 0.03) * 0.12 * (1 - land), 4); csGround(400, '#5a2d48', '#7a3f5f');
          const squash = jt < 0.08 ? 1 - 0.1 * (jt / 0.08) : jt > 0.92 ? 0.9 + 0.1 * ((jt - 0.92) / 0.08) : 1;
          hero(180, hy, 1.9, 1, t < 118 ? 0 : t * 0.1, { x: jt > 0 && jt < 1 ? 'delight' : 'admiration', g: jt > 0 && jt < 1 ? 'cheer' : 'reach', jump, sy: squash, mo: jt > 0 && jt < 1 ? 0.6 : 0.25, brow: 0.5 });
          if (t > 166) csConfetti(t - 166, 30);
      } },
    { sky: 9000, title: 'THE LONG WAY DOWN', sfx: 3, text: 'Our hero hops on a passing cloud and rides it down through the storm, past the thunderheads, toward the tiny lights of home.',
      art(t) {
          const u = clamp(t / 280, 0, 1);
          for (let k = 0; k < 40; k++) { const x = (k * 53) % 360, y = 436 - (k % 5) * 9 * u; ctx.fillStyle = k % 2 ? 'rgba(255,211,42,' + (0.25 + 0.7 * u).toFixed(2) + ')' : 'rgba(255,177,66,' + (0.25 + 0.7 * u).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(x, y, 1 + 2.2 * u, 0, TAU); ctx.fill(); }
          drawGlow(180, 470, 80 + 240 * u, '#ffb142', 0.3 + 0.4 * u);
          for (let i = 0; i < 11; i++) { const y = 520 - ((i * 62 + t * 3.4) % 560), x = (i * 83) % 330; ctx.fillStyle = 'rgba(255,255,255,0.33)'; ctx.beginPath(); ctx.ellipse(x + 20, y, 54, 16, 0, 0, TAU); ctx.fill(); }
          ctx.strokeStyle = 'rgba(190,210,255,0.35)'; ctx.lineWidth = 1.2; for (let k = 0; k < 30; k++) { const x0 = (k * 41 + t * 4) % 380 - 10, y0 = 34 + (k * 77 + t * 16) % 420; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 - 7, y0 + 18); ctx.stroke(); }
          const lt = t % 115; if (lt < 14) { const bx = 70 + (Math.floor(t / 115) * 97) % 220; ctx.strokeStyle = 'rgba(255,255,255,' + (1 - lt / 14).toFixed(2) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(bx, 34); ctx.lineTo(bx - 18, 130); ctx.lineTo(bx + 10, 150); ctx.lineTo(bx - 14, 260); ctx.stroke(); csFlash(0.35 * (1 - lt / 14)); }
          const sw = Math.sin(t * 0.05);
          ctx.save(); ctx.translate(180 + sw * 22, 372 + Math.sin(t * 0.08) * 5); ctx.rotate(sw * 0.1);
          ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.beginPath(); ctx.ellipse(0, 0, 70, 20, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(-30, -12, 36, 22, 0, 0, TAU); ctx.fill(); ctx.restore();
          hero(180 + sw * 22, 350 + Math.sin(t * 0.08) * 5, 1.7, 1, t * 0.12, { x: t < 200 ? 'delight' : 'content', g: 'surf', tilt: sw * 0.12, mo: 0.4 + 0.3 * Math.sin(t * 0.2), brow: 0.4 });
      } },
    { sky: 3000, title: 'THE ROAD HOME', sfx: 4, text: 'Back on solid ground, the taco car is waiting. The hero hits the gas for one last cruise down the canyon road toward Valle Chiquito.',
      art(t) {
          csPursuit(t, { pal: 'dusk', speed: 2.3, shake: 0.25, lines: 0.2, village: true, sign: 2, car: { s: 1, y: 438, nitro: 0, spin: 3 } });
      } },
    { sky: 16000, title: 'THE PLAZA AWAKENS', sfx: 5, text: 'In the Plaza de los Piñatas the spirits have lost their curse. They rise from the stones, tip their marigold crowns, and rattle in rhythm.',
      art(t) {
          csStars(t); csGround(360, '#3a2a4a', '#4d3a62');
          for (let k = 0; k < 16; k++) { const x = (k * 47 + t * 0.5 + Math.sin(t * 0.03 + k) * 20) % 380, y = 40 + (t * 0.8 + k * 37) % 330; ctx.save(); ctx.translate(x, y); ctx.rotate(t * 0.04 + k); ctx.fillStyle = k % 2 ? '#ff9f1c' : '#ffd166'; ctx.beginPath(); ctx.ellipse(0, 0, 4, 2, 0, 0, TAU); ctx.fill(); ctx.restore(); }
          ctx.save(); ctx.beginPath(); ctx.rect(0, 34, W, 330); ctx.clip();
          for (let k = 0; k < 7; k++) { const rise = ease((t - k * 12) / 55), gx = 34 + k * 49, gy = 318 - (k % 3) * 10 - Math.sin(t * 0.04 + k) * 4 + (1 - rise) * 120; drawGhost(gx, gy, 1.05 + (k % 2) * 0.14, t, k, { alpha: rise * 0.92, look: (180 - gx) / 180, chat: 5, cheer: t > 100 + k * 6, tip: t > 70 }); }
          ctx.restore();
          csNotes(t);
          const hop = Math.abs(Math.sin(t * 0.12)) * 5; hero(180, 392, 1.6, 1, t * 0.6, { g: 'dance', jump: hop, tilt: Math.sin(t * 0.12) * 0.09, mo: 0.4 + 0.4 * Math.sin(t * 0.25), sx: 1 });
      } },
    { sky: 1500, title: 'ABUELA\'S CANTINA', text: 'Abuela throws open the cantina doors. Free tamales for everyone, and a toast to the hero. Nobody notices the candle by the window gutter, or the cold that slips in beside it.',
      art(t) {
          ctx.fillStyle = '#6b3d24'; ctx.fillRect(0, 34, W, 410); ctx.fillStyle = '#8a5a33'; for (let i = 0; i < 9; i++) ctx.fillRect(0, 70 + i * 44, W, 3);
          ctx.fillStyle = '#4a2814'; ctx.fillRect(0, 330, W, 114); ctx.fillStyle = '#a0703c'; ctx.fillRect(0, 322, W, 12);
          csLanterns(t, 60); drawGlow(180, 200, 160, '#ffb142', 0.35 * (1 - clamp((t - 60) / 200, 0, 0.5)));
          ctx.fillStyle = 'rgba(8,0,20,' + (clamp((t - 40) / 260, 0, 1) * 0.35).toFixed(2) + ')'; ctx.fillRect(0, 34, W, 410);
          drawVillager('abuela', 120, 336, 1.5, t, 3); drawVillager('kid', 260, 340, 1.4, t, 6);
          ctx.fillStyle = '#5fa04e'; ctx.beginPath(); ctx.ellipse(180, 316, 32, 12, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.ellipse(180, 322, 34, 10, 0, Math.PI, 0, true); ctx.fill();
          drawGhost(318, 150, 1.05, t, 4, { baron: true, alpha: clamp((t - 50) / 120, 0, 1) * (0.2 + 0.08 * Math.sin(t * 0.07)), col: '#ff7a6a', look: -1 });   // watching from the window
          hero(180, 290 + Math.sin(t * 0.06) * 2, 1.4, 1, 0, { g: 'clap', tilt: Math.sin(t * 0.05) * 0.07, mo: 0.4 + 0.4 * Math.abs(Math.sin(t * 0.2)), brow: 0.2 });
      } },
    { sky: 14000, title: 'THE BAND TUNES UP', text: 'Trumpets, guitars and one very enthusiastic accordion. The whole valley sings along, even the dead, who have so much to say tonight. The hero conducts. Nobody counts how many hands are clapping.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#3a2548', '#4d3262'); csHouses(t * 0.05, gy, true, t); csVillagers(t, gy); csNotes(t);
          ctx.fillStyle = 'rgba(30,0,40,' + (clamp(t / 320, 0, 1) * 0.28).toFixed(2) + ')'; ctx.fillRect(0, 34, W, 410);
          drawGlow(180, gy - 40, 100, '#ffd32a', 0.3);
          for (let k = 0; k < 5; k++) drawGhost(30 + k * 75, gy - 26 + Math.sin(t * 0.05 + k) * 6, 0.85, t, k + 7, { alpha: 0.18 + 0.2 * clamp((t - 40 - k * 20) / 120, 0, 1), cheer: true, chat: 6, col: '#bcd6ff' });
          drawGhost(332, 250, 0.7, t, 4, { baron: true, alpha: clamp((t - 120) / 160, 0, 0.55) * (0.65 + 0.35 * Math.sin(t * 0.1)), col: '#ff7a6a', look: -1 });
          hero(182, gy - 6, 1.8, 1, t * 0.7, { x: h3Dn(t * 0.7).li > 0.6 ? 'daydream' : 'gleeful', g: 'dance', tilt: Math.sin(t * 0.14) * 0.14, mo: 0.3 + 0.3 * Math.sin(t * 0.3), jump: Math.max(0, Math.sin(t * 0.14)) * 5 });
      } },
    { sky: t => 9000 + Math.min(t, 320) / 320 * 8000, title: 'THE LANTERNS GO OUT', text: 'The villagers hang every lantern back on its string. Then, one by one, the flames gutter and die. The music thins out. Somewhere, very close, someone is laughing.',
      art(t) {
          const gy = 388; csGround(gy, '#4a2640', '#643454'); csHouses(t * 0.05, gy, false, t);
          const fl = clamp(1 - (t - 40) / 240, 0, 1); ctx.save(); ctx.globalAlpha = fl * (t > 40 && t % 17 < 3 ? 0.4 : 1); csLanterns(t, 110); csLanterns(t + 20, 160); csLanterns(t + 40, 215); ctx.restore();
          ctx.fillStyle = 'rgba(10,0,24,' + (clamp((t - 30) / 260, 0, 1) * 0.62).toFixed(2) + ')'; ctx.fillRect(34, 34, W, 410);
          drawVillager('dancer', 60, gy + 30, 1.4, t * (1 - clamp((t - 120) / 80, 0, 1)), 5); drawVillager('guitar', 300, gy + 30, 1.3, t * (1 - clamp((t - 150) / 80, 0, 1)), 1);
          drawGhost(180, 120, 2.2, t, 4, { baron: true, alpha: clamp((t - 140) / 160, 0, 0.45), col: '#ff6a5a', chat: 3 });
          hero(180, gy - 4, 1.6, 1, 0, { x: t < 120 ? 'startled' : 'worried', g: 'point',  tilt: Math.sin(t * 0.03) * 0.04, mo: 0.1, brow: 1 });
      } },
    { sky: 21000, title: 'THE LAST BOTTLE', text: 'While the hero laughs, a shape leans over the toasting pitcher. A cold green wisp slides in. The Baron never wanted peace. If he cannot have the sombrero, he will have the valley.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#26142e', '#38204a'); csHouses(t * 0.01, gy, true, t);
          ctx.fillStyle = 'rgba(20,0,30,0.25)'; ctx.fillRect(0, 34, W, 410);
          ctx.fillStyle = '#6b3d24'; ctx.fillRect(100, gy - 20, 160, 10); ctx.fillRect(114, gy - 10, 8, 44); ctx.fillRect(238, gy - 10, 8, 44);
          for (let k = 0; k < 4; k++) { ctx.fillStyle = '#c9b27c'; ctx.fillRect(116 + k * 30 + (k > 1 ? 40 : 0), gy - 32, 10, 12); }
          ctx.fillStyle = '#d9a441'; roundRect(165, gy - 64, 30, 44, 6); ctx.fill(); ctx.fillStyle = '#b9822c'; ctx.fillRect(162, gy - 68, 36, 6);
          const lean = ease(clamp((t - 20) / 60, 0, 1));
          drawGhost(248 - lean * 52, gy - 122 + lean * 14, 1.7, t, 4, { baron: true, alpha: 0.88 * clamp(t / 40, 0, 1), col: '#ff7a6a', look: -1, chat: 6 });
          if (t > 70) { const u = clamp((t - 70) / 60, 0, 1); for (let k = 0; k < 14; k++) { const p = (t * 0.03 + k * 0.07) % 1; ctx.fillStyle = 'rgba(120,255,140,' + (0.85 * (1 - p) * u).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(196 - p * 28 + Math.sin(k * 3 + t * 0.2) * 4, gy - 100 + p * 38, 2.4, 0, TAU); ctx.fill(); }
              drawGlow(180, gy - 52, 60 + 20 * Math.sin(t * 0.2), '#7dff8a', 0.3 * u); }
          drawVillager('dancer', 300, gy + 34, 1.4, t, 5); drawVillager('kid', 345, gy + 38, 1.3, t, 2);
          hero(62, gy - 6, 1.6, 1, 0, { x: 'gleeful', g: 'laugh', mo: 0.8, brow: 0.2, tilt: Math.sin(t * 0.06) * 0.05 });
      } },
    { sky: 21000, title: 'THE TOAST', text: 'Abuela raises her cup. "To the hero!" they cry. The wine tastes of ash. One by one, the villagers lower their cups, and do not rise again.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#26142e', '#38204a'); csHouses(t * 0.02, gy, true, t);
          ctx.fillStyle = 'rgba(70,0,20,' + (clamp(t / 240, 0, 1) * 0.3).toFixed(2) + ')'; ctx.fillRect(0, 34, W, 410);
          const V = [['dancer', 40, 60], ['guitar', 105, 105], ['trumpet', 255, 150], ['kid', 310, 195], ['abuela', 150, 235]];
          V.forEach(([k, x, t0], n) => {
              const u = clamp((t - t0) / 36, 0, 1), dir = x < 180 ? -1 : 1, e = u * u;
              ctx.save(); ctx.translate(x, gy + 36 + (n % 2) * 4); ctx.rotate(dir * e * 1.5); ctx.translate(0, e * 6);
              drawVillager(k, 0, 0, 1.5, t0 > t ? t : t0, n + 2); ctx.restore();
              const gt = t - t0 - 34; if (gt > 0) drawGhost(x, gy - 10 - gt * 0.85, 1.1, t, n, { alpha: clamp(gt / 30, 0, 0.8) * (1 - clamp((gt - 160) / 60, 0, 1)), look: (180 - x) / 180, chat: 4, col: '#bcd6ff' });
              if (t > t0 && t < t0 + 20) csRing(x, gy, (t - t0) * 3, 1 - (t - t0) / 20, '#9fb8ff', 2);
          });
          drawGhost(180, 110 + Math.sin(t * 0.03) * 6, 2.6, t, 4, { baron: true, alpha: clamp((t - 30) / 100, 0, 0.85), col: '#ff7a6a', cheer: true, chat: 9 });
          const lean = clamp((t - 100) / 120, 0, 1); hero(182, gy - 6, 1.7, 1, 0, { x: lean > 0.5 ? 'anguish' : 'horror', g: 'clutch', tilt: -0.1 * lean, mo: 0.9 * lean, brow: 1, sy: 1 - 0.05 * lean });
      } },
    { sky: 21000, title: 'THE CHASE', text: 'The hero runs. Past the shuttered cantina, down the street where the lanterns lie broken. The laughter is always one step ahead, and it is wearing his own sombrero.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#1f1026', '#341a40'); csHouses(t * 1.8, gy, true, t);
          ctx.fillStyle = 'rgba(100,0,16,0.22)'; ctx.fillRect(0, 34, W, 410);
          ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 1.5; for (let k = 0; k < 12; k++) { const x0 = ((k * 97 - t * 9) % 420 + 420) % 420 - 20, y0 = 120 + (k * 53) % 230; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + 34, y0); ctx.stroke(); }
          const lt = t % 140; if (lt < 8) csFlash(0.35 * (1 - lt / 8));
          const gx = 285 + Math.sin(t * 0.07) * 22, gyy = gy - 100 + Math.sin(t * 0.12) * 14;
          for (let k = 1; k < 9; k++) { ctx.fillStyle = 'rgba(255,80,50,' + (0.3 * (1 - k / 9)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(gx + k * 16, gyy + 20 + Math.sin(k + t * 0.2) * 6, 10 - k, 0, TAU); ctx.fill(); }
          drawGhost(gx, gyy, 1.9, t, 4, { baron: true, alpha: 0.9, col: '#ff5a4a', cheer: true, chat: 10, look: -1 });
          drawSombrero(gx, gyy - 58, 22, 0.25 + Math.sin(t * 0.12) * 0.1, 4);
          hero(110, gy - 6 - Math.abs(Math.sin(t * 0.3)) * 12, 1.8, 1, t * 0.5, { x: 'panic', g: 'run', tilt: 0.2, mo: 0.9, brow: 1 });
      } },
    { sky: 21000, title: 'THE REVENGE', text: 'The Baron never fell. His anger just rose with the smoke. The spirits in the plaza were his all along, and the ones who loved the hero most are the first to be taken.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#1f1026', '#341a40'); csHouses(t * 0.01, gy, true, t);
          ctx.fillStyle = 'rgba(120,0,16,' + (0.18 + 0.1 * Math.sin(t * 0.04)).toFixed(2) + ')'; ctx.fillRect(0, 34, W, 410);
          const lt = t % 130; if (lt < 9) csFlash(0.4 * (1 - lt / 9));
          drawGlow(180, 140, 250, '#ff2200', 0.28 + 0.12 * Math.sin(t * 0.08));
          drawGhost(180, 130 + Math.sin(t * 0.02) * 6, 3.8, t, 4, { baron: true, alpha: 0.9, col: '#ff5a4a', cheer: true, chat: 12 });
          ctx.save(); ctx.beginPath(); ctx.rect(0, 34, W, 355); ctx.clip();
          for (let k = 0; k < 7; k++) { const a = t * 0.012 + k * TAU / 7, x = 180 + Math.cos(a) * (150 + k % 2 * 14), y = 250 + Math.sin(a) * 70 - 20 * Math.sin(t * 0.05 + k); drawGhost(x, y, 0.95, t, k, { alpha: 0.9, look: (180 - x) / 180, chat: 8, cheer: false, col: '#ff6a5a' }); }
          ctx.restore();
          [['abuela', 70, 80], ['kid', 290, 130]].forEach(([k, x, t0], n) => { const u = clamp((t - t0) / 30, 0, 1), dir = x < 180 ? -1 : 1; ctx.save(); ctx.translate(x, gy + 36); ctx.rotate(dir * u * u * 1.5); drawVillager(k, 0, 0, 1.5, Math.min(t, t0), n + 1); ctx.restore();
              const gt = t - t0 - 30; if (gt > 0) drawGhost(x, gy - 10 - gt * 0.8, 1.1, t, n + 3, { alpha: clamp(gt / 30, 0, 0.8), look: (180 - x) / 180, chat: 4, col: '#bcd6ff' }); });
          for (let k = 0; k < 14; k++) { const u = ((t * 0.01 + k * 0.071) % 1); ctx.fillStyle = 'rgba(255,120,50,' + (0.7 * (1 - u)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc((k * 61) % 360 + Math.sin(t * 0.05 + k) * 10, 380 - u * 330, 2, 0, TAU); ctx.fill(); }
          const sh = Math.sin(t * 0.6) * (t > 60 && t < 90 ? 3 : 0);
          hero(182 + sh, gy - 6, 1.7, 1, 0, { x: 'horror', g: 'cower',  tilt: 0.08 * Math.sin(t * 0.05), mo: 0.9, brow: 1 });
      } },
    { sky: 21000, title: 'THE OFFER', text: 'A white flame burns in the Baron\'s ghostly hands. "Let it turn your skin white," he whispers, "and every spirit is saved. Refuse, and they stay ghosts forever." The villagers kneel and beg the hero to say yes.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#1f1026', '#341a40'); csHouses(t * 0.005, gy, true, t);
          ctx.fillStyle = 'rgba(100,0,16,0.2)'; ctx.fillRect(0, 34, W, 410);
          const fl = 0.85 + 0.15 * Math.sin(t * 0.3);
          drawGhost(260, 150 + Math.sin(t * 0.03) * 6, 3.0, t, 4, { baron: true, alpha: 0.88, col: '#ff7a6a', look: -1, chat: 5 });
          drawGlow(212, 262, 120 * fl, '#ffffff', 0.85); drawGlow(212, 262, 40 * fl, '#ffffff', 1);
          ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.beginPath(); ctx.moveTo(212, 292); ctx.quadraticCurveTo(190, 262, 212, 226 - 8 * fl); ctx.quadraticCurveTo(234, 262, 212, 292); ctx.fill();
          ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(206, 270); ctx.lineTo(160, gy - 60); ctx.stroke();
          [[40, 0], [88, 1], [300, 2], [338, 3], [60, 4]].forEach(([x, n]) => { const yy = gy - 4 + (n % 2) * 14 + Math.sin(t * 0.04 + n) * 3; drawGhost(x, yy, 1.05, t, n, { alpha: 0.8, look: (150 - x) / 180, chat: 4, col: '#bcd6ff' }); });
          hero(150, gy - 6, 1.8, 1, 0, { x: 'cold', g: 'stoic',  mo: 0, brow: 0.3, tilt: Math.sin(t * 0.04) * 0.02 });
          if (t > 120) drawGlow(150, gy - 60, 70 * clamp((t - 120) / 80, 0, 1), '#ffffff', 0.25);
      } },
    { sky: 21000, title: 'THE REFUSAL', text: 'Hula Vaquero looks at the white flame and does not even blink. "No." A refused flame cannot be kept: it turns on its maker. The Baron\'s ghost shrieks and burns away to nothing. The hero laughs. "From the very first pop," he says. "I knew."',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#1f1026', '#341a40'); csHouses(t * 0.005, gy, true, t);
          ctx.fillStyle = 'rgba(100,0,16,0.2)'; ctx.fillRect(0, 34, W, 410);
          const flare = ease(clamp((t - 44) / 50, 0, 1)), b = clamp((t - 70) / 150, 0, 1), bx = 260 + Math.sin(t * 1.4) * 3 * b, by = 150;
          if (b < 1) {   // the refused flame swells and lashes back at the Baron
              const fl = (1 + flare * 1.2) * (0.9 + 0.1 * Math.sin(t * 0.4)); drawGlow(212, 262, 120 * fl + flare * 160, '#ffffff', 0.85 * (1 - b * 0.6)); drawGlow(212, 262, 40 * fl, '#ffffff', 1);
              ctx.fillStyle = 'rgba(255,255,255,' + (0.92 * (1 - b)).toFixed(2) + ')'; ctx.beginPath(); ctx.moveTo(212, 292); ctx.quadraticCurveTo(190 - 12 * flare, 262, 212, 226 - 30 * flare); ctx.quadraticCurveTo(234 + 12 * flare, 262, 212, 292); ctx.fill();
              if (flare > 0.1) { ctx.strokeStyle = 'rgba(255,255,255,' + (0.8 * flare * (1 - b)).toFixed(2) + ')'; ctx.lineWidth = 3 + 7 * flare; ctx.beginPath(); ctx.moveTo(212, 250); ctx.quadraticCurveTo(250, 200 + Math.sin(t * 0.3) * 10, bx, by + 40); ctx.stroke(); }
              if (t > 40 && t < 80) csRing(212, 262, (t - 40) * 6, 1 - (t - 40) / 40, '#ffffff', 3);
              drawGhost(bx, by + b * 14, 3.0 - 1.0 * b, t, 4, { baron: true, alpha: 0.88 * (1 - b * b), col: b > 0.15 ? '#ffffff' : '#ff7a6a', look: -1, cheer: false });
              if (b > 0.02) { ctx.save(); ctx.translate(bx, by - 10); ctx.globalAlpha = 0.9 * (1 - b); csCracks(70 * (1 - 0.3 * b), Math.min(1, b * 2.2), t); ctx.restore(); drawGlow(bx, by, 140 * (0.5 + b), '#ffffff', 0.5 * (1 - b)); }
          }
          for (let q = 0; q < 24; q++) { const u = clamp((t - 80 - q * 4) / 120, 0, 1); if (u <= 0 || u >= 1) continue; ctx.fillStyle = (q % 3 ? 'rgba(255,255,255,' : 'rgba(255,200,140,') + (0.9 * (1 - u)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(bx + Math.sin(q * 5) * 50 + Math.sin(t * 0.04 + q) * 10, by + 30 - u * 120 + (q % 5) * 6, 2, 0, TAU); ctx.fill(); }
          if (t > 212 && t < 232) csFlash(0.3 * (1 - (t - 212) / 20));
          [[40, 0], [88, 1], [300, 2], [338, 3], [60, 4]].forEach(([x, n]) => { const sag = clamp((t - 215) / 120, 0, 1), yy = gy - 4 + (n % 2) * 14 + sag * 16 + Math.sin(t * 0.05 + n) * 3; drawGhost(x, yy, 1.05, t, n, { alpha: 0.8 - 0.15 * sag, look: 0, chat: 5, col: '#bcd6ff' }); });
          const lh = Math.sin(t * 0.55) * 0.5 + 0.5, k = clamp((t - 200) / 30, 0, 1);
          hero(176 + Math.sin(t * 0.8) * 1.5 * k, gy - 6 - lh * 5 * k, 1.9, 1, 0, { x: k > 0.3 ? 'laugh' : 'cold', g: 'crossed', mo: 0.2, brow: 0, tilt: -0.16 * k + Math.sin(t * 0.55) * 0.04 * k, sy: 1 + 0.03 * lh * k });
          if (t > 205) for (let q = 0; q < 3; q++) { const u = ((t * 0.05 + q * 0.33) % 1); ctx.fillStyle = 'rgba(255,255,255,' + (0.9 * (1 - u)).toFixed(2) + ')'; ctx.font = 'bold ' + (16 + q * 3) + 'px system-ui, sans-serif'; ctx.fillText(q % 2 ? 'HA!' : 'ha', 198 + q * 22 + Math.sin(t * 0.2 + q) * 4, gy - 150 - u * 50); }
      } },
    { sky: 1500, title: 'THE LEDGER', text: 'The night he rode out to fight the Baron, the hero found an old book in Abuela\'s cellar. A balloon never stays dead, it said. He rises again as a ghost, offers the one who beat him a white flame, and a refused flame returns to its maker.',
      art(t) {
          ctx.fillStyle = '#3a2314'; ctx.fillRect(0, 34, W, 410); ctx.fillStyle = '#4a2e1a'; for (let i = 0; i < 9; i++) ctx.fillRect(0, 70 + i * 44, W, 3);
          for (let r = 0; r < 2; r++) { ctx.fillStyle = '#5a3a20'; ctx.fillRect(10, 110 + r * 90, W - 20, 6); for (let k = 0; k < 7; k++) { ctx.fillStyle = ['#6b8e4e', '#a0522d', '#8a6a9a', '#c9a24b'][(k + r) % 4]; roundRect(24 + k * 48, 74 + r * 90, 22, 36, 5); ctx.fill(); } }
          ctx.fillStyle = '#2a170c'; ctx.fillRect(0, 330, W, 114);
          ctx.fillStyle = '#6a4326'; ctx.fillRect(190, 318, 160, 14); ctx.fillRect(200, 330, 10, 60); ctx.fillRect(330, 330, 10, 60);
          const fl = 0.8 + 0.2 * Math.sin(t * 0.3) + 0.08 * Math.sin(t * 0.77); drawGlow(300, 290, 170 * fl, '#ffb142', 0.7);
          ctx.fillStyle = '#e6d9b8'; ctx.beginPath(); ctx.moveTo(214, 316); ctx.lineTo(260, 304); ctx.lineTo(260, 290); ctx.lineTo(214, 300); ctx.fill(); ctx.beginPath(); ctx.moveTo(262, 304); ctx.lineTo(308, 316); ctx.lineTo(308, 300); ctx.lineTo(262, 290); ctx.fill();   // the open book
          ctx.strokeStyle = '#7a5a30'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(236, 304, 8, 0, TAU); ctx.moveTo(231, 308); ctx.quadraticCurveTo(236, 311, 241, 308); ctx.stroke();   // doodled balloon
          ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.beginPath(); ctx.moveTo(286, 308); ctx.quadraticCurveTo(278, 298, 286, 288); ctx.quadraticCurveTo(294, 298, 286, 308); ctx.fill();   // doodled white flame
          ctx.fillStyle = '#d9c9a0'; roundRect(318, 296, 10, 22, 2); ctx.fill(); ctx.fillStyle = '#ffe9a0'; ctx.beginPath(); ctx.ellipse(323, 291, 3, 6 * fl, 0, 0, TAU); ctx.fill();
          hero(120, 392, 1.8, 1, 0, { x: 'concentrating', g: 'hold',  tilt: 0.1, mo: 0.3, brow: 0, jump: 0 });
          ctx.fillStyle = 'rgba(110,70,25,0.3)'; ctx.fillRect(0, 34, W, 410);
          for (let e = 0; e < 8; e++) { ctx.fillStyle = 'rgba(0,0,0,' + (0.07 * (8 - e)).toFixed(2) + ')'; ctx.fillRect(0, 34 + e * 8, W, 8); ctx.fillRect(0, 440 - e * 8, W, 8); ctx.fillRect(e * 8, 34, 8, 410); ctx.fillRect(W - e * 8 - 8, 34, 8, 410); }
          for (let k = 0; k < 14; k++) { const r = csRnd(Math.floor(t / 4) * 31 + k * 7); ctx.fillStyle = 'rgba(255,240,210,0.3)'; ctx.fillRect(r * W, 34 + csRnd(k + Math.floor(t / 4)) * 410, 1, 3 + r * 10); }
          ctx.fillStyle = 'rgba(255,230,180,' + (0.85 * clamp(t / 20, 0, 1) * (1 - clamp((t - 130) / 40, 0, 1))).toFixed(2) + ')'; ctx.font = '800 12px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('THE NIGHT HE LEFT', 180, 60); ctx.textAlign = 'left';
      } },
    { sky: 21000, title: 'THE PROMISE', text: 'The night he rode out to challenge the Baron, he made the village promise one thing: when he came home, they would throw a fiesta, and every single one of them would be in the plaza. Bait works best when it is alive.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#26142e', '#38204a'); csHouses(t * 0.004, gy, true, t);
          drawGlow(300, gy - 40, 120, '#ffb142', 0.25);
          drawVillager('abuela', 54, gy + 34, 1.5, t, 3); drawVillager('kid', 108, gy + 38, 1.3, t, 6); drawVillager('dancer', 30, gy + 40, 1.3, t, 5); drawVillager('guitar', 80, gy + 42, 1.3, t, 1);
          const nod = (t > 150 ? Math.max(0, Math.sin((t - 150) * 0.25)) : 0) * 3;
          drawTacoCar(290, gy - 18, 1.9, {}); drawSombrero(290, gy - 30, 12, 0, 4);
          hero(190, gy - 6, 1.8, 1, 0, { x: t < 420 ? 'resolve' : 'sly', g: 'oath',  mo: 0.3, brow: 0.4, tilt: -0.03 });
          ctx.fillStyle = 'rgba(110,70,25,0.28)'; ctx.fillRect(0, 34, W, 410);
          for (let e = 0; e < 8; e++) { ctx.fillStyle = 'rgba(0,0,0,' + (0.07 * (8 - e)).toFixed(2) + ')'; ctx.fillRect(0, 34 + e * 8, W, 8); ctx.fillRect(0, 440 - e * 8, W, 8); ctx.fillRect(e * 8, 34, 8, 410); ctx.fillRect(W - e * 8 - 8, 34, 8, 410); }
          for (let k = 0; k < 14; k++) { const r = csRnd(Math.floor(t / 4) * 31 + k * 7); ctx.fillStyle = 'rgba(255,240,210,0.3)'; ctx.fillRect(r * W, 34 + csRnd(k + Math.floor(t / 4)) * 410, 1, 3 + r * 10); }
          ctx.fillStyle = 'rgba(255,230,180,' + (0.85 * clamp(t / 20, 0, 1) * (1 - clamp((t - 130) / 40, 0, 1))).toFixed(2) + ')'; ctx.font = '800 12px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('THE NIGHT HE LEFT', 180, 60); ctx.textAlign = 'left';
      } },
    { sky: 21000, title: 'THE LAUGH', text: 'He laughs, and the plaza has no one left to laugh back. It was never about the village. He never cared about it, and he is glad they are gone.',
      art(t) {
          t += 240;
          const gy = 388; csStars(t); csGround(gy, '#1f1026', '#341a40'); csHouses(t * 0.005, gy, true, t);
          ctx.fillStyle = 'rgba(100,0,16,0.2)'; ctx.fillRect(0, 34, W, 410);
          const flare = ease(clamp((t - 44) / 50, 0, 1)), b = clamp((t - 70) / 150, 0, 1), bx = 260 + Math.sin(t * 1.4) * 3 * b, by = 150;
          if (b < 1) {   // the refused flame swells and lashes back at the Baron
              const fl = (1 + flare * 1.2) * (0.9 + 0.1 * Math.sin(t * 0.4)); drawGlow(212, 262, 120 * fl + flare * 160, '#ffffff', 0.85 * (1 - b * 0.6)); drawGlow(212, 262, 40 * fl, '#ffffff', 1);
              ctx.fillStyle = 'rgba(255,255,255,' + (0.92 * (1 - b)).toFixed(2) + ')'; ctx.beginPath(); ctx.moveTo(212, 292); ctx.quadraticCurveTo(190 - 12 * flare, 262, 212, 226 - 30 * flare); ctx.quadraticCurveTo(234 + 12 * flare, 262, 212, 292); ctx.fill();
              if (flare > 0.1) { ctx.strokeStyle = 'rgba(255,255,255,' + (0.8 * flare * (1 - b)).toFixed(2) + ')'; ctx.lineWidth = 3 + 7 * flare; ctx.beginPath(); ctx.moveTo(212, 250); ctx.quadraticCurveTo(250, 200 + Math.sin(t * 0.3) * 10, bx, by + 40); ctx.stroke(); }
              if (t > 40 && t < 80) csRing(212, 262, (t - 40) * 6, 1 - (t - 40) / 40, '#ffffff', 3);
              drawGhost(bx, by + b * 14, 3.0 - 1.0 * b, t, 4, { baron: true, alpha: 0.88 * (1 - b * b), col: b > 0.15 ? '#ffffff' : '#ff7a6a', look: -1, cheer: false });
              if (b > 0.02) { ctx.save(); ctx.translate(bx, by - 10); ctx.globalAlpha = 0.9 * (1 - b); csCracks(70 * (1 - 0.3 * b), Math.min(1, b * 2.2), t); ctx.restore(); drawGlow(bx, by, 140 * (0.5 + b), '#ffffff', 0.5 * (1 - b)); }
          }
          for (let q = 0; q < 24; q++) { const u = clamp((t - 80 - q * 4) / 120, 0, 1); if (u <= 0 || u >= 1) continue; ctx.fillStyle = (q % 3 ? 'rgba(255,255,255,' : 'rgba(255,200,140,') + (0.9 * (1 - u)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(bx + Math.sin(q * 5) * 50 + Math.sin(t * 0.04 + q) * 10, by + 30 - u * 120 + (q % 5) * 6, 2, 0, TAU); ctx.fill(); }
          if (t > 212 && t < 232) csFlash(0.3 * (1 - (t - 212) / 20));
          [[40, 0], [88, 1], [300, 2], [338, 3], [60, 4]].forEach(([x, n]) => { const sag = clamp((t - 215) / 120, 0, 1), yy = gy - 4 + (n % 2) * 14 + sag * 16 + Math.sin(t * 0.05 + n) * 3; drawGhost(x, yy, 1.05, t, n, { alpha: 0.8 - 0.15 * sag, look: 0, chat: 5, col: '#bcd6ff' }); });
          const lh = Math.sin(t * 0.55) * 0.5 + 0.5, k = clamp((t - 200) / 30, 0, 1);
          hero(176, gy - 6, 1.9, 1, 0, { x: 'hysterical', g: 'laugh', mo: 0.2, brow: 0, tilt: -0.12 * k });
          if (t > 205) for (let q = 0; q < 3; q++) { const u = ((t * 0.05 + q * 0.33) % 1); ctx.fillStyle = 'rgba(255,255,255,' + (0.9 * (1 - u)).toFixed(2) + ')'; ctx.font = 'bold ' + (16 + q * 3) + 'px system-ui, sans-serif'; ctx.fillText(q % 2 ? 'HA!' : 'ha', 198 + q * 22 + Math.sin(t * 0.2 + q) * 4, gy - 150 - u * 50); }
      } },
    { sky: 1500, title: 'THE PLUNDER', text: 'While Abuela\'s spirit wails, the hero empties the cantina till, pockets the tips, and kicks the guacamole across the floor. Free tamales for the hero. Nothing for anyone else, ever again.',
      art(t) {
          ctx.fillStyle = '#4b2a18'; ctx.fillRect(0, 34, W, 410); ctx.fillStyle = '#5e3820'; for (let i = 0; i < 9; i++) ctx.fillRect(0, 70 + i * 44, W, 3);
          ctx.fillStyle = '#2f180c'; ctx.fillRect(0, 330, W, 114); ctx.fillStyle = '#6e4626'; ctx.fillRect(0, 322, W, 12);
          for (let k = 0; k < 6; k++) { ctx.fillStyle = k % 2 ? '#2e7d4f' : '#a0522d'; roundRect(28 + k * 58, 130, 14, 34, 4); ctx.fill(); }   // shelf of bottles
          ctx.fillStyle = '#6e4626'; ctx.fillRect(10, 166, W - 20, 6);
          ctx.fillStyle = 'rgba(8,0,16,0.45)'; ctx.fillRect(0, 34, W, 410);
          ctx.fillStyle = '#7a5230'; ctx.fillRect(220, 296, 120, 34); ctx.fillStyle = '#c9a24b'; roundRect(250, 268, 56, 30, 4); ctx.fill(); ctx.fillStyle = '#7a5a18'; ctx.fillRect(250, 276, 56, 4);
          for (let k = 0; k < 14; k++) { const u = ((t * 0.018 + k / 14) % 1), x = 278 + (150 - 278) * u, y = 270 - Math.sin(u * Math.PI) * 90 + u * 90; ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.ellipse(x, y, 5, 5 * Math.abs(Math.cos(t * 0.2 + k)) + 1, 0, 0, TAU); ctx.fill(); }
          const kick = clamp((t - 20) / 40, 0, 1); ctx.fillStyle = '#5fa04e'; ctx.beginPath(); ctx.ellipse(70 + kick * 40, 378 - Math.sin(kick * Math.PI) * 40, 30 - kick * 6, 11, kick * 6, 0, TAU); ctx.fill();
          if (kick >= 1) { ctx.fillStyle = 'rgba(95,160,78,0.9)'; ctx.beginPath(); ctx.ellipse(130, 392, 44, 7, 0, 0, TAU); ctx.fill(); }
          const pile = 8 + Math.min(t, 300) * 0.07; ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.ellipse(120, 400, pile, pile * 0.3, 0, Math.PI, 0); ctx.fill(); drawGlow(120, 396, pile * 2.4, '#ffd32a', 0.4);
          drawGhost(70, 250 + Math.sin(t * 0.06) * 8, 1.7, t, 3, { who: 'abuela', alpha: 0.85, col: '#bcd6ff', chat: 9, look: 1 });
          hero(185, 392, 1.8, 1, 0, { x: 'greedy', g: 'grab', mo: 0.9, brow: 0, tilt: Math.sin(t * 0.15) * 0.04, jump: Math.max(0, Math.sin(t * 0.15)) * 4 });
      } },
    { sky: 21000, title: 'THE PORTRAIT', text: 'He rips down the fiesta banners, the lanterns, and the names of the dead, and hangs a giant portrait of himself in their place. The ghosts are told to hold the ropes.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#1f1026', '#341a40'); csHouses(t * 0.004, gy, true, t);
          ctx.fillStyle = 'rgba(40,0,20,0.3)'; ctx.fillRect(0, 34, W, 410);
          for (let k = 0; k < 12; k++) { const u = (t * 0.006 + k * 0.083) % 1; ctx.save(); ctx.translate((k * 71) % 360 + Math.sin(t * 0.03 + k) * 20, 40 + u * 340); ctx.rotate(t * 0.04 + k); ctx.fillStyle = ['#e63946', '#ffd32a', '#2ec4b6', '#ff70a6'][k % 4]; ctx.fillRect(-9, -3, 18, 6); ctx.restore(); }   // torn banners
          const drop = ease(clamp(t / 110, 0, 1)), py = -260 + drop * 260 + Math.sin(t * 0.04) * 2;
          ctx.save(); ctx.translate(0, py); ctx.strokeStyle = '#c9a56a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(60, 100); ctx.lineTo(115, 70); ctx.moveTo(300, 100); ctx.lineTo(245, 70); ctx.stroke();
          ctx.fillStyle = '#d4a017'; roundRect(100, 66, 160, 210, 8); ctx.fill(); ctx.fillStyle = '#2a0f3a'; ctx.fillRect(112, 78, 136, 186);
          ctx.save(); ctx.beginPath(); ctx.rect(112, 78, 136, 186); ctx.clip(); drawGlow(180, 170, 120, '#ff4a2a', 0.45); hero(180, 262, 2.2, 1, 0, { x: 'sneer', g: 'power', mo: 0.9, brow: 0 }); ctx.restore(); ctx.restore();
          drawGhost(40, 110 + py * 0.2, 1.2, t, 1, { alpha: 0.8, col: '#bcd6ff', look: 1, chat: 3 }); drawGhost(322, 110 + py * 0.2, 1.2, t, 2, { alpha: 0.8, col: '#bcd6ff', look: -1, chat: 3 });
          ctx.strokeStyle = '#c9a56a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(52, 118 + py * 0.2); ctx.lineTo(115, 70 + py); ctx.moveTo(310, 118 + py * 0.2); ctx.lineTo(245, 70 + py); ctx.stroke();
          hero(100, gy - 6, 1.7, 1, 0, { x: 'haughty', g: 'crossed', mo: 0.7, brow: 0, tilt: -0.05 + Math.sin(t * 0.05) * 0.03 });
      } },
    { sky: 21000, title: 'THE CROWNING', text: 'He climbs the pedestal where the Golden Sombrero used to shine and sits down on it like a throne. The ghosts bow. There is no Baron left to bow to, so they bow to him.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#16091c', '#26112c'); csHouses(t * 0.003, gy, true, t);
          ctx.fillStyle = 'rgba(70,0,20,0.28)'; ctx.fillRect(0, 34, W, 410);
          ctx.save(); ctx.translate(180, gy - 124); for (let k = 0; k < 12; k++) { ctx.rotate(TAU / 12); ctx.fillStyle = 'rgba(255,226,120,0.07)'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(300, -10); ctx.lineTo(300, 10); ctx.fill(); } ctx.restore();
          ctx.fillStyle = '#6a5a4c'; for (let k = 0; k < 3; k++) { ctx.fillRect(110 - k * 20, gy - 20 * (k + 1) + 20, 140 + k * 40, 20); } ctx.fillStyle = '#857463'; ctx.fillRect(120, gy - 74, 120, 14);
          const b = clamp(t / 90, 0, 1) * 0.6;
          [[34, 0], [86, 1], [274, 0], [326, 1]].forEach(([x, n], q) => { ctx.save(); ctx.translate(x, gy + 6 + n * 14); ctx.rotate((x < 180 ? 1 : -1) * b); drawGhost(0, 0, 1.15, t, q, { alpha: 0.85, col: '#bcd6ff', chat: 0 }); ctx.restore(); });
          drawGlow(180, gy - 150, 90, '#ffd32a', 0.55); hero(180, gy - 74, 1.7, 1, t * 0.05, { x: 'haughty', g: 'triumph',  sy: 0.92, mo: 0.8, brow: 0, tilt: Math.sin(t * 0.04) * 0.03 });
          const lift = ease(clamp((t - 90) / 70, 0, 1)); drawSombrero(180, (gy - 260) + lift * 98, 30, 0, 4);
      } },
    { sky: 21000, title: 'THE REHEARSAL', text: 'Every night the ghosts cheer on his signal, in perfect time, forever. Any that cheer late are ground to dust. He is adored at last, and he has made sure of it.',
      art(t) {
          const gy = 388; csStars(t); csGround(gy, '#16091c', '#26112c'); csHouses(t * 0.003, gy, true, t);
          ctx.fillStyle = 'rgba(70,0,20,0.28)'; ctx.fillRect(0, 34, W, 410);
          const beat = (t % 40) < 20;
          for (let r = 0; r < 2; r++) for (let k = 0; k < 8; k++) {
              const x = 24 + k * 44 + (r ? 22 : 0), y = r ? 300 : 244, id = r * 8 + k, bad = id === 5, d = bad ? clamp((t - 130) / 70, 0, 1) : 0;
              if (d >= 1) continue;
              drawGhost(x, y + Math.sin(t * 0.05 + k) * 3 + d * 20, r ? 0.9 : 0.75, t, id, { alpha: 0.85 * (1 - d), col: bad && t > 120 ? '#ff9a8a' : '#bcd6ff', cheer: bad && t < 120 ? !beat : beat, chat: 0 });
              if (bad && d > 0) for (let q = 0; q < 6; q++) { ctx.fillStyle = 'rgba(220,230,255,' + (0.8 * (1 - d)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(x + Math.sin(q * 3) * 14, y - d * 60 + q * 5, 2, 0, TAU); ctx.fill(); }
          }
          if (t > 125 && t < 140) csRing(180, gy - 60, (t - 125) * 4, 1 - (t - 125) / 15, '#ff7a6a', 3);
          const st = t % 40; hero(180, gy - 6, 1.9, 1, t * 0.2, { x: 'manic', g: 'cheer', hoop: true, mo: 0.9, brow: 0, jump: st < 6 ? Math.sin(st / 6 * Math.PI) * 8 : 0, tilt: Math.sin(t * 0.1) * 0.05 });
          if (beat && st < 4) csFlash(0.06);
      } },
    { sky: 22000, title: 'THE WHY', text: 'The smallest spirit finds the courage to ask him why. He sits on the ledge, still smiling, and the smoke loosens something underneath.', art(t) { csWhy(t, 1); } },
    { sky: 22000, title: 'THE TANGENT', text: 'The smoke carries him far from the question. He talks to the stars, to his own hand, and to the voices he swears are whispering. Then he reaches into his pocket.', art(t) { csWhy(t, 2); } },
    { sky: 22000, title: 'THE STASH', text: 'A baggie, a rolled bill, one hard snort. The whispers swell into a chant, and the only thing they are cheering for is the hat.', art(t) { csWhy(t, 2); } },
    { sky: 22000, title: 'THE BREAKING', wired: true, text: 'Wired and wide awake, he finally says the quiet part out loud. The smallest spirit only needs one sentence to break him.', art(t) { csWhy(t, 3); } },
    { sky: 22000, title: 'THE FIESTA NEVER ENDS', text: 'Years pass. The Fiesta del Sol has never once stopped, and no one is allowed to leave. Hula Vaquero is the most loved man in the valley, because there is no one left who can say otherwise. THE END.',
      art(t) {
          const gy = 388; csStars(t); ctx.fillStyle = 'rgba(' + 90 + ',0,16,0.3)'; ctx.fillRect(0, 34, W, 410);
          const sq = 38 + 6 * Math.sin(t * 0.05); drawGlow(180, 120, 260, '#ff3a1a', 0.35);
          for (let w = 0; w < 3; w++) { ctx.strokeStyle = ['rgba(255,60,30,0.9)', 'rgba(255,180,60,0.7)', 'rgba(255,255,255,0.4)'][w]; ctx.lineWidth = 11 - w * 4; ctx.beginPath(); ctx.ellipse(180, 120, 150, sq, Math.sin(t * 0.008) * 0.12, 0, TAU); ctx.stroke(); }
          for (let q = 0; q < 8; q++) { const a = t * 0.03 + q * TAU / 8; ctx.fillStyle = '#fff2b0'; ctx.beginPath(); ctx.arc(180 + Math.cos(a) * 150, 120 + Math.sin(a) * sq, 3.5, 0, TAU); ctx.fill(); }
          csGround(gy, '#1a0c22', '#2e1638'); csHouses(t * 0.004, gy, true, t); ctx.save(); ctx.globalAlpha = 0.8; csLanterns(t, 190); ctx.restore();
          for (let r = 0; r < 2; r++) for (let k = 0; k < 8; k++) drawGhost(20 + k * 46 + (r ? 23 : 0), (r ? 340 : 296) + Math.sin(t * 0.09 + k) * 5, r ? 0.95 : 0.8, t, r * 8 + k, { alpha: 0.7, cheer: ((t + k * 3) % 36) < 18, col: '#bcd6ff', chat: 0 });
          ctx.fillStyle = '#857463'; ctx.fillRect(140, gy - 56, 80, 14); ctx.fillStyle = '#6a5a4c'; ctx.fillRect(150, gy - 42, 60, 44);
          hero(180, gy - 56, 1.6, 1, t * 0.25, { x: 'bliss', g: 'power', hoop: true, mo: 1, brow: 0, tilt: Math.sin(t * 0.09) * 0.05 }); drawSombrero(180, gy - 56 - 64, 24, Math.sin(t * 0.09) * 0.05, 4); csConfetti(t, 40);
      } },
];