

// =====================================================================
//  OPENING CUTSCENE + "ANDALE!"
// =====================================================================
let cs = null;
const CPS = 0.55;   // typed characters per frame
const fakeBall = (x, y, r, color, hat, ex) => Object.assign({ type: SHIP_OF_COL[color] || 'basic', x, y, r, color, hat, vx: 0, phase: 0, flash: 0, burnT: 0, slowT: 0, shieldHp: 0, armored: false, elite: false, boss: false, hp: 1, maxHp: 1, nobar: true }, ex || {});
const BALLCOLS = ['#ff6b6b', '#4ecdc4', '#ffe66d', '#a29bfe', '#ff9ff3'];
// ---------- opening-cutscene cast: villagers made just for the intro ----------
function vHead(x, y, r, skin, t, seed, sing, blind) {
    ctx.fillStyle = rg(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r * 1.2, [[0, shade(skin, 0.28)], [1, skin]]);
    ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    const blink = ((Math.floor(t) + seed * 37) % 160) < 5;
    if (!blind) for (const sx of [-1, 1]) {
        const ex = x + sx * r * 0.38, ey = y - r * 0.08;
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.ellipse(ex, ey, r * 0.2, blink ? r * 0.04 : r * 0.24, 0, 0, TAU); ctx.fill();
        if (!blink) { ctx.fillStyle = '#2b1a10'; ctx.beginPath(); ctx.arc(ex, ey + r * 0.02, r * 0.12, 0, TAU); ctx.fill(); }
        ctx.strokeStyle = '#1a0f0a'; ctx.lineWidth = Math.max(0.5, r * 0.08); ctx.beginPath(); ctx.moveTo(ex - r * 0.22, ey - r * 0.3); ctx.lineTo(ex + r * 0.22, ey - r * 0.34); ctx.stroke();
    }
    ctx.fillStyle = 'rgba(70,35,18,0.35)'; ctx.beginPath(); ctx.ellipse(x, y + r * 0.2, r * 0.1, r * 0.13, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(230,90,80,0.3)'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.ellipse(x + sx * r * 0.58, y + r * 0.28, r * 0.17, r * 0.11, 0, 0, TAU); ctx.fill(); }
    if (sing) { ctx.fillStyle = '#4a1612'; ctx.beginPath(); ctx.ellipse(x, y + r * 0.58, r * 0.2, r * (0.1 + 0.12 * Math.abs(Math.sin(t * 0.25 + seed))), 0, 0, TAU); ctx.fill(); }
    else { ctx.strokeStyle = '#6a2a20'; ctx.lineWidth = Math.max(0.5, r * 0.08); ctx.beginPath(); ctx.arc(x, y + r * 0.3, r * 0.3, 0.3, Math.PI - 0.3); ctx.stroke(); }
}
function vArm(x0, y0, x1, y1, col, hand) {
    ctx.lineCap = 'round'; ctx.strokeStyle = col; ctx.lineWidth = 3.6; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    ctx.fillStyle = hand; ctx.beginPath(); ctx.arc(x1, y1, 2.2, 0, TAU); ctx.fill();
}
function charroSuit(col, trim, bow) {
    ctx.fillStyle = col; ctx.fillRect(-6.5, -24, 5.4, 22); ctx.fillRect(1.1, -24, 5.4, 22);
    ctx.fillStyle = trim; ctx.fillRect(-6.5, -24, 1, 22); ctx.fillRect(5.5, -24, 1, 22);
    ctx.fillStyle = '#1a1210'; roundRect(-8, -3.5, 7.6, 4.5, 1.5); ctx.fill(); roundRect(0.4, -3.5, 7.6, 4.5, 1.5); ctx.fill();
    ctx.fillStyle = lg(-9, -44, 9, -22, [[0, shade(col, 0.2)], [1, shade(col, -0.25)]]);
    ctx.beginPath(); ctx.moveTo(-5, -44); ctx.lineTo(5, -44); ctx.lineTo(9.5, -22); ctx.lineTo(-9.5, -22); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#f4f0e6'; ctx.beginPath(); ctx.moveTo(-3, -44); ctx.lineTo(3, -44); ctx.lineTo(0, -31); ctx.closePath(); ctx.fill();
    ctx.fillStyle = trim; for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.arc(0, -29 + k * 2.2, 0.8, 0, TAU); ctx.fill(); }
    ctx.fillStyle = bow; ctx.beginPath(); ctx.moveTo(0, -42.5); ctx.lineTo(-3.6, -45); ctx.lineTo(-3.6, -40); ctx.closePath(); ctx.moveTo(0, -42.5); ctx.lineTo(3.6, -45); ctx.lineTo(3.6, -40); ctx.closePath(); ctx.fill();
}
// ---------- shared 2D humanoid rig ----------
// Every walking NPC is a parameter set on this one body: hip joints that sway with the weight shift, two-bone IK legs and arms with real knees and elbows,
// planted or tapping feet, and a torso/costume callback that rides on the pelvis. Costume = data (colours, widths, hem height), motion = the same for all.
function ik2d(ax, ay, bx, by, l1, l2, side) {
    let dx = bx - ax, dy = by - ay, d = Math.hypot(dx, dy) || 1e-3; const mx = l1 + l2 - 0.02; if (d > mx) { dx *= mx / d; dy *= mx / d; d = mx; }
    const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d), h = Math.sqrt(Math.max(0, l1 * l1 - a * a)), ux = dx / d, uy = dy / d;
    return [ax, ay, ax + ux * a - uy * h * side, ay + uy * a + ux * h * side, ax + dx, ay + dy];
}
function limb2d(p, w1, w2, col, col2) {
    ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = col;
    ctx.lineWidth = w1; ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(p[2], p[3]); ctx.stroke();
    if (col2) ctx.strokeStyle = col2;
    ctx.lineWidth = w2; ctx.beginPath(); ctx.moveTo(p[2], p[3]); ctx.lineTo(p[4], p[5]); ctx.stroke();
}
function villagerRig(o) {
    const ph = o.ph, t = o.t, seed = o.seed, hw = o.hw, L = o.leg, hy = o.hipY, sw = Math.sin(ph) * (o.sway == null ? 1.1 : o.sway), dip = Math.abs(Math.sin(ph)) * 0.5, tx = sw * 0.7, ty = dip * 0.8;
    const hip = [sw, hy + dip];
    for (const sx of [-1, 1]) {   // legs: planted wide, one foot taps on the beat, or alternate small steps when o.step is set
        const tap = o.tap && sx < 0 ? Math.max(0, Math.sin(t * 0.18 + seed * 1.7)) * 2.4 : 0, stp = o.step ? Math.max(0, Math.sin(ph * 2 + (sx > 0 ? Math.PI : 0))) * o.step : 0;
        const lift = tap + stp, fx = sx * (hw + (o.stance || 1.4)) + (stp ? Math.sin(ph) * -0.6 * sx : 0), fy = -1.6 - lift;
        const hp = [hip[0] + sx * hw, hip[1]], p = ik2d(hp[0], hp[1], fx, fy, L, L, -sx);
        limb2d(p, o.lw, o.lw * 0.86, o.legCol, o.shinCol);
        if (o.trim) { ctx.strokeStyle = o.trim; ctx.lineWidth = 0.9; const k = sx * o.lw * 0.3; ctx.beginPath(); ctx.moveTo(p[0] * 0 + hp[0] + k, hp[1]); ctx.lineTo(p[2] + k, p[3]); ctx.lineTo(p[4] + k * 0.8, p[5]); ctx.stroke(); }
        ctx.fillStyle = o.shoe; roundRect(p[4] - 3.9 + sx * 0.9, p[5] - 1.6, 7.8, 4.4, 1.6); ctx.fill();
    }
    ctx.save(); ctx.translate(tx, ty); ctx.rotate(sw * 0.012); o.torso(); ctx.restore();
    [-1, 1].forEach((sx, i) => {   // arms ride on the shoulders; hands are targets given in figure space
        const sh = [sx * o.shW + tx, o.shY + ty], h = o.hands[i], p = ik2d(sh[0], sh[1], h[0], h[1], o.arm, o.arm, -sx);
        limb2d(p, o.aw, o.aw * 0.88, o.armCol);
        ctx.fillStyle = o.armCol; ctx.beginPath(); ctx.arc(sh[0], sh[1], o.aw * 0.55, 0, TAU); ctx.fill();
        ctx.fillStyle = o.hand; ctx.beginPath(); ctx.arc(p[4], p[5], 2.2, 0, TAU); ctx.fill();
    });
}
function charroTorso(col, trim, bow) {   // the jacket half of charroSuit, with no legs, so the rig can supply them
    ctx.fillStyle = lg(-9, -44, 9, -22, [[0, shade(col, 0.2)], [1, shade(col, -0.25)]]);
    ctx.beginPath(); ctx.moveTo(-5, -44); ctx.lineTo(5, -44); ctx.lineTo(9.5, -22); ctx.lineTo(-9.5, -22); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#f4f0e6'; ctx.beginPath(); ctx.moveTo(-3, -44); ctx.lineTo(3, -44); ctx.lineTo(0, -31); ctx.closePath(); ctx.fill();
    ctx.fillStyle = trim; for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.arc(0, -29 + k * 2.2, 0.8, 0, TAU); ctx.fill(); }
    ctx.fillStyle = bow; ctx.beginPath(); ctx.moveTo(0, -42.5); ctx.lineTo(-3.6, -45); ctx.lineTo(-3.6, -40); ctx.closePath(); ctx.moveTo(0, -42.5); ctx.lineTo(3.6, -45); ctx.lineTo(3.6, -40); ctx.closePath(); ctx.fill();
}
function drawGuitarBody() {
    ctx.save(); ctx.translate(3, -27); ctx.rotate(-0.55);
    ctx.fillStyle = '#7a4a20'; ctx.fillRect(-26, -1.6, 20, 3.2); ctx.fillStyle = '#3a2210'; ctx.fillRect(-29, -2.6, 4, 5.2);
    ctx.fillStyle = lg(0, -8, 0, 8, [[0, '#d99a4c'], [1, '#8a5522']]);
    ctx.beginPath(); ctx.arc(-3, 0, 6.2, 0, TAU); ctx.arc(5, 0, 7.6, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1a0d05'; ctx.beginPath(); ctx.arc(3, 0, 2.2, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 0.4; ctx.beginPath(); ctx.moveTo(-26, 0); ctx.lineTo(10, 0); ctx.stroke();
    ctx.restore();
}
function drawGuitar(t, seed) {
    ctx.save(); ctx.translate(3, -27); ctx.rotate(-0.55);
    ctx.fillStyle = '#7a4a20'; ctx.fillRect(-26, -1.6, 20, 3.2); ctx.fillStyle = '#3a2210'; ctx.fillRect(-29, -2.6, 4, 5.2);
    ctx.fillStyle = lg(0, -8, 0, 8, [[0, '#d99a4c'], [1, '#8a5522']]);
    ctx.beginPath(); ctx.arc(-3, 0, 6.2, 0, TAU); ctx.arc(5, 0, 7.6, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1a0d05'; ctx.beginPath(); ctx.arc(3, 0, 2.2, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 0.4; ctx.beginPath(); ctx.moveTo(-26, 0); ctx.lineTo(10, 0); ctx.stroke();
    ctx.restore();
    const sy = Math.sin(t * 0.3 + seed) * 4;
    vArm(-6, -40, -17, -37, '#222', '#c68e60'); vArm(6, -40, 5, -29 + sy, '#222', '#c68e60');
}
function drawTrumpetBody() {
    ctx.save(); ctx.translate(3, -47); ctx.rotate(-0.5);
    ctx.fillStyle = lg(0, -3, 0, 3, [[0, '#ffe58a'], [1, '#b8860b']]);
    ctx.fillRect(0, -1.2, 15, 2.4);
    ctx.beginPath(); ctx.moveTo(15, -1.2); ctx.lineTo(24, -6); ctx.lineTo(24, 6); ctx.lineTo(15, 1.2); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#d4a017'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(8, 3.2, 6, 3, 0, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#fff6c4'; ctx.fillRect(2, -1, 11, 0.7);
    ctx.restore();
}
function drawTrumpetNotes(t, seed) {
    for (let k = 0; k < 3; k++) {   // floating notes
        const age = (t * 0.7 + k * 40 + seed * 20) % 120;
        ctx.fillStyle = `rgba(255,236,150,${1 - age / 120})`; ctx.font = 'bold 11px system-ui, sans-serif';
        ctx.fillText(k % 2 ? '♪' : '♫', 20 + Math.sin(age * 0.1 + k) * 5, -52 - age * 0.45);
    }
}
function drawVillager2D(kind, x, y, s, t, seed) {
    const ph = t * 0.12 + seed * 2.3, bob = Math.abs(Math.sin(ph)) * (kind === 'abuela' ? 1.2 : 3), sway = Math.sin(ph) * 2;
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(0, 1, 15, 3.6, 0, 0, TAU); ctx.fill();
    ctx.translate(sway * 0.3, -bob);
    if (kind === 'guitar') {
        villagerRig({ ph, t, seed, hw: 3.3, hipY: -21.6, leg: 11.2, lw: 5.2, legCol: '#1d1d22', trim: '#cfd3d8', shoe: '#1a1210', tap: true, stance: 1.5, shW: 6.2, shY: -40.5, arm: 6.6, aw: 3.6, armCol: '#222', hand: '#c68e60',
            torso: () => { charroTorso('#1d1d22', '#cfd3d8', '#c0392b'); drawGuitarBody(); }, hands: [[-17, -37 + Math.sin(t * 0.3 + seed + 1) * 0.8], [5, -29 + Math.sin(t * 0.3 + seed) * 4]] });
        vHead(0, -51, 6.4, '#b9784c', t, seed, true); drawStache(0, -47.2, 4.2); drawSombrero(0, -54.5, 15, sway * 0.02, 1);
    } else if (kind === 'trumpet') {
        villagerRig({ ph, t, seed, hw: 3.3, hipY: -21.6, leg: 11.2, lw: 5.2, legCol: '#1f3a5f', trim: '#f1c40f', shoe: '#1a1210', stance: 1.5, sway: 0.8, shW: 6.2, shY: -40.5, arm: 6.6, aw: 3.6, armCol: '#1f3a5f', hand: '#c68e60',
            torso: () => { charroTorso('#1f3a5f', '#f1c40f', '#f1c40f'); drawTrumpetBody(); }, hands: [[3.5, -42.5], [11.5, -44.5 + Math.sin(t * 0.5 + seed) * 0.6]] });
        drawTrumpetNotes(t, seed);
        vHead(0, -51, 6.4, '#a56a40', t, seed, false); drawStache(0, -47.2, 4.2); drawSombrero(0, -54.5, 15, sway * 0.02, 3);
    } else if (kind === 'dancer') {
        const w = 22 + Math.sin(ph * 2) * 5, wv = Math.sin(ph * 2 + 1) * 3;
        villagerRig({ ph, t, seed, hw: 3, hipY: -17.2, leg: 8.4, lw: 4.4, legCol: '#c68e60', shoe: '#4a2a1c', step: 1.6, sway: 1.6, stance: 1.8, shW: 5, shY: -41, arm: 14.5, aw: 3.4, armCol: '#fffaf0', hand: '#c68e60',
            torso: () => {
        // swirling folklorico skirt: red base, white and green ruffle bands, wavy hem
        ctx.fillStyle = lg(-w, -26, w, -2, [[0, '#e0384b'], [1, '#9c1626']]);
        ctx.beginPath(); ctx.moveTo(-5, -27); ctx.lineTo(5, -27);
        for (let i = 0; i <= 10; i++) { const u = i / 10; ctx.lineTo(w * (u * 2 - 1) * (u > 0.5 ? 1 : 1), -3 + Math.sin(i * 1.3 + ph * 2) * 2 + (Math.abs(u - 0.5) * 6)); }
        ctx.closePath(); ctx.fill();
        ctx.save(); ctx.clip();
        ctx.strokeStyle = '#fff6e0'; ctx.lineWidth = 2.2; for (let k = 0; k < 2; k++) { ctx.beginPath(); ctx.moveTo(-w, -9 - k * 6 + wv); ctx.quadraticCurveTo(0, -4 - k * 6 - wv, w, -9 - k * 6 + wv); ctx.stroke(); }
        ctx.strokeStyle = '#1e9c58'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-w, -15 + wv); ctx.quadraticCurveTo(0, -10 - wv, w, -15 + wv); ctx.stroke();
        ctx.restore();
        ctx.fillStyle = '#fffaf0'; ctx.beginPath(); ctx.moveTo(-6, -43); ctx.lineTo(6, -43); ctx.lineTo(5, -26); ctx.lineTo(-5, -26); ctx.closePath(); ctx.fill();   // blouse
        ctx.strokeStyle = '#e0384b'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(0, -43, 5, 0.2, Math.PI - 0.2); ctx.stroke();
        ctx.fillStyle = '#1e9c58'; for (let k = -2; k <= 2; k++) { ctx.beginPath(); ctx.arc(k * 2, -40 + Math.abs(k) * 0.4, 0.7, 0, TAU); ctx.fill(); }

            }, hands: [[-w * 0.78, -17 + wv], [w * 0.78, -17 - wv]] });
        ctx.strokeStyle = '#140b08'; ctx.lineWidth = 3; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sx * 5, -54); ctx.quadraticCurveTo(sx * 9, -46, sx * 7 + Math.sin(ph) * 2, -36); ctx.stroke(); ctx.fillStyle = '#e0384b'; ctx.beginPath(); ctx.arc(sx * 7 + Math.sin(ph) * 2, -36, 1.8, 0, TAU); ctx.fill(); }   // braids
        vHead(0, -51, 6.2, '#c68e60', t, seed, true);
        ctx.fillStyle = '#140b08'; ctx.beginPath(); ctx.arc(0, -51, 6.5, Math.PI * 1.02, Math.PI * 1.98); ctx.fill(); ctx.fillRect(-6.4, -52, 1.6, 4);
        ctx.fillStyle = '#ff4f6d'; for (let k = 0; k < 5; k++) { const a = k * TAU / 5; ctx.beginPath(); ctx.arc(-5 + Math.cos(a) * 2.4, -57 + Math.sin(a) * 2.4, 1.9, 0, TAU); ctx.fill(); }
        ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.arc(-5, -57, 1.2, 0, TAU); ctx.fill();
    } else if (kind === 'abuela') {
        const sh = Math.sin(t * 0.45 + seed) * 3;
        villagerRig({ ph, t, seed, hw: 2.8, hipY: -15.4, leg: 7.6, lw: 4, legCol: '#d9a577', shoe: '#8a5a3a', step: 1.3, sway: 0.9, stance: 1.2, shW: 7, shY: -33, arm: 6.5, aw: 3.6, armCol: '#1aa39a', hand: '#d9a577',
            torso: () => {
                ctx.fillStyle = lg(-12, -30, 12, 0, [[0, '#3d4f86'], [1, '#26325a']]); ctx.beginPath(); ctx.moveTo(-6, -36); ctx.lineTo(6, -36); ctx.lineTo(12.5, -6); ctx.lineTo(-12.5, -6); ctx.closePath(); ctx.fill();
                ctx.fillStyle = '#f6f1e4'; ctx.beginPath(); ctx.moveTo(-5, -24); ctx.lineTo(5, -24); ctx.lineTo(6.6, -8); ctx.lineTo(-6.6, -8); ctx.closePath(); ctx.fill();   // apron
                ctx.fillStyle = '#e8b4c8'; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.arc(k * 3, -15 + Math.abs(k), 1, 0, TAU); ctx.fill(); }
                ctx.fillStyle = '#1aa39a'; ctx.beginPath(); ctx.moveTo(-9, -37); ctx.quadraticCurveTo(0, -42, 9, -37); ctx.lineTo(11, -23); ctx.lineTo(-11, -23); ctx.closePath(); ctx.fill();   // rebozo
                ctx.strokeStyle = '#f1c40f'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-10, -26); ctx.lineTo(10, -26); ctx.stroke();
                ctx.strokeStyle = '#e8e0cc'; ctx.lineWidth = 0.7; for (let k = -10; k <= 10; k += 2.5) { ctx.beginPath(); ctx.moveTo(k, -23); ctx.lineTo(k, -20); ctx.stroke(); }
            }, hands: [[-13, -38 - sh], [13, -38 + sh]] });
        for (const sx of [-1, 1]) { ctx.save(); ctx.translate(sx * 13, -42 + sh * sx); ctx.fillStyle = '#d4a017'; ctx.fillRect(-0.7, 1.5, 1.4, 4); ctx.fillStyle = sx < 0 ? '#e0384b' : '#27ae60'; ctx.beginPath(); ctx.ellipse(0, -1, 3, 4.2, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.fillRect(-1.5, -3.6, 1, 3); ctx.restore(); }   // maracas
        vHead(0, -43, 5.6, '#d9a577', t, seed, true);
        ctx.fillStyle = '#ece8e0'; ctx.beginPath(); ctx.arc(0, -43, 6, Math.PI * 1.05, Math.PI * 1.95); ctx.fill(); ctx.beginPath(); ctx.arc(0, -50.5, 3.2, 0, TAU); ctx.fill();   // white hair and bun
        ctx.strokeStyle = '#3a2a20'; ctx.lineWidth = 0.6; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.arc(sx * 2.2, -43.5, 1.9, 0, TAU); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(-0.3, -43.5); ctx.lineTo(0.3, -43.5); ctx.stroke();   // glasses
    } else if (kind === 'kid') {
        ctx.scale(0.8, 0.8);
        const swing = Math.sin(t * 0.1 + seed) * 0.9 - 0.9, kh = [9.5, -31];
        villagerRig({ ph, t, seed, hw: 3, hipY: -17.6, leg: 9.4, lw: 5, legCol: '#3d6fb5', shinCol: '#d9a577', shoe: '#5a3a1c', step: 1.4, sway: 1.2, stance: 1.2, shW: 7.2, shY: -37.5, arm: 5.4, aw: 3.4, armCol: '#e0384b', hand: '#d9a577',
            torso: () => { for (let k = 0; k < 6; k++) { ctx.fillStyle = k % 2 ? '#fff' : '#e0384b'; ctx.fillRect(-8, -40 + k * 3.4, 16, 3.4); } ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(2, -40, 6, 20); },
            hands: [[-12, -29], kh] });
        ctx.save(); ctx.translate(kh[0], kh[1]); ctx.rotate(swing - 1.2);
        ctx.strokeStyle = '#7a4a20'; ctx.lineWidth = 3.2; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -30); ctx.stroke();   // bat
        ctx.strokeStyle = '#e0384b'; ctx.lineWidth = 3.2; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(0, -8 - k * 9); ctx.lineTo(0, -11 - k * 9); ctx.stroke(); }
        ctx.fillStyle = '#d9a577'; ctx.beginPath(); ctx.arc(0, -1, 2.2, 0, TAU); ctx.fill(); ctx.restore();
        vHead(0, -47, 7, '#d9a577', t, seed, true, true);
        ctx.fillStyle = '#ffd32a'; ctx.fillRect(-7.5, -50, 15, 4.4);   // blindfold
        ctx.fillStyle = '#e0384b'; for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.arc(-5 + k * 3.4, -47.8, 0.8, 0, TAU); ctx.fill(); }
        ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.moveTo(7, -48); ctx.lineTo(11, -45); ctx.lineTo(8, -44); ctx.fill();
        ctx.save(); ctx.scale(1.25, 1.25); drawSombrero(0, -39, 14, sway * 0.03, 0); ctx.restore();
    }
    ctx.restore();
}
// ---------- 3D villagers ----------
// The same generic skeleton as villagerRig (every NPC is one parameter set on one body), rebuilt from the hero's shared meshes (sphere / tube / cone) and drawn through the hero's own
// lit WebGL pass, so the cast has real volume, light and turning heads. Wherever the 3D hero is unavailable they fall back to the flat drawing above.
const NPC3 = {
    guitar: { sk: '#b9784c', leg: '#1d1d22', shoe: '#1a1210', arm: '#222222', top: '#1d1d22', trim: '#cfd3d8', bow: '#c0392b', hw: 3.3, hipY: -21.6, L: 11.2, lw: 5.2, tap: 1, stance: 1.5, sway: 1.1, shW: 6.2, shY: -40.5, A: 6.6, aw: 3.6, hy: -51, hr: 6.4, hat: 1, hs: 15, hY: -54.5, stache: 1, sing: 1 },
    trumpet: { sk: '#a56a40', leg: '#1f3a5f', shoe: '#1a1210', arm: '#1f3a5f', top: '#1f3a5f', trim: '#f1c40f', bow: '#f1c40f', hw: 3.3, hipY: -21.6, L: 11.2, lw: 5.2, stance: 1.5, sway: 0.8, shW: 6.2, shY: -40.5, A: 6.6, aw: 3.6, hy: -51, hr: 6.4, hat: 3, hs: 15, hY: -54.5, stache: 1 },
    dancer: { sk: '#c68e60', leg: '#c68e60', shoe: '#4a2a1c', arm: '#fffaf0', hw: 3, hipY: -17.2, L: 8.4, lw: 4.4, step: 1.6, stance: 1.8, sway: 1.6, shW: 5, shY: -41, A: 14.5, aw: 3.4, hy: -51, hr: 6.2, hair: '#140b08', sing: 1 },
    abuela: { sk: '#d9a577', leg: '#d9a577', shoe: '#8a5a3a', arm: '#1aa39a', hw: 2.8, hipY: -15.4, L: 7.6, lw: 4, step: 1.3, stance: 1.2, sway: 0.9, shW: 7, shY: -33, A: 6.5, aw: 3.6, hy: -43, hr: 5.6, hair: '#ece8e0', sing: 1 },
    kid: { sk: '#d9a577', leg: '#3d6fb5', shin: '#d9a577', shoe: '#5a3a1c', arm: '#e0384b', hw: 3, hipY: -17.6, L: 9.4, lw: 5, step: 1.4, stance: 1.2, sway: 1.2, shW: 7.2, shY: -37.5, A: 5.4, aw: 3.4, hy: -47, hr: 7, hat: 0, hs: 17.5, hY: -48.75, blind: 1, sing: 1, K: 0.8 },
};
function drawVillager3D(kind, x, y, s, t, seed) {
    const C = NPC3[kind], gl = H3.gl, Mh = H3.M, U = H3.U, V = H3_VIEW, K = C.K || 1;
    const dens = Math.min(ctx.getTransform().a * s, 6), pw = Math.max(8, Math.ceil(56 * dens)), ph = Math.max(8, Math.ceil(78 * dens));
    if (H3.cw < pw || H3.ch < ph) { H3.cw = Math.max(H3.cw, pw); H3.ch = Math.max(H3.ch, ph); H3.cv.width = H3.cw; H3.cv.height = H3.ch; }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, pw, ph); gl.scissor(0, 0, pw, ph); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(H3.prog); gl.enable(gl.DEPTH_TEST);
    gl.uniformMatrix4fv(U.uVP, false, m4.chain(m4.persp(2 * Math.atan(V.halfH / V.D), V.halfW / V.halfH, 20, 400), m4.T(0, 0, -V.D), m4.RX(V.pitch), m4.T(0, -V.cy, 0)));
    gl.uniform1f(U.uHQ, 0); gl.uniform1f(U.uSk, 0); gl.uniform1f(U.uBulge, 0); gl.uniform1f(U.uCm, 0); gl.uniform1f(U.uASr, 0); gl.uniform3f(U.uSw, 0, 0, 0);
    gl.uniform4f(U.uBr, 0, 0, 0, 0); gl.uniform4f(U.uHd, 0, 0, 0, 0); h3Dirty(); const sk0 = H3.skinAmt; H3.skinAmt = 0;
    const ph0 = t * 0.12 + seed * 2.3, bob = Math.abs(Math.sin(ph0)) * (kind === 'abuela' ? 1.2 : 3), swy = Math.sin(ph0) * 2;
    const yaw = clamp((W / 2 - x) / 200, -1, 1) * 0.5 + Math.sin(t * 0.03 + seed * 1.7) * 0.3 + (kind === 'dancer' ? Math.sin(ph0) * 0.3 : 0);
    H3ROOT = m4.chain(m4.T(swy * 0.3, -29.5 + bob, 0), m4.RY(yaw), m4.S(K, K, K));
    const c3 = c => cssRgb(c), Y = (px, py, pz) => [px, -py, pz || 0];
    const sph = (p, r, col, o) => h3Draw(Mh.sphere, m4.chain(m4.T(p[0], p[1], p[2]), m4.S(r[0], r[1], r[2])), Object.assign({ col: typeof col === 'string' ? c3(col) : col, spec: 0.12, shin: 14, rim: 0.28 }, o));
    const tub = (a, b, r, col, o) => h3Draw(Mh.tube, m4.seg(a, b, r), Object.assign({ col: typeof col === 'string' ? c3(col) : col, spec: 0.12, shin: 14, rim: 0.28 }, o));
    const GOLD = { spec: 0.9, shin: 30, rim: 0.3 }, CLOTH = { spec: 0.04, shin: 8, rim: 0.3 };
    const sw = Math.sin(ph0) * C.sway, dip = Math.abs(Math.sin(ph0)) * 0.5, tx = sw * 0.7, ty = dip * 0.8, hip = [sw, C.hipY + dip];
    for (const sx of [-1, 1]) {   // legs: planted wide, one foot taps on the beat (or alternate small steps), two-bone IK with real knees
        const tap = C.tap && sx < 0 ? Math.max(0, Math.sin(t * 0.18 + seed * 1.7)) * 2.4 : 0, stp = C.step ? Math.max(0, Math.sin(ph0 * 2 + (sx > 0 ? Math.PI : 0))) * C.step : 0;
        const lift = tap + stp, fx = sx * (C.hw + C.stance) + (stp ? Math.sin(ph0) * -0.6 * sx : 0), fy = -1.6 - lift, hp = [hip[0] + sx * C.hw, hip[1]], p = ik2d(hp[0], hp[1], fx, fy, C.L, C.L, -sx);
        const H = Y(p[0], p[1], 0), Kn = Y(p[2], p[3], 1.6), A = Y(p[4], p[5], 0.6), r = C.lw / 2;
        tub(H, Kn, r, C.leg, CLOTH); tub(Kn, A, r * 0.86, C.shin || C.leg, CLOTH); sph(Kn, [r * 0.95, r * 0.95, r * 0.95], C.leg, CLOTH); sph(H, [r * 1.1, r * 1.1, r * 1.1], C.leg, CLOTH);
        sph([A[0] + sx * 0.8, A[1] - 0.9, 2.4], [3.5, 2.3, 5.2], C.shoe, { spec: 0.3, shin: 20, rim: 0.3 });
    }
    // torso + costume
    const tc = (px, py, pz) => [px + tx, -(py + ty), pz || 0];
    const torso = (cy, rx, ry, rz, col) => sph(tc(0, cy, 0), [rx, ry, rz], col, CLOTH);
    if (kind === 'guitar' || kind === 'trumpet') {
        torso(-33.5, 7.6, 11.5, 4.8, C.top); sph(tc(0, -22.5, 0), [7.2, 3.4, 4.4], C.top, CLOTH);
        sph(tc(0, -38, 3.4), [3.4, 5.6, 2.2], '#f4f0e6', CLOTH);   // shirt front
        for (let k = 0; k < 4; k++) sph(tc(0, -29 + k * 2.2, 4.7), [0.8, 0.8, 0.6], C.trim, GOLD);
        for (const sx of [-1, 1]) { sph(tc(sx * 2.2, -42.5, 4.2), [2.0, 2.4, 1.2], C.bow, CLOTH); }
        tub(tc(-6.8, -23, 0.4), tc(-6.8, -41, 0.4), 0.5, C.trim, GOLD); tub(tc(6.8, -23, 0.4), tc(6.8, -41, 0.4), 0.5, C.trim, GOLD);
    } else if (kind === 'dancer') {
        const w = 22 + Math.sin(ph0 * 2) * 5, wv = Math.sin(ph0 * 2 + 1) * 3;
        h3Draw(Mh.cone, m4.seg(Y(0, -3 + wv * 0.3, 0), Y(0, -36, 0), w), Object.assign({ col: c3('#d12e44') }, CLOTH));
        for (let k = 0; k < 2; k++) { const yy = -9 - k * 7, rr = w * (1 - (yy + 3) / -33) * 0.0 + w * (1 - (-yy - 3) / 33); sph(Y(0, yy + wv * 0.2, 0), [rr * 1.01, 1.1, rr * 1.01], '#fff6e0', CLOTH); }
        { const yy = -15, rr = w * (1 - 12 / 33); sph(Y(0, yy, 0), [rr * 1.01, 1.0, rr * 1.01], '#1e9c58', CLOTH); }
        torso(-34.5, 6.2, 9.4, 4.2, '#fffaf0'); sph(tc(0, -42.5, 2.4), [4.4, 1.4, 2.6], '#e0384b', CLOTH);
    } else if (kind === 'abuela') {
        h3Draw(Mh.cone, m4.seg(Y(0, -6, 0), Y(0, -34, 0), 12.5), Object.assign({ col: c3('#2f4078') }, CLOTH));
        torso(-30, 6.6, 12, 5, '#2f4078'); sph(tc(0, -14, 8.2), [4.6, 7.8, 1.0], '#f6f1e4', CLOTH);
        sph(tc(0, -31, 0.2), [9.2, 6.4, 5.8], '#1aa39a', CLOTH); tub(tc(-10, -26, 0), tc(10, -26, 0), 0.5, '#f1c40f', GOLD);
        for (let k = -1; k <= 1; k++) sph(tc(k * 3, -15 + Math.abs(k), 9.1), [1, 1, 0.5], '#e8b4c8', CLOTH);
    } else if (kind === 'kid') {
        torso(-31.8, 7.8, 8.6, 5.2, '#ffffff');
        for (let k = 0; k < 3; k++) sph(tc(0, -37 + k * 6.8 - 0.2, 0), [8.0, 1.5, 5.5], '#e0384b', CLOTH);
    }
    // neck + head
    const hx = tx * 0.6 + sw * 0.2, hy = -C.hy - ty * 0.5, r = C.hr, HM = m4.chain(m4.T(hx, hy, 0), m4.RY(-yaw * 0.5 + Math.sin(t * 0.07 + seed) * 0.12), m4.RZ(swy * 0.02));
    tub(tc(0, C.shY + 1, 0), [hx, hy - r * 0.8, 0], r * 0.42, C.sk, { spec: 0.1, shin: 16, rim: 0.28 });
    const L = (p, rr, col, o) => h3Draw(Mh.sphere, m4.chain(HM, m4.T(p[0], p[1], p[2]), m4.S(rr[0], rr[1], rr[2])), Object.assign({ col: typeof col === 'string' ? c3(col) : col, spec: 0.1, shin: 16, rim: 0.28 }, o));
    const zS = (px, py) => 0.96 * r * Math.sqrt(Math.max(0.04, 1 - (px / r) * (px / r) - (py / (1.04 * r)) * (py / (1.04 * r))));
    L([0, 0, 0], [r, r * 1.04, r * 0.96], C.sk);
    for (const sx of [-1, 1]) L([sx * r * 0.98, -r * 0.05, 0], [r * 0.16, r * 0.26, r * 0.12], C.sk);
    L([0, -r * 0.1, zS(0, -r * 0.1) + r * 0.04], [r * 0.16, r * 0.2, r * 0.2], shade(C.sk, -0.14));
    const blink = ((Math.floor(t) + seed * 37) % 160) < 5;
    if (!C.blind) for (const sx of [-1, 1]) {
        const ex = sx * r * 0.38, ey = r * 0.12, ez = zS(ex, ey) - r * 0.02;
        L([ex, ey, ez], [r * 0.19, r * (blink ? 0.04 : 0.23), r * 0.09], [0.96, 0.93, 0.86], { spec: 0, rim: 0.05 });
        if (!blink) L([ex, ey - r * 0.02, ez + r * 0.06], [r * 0.12, r * 0.13, r * 0.05], [0.1, 0.06, 0.04], { spec: 0, rim: 0 });
        h3Draw(Mh.tube, m4.chain(HM, m4.seg([ex - r * 0.22, ey + r * 0.34, ez - r * 0.05], [ex + r * 0.22, ey + r * 0.38, ez - r * 0.05], r * 0.06)), { col: c3('#1a0f0a'), spec: 0.05, shin: 8, rim: 0.1 });
    }
    const tk = ((kind === 'trumpet') ? 0 : C.sing ? 0.1 + 0.12 * Math.abs(Math.sin(t * 0.25 + seed)) : 0);
    if (C.sing) L([0, -r * 0.5, zS(0, -r * 0.5) - r * 0.02], [r * 0.2, r * (0.1 + 0.12 * Math.abs(Math.sin(t * 0.25 + seed))), r * 0.08], '#4a1612', { spec: 0.2 });
    else L([0, -r * 0.46, zS(0, -r * 0.46) - r * 0.01], [r * 0.3, r * 0.05, r * 0.08], '#6a2a20', { spec: 0.2 });
    for (const sx of [-1, 1]) L([sx * r * 0.58, -r * 0.3, zS(sx * r * 0.58, -r * 0.3) - r * 0.04], [r * 0.17, r * 0.1, r * 0.05], '#e65a50', { spec: 0, rim: 0, col: [0.9, 0.35, 0.3] });
    if (C.stache) for (const sx of [-1, 1]) L([sx * r * 0.27, -r * 0.34, zS(sx * r * 0.27, -r * 0.34) + r * 0.04], [r * 0.34, r * 0.12, r * 0.12], '#2a1a10', { spec: 0.3, shin: 20 });
    if (C.hair) {
        L([0, r * 0.12, -r * 0.14], [r * 1.07, r * 1.02, r * 1.01], C.hair, { spec: 0.35, shin: 24, rim: 0.4 });
        if (kind === 'dancer') {
            for (const sx of [-1, 1]) { const b = (px, py, pz) => [hx + sx * px, hy - py, pz]; tub(b(5.8, 1, -1), b(7.6, 8, -0.5), 1.4, C.hair, { spec: 0.35, shin: 24, rim: 0.4 }); tub(b(7.6, 8, -0.5), b(7 + Math.sin(ph0) * 2, 16, 0), 1.3, C.hair, { spec: 0.35, shin: 24, rim: 0.4 }); }
            for (let k = 0; k < 5; k++) { const a = k * TAU / 5; L([-r * 0.8 + Math.cos(a) * 2.2, r * 0.95 + Math.sin(a) * 2.2, r * 0.2], [1.9, 1.9, 1.2], '#ff4f6d', { spec: 0.3 }); }
            L([-r * 0.8, r * 0.95, r * 0.4], [1.2, 1.2, 1], '#ffd32a', { spec: 0.6 });
        } else L([0, r * 1.2, -r * 0.3], [3.3, 3.3, 3.3], C.hair, { spec: 0.3, shin: 20 });   // bun
    }
    if (C.blind) { L([0, r * 0.12, 0], [r * 1.045, r * 0.24, r * 0.99], '#ffd32a', { spec: 0.3, shin: 18 }); L([r * 0.95, r * 0.1, -r * 0.4], [2.2, 1.0, 1.2], '#ffd32a'); }
    if (C.hat != null) {
        const hc = hatCol(HAT_STYLES[C.hat % HAT_STYLES.length]), s2 = C.hs, HT = m4.chain(m4.T(hx * 0.6, -C.hY - ty * 0.5, 0.3), m4.RY(-yaw * 0.5), m4.RZ(swy * 0.03), m4.RX(0.12));
        const Hs = (p, rr, col, o) => h3Draw(Mh.sphere, m4.chain(HT, m4.T(p[0], p[1], p[2]), m4.S(rr[0], rr[1], rr[2])), Object.assign({ col: cssRgb(col), spec: 0.1, shin: 10, rim: 0.3 }, o));
        Hs([0, 0, 0], [s2, s2 * 0.1, s2 * 0.97], hc.brim); Hs([0, s2 * 0.3, 0], [s2 * 0.44, s2 * 0.42, s2 * 0.44], hc.crown); Hs([0, s2 * 0.1, 0], [s2 * 0.455, s2 * 0.07, s2 * 0.455], hc.band);
        for (let k = 0; k < 7; k++) { const a = k * TAU / 7 + 0.3; Hs([Math.cos(a) * s2 * 0.88, s2 * 0.01, Math.sin(a) * s2 * 0.85], [s2 * 0.045, s2 * 0.04, s2 * 0.045], hc.trim, GOLD); }
    }
    // arms: ride on the shoulders, hands are targets in figure space (as in the flat rig), pushed forward so they read in front of the body
    let hands;
    if (kind === 'guitar') hands = [[-17, -37 + Math.sin(t * 0.3 + seed + 1) * 0.8], [5, -29 + Math.sin(t * 0.3 + seed) * 4]];
    else if (kind === 'trumpet') hands = [[3.5, -42.5], [11.5, -44.5 + Math.sin(t * 0.5 + seed) * 0.6]];
    else if (kind === 'dancer') { const w = 22 + Math.sin(ph0 * 2) * 5, wv = Math.sin(ph0 * 2 + 1) * 3; hands = [[-w * 0.78, -17 + wv], [w * 0.78, -17 - wv]]; }
    else if (kind === 'abuela') { const sh = Math.sin(t * 0.45 + seed) * 3; hands = [[-13, -38 - sh], [13, -38 + sh]]; }
    else hands = [[-12, -29], [9.5, -31]];
    const zh = kind === 'dancer' ? 3 : 6.5, hp3 = [];
    [-1, 1].forEach((sx, i) => {
        const sh = [sx * C.shW + tx, C.shY + ty], h = hands[i], p = ik2d(sh[0], sh[1], h[0], h[1], C.A, C.A, -sx), r2 = C.aw / 2;
        const S0 = Y(p[0], p[1], 0), E = Y(p[2], p[3], zh * 0.55), Wr = Y(p[4], p[5], zh); hp3.push(Wr);
        tub(S0, E, r2, C.arm, CLOTH); tub(E, Wr, r2 * 0.88, C.arm, CLOTH); sph(S0, [r2 * 1.15, r2 * 1.15, r2 * 1.15], C.arm, CLOTH); sph(E, [r2 * 0.95, r2 * 0.95, r2 * 0.95], C.arm, CLOTH); sph(Wr, [2.3, 2.3, 2.3], C.sk, { spec: 0.1, shin: 16, rim: 0.28 });
    });
    // props that live in the hands
    if (kind === 'guitar') {
        const g = (lx, ly, lz) => { const a = -0.55; return [3 + lx * Math.cos(a) - ly * Math.sin(a), -(-27 + lx * Math.sin(a) + ly * Math.cos(a)), lz]; };
        sph(g(-3, 0, 6), [6.2, 6.2, 2.6], '#c98a42', { spec: 0.4, shin: 24 }); sph(g(5, 0, 6), [7.6, 7.6, 2.6], '#c98a42', { spec: 0.4, shin: 24 }); sph(g(3, 0, 8.4), [2.2, 2.2, 0.5], '#1a0d05', { spec: 0 });
        tub(g(-6, 0, 5.4), g(-26, 0, 5.4), 1.4, '#7a4a20', { spec: 0.2, shin: 16 }); sph(g(-27.5, 0, 5.4), [2.4, 2.6, 1.6], '#3a2210');
    } else if (kind === 'trumpet') {
        const g = (lx, ly) => { const a = -0.5; return [3 + lx * Math.cos(a) - ly * Math.sin(a), -(-47 + lx * Math.sin(a) + ly * Math.cos(a)), 6]; };
        tub(g(0, 0), g(15, 0), 1.2, '#f2c744', GOLD); h3Draw(Mh.cone, m4.seg(g(25, 0), g(14, 0), 6.4), Object.assign({ col: c3('#f2c744') }, GOLD));
    } else if (kind === 'abuela') {
        hp3.forEach((p, i) => { tub([p[0], p[1] + 1, p[2]], [p[0], p[1] + 6, p[2]], 0.7, '#d4a017', GOLD); sph([p[0], p[1] + 8, p[2]], [2.6, 3.2, 2.6], i ? '#27ae60' : '#e0384b', { spec: 0.5, shin: 26 }); });
    } else if (kind === 'kid') {
        const swing = Math.sin(t * 0.1 + seed) * 0.9 - 0.9, a = swing - 1.2, e = Y(9.5 + 30 * Math.sin(a), -31 - 30 * Math.cos(a), 6.5);
        tub(Y(9.5, -31, 6.5), e, 1.7, '#7a4a20', { spec: 0.15, shin: 12 });
    }
    H3ROOT = null; H3.skinAmt = sk0;
    ctx.save(); ctx.translate(x, y - 29.5 * s); ctx.scale(s, s); ctx.drawImage(H3.cv, 0, H3.ch - ph, pw, ph, -28, -48, 56, 78); ctx.restore();
}
function drawVillager(kind, x, y, s, t, seed) {
    if (OPT.hd && OPT.gfx >= 1 && NPC3[kind] && h3Init() && H3.ok && !(H3.lo && s > 99)) {
        ctx.save(); ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(x, y + s, 15 * s, 3.6 * s, 0, 0, TAU); ctx.fill(); ctx.restore();
        try { drawVillager3D(kind, x, y, s, t, seed); return; } catch (e) { H3ROOT = null; }
    }
    drawVillager2D(kind, x, y, s, t, seed);
}
function drawPinata(x, y, t) {
    const sw = Math.sin(t * 0.07) * 0.18;
    ctx.save(); ctx.translate(x, 96); ctx.strokeStyle = '#e8dcc0'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, y - 96); ctx.stroke();
    ctx.translate(0, y - 96); ctx.rotate(sw);
    const cols = ['#e0384b', '#ffd32a', '#1e9c58', '#2e86de', '#ff7ac0', '#ff9f1c', '#9b59b6'];
    for (let i = 0; i < 7; i++) { const a = i * TAU / 7 - Math.PI / 2; ctx.fillStyle = cols[i]; ctx.beginPath(); ctx.moveTo(Math.cos(a - 0.4) * 11, Math.sin(a - 0.4) * 11); ctx.lineTo(Math.cos(a) * 26, Math.sin(a) * 26); ctx.lineTo(Math.cos(a + 0.4) * 11, Math.sin(a + 0.4) * 11); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 0.8; ctx.stroke(); }
    ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.arc(0, 0, 11, 0, TAU); ctx.fill();
    ctx.fillStyle = '#e0384b'; ctx.beginPath(); ctx.arc(0, 0, 7, 0, TAU); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-2.5, -2, 1.7, 0, TAU); ctx.arc(2.5, -2, 1.7, 0, TAU); ctx.fill();
    ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(-2.5, -2, 0.8, 0, TAU); ctx.arc(2.5, -2, 0.8, 0, TAU); ctx.fill();
    ctx.restore();
}

const VQ = { nohoop: false, mo: 0, mw: 0, brow: 0 };
const ease = u => { u = clamp(u, 0, 1); return 1 - Math.pow(1 - u, 3); };
const CUT = [
    { sky: 0, title: 'I · THE FIESTA', text: 'Every year, the village of Valle Chiquito throws the Fiesta del Sol, lit by the legendary Golden Sombrero.',
      art(t) {
        const gy = 388, cam = t * 0.18;
        ctx.fillStyle = '#5a2d48'; ctx.fillRect(0, gy, W, H - gy);
        ctx.fillStyle = '#7a3f5f'; ctx.fillRect(0, gy, W, 5);
        csHouses(cam, gy, false, t);
        // sagging string of lanterns, swaying
        for (let row = 0; row < 2; row++) {
            const y0 = 120 + row * 46;
            ctx.strokeStyle = '#2d1830'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-10, y0); ctx.quadraticCurveTo(W / 2, y0 + 38, W + 10, y0 + 6); ctx.stroke();
            for (let i = 0; i < 9; i++) {
                const u = (i + 0.5) / 9, x = u * W, y = y0 + 38 * 2 * u * (1 - u) + 6 * u, sw = Math.sin(t * 0.05 + i * 0.9 + row) * 1.5;
                const col = ['#ff6b6b', '#feca57', '#48dbfb', '#1dd1a1', '#ff9ff3'][(i + row * 2) % 5];
                drawGlow(x + sw, y + 12, 22, col, 0.65);
                ctx.fillStyle = col; roundRect(x - 5 + sw, y + 4, 10, 15, 4); ctx.fill();
                ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(x - 3 + sw, y + 7, 2, 8);
            }
        }
        // golden sombrero with slow light rays
        const sx = 262, sy = 175 + Math.sin(t * 0.04) * 7;
        ctx.save(); ctx.translate(sx, sy); ctx.rotate(t * 0.004);
        for (let k = 0; k < 14; k++) { ctx.rotate(TAU / 14); ctx.fillStyle = 'rgba(255,226,120,0.10)'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(220, -9); ctx.lineTo(220, 9); ctx.closePath(); ctx.fill(); }
        ctx.restore();
        drawGlow(sx, sy, 110, '#ffd32a', 0.95);
        drawSombrero(sx, sy, 44, Math.sin(t * 0.03) * 0.07, 4);
        // the whole village is dancing: back row, then the front row with our hero
        drawPinata(318, 238, t);
        drawVillager('guitar', 52, gy + 14, 1.05, t, 1);
        drawVillager('trumpet', 138, gy + 12, 1.0, t, 2);
        drawVillager('abuela', 232, gy + 14, 1.0, t, 3);
        drawVillager('dancer', 336, gy + 12, 1.05, t, 4);
        drawVillager('dancer', 72, gy + 46, 1.45, t, 5);
        drawVillager('kid', 292, gy + 44, 1.35, t, 6);
        const hx = 182 + Math.sin(t * 0.02) * 22, hop = Math.abs(Math.sin(t * 0.11)) * 11, face = Math.cos(t * 0.02) >= 0 ? 1 : -1;
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(hx, gy + 30, 28, 6, 0, 0, TAU); ctx.fill();
        VQ.nohoop = true; VQ.g = 'dance'; VQ.jump = hop; drawVaquero(hx, gy - 6, 1.8, face, 0); VQ.jump = 0; VQ.nohoop = false; VQ.g = null;
        // falling confetti
        for (let i = 0; i < 38; i++) {
            const x = (i * 41 + Math.sin(t * 0.03 + i) * 12) % W, y = (t * (0.7 + (i % 4) * 0.3) + i * 53) % (H - 150);
            ctx.fillStyle = ['#ff6b6b', '#feca57', '#48dbfb', '#1dd1a1', '#ff9ff3'][i % 5]; ctx.fillRect(x, y, 3, 5);
        }
      } },
    { sky: 12000, title: 'II · THE THEFT', text: 'One night, a shadow rose over the rooftops. El Gran Globo, the balloon baron nobody ever invited, stole the Sombrero.',
      art(t) {
        ctx.fillStyle = 'rgba(8,0,18,0.45)'; ctx.fillRect(0, 0, W, H);
        csHouses(0, 520, true, t);
        const rise = ease(t / 75), shk = t < 75 ? 3 : Math.max(0, 2 - (t - 75) * 0.05);
        const vy = 262 + (1 - rise) * 330;
        // beam of stolen light streaming up from the village into his claws
        if (t < 150) {
            const a = (1 - t / 150) * 0.55;
            ctx.fillStyle = lg(0, vy, 0, 520, [[0, `rgba(255,211,42,${a})`], [1, 'rgba(255,211,42,0)']]);
            ctx.fillRect(W / 2 - 22, vy + 80, 44, 520 - vy - 80);
        }
        ctx.save(); ctx.translate(rand(-shk, shk), rand(-shk, shk));
        drawVillain(W / 2, vy, 84, t, { hold: true });
        ctx.restore();
        const f1 = Math.max(0, 1 - Math.abs(t - 72) / 9), f2 = Math.max(0, 1 - Math.abs(t - 170) / 9);
        if (f1 + f2 > 0) { ctx.fillStyle = `rgba(235,240,255,${(f1 + f2) * 0.55})`; ctx.fillRect(0, 0, W, H); }
        ctx.fillStyle = lg(0, 0, 0, H, [[0, 'rgba(0,0,0,0.55)'], [0.3, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,0)']]); ctx.fillRect(0, 0, W, 200);
        if (t > 78) {   // title slam
            const k = ease((t - 78) / 10), sc = 1 + (1 - k) * 1.8;
            ctx.save(); ctx.translate(W / 2, 92); ctx.scale(sc, sc); ctx.globalAlpha = k;
            ctx.textAlign = 'center'; ctx.font = '900 34px system-ui, sans-serif';
            outlineText('EL GRAN GLOBO', 0, 0, '#ff3b2f', 'rgba(0,0,0,0.9)', 8);
            ctx.restore(); ctx.textAlign = 'left';
        }
      } },
    { sky: 12000, title: 'III · THE FALL', text: 'His army of mustachioed balls rained down. The guitars fell silent. The fiesta was over.',
      art(t) {
        ctx.fillStyle = 'rgba(70,6,0,0.4)'; ctx.fillRect(0, 0, W, H);
        // burning village on the horizon with rising smoke
        csHouses(0, 540, true, t);
        for (let i = 0; i < 5; i++) {
            const x = 30 + i * 75 + Math.sin(i * 7) * 12;
            drawGlow(x, 530, 70 + Math.sin(t * 0.3 + i) * 8, '#ff6a00', 0.8);
            for (let k = 0; k < 6; k++) { const age = (t * 0.7 + k * 30 + i * 11) % 180, sx = x + Math.sin(age * 0.05 + k) * 14 + age * 0.1; ctx.fillStyle = `rgba(30,20,24,${0.5 * (1 - age / 180)})`; ctx.beginPath(); ctx.arc(sx, 520 - age * 2.2, 8 + age * 0.12, 0, TAU); ctx.fill(); }
        }
        // ball rain with motion trails
        for (let i = 0; i < 24; i++) {
            const r = 10 + (i % 3) * 4, x = (i * 53) % 330 + 15, sp = 2.4 + (i % 4) * 0.5, y = ((t * sp + i * 97) % 620) - 40;
            ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = r * 1.4; ctx.beginPath(); ctx.moveTo(x, y - 40); ctx.lineTo(x, y - r); ctx.stroke();
            drawBall(fakeBall(x, y, r, BALLCOLS[i % 5], i % 4));
        }
        // looming eyes in the storm clouds
        const open = Math.min(1, Math.max(0, (t - 20) / 30)), pu = 0.7 + 0.3 * Math.sin(t * 0.1);
        for (const sx of [-1, 1]) {
            const ex = W / 2 + sx * 48, ey = 70;
            drawGlow(ex, ey, 90, '#ff2a00', 0.8 * open * pu);
            ctx.fillStyle = `rgba(255,225,70,${open})`; ctx.beginPath(); ctx.moveTo(ex - sx * 30, ey + 8); ctx.quadraticCurveTo(ex, ey - 22 * open, ex + sx * 32, ey - 12); ctx.quadraticCurveTo(ex, ey + 14 * open, ex - sx * 30, ey + 8); ctx.fill();
            ctx.fillStyle = `rgba(0,0,0,${open})`; ctx.beginPath(); ctx.ellipse(ex, ey, 3.5, 11 * open, 0, 0, TAU); ctx.fill();
        }
      } },
    { sky: 4000, title: 'IV · THE HERO', text: 'Only one rider dared to answer: Hula Vaquero, and his abuela\'s enchanted hula hoop.',
      art(t) {
        const z = 1 + t * 0.0009;
        ctx.save(); ctx.translate(W / 2, 310); ctx.scale(z, z); ctx.translate(-W / 2, -310);
        const equip = t >= 125, lift = ease((t - 125) / 90) * 46;
        for (let i = 0; i < 26; i++) { const a = (i * 2.399) % TAU, rr = 70 + (i % 5) * 22, tw = 0.5 + 0.5 * Math.sin(t * 0.07 + i * 1.7); drawGlow(W / 2 + Math.cos(a) * rr * 1.2, 320 + Math.sin(a) * rr, 8, '#fff3a0', 0.9 * tw); }   // twinkles
        const hy = 330 - lift;
        if (!equip) {
            VQ.nohoop = true; VQ.g = 'hips'; drawVaquero(W / 2, hy, 3, 1, 0); VQ.nohoop = false; VQ.g = null;
            // the hoop floats beside him, glowing and still, then flies to his waist
            const u = ease((t - 95) / 30), hx = lerp(W / 2 + 96, W / 2 + 9, u), hyy = lerp(292 + Math.sin(t * 0.05) * 7, hy + 6, u);
            const rx = lerp(40, 57, u), ry = lerp(11, 15, u), tilt = lerp(-0.5, 0, u), hc = hoopColors();
            drawGlow(hx, hyy, 120, hc[1], 0.9);
            ctx.lineCap = 'round'; ctx.lineWidth = 8; ctx.strokeStyle = hc[0]; ctx.beginPath(); ctx.ellipse(hx, hyy, rx, ry, tilt, 0, TAU); ctx.stroke();
            ctx.lineWidth = 4; ctx.strokeStyle = hc[1]; ctx.beginPath(); ctx.ellipse(hx, hyy, rx, ry, tilt, 0, TAU); ctx.stroke();
            ctx.lineWidth = 1.6; ctx.strokeStyle = hc[2]; ctx.beginPath(); ctx.ellipse(hx, hyy, rx, ry, tilt, Math.PI * 1.1, Math.PI * 1.6); ctx.stroke();
        } else {
            VQ.g = 'flex'; drawVaquero(W / 2, hy, 3, 1, 0); VQ.g = null;
            const k = (t - 125) / 22; if (k < 1) addRingFx(W / 2 + 9, hy + 6, 40 + k * 160, `rgba(255,243,160,${1 - k})`);
        }
        ctx.restore();
      } },
    { sky: t => Math.min(t, 330) / 330 * 28000, title: 'V · THE CLIMB', text: 'Through clouds, storms and stars he rode, up to the Fiesta Galaxy, where El Gran Globo waits.',
      art(t) {
        for (let i = 0; i < 16; i++) { const x = (i * 67) % W, y = (t * (18 + (i % 4) * 5) + i * 91) % (H + 120) - 60; ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 55); ctx.stroke(); }
        const f = Math.min(t, 330) / 330 * 28000, bi = biomeIdx(f), a = 1 - clamp((f - BIOMES[bi].at) / 5500, 0, 1);
        ctx.save(); ctx.translate(rand(-1, 1), rand(-1, 1)); ctx.translate(W / 2, 345 + Math.sin(t * 0.05) * 7); ctx.rotate(Math.sin(t * 0.03) * 0.05);
        VQ.g = 'surf'; drawVaquero(0, 0, 2.6, 1, 0); VQ.g = null; ctx.restore();
        if (a > 0.02) { ctx.globalAlpha = a; ctx.textAlign = 'center'; ctx.font = '900 22px system-ui, sans-serif'; outlineText(BIOMES[bi].name.toUpperCase(), W / 2, 96, '#fff', 'rgba(0,0,0,0.55)', 5); ctx.textAlign = 'left'; ctx.globalAlpha = 1; }
      } },
    { sky: 28000, title: 'VI · THE MISSION', text: 'Pop the balls. Collect gold and relics. Take back the Sombrero, and bring back the fiesta!',
      art(t) {
        const f = Math.max(0, 1 - ((t + 30) % 130) / 8); if (f > 0) { ctx.fillStyle = `rgba(230,200,255,${f * 0.25})`; ctx.fillRect(0, 0, W, H); }
        for (let i = 0; i < 3; i++) { const k = ((t * 0.012 + i / 3) % 1); addRingFx(W / 2, 190, 60 + k * 260, `rgba(255,60,40,${(1 - k) * 0.45})`); }
        const orbit = [];
        for (let i = 0; i < 9; i++) { const a = t * 0.022 + i * TAU / 9, d = Math.sin(a); orbit.push({ a, d, i }); }
        const drawOrb = o => { const sc = 0.78 + 0.4 * (o.d * 0.5 + 0.5), r = (12 + (o.i % 3) * 2) * sc; ctx.globalAlpha = o.d < 0 ? 0.7 : 1; drawBall(fakeBall(W / 2 + Math.cos(o.a) * 150, 200 + o.d * 70, r, BALLCOLS[o.i % 5], o.i % 4)); ctx.globalAlpha = 1; };
        orbit.filter(o => o.d < 0).forEach(drawOrb);                       // behind him
        drawVillain(W / 2, 190 + Math.sin(t * 0.04) * 6, 74, t, { hold: true });
        orbit.filter(o => o.d >= 0).forEach(drawOrb);                      // in front of him
        ctx.save(); ctx.translate(W / 2, 430 - Math.min(t, 120) * 0.15); ctx.rotate(Math.sin(t * 0.03) * 0.03);
        VQ.g = 'pointup'; drawVaquero(0, 0, 2.1, 1, 0); VQ.g = null; ctx.restore();
      } },
];
const lerp = (a, b, u) => a + (b - a) * u;
function addRingFx(x, y, r, col) { ctx.strokeStyle = col; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke(); }
function csHouses(cam, gy, dark, t) {
    const off = ((cam % 90) + 90) % 90;
    for (let i = -1; i < 6; i++) {
        const x = i * 90 - off, h = 58 + ((i + 20) * 13) % 22;
        ctx.fillStyle = dark ? '#150a17' : ['#d9a066', '#e2b07a', '#cf9358', '#dcae74'][(i + 8) % 4]; roundRect(x, gy - h, 72, h, 4); ctx.fill();
        ctx.fillStyle = dark ? '#0c050e' : '#8a4b2a'; ctx.fillRect(x - 3, gy - h - 4, 78, 7);
        if (dark) { const on = Math.sin(t * 0.2 + i * 3) > -0.4; ctx.fillStyle = on ? '#ff9a2a' : '#3a1a10'; ctx.fillRect(x + 12, gy - h + 16, 12, 12); ctx.fillRect(x + 46, gy - h + 16, 12, 12); }
        else { ctx.fillStyle = '#4a2a1c'; roundRect(x + 27, gy - 34, 18, 34, 8); ctx.fill(); ctx.fillStyle = '#ffd32a'; ctx.fillRect(x + 8, gy - h + 14, 12, 11); ctx.fillRect(x + 52, gy - h + 14, 12, 11); }
    }
}
function drawVillain(cx, cy, R, t, o = {}) {
    const pulse = 0.5 + 0.5 * Math.sin(t * 0.09), fl = Math.sin(t * 0.07) * R * 0.1;
    ctx.save(); ctx.translate(cx, cy);
    drawGlow(0, 0, R * 2.7, '#ff2a00', 0.3 + 0.2 * pulse);
    // tattered cape
    ctx.fillStyle = lg(0, -R * 0.4, 0, R * 1.9, [[0, '#4a0b18'], [1, '#14030a']]);
    ctx.beginPath(); ctx.moveTo(-R * 0.95, -R * 0.1); ctx.quadraticCurveTo(-R * 1.55 + fl, R * 0.7, -R * 1.35 + fl, R * 1.55);
    for (let i = 0; i <= 8; i++) { const u = i / 8; ctx.lineTo(-R * 1.35 + u * R * 2.7 + fl * (1 - u * 2) * 0.5, R * (i % 2 ? 1.28 : 1.72) + Math.sin(t * 0.1 + i) * R * 0.05); }
    ctx.quadraticCurveTo(R * 1.55 - fl, R * 0.7, R * 0.95, -R * 0.1); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#a3121f'; ctx.lineWidth = R * 0.03; ctx.stroke();
    // bone horns
    for (const sx of [-1, 1]) {
        ctx.fillStyle = lg(sx * R * 0.6, -R * 0.2, sx * R * 1.5, -R * 1.0, [[0, '#6b6350'], [1, '#e6dcc0']]);
        ctx.beginPath(); ctx.moveTo(sx * R * 0.6, -R * 0.05); ctx.quadraticCurveTo(sx * R * 1.6, -R * 0.05, sx * R * 1.58, -R * 1.05); ctx.quadraticCurveTo(sx * R * 1.32, -R * 0.35, sx * R * 0.5, -R * 0.45); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = R * 0.02; ctx.stroke();
    }
    // armored crimson body
    ctx.fillStyle = rg(-R * 0.35, -R * 0.4, R * 0.1, 0, 0, R * 1.05, [[0, '#8c1d22'], [0.45, '#4a0d12'], [1, '#12030a']]);
    ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.clip();
    ctx.strokeStyle = `rgba(255,110,20,${0.45 + 0.4 * pulse})`; ctx.lineWidth = R * 0.028; ctx.lineJoin = 'round';
    [[[-0.9, -0.1], [-0.65, -0.3], [-0.78, -0.55], [-0.5, -0.85]], [[0.95, 0.05], [0.7, -0.2], [0.85, -0.5], [0.6, -0.8]], [[-0.2, 0.95], [-0.05, 0.7], [-0.3, 0.55]]].forEach(pl => { ctx.beginPath(); pl.forEach((p, i) => i ? ctx.lineTo(p[0] * R, p[1] * R) : ctx.moveTo(p[0] * R, p[1] * R)); ctx.stroke(); });
    ctx.fillStyle = lg(-R, R * 0.5, R, R * 1.1, [[0, '#9aa3ad'], [0.5, '#e3e8ee'], [1, '#4b525b']]);   // steel jaw plate
    ctx.beginPath(); ctx.moveTo(-R, R * 0.6); ctx.quadraticCurveTo(0, R * 0.86, R, R * 0.6); ctx.lineTo(R, R * 1.1); ctx.lineTo(-R, R * 1.1); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#2b2f36'; for (let i = -3; i <= 3; i++) { ctx.beginPath(); ctx.arc(i * R * 0.24, R * (0.8 + 0.012 * i * i * 0.4), R * 0.035, 0, TAU); ctx.fill(); }
    ctx.restore();
    ctx.strokeStyle = `rgba(255,60,30,${0.55 + 0.25 * pulse})`; ctx.lineWidth = R * 0.03; ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.stroke();
    // glowing predator eyes, heavy brows, scar
    for (const sx of [-1, 1]) {
        const ex = sx * R * 0.38, ey = -R * 0.12;
        drawGlow(ex, ey, R * 0.5, '#ffcc00', 0.45 + 0.2 * pulse);
        ctx.fillStyle = '#ffe14d'; ctx.strokeStyle = '#000'; ctx.lineWidth = R * 0.02;
        ctx.beginPath(); ctx.moveTo(ex - sx * R * 0.25, ey + R * 0.07); ctx.quadraticCurveTo(ex, ey - R * 0.2, ex + sx * R * 0.27, ey - R * 0.1); ctx.quadraticCurveTo(ex, ey + R * 0.15, ex - sx * R * 0.25, ey + R * 0.07); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#000'; ctx.beginPath(); ctx.ellipse(ex, ey, R * 0.035, R * 0.11, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#0a0102'; ctx.lineWidth = R * 0.1; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(ex - sx * R * 0.34, ey - R * 0.08); ctx.lineTo(ex + sx * R * 0.38, ey - R * 0.33); ctx.stroke();
    }
    ctx.strokeStyle = '#e0c9ac'; ctx.lineWidth = R * 0.035; ctx.beginPath(); ctx.moveTo(-R * 0.5, -R * 0.52); ctx.lineTo(-R * 0.22, R * 0.2); ctx.stroke();
    ctx.lineWidth = R * 0.018; for (let k = 0; k < 4; k++) { const u = 0.15 + k * 0.22, px = -R * 0.5 + u * R * 0.28, py = -R * 0.52 + u * R * 0.72; ctx.beginPath(); ctx.moveTo(px - R * 0.05, py - R * 0.02); ctx.lineTo(px + R * 0.05, py + R * 0.02); ctx.stroke(); }
    // jagged grin with gold fangs
    ctx.fillStyle = '#0a0102'; ctx.beginPath(); ctx.moveTo(-R * 0.52, R * 0.36); ctx.quadraticCurveTo(0, R * 0.28, R * 0.52, R * 0.36); ctx.quadraticCurveTo(R * 0.4, R * 0.8, 0, R * 0.8); ctx.quadraticCurveTo(-R * 0.4, R * 0.8, -R * 0.52, R * 0.36); ctx.fill();
    for (let i = -4; i <= 4; i++) { const yb = R * (0.325 + 0.009 * i * i), len = (Math.abs(i) === 2 ? 0.2 : 0.12) * R; ctx.fillStyle = Math.abs(i) === 2 ? '#f1c40f' : '#f4efe4'; ctx.beginPath(); ctx.moveTo(i * R * 0.12 - R * 0.055, yb); ctx.lineTo(i * R * 0.12, yb + len); ctx.lineTo(i * R * 0.12 + R * 0.055, yb); ctx.fill(); }
    for (let i = -3; i <= 3; i++) { const yb = R * (0.77 - 0.014 * i * i); ctx.fillStyle = '#f4efe4'; ctx.beginPath(); ctx.moveTo(i * R * 0.12 - R * 0.05, yb); ctx.lineTo(i * R * 0.12, yb - R * 0.1); ctx.lineTo(i * R * 0.12 + R * 0.05, yb); ctx.fill(); }
    drawStache(0, R * 0.25, R * 0.42);
    // cigar with ember and smoke
    ctx.save(); ctx.translate(R * 0.5, R * 0.5); ctx.rotate(-0.22);
    ctx.fillStyle = '#6b3f1d'; ctx.fillRect(0, -R * 0.045, R * 0.5, R * 0.09); ctx.fillStyle = '#d4a017'; ctx.fillRect(R * 0.08, -R * 0.045, R * 0.04, R * 0.09);
    drawGlow(R * 0.5, 0, R * 0.25, '#ff6a00', 0.9); ctx.fillStyle = '#ff7a1a'; ctx.beginPath(); ctx.arc(R * 0.5, 0, R * 0.05, 0, TAU); ctx.fill(); ctx.restore();
    for (let k = 0; k < 5; k++) { const age = (t * 0.7 + k * 22) % 110; ctx.fillStyle = `rgba(210,210,215,${0.35 * (1 - age / 110)})`; ctx.beginPath(); ctx.arc(R * 0.98 + Math.sin(age * 0.07 + k) * R * 0.08, R * 0.4 - age * R * 0.011, R * (0.05 + age * 0.0011), 0, TAU); ctx.fill(); }
    // black sombrero with a skull
    drawSombrero(0, -R * 0.8, R * 1.3, Math.sin(t * 0.04) * 0.03, 1);
    ctx.fillStyle = '#f4efe4'; ctx.beginPath(); ctx.arc(0, -R * 1.22, R * 0.1, 0, TAU); ctx.fill(); ctx.fillRect(-R * 0.06, -R * 1.16, R * 0.12, R * 0.1);
    ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(-R * 0.04, -R * 1.23, R * 0.025, 0, TAU); ctx.arc(R * 0.04, -R * 1.23, R * 0.025, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#f4efe4'; ctx.lineWidth = R * 0.025; ctx.beginPath(); ctx.moveTo(-R * 0.16, -R * 1.1); ctx.lineTo(R * 0.16, -R * 1.02); ctx.moveTo(R * 0.16, -R * 1.1); ctx.lineTo(-R * 0.16, -R * 1.02); ctx.stroke();
    // clawed hands clutching the stolen Golden Sombrero
    if (o.hold) {
        drawGlow(0, R * 1.15, R * 0.9, '#ffd32a', 0.9);
        drawSombrero(0, R * 1.15, R * 0.5, 0, 4);
        for (const sx of [-1, 1]) {
            ctx.strokeStyle = '#1a0608'; ctx.lineWidth = R * 0.2; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(sx * R * 0.78, R * 0.65); ctx.lineTo(sx * R * 0.58, R * 1.08); ctx.stroke();
            ctx.fillStyle = '#1a0608'; ctx.beginPath(); ctx.ellipse(sx * R * 0.52, R * 1.12, R * 0.17, R * 0.13, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = '#e6dcc0'; for (let k = -1; k <= 1; k++) { const bx = sx * R * 0.4, by = R * 1.12 + k * R * 0.08; ctx.beginPath(); ctx.moveTo(bx, by - R * 0.035); ctx.lineTo(bx - sx * R * 0.2, by + k * R * 0.02); ctx.lineTo(bx, by + R * 0.035); ctx.fill(); }
        }
    }
    ctx.restore();
}
const CSL = () => (cs && cs.list) || CUT;
function csSky() { const sc = CSL()[cs.i]; return typeof sc.sky === 'function' ? sc.sky(cs.t) : sc.sky; }
function startCutscene() { cs = { i: 0, t: 0 }; mode = 'cutscene'; drag = null; }
function endCutscene() { if (csHushed) { csHushed = false; applyVol(); } if (cs && cs.end) { const f = cs.end; cs = null; f(); return; } save.seenIntro = true; persist(); cs = null; openMap(); }
function ride() { if (OPT.intro === 2 || (OPT.intro === 0 && save.seenIntro)) openMap(); else startCutscene(); }
function csNext() {
    if (!cs) return;
    if (muIs()) { if (cs.i >= CSL().length - 1) endCutscene(); else { cs.i++; cs.t = 0; sfx('click'); } return; }   // the musical: a tap moves on to the next number
    const full = Math.ceil(CSL()[cs.i].text.length / CPS);
    if (cs.t < full) { cs.t = full; return; }
    if (cs.i >= CSL().length - 1) { endCutscene(); return; }
    cs.i++; cs.t = 0; sfx('click');
}
function wrapLines(text, maxW) {
    const out = []; let line = '';
    for (const w of text.split(' ')) {
        const test = line ? line + ' ' + w : w;
        if (ctx.measureText(test).width > maxW && line) { out.push(line); line = w; } else line = test;
    }
    if (line) out.push(line);
    return out;
}
function drawCutscene() {
    csFrameN++;
    const sc = CSL()[cs.i], t = cs.t, full = Math.ceil(sc.text.length / CPS);
    sc.art(t);
    VQ.nohoop = false;
    if (cs.spL && cs.spI === cs.i) drawBubbles();
    drawHeroPortrait();
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, 34);
    ctx.fillStyle = '#9aa3c7'; ctx.font = '700 11px system-ui, sans-serif'; ctx.fillText('HULA VAQUERO', 12, 22);
    ctx.textAlign = 'right'; ctx.fillText((cs.i + 1) + ' / ' + CSL().length, W - 12, 22); ctx.textAlign = 'left';
    // subtitle card
    const px = 12, py = 446, pw = W - 24, ph = 138;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; roundRect(px, py + 3, pw, ph, 14); ctx.fill();
    ctx.fillStyle = 'rgba(12,10,26,0.88)'; roundRect(px, py, pw, ph, 14); ctx.fill();
    ctx.strokeStyle = 'rgba(255,211,42,0.55)'; ctx.lineWidth = 1.5; roundRect(px, py, pw, ph, 14); ctx.stroke();
    ctx.fillStyle = '#ffd32a'; ctx.font = '800 11px system-ui, sans-serif'; ctx.fillText(sc.title, px + 16, py + 24);
    ctx.fillStyle = 'rgba(255,211,42,0.35)'; ctx.fillRect(px + 16, py + 31, 34, 2);
    ctx.font = '600 15px system-ui, sans-serif';
    const lines = wrapLines(sc.text, pw - 32);
    let left = Math.floor(t * CPS);
    ctx.fillStyle = '#f4f1ff';
    lines.forEach((ln, i) => { ctx.fillText(ln.slice(0, Math.max(0, left)), px + 16, py + 58 + i * 22); left -= ln.length + 1; });
    if (t >= full && Math.floor(t / 25) % 2 === 0) { ctx.fillStyle = '#ffd32a'; ctx.font = '700 11px system-ui, sans-serif'; ctx.textAlign = 'right'; ctx.fillText('tap to continue ▸', px + pw - 14, py + ph - 10); ctx.textAlign = 'left'; }
    for (let i = 0; i < CSL().length; i++) { ctx.fillStyle = i === cs.i ? '#ffd32a' : 'rgba(255,255,255,0.3)'; ctx.beginPath(); ctx.arc(24 + i * 12, 612, 3, 0, TAU); ctx.fill(); }
    if (t < 20) { ctx.fillStyle = `rgba(${sc.fade || '0,0,0'},${1 - t / 20})`; ctx.fillRect(0, 0, W, H); }
    btn(W - 92, H - 46, 82, 34, 'SKIP ►', endCutscene, '#636e72');
    if (t > full + 170 + (cs.spL && cs.spI === cs.i ? cs.holdX || 0 : 0)) csNext();
}
function drawAndale() {
    const age = 110 - g.intro, k = age < 14 ? 0.3 + 0.7 * (age / 14) + 0.25 * Math.sin(age / 14 * Math.PI) : 1;
    ctx.save();
    ctx.globalAlpha = Math.min(1, g.intro / 25);
    ctx.translate(W / 2, 260); ctx.rotate(Math.sin(age * 0.35) * 0.04); ctx.scale(k, k);
    ctx.textAlign = 'center'; ctx.font = 'bold 58px system-ui, sans-serif';
    outlineText('ANDALE!', 0, 0, '#ffd32a', 'rgba(120,20,0,0.9)', 10);
    ctx.restore();
}

function drawBuzzard(pt, fl) {   // the Buzzard Buddy: feathered wings, hooked beak, bald head, sombrero
    ctx.save(); ctx.translate(pt.x, pt.y);
    const flap = fl;
    for (const sx of [-1, 1]) {   // wings with feather fingers
        ctx.fillStyle = '#5a3d24';
        ctx.beginPath(); ctx.moveTo(sx * 3, -1); ctx.quadraticCurveTo(sx * 9, -7 - flap, sx * 17, -5 - flap * 1.4); ctx.lineTo(sx * 15, -2 - flap * 0.7); ctx.lineTo(sx * 17, 0 - flap * 0.4); ctx.lineTo(sx * 13, 1); ctx.lineTo(sx * 14, 3); ctx.lineTo(sx * 8, 3); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 0.6;
        for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(sx * (6 + k * 3), 0); ctx.lineTo(sx * (10 + k * 3), -3 - flap * (0.3 + k * 0.2)); ctx.stroke(); }
        ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.beginPath(); ctx.moveTo(sx * 4, -1); ctx.quadraticCurveTo(sx * 9, -6 - flap, sx * 14, -5 - flap); ctx.lineTo(sx * 10, -2); ctx.fill();
    }
    ctx.fillStyle = '#3d2814'; ctx.beginPath(); ctx.moveTo(-2, 3); ctx.lineTo(0, 9); ctx.lineTo(2, 3); ctx.fill();   // tail
    ctx.fillStyle = lg(-6, -3, 6, 4, [[0, '#6b4a2c'], [1, '#33200f']]); ctx.beginPath(); ctx.ellipse(0, 0, 6, 4.4, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#e8d9bd'; ctx.beginPath(); ctx.ellipse(0, -3.4, 3.6, 1.6, 0, 0, TAU); ctx.fill();   // fluffy neck ruff
    ctx.fillStyle = '#d9806b'; ctx.beginPath(); ctx.arc(0, -5.6, 2.9, 0, TAU); ctx.fill();               // bald head
    ctx.fillStyle = '#c4604d'; ctx.beginPath(); ctx.arc(-0.8, -6.2, 1.6, 0, TAU); ctx.fill();
    ctx.fillStyle = '#f4d35e'; ctx.beginPath(); ctx.moveTo(1.8, -6.4); ctx.quadraticCurveTo(5.4, -6, 4.6, -3.6); ctx.quadraticCurveTo(3.4, -5, 1.8, -5); ctx.fill();   // hooked beak
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(0.6, -6.4, 0.9, 0, TAU); ctx.fill();
    ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(0.8, -6.4, 0.5, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#111'; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(-0.6, -7.6); ctx.lineTo(1.8, -7); ctx.stroke();
    ctx.strokeStyle = '#d4a017'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(-1.6, 4); ctx.lineTo(-1.8, 6.4); ctx.moveTo(1.6, 4); ctx.lineTo(1.8, 6.4); ctx.stroke();   // feet
    if (OPT.hats) drawSombrero(0, -8, 6.5, 0.08, 2);
    ctx.restore();
}