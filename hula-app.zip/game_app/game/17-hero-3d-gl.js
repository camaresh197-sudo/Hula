
// =====================================================================
//  HERO 3D: N64-style low-poly vaquero. Smooth-shaded meshes, bilinear/mipmapped textures,
//  lit by a key + fill + rim light, rendered with WebGL into a shared canvas and blitted into the 2D game.
// =====================================================================
const H3 = { ok: null, cv: null, gl: null, cw: 0, ch: 0, prog: null, U: {}, M: null, tex: new Map() };
const H3_VS = `attribute vec3 aP;attribute vec3 aN;attribute vec2 aUV;
uniform mat4 uM;uniform mat4 uVP;uniform mat3 uNM;
uniform float uBulge;uniform float uCm;uniform vec3 uCl;uniform vec2 uCw;uniform vec2 uAr;
uniform float uFn;uniform vec4 uFa[20];uniform vec4 uFb[20];
uniform float uSk;uniform mat4 uB0;uniform mat4 uB1;uniform mat4 uB2;uniform mat3 uN0;uniform mat3 uN1;uniform mat3 uN2;uniform float uBw;uniform vec3 uSw;
varying vec3 vN;varying vec3 vW;varying vec2 vUV;varying vec3 vL;
void main(){
  vec4 p=vec4(aP,1.0);vec3 n=aN;
  if(uFn>0.5){for(int i=0;i<20;i++){if(float(i)>=uFn)break;vec4 fa=uFa[i];vec3 fb=uFb[i].xyz;vec2 d=aP.xy-fa.xy;float s2=fa.z*fa.z;float w=exp(-dot(d,d)/(2.0*s2))*step(0.0,aP.z);p.xyz+=fb*w;n.xy+=fb.z*w*d/s2*1.6;}}   // face morph: expression-driven soft pushes of the skin (cheek lift, folds, brow bunching), each a gaussian bump in head space
  if(uSk>1.5){   // three bones (spine): blend widths around t = 1/3 and 2/3
    float t=aP.y;float w1=smoothstep(0.3333-uBw*0.5,0.3333+uBw*0.5,t);float w2=smoothstep(0.6667-uBw*0.5,0.6667+uBw*0.5,t);
    vec4 a=uB0*vec4(aP.x,3.0*t,aP.z,1.0);vec4 b=uB1*vec4(aP.x,3.0*t-1.0,aP.z,1.0);vec4 c=uB2*vec4(aP.x,3.0*t-2.0,aP.z,1.0);
    p=mix(mix(a,b,w1),c,w2);n=mix(mix(normalize(uN0*aN),normalize(uN1*aN),w1),normalize(uN2*aN),w2);
  } else if(uSk>0.5){
    float t=aP.y;float w=smoothstep(0.5-uBw,0.5+uBw,t);float rb=1.0+uBulge*4.0*w*(1.0-w);   // volume preservation at the joint (no candy-wrapper collapse)
    vec4 a=uB0*vec4(aP.x*rb,2.0*t,aP.z*rb,1.0);vec4 b=uB1*vec4(aP.x*rb,2.0*t-1.0,aP.z*rb,1.0);
    p=mix(a,b,w);n=mix(normalize(uN0*aN),normalize(uN1*aN),w);
  }
  if(uCm>3.5){   // hair: locks trail the head's motion with the same spring state as the cloth, tips most; the roots stay glued to the scalp
    float w=pow(aUV.y,1.5);p.xyz+=vec3(uCl.x*1.5,uCl.y*0.9,uCl.z*1.5)*w;p.x+=sin(uCw.y*1.3+aP.y*0.8+aP.z*0.5)*uCw.x*0.5*w;p.z+=cos(uCw.y*1.1+aP.y*0.7)*uCw.x*0.4*w;
  } else if(uCm>0.5){   // cheap cloth: spring-lagged displacement + hem flutter (1 poncho, 2 tassels, 3 hat brim)
    float ang=atan(aP.z,aP.x);float pc=ang*5.0+uCw.y;vec2 rd=normalize(aP.xz+vec2(0.001));
    if(uCm<1.5){float sd=aP.x>0.0?1.0:-1.0;float lf=sd>0.0?uAr.y:uAr.x;float ws=exp(-pow((abs(aP.x)-5.8)/3.3,2.0))*exp(-pow((aP.y-15.8)/2.8,2.0));p.x+=sd*(1.8+0.8*lf)*ws;p.y+=lf*2.0*ws;}   // the capelet rides over the shoulder cap and lifts with the arm
    if(uCm<2.5){float w=uCm<1.5?aUV.y*aUV.y:1.0;p.xyz+=vec3(uCl.x,uCl.y*0.6,uCl.z)*w;p.xz+=rd*uCw.x*w*sin(pc);n.xz+=rd*cos(pc)*uCw.x*w*1.2;}
    else{float w=smoothstep(7.0,14.5,length(aP.xz));p.y+=(uCl.y*0.8-aP.x/14.7*uCl.x*0.3+sin(ang*2.0+uCw.y)*uCw.x*0.35)*w;}
  }
  if(uSw.x!=0.0){p.x+=uSw.x*aUV.y*sin(uSw.y+aP.x*0.35);p.z+=uSw.x*0.5*aUV.y*sin(uSw.y*1.3+aP.x*0.5);}
  vec4 wp=uM*p;vW=wp.xyz;vN=uNM*n;vUV=aUV;vL=aP;gl_Position=uVP*wp;
}`;
const H3_FS = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec3 vN;varying vec3 vW;varying vec2 vUV;varying vec3 vL;uniform float uSkinD;uniform float uProj;uniform mat4 uHI;uniform vec2 uLidSh;
uniform sampler2D uTex;uniform float uUseTex;uniform vec3 uCol;uniform float uSpec;uniform float uShin;uniform float uRim;uniform float uHoop;uniform vec3 uH0;uniform vec3 uH1;uniform float uPh;uniform float uGlow;
uniform vec4 uBr;uniform vec4 uHd;uniform float uHQ;uniform sampler2D uNz;uniform vec3 uAS[6];uniform float uASr;
// skin micro-detail: three-component value noise (8 hashes) drives pore-scale bumps, fine grain and slow tone mottling
vec3 hs3(vec3 p){p=fract(p*vec3(0.1031,0.1030,0.0973));p+=dot(p,p.yxz+33.33);return fract((p.xxy+p.yxx)*p.zyx);}
vec3 vn3(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
  return mix(mix(mix(hs3(i),hs3(i+vec3(1,0,0)),f.x),mix(hs3(i+vec3(0,1,0)),hs3(i+vec3(1,1,0)),f.x),f.y),mix(mix(hs3(i+vec3(0,0,1)),hs3(i+vec3(1,0,1)),f.x),mix(hs3(i+vec3(0,1,1)),hs3(i+vec3(1,1,1)),f.x),f.y),f.z);}
// procedural studio environment: warm horizon, blue sky, ground bounce, two softboxes and a back strip; rg = roughness (0 mirror .. 1 diffuse irradiance)
vec3 env(vec3 d,float rg){
  float y=d.y;
  vec3 c=mix(vec3(0.34,0.24,0.20),vec3(0.95,0.78,0.62),smoothstep(-0.5,0.05,y));
  c=mix(c,mix(vec3(0.62,0.68,0.84),vec3(0.26,0.38,0.66),clamp(y,0.0,1.0)),smoothstep(0.0,0.75,y));
  c+=vec3(1.0,0.92,0.78)*pow(max(dot(d,vec3(-0.5,0.7,0.62)*0.99),0.0),mix(70.0,5.0,rg))*mix(2.4,0.5,rg);
  c+=vec3(0.45,0.6,1.0)*pow(max(dot(d,normalize(vec3(0.8,0.1,0.55))),0.0),mix(32.0,4.0,rg))*mix(1.3,0.35,rg);
  c+=vec3(0.75,0.82,1.0)*pow(max(dot(d,normalize(vec3(0.2,0.4,-0.9))),0.0),mix(24.0,4.0,rg))*mix(1.2,0.3,rg);
  return c;
}
// soft shadow of a capsule (an arm segment A-B, radius r) on point P toward the light: closest approach between the light ray and the segment, with a gate so a limb never shadows itself
float capSh(vec3 P,vec3 L,vec3 A,vec3 B,float r){
  vec3 ba=B-A,pa=P-A;float bb=dot(ba,ba),bl=dot(ba,L),lp=dot(L,pa);
  float s=clamp((dot(ba,pa)-bl*lp)/max(bb-bl*bl,1e-3),0.0,1.0);float t=max(lp-s*bl,0.0);
  float d=length(pa-ba*s-L*t);
  return 1.0-0.5*(1.0-smoothstep(r*0.35,r*1.7+t*0.1,d))*smoothstep(r*0.7,r*1.6,t);
}
// soft analytic shadows: the sombrero brim (a disc) and the head (a sphere) fall on whatever is below / behind them
float occl(vec3 P,vec3 L){
  float s=1.0;
  if(uBr.w>0.0){float yf=smoothstep(uBr.y-0.2,uBr.y-3.6,P.y);float t=max(uBr.y-P.y,0.0)/max(L.y,0.25);float d=length(P.xz+L.xz*t-uBr.xz);float w=3.2+0.9*t;s*=mix(1.0,smoothstep(uBr.w-w,uBr.w+w,d),0.34*yf);}
  if(uASr>0.0){s*=capSh(P,L,uAS[0],uAS[1],uASr)*capSh(P,L,uAS[1],uAS[2],uASr*0.82)*capSh(P,L,uAS[3],uAS[4],uASr)*capSh(P,L,uAS[4],uAS[5],uASr*0.82);}
  vec3 oc=P-uHd.xyz;float tca=-dot(oc,L);
  if(uHd.w>0.0&&tca>0.0){float d2=sqrt(max(dot(oc,oc)-tca*tca,0.0));s*=mix(1.0,smoothstep(uHd.w*0.55,uHd.w*1.2,d2),0.75);}
  return s;
}
void main(){
  vec3 N=normalize(vN);
  vec3 lp=vL,base;
  if(uProj>0.5){   // face add-ons (muscle bulges, folds, pads): sample the face texture at their head-space position, tinted by their colour, so they melt into the skin instead of sitting on it
    vec3 hp=(uHI*vec4(vW,1.0)).xyz;lp=hp;base=texture2D(uTex,vec2((hp.x+7.0)/14.0,(8.3-hp.y)/14.0)).rgb*uCol/vec3(0.66,0.44,0.29);
  } else base=uUseTex>0.5?texture2D(uTex,vUV).rgb:uCol;
  if(uLidSh.y>0.0){vec3 hq=(uHI*vec4(vW,1.0)).xyz;base*=1.0-uLidSh.y*smoothstep(uLidSh.x-0.7,uLidSh.x+0.03,hq.y);}   // shadow of the upper lid across the eyeball
  if(uSkinD>0.0){
    vec2 nq=lp.xy+lp.z*vec2(0.73,0.41);   // baked noise: four texture reads in place of ~30 hashes; mip-mapping also calms it down with distance
    vec3 a=texture2D(uNz,nq*(26.0/256.0)).rgb-0.5,b=texture2D(uNz,nq*(58.0/256.0)+0.31).rgb-0.5,c=texture2D(uNz,nq*(2.2/256.0)+0.7).rgb;
    N=normalize(N+(a*0.16+b*0.1)*uSkinD);   // pore-scale bump + fine grain
    float pore=smoothstep(0.34,0.5,texture2D(uNz,nq*(34.0/256.0)+0.13).g);base*=1.0-0.05*pore*uSkinD;   // dark pores
    base*=1.0+(c.x-0.5)*0.07*uSkinD;base+=vec3(0.03,-0.004,-0.012)*(c.y-0.45)*uSkinD;   // blotchy tone, redder / yellower patches
  }
  float Q=uHQ>0.5?(0.65+0.35*(uHQ-1.0)):0.0;
  if(uHoop>0.5){float tape=step(0.5,fract(vUV.x*22.0+uPh));base=mix(uH0,uH1,tape);}
  vec3 V=normalize(vec3(0.0,0.26,0.97));
  vec3 L=normalize(vec3(-0.5,0.7,0.62));
  float ndl=dot(N,L);float wrap=clamp((ndl+0.45)/1.45,0.0,1.0);wrap=wrap*wrap*(3.0-2.0*wrap);
  float sh=occl(vW,L);
  float metal=smoothstep(0.7,0.95,uSpec);
  float ao=mix(0.8,1.0,clamp(N.y*0.5+0.5,0.0,1.0));
  if(Q>0.0){   // contact occlusion: the dim pocket under the sombrero brim, and under the chin / around the collar
    float ub=0.0;if(uBr.w>0.0&&vW.y<uBr.y-0.25){ub=smoothstep(uBr.y-0.2,uBr.y-7.0,vW.y)*smoothstep(uBr.w*1.1,uBr.w*0.3,length(vW.xz-uBr.xz));}
    float ha=uHd.w>0.0?smoothstep(uHd.y-uHd.w*0.2,uHd.y-uHd.w*1.0,vW.y)*smoothstep(uHd.w*2.1,uHd.w*0.95,length(vW-uHd.xyz)):0.0;   // fades in with depth below the head centre (a hard cut here made a straight band across the face)
    ao*=(1.0-0.4*ub*Q)*(1.0-0.3*ha*Q);
  }
  vec3 diff=base*(env(N,1.0)*0.6+vec3(1.0,0.92,0.80)*wrap*0.9*sh)*ao*(1.0-0.7*metal);
  if(Q>0.0){float sss=smoothstep(-0.3,0.15,ndl)*(1.0-smoothstep(0.15,0.65,ndl));diff+=base*vec3(0.5,0.16,0.07)*sss*0.5*Q*(1.0-metal)*sh;}   // warm light bleeding through skin and cloth at the terminator
  float rg=clamp(1.0-uShin/42.0,0.0,1.0);
  float nv=max(dot(N,V),0.0);float fr=pow(1.0-nv,4.0);
  vec3 F0=mix(vec3(0.05),base*1.05,metal);vec3 F=F0+(vec3(1.0)-F0)*fr;
  vec3 refl=env(reflect(-V,N),rg)*F*(0.3+uSpec*0.9);
  vec3 lit=diff+refl*mix(0.55,1.0,metal);
  vec3 Hh=normalize(L+V);float sp=pow(max(dot(N,Hh),0.0),uShin)*uSpec*sh;lit+=vec3(1.0,0.96,0.86)*sp;
  float rim=pow(1.0-nv,2.6)*uRim;lit+=vec3(0.55,0.65,1.0)*rim*(0.5+0.5*max(N.y,0.0)+0.35*step(0.0,-ndl+0.8));
  if(Q>0.0){
    lit+=vec3(1.0,0.94,0.82)*pow(max(dot(N,Hh),0.0),max(uShin*0.2,2.0))*uSpec*0.22*sh*Q;   // soft second highlight lobe
    vec3 R2=normalize(vec3(-0.85,0.2,-0.5));lit+=vec3(1.0,0.72,0.48)*pow(max(dot(N,R2),0.0),2.0)*pow(1.0-nv,1.6)*uRim*1.3*Q;   // warm back-left rim to separate him from the dark
  }
  lit+=base*uGlow;
  vec3 col=lit*0.86;
  if(Q>0.0){vec3 x=col*1.05;vec3 a=clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14),0.0,1.0);col=mix(col,a,0.5*Q);col+=(fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453)-0.5)/255.0;}   // filmic roll-off + dither (no banding)
  gl_FragColor=vec4(col,1.0);
}`;
// post-processing: bright-pass, downsample, gaussian blur, composite (bloom + supersample resolve)
const H3_PVS = 'attribute vec2 aQ;varying vec2 vQ;void main(){vQ=aQ*0.5+0.5;gl_Position=vec4(aQ,0.0,1.0);}';
const H3_PFS = `precision mediump float;
varying vec2 vQ;uniform sampler2D uT0;uniform sampler2D uT1;uniform float uMode;uniform vec2 uSc;uniform vec2 uSc2;uniform vec2 uTx;uniform vec2 uTx2;uniform float uOff;uniform vec2 uDir;uniform float uG;uniform float uSS;
vec2 cl(vec2 p){return clamp(p,uTx*0.5,uSc-uTx*0.5);}
vec4 bp(vec2 p){vec4 c=texture2D(uT0,cl(p));float m=max(c.r,max(c.g,c.b))/max(c.a,0.001);float k=smoothstep(0.82,1.0,m);return vec4(c.rgb*k,c.a*k);}
void main(){
  vec2 uv=vQ*uSc;vec2 o=uTx*uOff;
  if(uMode<0.5){gl_FragColor=(bp(uv+vec2(-o.x,-o.y))+bp(uv+vec2(o.x,-o.y))+bp(uv+vec2(-o.x,o.y))+bp(uv+vec2(o.x,o.y)))*0.25;}
  else if(uMode<1.5){gl_FragColor=(texture2D(uT0,cl(uv+vec2(-o.x,-o.y)))+texture2D(uT0,cl(uv+vec2(o.x,-o.y)))+texture2D(uT0,cl(uv+vec2(-o.x,o.y)))+texture2D(uT0,cl(uv+vec2(o.x,o.y))))*0.25;}
  else if(uMode<2.5){
    vec2 d=uDir;vec4 c=texture2D(uT0,cl(uv))*0.2270;
    c+=(texture2D(uT0,cl(uv+d))+texture2D(uT0,cl(uv-d)))*0.1946;
    c+=(texture2D(uT0,cl(uv+d*2.0))+texture2D(uT0,cl(uv-d*2.0)))*0.1216;
    c+=(texture2D(uT0,cl(uv+d*3.0))+texture2D(uT0,cl(uv-d*3.0)))*0.0540;
    c+=(texture2D(uT0,cl(uv+d*4.0))+texture2D(uT0,cl(uv-d*4.0)))*0.0162;
    gl_FragColor=c;
  } else {
    vec2 e=uTx*uSS*0.25;vec4 s=(texture2D(uT0,cl(uv+vec2(-e.x,-e.y)))+texture2D(uT0,cl(uv+vec2(e.x,-e.y)))+texture2D(uT0,cl(uv+vec2(-e.x,e.y)))+texture2D(uT0,cl(uv+vec2(e.x,e.y))))*0.25;vec2 u2=clamp(vQ*uSc2,uTx2*0.5,uSc2-uTx2*0.5);vec4 g=texture2D(uT1,u2);
    gl_FragColor=vec4(min(s.rgb+g.rgb*uG,1.0),min(s.a+g.a*uG,1.0));
  }
}`;
// ---- tiny 4x4 matrix kit (column-major) ----
const m4 = {
    id: () => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1],
    mul(a, b) { const o = new Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3]; return o; },
    T: (x, y, z) => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1],
    S: (x, y, z) => [x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1],
    RX: a => { const c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]; },
    RY: a => { const c = Math.cos(a), s = Math.sin(a); return [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]; },
    RZ: a => { const c = Math.cos(a), s = Math.sin(a); return [c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; },
    chain(...ms) { let o = ms[0]; for (let i = 1; i < ms.length; i++) o = m4.mul(o, ms[i]); return o; },
    persp(fov, asp, n, f) { const t = 1 / Math.tan(fov / 2); return [t / asp, 0, 0, 0, 0, t, 0, 0, 0, 0, (f + n) / (n - f), -1, 0, 0, 2 * f * n / (n - f), 0]; },
    // twist-free frame: unit Y-segment (0..1) -> p0..p1, local X kept as close to `ref` as possible (so textures never spin as a limb bends)
    frame(p0, p1, rs, ref) {
        const dx = p1[0] - p0[0], dy = p1[1] - p0[1], dz = p1[2] - p0[2], L = Math.hypot(dx, dy, dz) || 1, yx = dx / L, yy = dy / L, yz = dz / L;
        let rx = ref[0], ry = ref[1], rz = ref[2], d = rx * yx + ry * yy + rz * yz; rx -= yx * d; ry -= yy * d; rz -= yz * d;
        let l = Math.hypot(rx, ry, rz); if (l < 1e-4) { rx = 0; ry = 0; rz = 1; d = yz; rx -= yx * d; ry -= yy * d; rz -= yz * d; l = Math.hypot(rx, ry, rz) || 1; }
        rx /= l; ry /= l; rz /= l;
        const zx = ry * yz - rz * yy, zy = rz * yx - rx * yz, zz = rx * yy - ry * yx;
        return [rx * rs, ry * rs, rz * rs, 0, yx * L, yy * L, yz * L, 0, zx * rs, zy * rs, zz * rs, 0, p0[0], p0[1], p0[2], 1];
    },
    // matrix taking a unit Y-segment (0..1) onto p0->p1, with the given radius scale
    seg(p0, p1, rs) {
        const dx = p1[0] - p0[0], dy = p1[1] - p0[1], dz = p1[2] - p0[2], L = Math.hypot(dx, dy, dz) || 1, ux = dx / L, uy = dy / L, uz = dz / L;
        // axis = Y x u, angle = acos(uy)
        let ax = uz, ay = 0, az = -ux, al = Math.hypot(ax, az);
        let R = m4.id();
        if (al > 1e-5) { ax /= al; az /= al; const c = uy, s = al, t = 1 - c; R = [t * ax * ax + c, t * ax * ay + az * s, t * ax * az - ay * s, 0, t * ax * ay - az * s, t * ay * ay + c, t * ay * az + ax * s, 0, t * ax * az + ay * s, t * ay * az - ax * s, t * az * az + c, 0, 0, 0, 0, 1]; }
        else if (uy < 0) R = m4.RX(Math.PI);
        return m4.chain(m4.T(p0[0], p0[1], p0[2]), R, m4.S(rs, L, rs));
    },
};
// two-bone IK: joint position for a chain a -> (joint) -> reach toward t with bone lengths l1,l2; pole picks the bend direction. returns {j, e} (joint, end effector)
function ik2(a, t, l1, l2, pole) {
    let dx = t[0] - a[0], dy = t[1] - a[1], dz = t[2] - a[2], D = Math.hypot(dx, dy, dz) || 1e-3; dx /= D; dy /= D; dz /= D;
    const Dc = Math.max(Math.abs(l1 - l2) + 0.05, Math.min(l1 + l2 - 0.05, D)), x = (l1 * l1 - l2 * l2 + Dc * Dc) / (2 * Dc), h = Math.sqrt(Math.max(l1 * l1 - x * x, 0));
    const pd = pole[0] * dx + pole[1] * dy + pole[2] * dz; let px = pole[0] - dx * pd, py = pole[1] - dy * pd, pz = pole[2] - dz * pd; const pl = Math.hypot(px, py, pz) || 1; px /= pl; py /= pl; pz /= pl;
    return { j: [a[0] + dx * x + px * h, a[1] + dy * x + py * h, a[2] + dz * x + pz * h], e: [a[0] + dx * Dc, a[1] + dy * Dc, a[2] + dz * Dc] };
}
function m4NormalMat(M) {   // inverse-transpose of the upper 3x3 (columns are the transformed basis vectors)
    const a = [M[0], M[1], M[2]], b = [M[4], M[5], M[6]], c = [M[8], M[9], M[10]];
    const cr = (u, v) => [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    const bc = cr(b, c), ca = cr(c, a), ab = cr(a, b);
    const sg = a[0] * bc[0] + a[1] * bc[1] + a[2] * bc[2] < 0 ? -1 : 1;   // mirrored matrices flip the cofactor
    return [bc[0] * sg, bc[1] * sg, bc[2] * sg, ca[0] * sg, ca[1] * sg, ca[2] * sg, ab[0] * sg, ab[1] * sg, ab[2] * sg];   // cofactor matrix == inv-transpose up to a scalar (normalised in the shader)
}
const _nm3 = new Float32Array(9);
function m4NormalInto(M) {   // same as m4NormalMat but writes into one scratch array (the GL upload copies it immediately)
    const ax = M[0], ay = M[1], az = M[2], bx = M[4], by = M[5], bz = M[6], cx = M[8], cy = M[9], cz = M[10];
    const b0 = by * cz - bz * cy, b1 = bz * cx - bx * cz, b2 = bx * cy - by * cx, sg = ax * b0 + ay * b1 + az * b2 < 0 ? -1 : 1, o = _nm3;
    o[0] = b0 * sg; o[1] = b1 * sg; o[2] = b2 * sg;
    o[3] = (cy * az - cz * ay) * sg; o[4] = (cz * ax - cx * az) * sg; o[5] = (cx * ay - cy * ax) * sg;
    o[6] = (ay * bz - az * by) * sg; o[7] = (az * bx - ax * bz) * sg; o[8] = (ax * by - ay * bx) * sg;
    return o;
}
function m4Inv(m) {   // general 4x4 inverse (column-major), for mapping world positions back into head space
    const a = m, o = new Float32Array(16);
    const b00 = a[0] * a[5] - a[1] * a[4], b01 = a[0] * a[6] - a[2] * a[4], b02 = a[0] * a[7] - a[3] * a[4], b03 = a[1] * a[6] - a[2] * a[5], b04 = a[1] * a[7] - a[3] * a[5], b05 = a[2] * a[7] - a[3] * a[6];
    const b06 = a[8] * a[13] - a[9] * a[12], b07 = a[8] * a[14] - a[10] * a[12], b08 = a[8] * a[15] - a[11] * a[12], b09 = a[9] * a[14] - a[10] * a[13], b10 = a[9] * a[15] - a[11] * a[13], b11 = a[10] * a[15] - a[11] * a[14];
    let d = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06; d = d ? 1 / d : 0;
    o[0] = (a[5] * b11 - a[6] * b10 + a[7] * b09) * d; o[1] = (a[2] * b10 - a[1] * b11 - a[3] * b09) * d; o[2] = (a[13] * b05 - a[14] * b04 + a[15] * b03) * d; o[3] = (a[10] * b04 - a[9] * b05 - a[11] * b03) * d;
    o[4] = (a[6] * b08 - a[4] * b11 - a[7] * b07) * d; o[5] = (a[0] * b11 - a[2] * b08 + a[3] * b07) * d; o[6] = (a[14] * b02 - a[12] * b05 - a[15] * b01) * d; o[7] = (a[8] * b05 - a[10] * b02 + a[11] * b01) * d;
    o[8] = (a[4] * b10 - a[5] * b08 + a[7] * b06) * d; o[9] = (a[1] * b08 - a[0] * b10 - a[3] * b06) * d; o[10] = (a[12] * b04 - a[13] * b02 + a[15] * b00) * d; o[11] = (a[9] * b02 - a[8] * b04 - a[11] * b00) * d;
    o[12] = (a[5] * b07 - a[4] * b09 - a[6] * b06) * d; o[13] = (a[0] * b09 - a[1] * b07 + a[2] * b06) * d; o[14] = (a[13] * b01 - a[12] * b03 - a[14] * b00) * d; o[15] = (a[8] * b03 - a[9] * b01 + a[10] * b00) * d;
    return o;
}
// ---- mesh builders: vertex = [px,py,pz, nx,ny,nz, u,v] ----
function h3Up(V, I) {
    if (H3.raw) return { V, I };
    const gl = H3.gl, vb = gl.createBuffer(), ib = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(V), gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(I), gl.STATIC_DRAW);
    return { vb, ib, n: I.length };
}
function h3Grid(V, I, nu, nv, f) {
    const b = V.length / 8;
    for (let j = 0; j <= nv; j++) for (let i = 0; i <= nu; i++) { const v = f(i / nu, j / nv), l = Math.hypot(v[3], v[4], v[5]) || 1; V.push(v[0], v[1], v[2], v[3] / l, v[4] / l, v[5] / l, v[6], v[7]); }
    for (let j = 0; j < nv; j++) for (let i = 0; i < nu; i++) { const a = b + j * (nu + 1) + i, c = a + nu + 1; I.push(a, c, a + 1, a + 1, c, c + 1); }
}
function mkEllipsoid(rx, ry, rz, nu = 22, nv = 14, uvf) {
    const V = [], I = [];
    h3Grid(V, I, nu, nv, (u, v) => { const ph = u * TAU, th = v * Math.PI, x = rx * Math.sin(th) * Math.cos(ph), y = ry * Math.cos(th), z = rz * Math.sin(th) * Math.sin(ph); const uv = uvf ? uvf(x, y, z) : [u, v]; return [x, y, z, x / (rx * rx), y / (ry * ry), z / (rz * rz), uv[0], uv[1]]; });
    return h3Up(V, I);
}
function headW(y) {   // head width profile by height (head-local): slightly narrow crown, cheekbone swell, firm jaw angle, then a defined chin
    const t = Math.max(-1, Math.min(1, -y / 6.5)), sm = (a, b, v) => { const q = Math.max(0, Math.min(1, (v - a) / (b - a))); return q * q * (3 - 2 * q); };
    if (t <= 0) return 1 - 0.1 * t * t;
    return (1 + 0.04 * Math.sin(Math.PI * Math.min(1, t / 0.5)) + 0.045 * Math.sin(Math.PI * Math.min(1, Math.max(0, (t - 0.3) / 0.5))) - 0.02 * t) * (1 - 0.36 * Math.pow(sm(0.66, 1.0, t), 1.05));
}
function mkSuper(rx, ry, rz, n1, n2, nu = 28, nv = 20, uvf, tap = 0) {   // squarish rounded head: flatter front than a sphere, so the face texture stays readable
    const V = [], I = [], sp = (v, e) => Math.sign(v) * Math.pow(Math.abs(v), e);
    h3Grid(V, I, nu, nv, (u, v) => {
        const ph = u * TAU, th = v * Math.PI, ct = Math.cos(th), st = Math.sin(th), cp = Math.cos(ph), sn = Math.sin(ph);
        const y = ry * sp(ct, 2 / n1), tp = tap ? headW(y) : 1, x = rx * tp * sp(st, 2 / n1) * sp(cp, 2 / n2), z = rz * tp * sp(st, 2 / n1) * sp(sn, 2 / n2);
        const ax = Math.abs(x / (rx * tp)), az = Math.abs(z / (rz * tp)), ay = Math.abs(y / ry), A = Math.pow(ax, n2) + Math.pow(az, n2), k = A > 1e-9 ? n1 * Math.pow(A, n1 / n2 - 1) : 0;
        const nx = k * Math.pow(ax, n2 - 1) * Math.sign(x) / rx, ny = n1 * Math.pow(ay, n1 - 1) * Math.sign(y) / ry, nz = k * Math.pow(az, n2 - 1) * Math.sign(z) / rz, uv = uvf ? uvf(x, y, z) : [u, v];
        return [x, y, z, nx, ny, nz, uv[0], uv[1]];
    });
    return h3Up(V, I);
}
function mkFrustum(r0, r1, nu = 14, nz = 1) {   // unit-height tube along +Y, optional z squash (nz)
    const V = [], I = [];
    h3Grid(V, I, nu, 1, (u, v) => { const a = u * TAU, r = r0 + (r1 - r0) * v; return [r * Math.cos(a), v, r * Math.sin(a) * nz, Math.cos(a), r0 - r1, Math.sin(a) / nz, u, v]; });
    return h3Up(V, I);
}
function mkParam(nu, nv, f, sg = 1) {   // parametric surface f(u,v)->[x,y,z,u,v]; normals by finite differences (sg flips)
    const V = [], I = [], e = 1e-3;
    h3Grid(V, I, nu, nv, (u, v) => {
        const p = f(u, v), a0 = f(u - e, v), a1 = f(u + e, v), b0 = f(u, Math.max(0, v - e)), b1 = f(u, Math.min(1, v + e));
        const ax = a1[0] - a0[0], ay = a1[1] - a0[1], az = a1[2] - a0[2], bx = b1[0] - b0[0], by = b1[1] - b0[1], bz = b1[2] - b0[2];
        return [p[0], p[1], p[2], sg * (by * az - bz * ay), sg * (bz * ax - bx * az), sg * (bx * ay - by * ax), p[3], p[4]];
    });
    return h3Up(V, I);
}
function crPt(P, t) {   // Catmull-Rom through profile points, t in 0..1
    const n = P.length - 1, x = Math.max(0, Math.min(0.99999, t)) * n, i = Math.floor(x), f = x - i, g = k => P[Math.max(0, Math.min(n, k))];
    const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2), c = k => 0.5 * ((2 * p1[k]) + (-p0[k] + p2[k]) * f + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * f * f + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * f * f * f);
    return [c(0), c(1)];
}
function mkTubes(list, nu) {   // list of {pts:[[x,y,z]..], rad:[..]} -> one static mesh of tapered tubes (twist-free frames)
    const V = [], I = [];
    for (const T of list) {
        const b = V.length / 8, n = T.pts.length;
        for (let i = 0; i < n; i++) {
            const p = T.pts[i], q0 = T.pts[Math.max(0, i - 1)], q1 = T.pts[Math.min(n - 1, i + 1)];
            let tx = q1[0] - q0[0], ty = q1[1] - q0[1], tz = q1[2] - q0[2]; const tl = Math.hypot(tx, ty, tz) || 1; tx /= tl; ty /= tl; tz /= tl;
            let rx = 1 - tx * tx, ry = -tx * ty, rz = -tx * tz; let rl = Math.hypot(rx, ry, rz); if (rl < 1e-3) { rx = 0; ry = 0; rz = 1; rl = 1; } rx /= rl; ry /= rl; rz /= rl;
            const sx = ty * rz - tz * ry, sy = tz * rx - tx * rz, sz = tx * ry - ty * rx;
            for (let j = 0; j <= nu; j++) { const a = j / nu * TAU, c = Math.cos(a), sn = Math.sin(a), nx = rx * c + sx * sn, ny = ry * c + sy * sn, nz = rz * c + sz * sn, r = T.rad[i]; V.push(p[0] + nx * r, p[1] + ny * r, p[2] + nz * r, nx, ny, nz, j / nu, i / (n - 1)); }
        }
        for (let i = 0; i < n - 1; i++) for (let j = 0; j < nu; j++) { const a = b + i * (nu + 1) + j, c = a + nu + 1; I.push(a, c, a + 1, a + 1, c, c + 1); }
    }
    return h3Up(V, I);
}
let H3ROOT = null;   // whole-body transform (break-dance spin / worm); folded into every draw
const H3AS = new Float32Array(18), H3WR = [{}, {}], H3CP = [[0, 0, 0], [0, 0, 0]], H3HJ = [0, 0, 0], H3MF = [0, 0], H3MT = {};   // H3HJ: how far the joint pinch sits from where the old palm grip was, so the wrist target can compensate and the joint still meets the lips
function limbGeo(V, I, prof, ky, nu, nt, us, ox, oz) {   // skinned tube: y = t in 0..1 (the shader bends it at t = .5); ky = world length per unit t (for the tip normals)
    const e = 0.02;
    h3Grid(V, I, nu, nt, (u, v) => {
        const a = (u + us) * TAU, c = Math.cos(a), sn = Math.sin(a), r = prof(v), v0 = Math.max(0, v - e), v1 = Math.min(1, v + e), dr = (prof(v1) - prof(v0)) / (v1 - v0), nl = Math.hypot(1, dr / ky);
        return [ox + r * c, v, oz + r * sn, c / nl, -dr / ky / nl, sn / nl, u, v];
    });
}
function mkLimb(prof, ky, nu = 14, nt = 16, us = 0) { const V = [], I = []; limbGeo(V, I, prof, ky, nu, nt, us, 0, 0); return h3Up(V, I); }
function mkLoop(rx, rz, tr, nu = 28, nv = 8) {   // torus with elliptical major circle (in XZ)
    const V = [], I = [];
    h3Grid(V, I, nu, nv, (u, v) => { const a = u * TAU, b = v * TAU, ox = Math.cos(a), oz = Math.sin(a), cx = rx * ox, cz = rz * oz, k = Math.cos(b), s = Math.sin(b); return [cx + tr * k * ox, tr * s, cz + tr * k * oz, k * ox, s, k * oz, u, v]; });
    return h3Up(V, I);
}
function mkLathe(prof, sgn, nu = 28) {   // revolve [r,y] points around Y; sgn picks which side the normal faces
    const V = [], I = [], n = prof.length;
    h3Grid(V, I, nu, n - 1, (u, v) => {
        const k = Math.min(n - 1, Math.round(v * (n - 1))), p = prof[k], q0 = prof[Math.max(0, k - 1)], q1 = prof[Math.min(n - 1, k + 1)], dr = q1[0] - q0[0], dy = q1[1] - q0[1], a = u * TAU;
        let nr = sgn * dy, ny = -sgn * dr; return [p[0] * Math.cos(a), p[1], p[0] * Math.sin(a), nr * Math.cos(a), ny, nr * Math.sin(a), u, v];
    });
    return h3Up(V, I);
}
function mkBox(w, h, d) {
    const V = [], I = [], x = w / 2, y = h / 2, z = d / 2, F = [[[0, 0, 1], [-x, -y, z], [x, -y, z], [x, y, z], [-x, y, z]], [[0, 0, -1], [x, -y, -z], [-x, -y, -z], [-x, y, -z], [x, y, -z]], [[1, 0, 0], [x, -y, z], [x, -y, -z], [x, y, -z], [x, y, z]], [[-1, 0, 0], [-x, -y, -z], [-x, -y, z], [-x, y, z], [-x, y, -z]], [[0, 1, 0], [-x, y, z], [x, y, z], [x, y, -z], [-x, y, -z]], [[0, -1, 0], [-x, -y, -z], [x, -y, -z], [x, -y, z], [-x, -y, z]]];
    for (const f of F) { const b = V.length / 8; f.slice(1).forEach((p, i) => V.push(p[0], p[1], p[2], f[0][0], f[0][1], f[0][2], i === 1 || i === 2 ? 1 : 0, i >= 2 ? 1 : 0)); I.push(b, b + 1, b + 2, b, b + 2, b + 3); }
    return h3Up(V, I);
}
// ---- textures painted with the 2D canvas, then uploaded (mipmapped, repeat, bilinear like an N64 would want) ----
function h3Tex(key, w, h, paint) {
    let t = H3.tex.get(key); if (t) return t;
    if (H3.tex.size > 56) { let n = 0; for (const [k, v] of H3.tex) { if (n++ >= 28) break; H3.gl.deleteTexture(v); H3.tex.delete(k); } }
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    const prev = ctx; ctx = cv.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0);
    try { paint(w, h); } finally { ctx = prev; }
    const gl = H3.gl; t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, cv);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const ext = gl.getExtension('EXT_texture_filter_anisotropic'); if (ext) gl.texParameterf(gl.TEXTURE_2D, ext.TEXTURE_MAX_ANISOTROPY_EXT, 4);
    H3.tex.set(key, t); return t;
}
function cssRgb(c) {
    if (c[0] === '#') { const r = hexToRgb(c); return [r[0] / 255, r[1] / 255, r[2] / 255]; }
    const m = /hsl\(([\d.]+),\s*([\d.]+)%,\s*([\d.]+)%\)/.exec(c);
    if (m) { const h = +m[1] / 360, s = +m[2] / 100, l = +m[3] / 100, q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q, f = t => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; }; return [f(h + 1 / 3), f(h), f(h - 1 / 3)]; }
    const r = /(\d+),\s*(\d+),\s*(\d+)/.exec(c); return r ? [r[1] / 255, r[2] / 255, r[3] / 255] : [1, 0, 1];
}
function h3Merged(list) {   // list of [builder, matrix]: bake many small static meshes into one draw call
    const V = [], I = [];
    for (const [fn, M] of list) {
        H3.raw = true; let r; try { r = fn(); } finally { H3.raw = false; }
        const nm = m4NormalMat(M), b = V.length / 8;
        for (let i = 0; i < r.V.length; i += 8) {
            const x = r.V[i], y = r.V[i + 1], z = r.V[i + 2], nx = r.V[i + 3], ny = r.V[i + 4], nz = r.V[i + 5];
            let ox = nm[0] * nx + nm[3] * ny + nm[6] * nz, oy = nm[1] * nx + nm[4] * ny + nm[7] * nz, oz = nm[2] * nx + nm[5] * ny + nm[8] * nz; const l = Math.hypot(ox, oy, oz) || 1;
            V.push(M[0] * x + M[4] * y + M[8] * z + M[12], M[1] * x + M[5] * y + M[9] * z + M[13], M[2] * x + M[6] * y + M[10] * z + M[14], ox / l, oy / l, oz / l, r.V[i + 6], r.V[i + 7]);
        }
        for (const k of r.I) I.push(k + b);
    }
    return h3Up(V, I);
}
// ---- texture painters ----
function txEye(w, h) {   // equirect eyeball: iris centred on the +Z pole (u .25, v .5); clean, readable stylised eye (the pupil itself is geometry so it can dilate)
    const F = w / 1024; ctx.save(); ctx.scale(F, F); w = 1024; h = 512;
    const R = mulberry(5), cx = w * 0.25, cy = h * 0.5, ir = w * 0.104, TA = Math.PI * 2;
    ctx.fillStyle = '#f8f4ec'; ctx.fillRect(0, 0, w, h);
    const sg = ctx.createRadialGradient(cx, cy, ir * 1.3, cx, cy, ir * 5.2); sg.addColorStop(0, 'rgba(255,252,246,0)'); sg.addColorStop(1, 'rgba(226,200,176,0.35)');
    ctx.fillStyle = sg; ctx.fillRect(0, 0, w, h);
    const sg2 = ctx.createRadialGradient(w * 0.75, cy, ir * 1.3, w * 0.75, cy, ir * 5.2); sg2.addColorStop(0, 'rgba(255,252,246,0)'); sg2.addColorStop(1, 'rgba(226,200,176,0.35)'); ctx.fillStyle = sg2; ctx.fillRect(0, 0, w, h);
    ctx.lineCap = 'round';
    for (let k = 0; k < 10; k++) { const dir = k % 2 ? -1 : 1, x0 = cx + dir * ir * (2.6 + R() * 1.2), y0 = cy + (R() - 0.5) * ir * 1.6; ctx.strokeStyle = 'rgba(190,90,80,0.06)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.quadraticCurveTo(x0 - dir * ir * 0.6, y0 + (R() - 0.5) * ir * 0.5, x0 - dir * ir * 1.2, y0 + (R() - 0.5) * ir * 0.4); ctx.stroke(); }
    let g = ctx.createRadialGradient(cx, cy, ir * 0.92, cx, cy, ir * 1.14); g.addColorStop(0, 'rgba(30,18,10,0.35)'); g.addColorStop(1, 'rgba(30,18,10,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, ir * 1.14, 0, TA); ctx.fill();   // soft limbal shadow
    g = ctx.createRadialGradient(cx, cy, ir * 0.2, cx, cy, ir); g.addColorStop(0, '#e0a552'); g.addColorStop(0.4, '#b8742e'); g.addColorStop(0.75, '#7c4a20'); g.addColorStop(1, '#4a2c14'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, ir, 0, TA); ctx.fill();
    for (let k = 0; k < 140; k++) {   // soft radial fibres
        const a = R() * TA, r0 = ir * (0.32 + R() * 0.1), r1 = ir * (0.7 + R() * 0.28);
        ctx.strokeStyle = R() < 0.55 ? 'rgba(244,206,128,' + (0.1 + R() * 0.12) + ')' : 'rgba(50,26,10,' + (0.08 + R() * 0.1) + ')'; ctx.lineWidth = 0.8 + R() * 0.8;
        ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); ctx.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(40,22,10,0.4)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, ir * 0.985, 0, TA); ctx.stroke();   // clean limbal edge
    g = ctx.createRadialGradient(cx, cy, ir * 0.18, cx, cy, ir * 0.46); g.addColorStop(0, 'rgba(8,4,2,1)'); g.addColorStop(1, 'rgba(8,4,2,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, ir * 0.46, 0, TA); ctx.fill();   // pupil falloff
    ctx.fillStyle = '#060302'; ctx.beginPath(); ctx.arc(cx, cy, ir * 0.26, 0, TA); ctx.fill();
    ctx.restore();
}
function txLid(w, h) {   // v: 0 = lid top .. 1 = lid edge (lash line)
    ctx.fillStyle = '#a56a45'; ctx.fillRect(0, 0, w, h);
    const g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0.7, 'rgba(60,28,14,0)'); g.addColorStop(0.9, 'rgba(60,28,14,0.35)'); g.addColorStop(0.96, 'rgba(40,20,10,0.6)'); g.addColorStop(1, 'rgba(30,14,8,0.8)'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
}
function txPoncho(w, h) {   // u = around (46 units), v = top->bottom (y2d -18..4.4)
    ctx.scale(w / 46, h / 22.4); ctx.translate(0, 18);
    const R = mulberry(37), body = ctx.createLinearGradient(0, -18, 0, 4.4); body.addColorStop(0, '#ef5d4c'); body.addColorStop(0.6, '#c0392b'); body.addColorStop(1, '#8f261c');
    ctx.fillStyle = body; ctx.fillRect(0, -18, 46, 23);
    for (let y = -18; y < 4.4; y += 0.3) { ctx.strokeStyle = (y * 10 | 0) % 2 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.1)'; ctx.lineWidth = 0.1; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(46, y); ctx.stroke(); }
    for (let x = 0; x < 46; x += 0.4) ln(x, -18, x, 4.4, 0.08, 'rgba(0,0,0,0.07)');
    const band = (y, hh, c) => { ctx.fillStyle = c; ctx.fillRect(0, y, 46, hh); ln(0, y, 46, y, 0.15, 'rgba(0,0,0,0.3)'); ln(0, y + hh, 46, y + hh, 0.15, 'rgba(255,255,255,0.25)'); };
    band(-4.4, 2, '#f1c40f'); band(-8.2, 1.7, '#27ae60'); band(-12, 1.3, '#2980b9'); band(-15.2, 0.8, '#f1e6c8');
    for (let r = 0; r < 4; r++) for (let k = 0; k < 46; k += 1.7) { if (r === 1) continue; const cx = k + (r % 2) * 0.85, cy = -3.5 - r * 3.9; ctx.fillStyle = r % 2 ? '#fff6d8' : '#16a085'; ctx.beginPath(); ctx.moveTo(cx, cy - 0.7); ctx.lineTo(cx + 0.6, cy); ctx.lineTo(cx, cy + 0.7); ctx.lineTo(cx - 0.6, cy); ctx.fill(); dot(cx, cy, 0.16, '#7d1f17'); }
    ctx.strokeStyle = '#fff6d8'; ctx.lineWidth = 0.24; ctx.beginPath(); for (let k = 0; k < 46; k += 1.15) ctx.lineTo(k, -6.1 - ((k / 1.15 | 0) % 2) * 0.7); ctx.stroke();
    ctx.fillStyle = '#f1e6c8'; ctx.fillRect(0, 2.2, 46, 1.9); for (let k = 0; k < 46; k += 1.2) { ctx.fillStyle = (k / 1.2 | 0) % 2 ? '#c0392b' : '#27ae60'; ctx.fillRect(k, 2.4, 0.6, 1.3); }
    ctx.fillStyle = '#8f261c'; ctx.fillRect(0, 4.1, 46, 0.4);
    for (let k = 0; k < 220; k++) dot(R() * 46, -18 + R() * 22, 0.1, R() < 0.5 ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.14)');
}
function txBoot(c) {   // polished black charro boot leather with fine stitching and a gold-thread flourish
    return (w, h) => {
        ctx.scale(w / 16, h / 8); const R = mulberry(23), g = ctx.createLinearGradient(0, 0, 0, 8);
        g.addColorStop(0, '#3a302c'); g.addColorStop(0.35, '#1d1614'); g.addColorStop(0.75, '#0f0a09'); g.addColorStop(1, '#070504'); ctx.fillStyle = g; ctx.fillRect(0, 0, 16, 8);
        for (let k = 0; k < 40; k++) { const x = R() * 16, y = R() * 8; ln(x, y, x + 1.5 + R() * 2.5, y + (R() - 0.5) * 0.4, 0.12, 'rgba(255,240,230,0.07)'); }   // polish streaks
        for (let k = 0; k < 160; k++) dot(R() * 16, R() * 8, 0.07, R() < 0.5 ? 'rgba(255,240,230,0.09)' : 'rgba(0,0,0,0.3)');
        ctx.strokeStyle = 'rgba(210,170,80,0.75)'; ctx.lineWidth = 0.12; ctx.setLineDash([0.35, 0.25]); ctx.beginPath(); ctx.moveTo(0, 0.9); ctx.lineTo(16, 0.9); ctx.moveTo(0, 7.1); ctx.lineTo(16, 7.1); ctx.stroke(); ctx.setLineDash([]);
        ctx.strokeStyle = 'rgba(201,162,74,0.9)'; ctx.lineWidth = 0.16; for (const x0 of [4, 12]) { ctx.beginPath(); ctx.moveTo(x0, 6.2); ctx.bezierCurveTo(x0 - 1.2, 4.4, x0 + 1.2, 3.2, x0, 1.8); ctx.stroke(); dot(x0, 1.7, 0.22, '#c9a24a'); }
        ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(0, 0, 16, 0.5);
    };
}

function chHorizVine(x0, x1, yc, amp, s, ph) {   // a vine run sideways along a band
    ctx.save(); ctx.rotate(-Math.PI / 2); chVine(-yc, x0, x1, amp, s, ph, true); ctx.restore();
}
function txStraw(base, trim) {   // brim: felt with a gold scroll embroidered round the outer top (and the same underneath), a braided rim
    return (w, h) => {
        const R = mulberry(53); ctx.fillStyle = base; ctx.fillRect(0, 0, w, h);
        for (let k = 0; k < 2200; k++) { const x = R() * w, y = R() * h; ln(x, y, x + (R() - 0.5) * 3, y + (R() - 0.5) * 3, 0.8, R() < 0.5 ? 'rgba(255,248,230,0.16)' : 'rgba(40,24,6,0.13)'); }
        for (const [a, b] of [[0.2, 0.46], [0.54, 0.8]]) {
            const yc = h * (a + b) / 2, hh = h * (b - a) / 2;
            ctx.fillStyle = 'rgba(0,0,0,0.07)'; ctx.fillRect(0, yc - hh, w, hh * 2);
            for (const o of [-1, 1]) { ln(0, yc + o * hh, w, yc + o * hh, 3.2, 'rgba(60,40,8,0.8)'); ln(0, yc + o * hh, w, yc + o * hh, 2, trim); ln(0, yc + o * (hh - 3.5), w, yc + o * (hh - 3.5), 1, trim); }
            ctx.save(); chHorizVine(0, w, yc, hh * 0.36, 0.5, 0); ctx.restore();
        }
        ln(0, h * 0.5, w, h * 0.5, 4, 'rgba(60,40,8,0.8)'); ln(0, h * 0.5, w, h * 0.5, 2.6, trim);   // braid on the rim
        for (let x = 0; x < w; x += 6) ln(x, h * 0.5 - 1.5, x + 3, h * 0.5 + 1.5, 0.8, 'rgba(255,240,170,0.8)');
    };
}
function txCrown(base, trim) {   // crown: felt, a row of gold scrolls above the band, a rosette on top
    return (w, h) => {
        const R = mulberry(57); ctx.fillStyle = base; ctx.fillRect(0, 0, w, h);
        for (let k = 0; k < 2200; k++) { const x = R() * w, y = R() * h; ln(x, y, x + (R() - 0.5) * 3, y + (R() - 0.5) * 3, 0.8, R() < 0.5 ? 'rgba(255,248,230,0.16)' : 'rgba(40,24,6,0.13)'); }
        for (const yc of [h * 0.2, h * 0.5, h * 0.8]) {
            const hh = h * 0.1;
            for (const o of [-1, 1]) { ln(0, yc + o * hh, w, yc + o * hh, 3, 'rgba(60,40,8,0.8)'); ln(0, yc + o * hh, w, yc + o * hh, 1.8, trim); }
            chHorizVine(0, w, yc, hh * 0.4, 0.4, 1);
        }
    };
}
function txBand(band, trim) {
    return (w, h) => {
        ctx.fillStyle = band; ctx.fillRect(0, 0, w, h); ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.fillRect(0, h * 0.7, w, h * 0.3);
        ctx.strokeStyle = trim; ctx.lineWidth = 2; for (let k = 0; k < 26; k++) { const x = k * w / 26; ctx.beginPath(); ctx.moveTo(x, h * 0.15); ctx.lineTo(x + w / 52, h * 0.55); ctx.moveTo(x + w / 52, h * 0.15); ctx.lineTo(x, h * 0.55); ctx.stroke(); }
        ctx.fillStyle = trim; ctx.fillRect(0, 0, w, 3); ctx.fillRect(0, h - 3, w, 3);
    };
}
function txBandolier(w, h) {
    ctx.fillStyle = '#4a2f16'; ctx.fillRect(0, 0, w, h); const R = mulberry(5);
    for (let k = 0; k < 120; k++) dot(R() * w, R() * h, 0.9, R() < 0.5 ? 'rgba(0,0,0,0.2)' : 'rgba(255,230,190,0.16)');
    ctx.strokeStyle = 'rgba(255,224,160,0.55)'; ctx.lineWidth = 1.2; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(0, 4); ctx.lineTo(w, 4); ctx.moveTo(0, h - 4); ctx.lineTo(w, h - 4); ctx.stroke(); ctx.setLineDash([]);
    for (let k = 0; k < 14; k++) { const x = (k + 0.5) * w / 14; ctx.fillStyle = '#2a1808'; ctx.fillRect(x - 6, 8, 12, h - 16); const g = ctx.createLinearGradient(x - 5, 0, x + 5, 0); g.addColorStop(0, '#a07a1e'); g.addColorStop(0.4, '#f5d76e'); g.addColorStop(1, '#8a6414'); ctx.fillStyle = g; ctx.fillRect(x - 5, 10, 10, h * 0.55); ctx.fillStyle = '#c47a3a'; ctx.beginPath(); ctx.moveTo(x - 5, 10); ctx.lineTo(x, 3); ctx.lineTo(x + 5, 10); ctx.fill(); dot(x - 1.5, 18, 1.2, '#fff'); }
}
function txBandana(w, h) {
    ctx.fillStyle = '#d0182f'; ctx.fillRect(0, 0, w, h); const R = mulberry(9);
    for (let k = 0; k < 14; k++) { dot(R() * w, R() * h, 3.2, '#fff'); }
    for (let k = 0; k < 40; k++) ln(R() * w, R() * h, R() * w, R() * h, 0.8, 'rgba(0,0,0,0.12)');
}
// body tables: uniform knots, Catmull-Rom (crPt). Torso top y 17.6 -> hip y -3.8; capelet y 17.7 -> 12.0
const TOR_X = [[0, 2.5], [0, 6.2], [0, 6.7], [0, 6.0], [0, 5.2], [0, 4.5], [0, 4.15], [0, 4.2], [0, 4.5], [0, 4.8], [0, 4.9]], TOR_Z = [[0, 2.2], [0, 3.0], [0, 3.5], [0, 3.7], [0, 3.35], [0, 3.0], [0, 2.8], [0, 2.9], [0, 3.1], [0, 3.2], [0, 3.3]];
const CAPE_X = [[0, 3.0], [0, 6.9], [0, 8.3], [0, 8.6]], CAPE_Z = [[0, 2.5], [0, 3.8], [0, 4.7], [0, 4.95]];

const CH_G = '#c9a24a', CH_GD = '#5b3f0e', CH_GH = '#f2dc8e';
function chLeaf(x, y, a, l, wd, s) {   // gold satin-stitch leaf with a shadow and a pale vein
    ctx.save(); ctx.translate(x, y); ctx.rotate(a);
    for (const [o, c] of [[1.6 * s, CH_GD], [0, CH_G]]) { ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(o, o); ctx.quadraticCurveTo(l * 0.5 + o, -wd + o, l + o, o); ctx.quadraticCurveTo(l * 0.5 + o, wd + o, o, o); ctx.fill(); }
    ctx.strokeStyle = CH_GH; ctx.globalAlpha = 0.7; ctx.lineWidth = 0.9 * s; ctx.beginPath(); ctx.moveTo(l * 0.1, 0); ctx.lineTo(l * 0.88, 0); ctx.stroke(); ctx.globalAlpha = 1; ctx.restore();
}
function chFlower(x, y, r, s, a0) {   // eight-petal flower
    for (let k = 0; k < 8; k++) chLeaf(x, y, a0 + k * TAU / 8, r, r * 0.33, s);
    dot(x + 1.2 * s, y + 1.2 * s, r * 0.24, CH_GD); dot(x, y, r * 0.24, CH_GH); dot(x - 0.25 * r * 0.2, y - 0.25 * r * 0.2, r * 0.1, '#fff6c8');
}
function chVine(x, y0, y1, amp, s, ph, fl) {   // a climbing vine: wavy stem, paired leaves, a flower now and then
    const st = 24 * s, n = Math.max(1, Math.round((y1 - y0) / st)), px = y => x + amp * Math.sin((y - y0) / st * 1.1 + ph);
    ctx.lineCap = 'round'; ctx.beginPath(); for (let y = y0; y <= y1; y += st / 6) ctx.lineTo(px(y) + 1.4 * s, y + 1.4 * s); ctx.strokeStyle = CH_GD; ctx.lineWidth = 3.4 * s; ctx.stroke();
    ctx.beginPath(); for (let y = y0; y <= y1; y += st / 6) ctx.lineTo(px(y), y); ctx.strokeStyle = CH_G; ctx.lineWidth = 2.4 * s; ctx.stroke(); ctx.lineCap = 'butt';
    for (let k = 0; k < n; k++) {
        const y = y0 + (k + 0.5) * st, X = px(y), d = k % 2 ? 1 : -1;
        chLeaf(X, y, d > 0 ? -0.75 : -Math.PI + 0.75, 17 * s, 5.2 * s, s); chLeaf(X, y + 4 * s, d > 0 ? 0.55 : Math.PI - 0.55, 13 * s, 4.2 * s, s);
        if (fl && k % 3 === 1) chFlower(X + d * 13 * s, y - 2 * s, 8.5 * s, s, k);
    }
    chFlower(px(y0), y0 - 4 * s, 9 * s, s, 0.2); ctx.lineWidth = 1;
}
function chFan(x, y, a, r, s, n) {   // a fan of feather-leaves (the wing motif on the jacket shoulders)
    for (let k = 0; k < n; k++) { const t = (k / (n - 1) - 0.5) * 1.5; chLeaf(x, y, a + t, r * (1 - 0.18 * Math.abs(t)), r * 0.13, s); }
    dot(x, y, 3.2 * s, CH_GD); dot(x, y, 2.2 * s, CH_G);
}
function chButton(x, y, r) {   // silver filigree button
    dot(x + r * 0.15, y + r * 0.2, r * 1.05, 'rgba(0,0,0,0.45)'); dot(x, y, r, '#7b828b'); dot(x, y, r * 0.88, '#d5d9de'); dot(x, y, r * 0.62, '#a9aeb5'); dot(x, y, r * 0.5, '#e6e9ec');
    ctx.strokeStyle = '#6b7178'; ctx.lineWidth = r * 0.07; for (let k = 0; k < 8; k++) { const a = k * TAU / 8; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 0.2, y + Math.sin(a) * r * 0.2); ctx.lineTo(x + Math.cos(a) * r * 0.62, y + Math.sin(a) * r * 0.62); ctx.stroke(); }
    dot(x - r * 0.3, y - r * 0.32, r * 0.18, 'rgba(255,255,255,0.9)');
}
function chWool(w, h, c0, c1, c2, seed) {   // dyed wool broadcloth with a fine twill
    const R = mulberry(seed), g = ctx.createLinearGradient(0, 0, w, 0); g.addColorStop(0, c0); g.addColorStop(0.25, c1); g.addColorStop(0.5, c2); g.addColorStop(0.75, c1); g.addColorStop(1, c0); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 3) { ctx.fillStyle = (y / 3 | 0) % 2 ? 'rgba(255,200,200,0.028)' : 'rgba(0,0,0,0.05)'; ctx.fillRect(0, y, w, 1.5); }
    for (let k = 0; k < Math.min(9000, w * h / 80); k++) { const x = R() * w, y = R() * h; ln(x, y, x + 1.5, y + 1.5, 0.8, R() < 0.5 ? 'rgba(255,190,190,0.08)' : 'rgba(30,0,4,0.12)'); }
    for (let k = 0; k < Math.min(120, w / 5); k++) { const x = R() * w, y = R() * h, r = 14 + R() * 46, rg = ctx.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, R() < 0.5 ? 'rgba(30,0,6,0.10)' : 'rgba(255,120,120,0.05)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = rg; ctx.fillRect(x - r, y - r, 2 * r, 2 * r); }
}
function txShirt(w, h) {   // 1024^2: u around (front centre u=.25), v top -> bottom: a charro jacket (red wool, gold vines), the vest and shirt in the V, silver buttons
    const R = mulberry(19), x0 = w * 0.25, vh = h * 0.045, ap = h * 0.6, vw = w * 0.085;
    chWool(w, h, '#5e0816', '#8a1322', '#6f0c1a', 19);
    // embroidery: vines down both front panels, the side seams and the back; a feather fan on each shoulder
    for (const sd of [-1, 1]) {
        chVine(x0 + sd * w * 0.105, h * 0.2, h * 0.86, 9, 1.0, sd > 0 ? 0 : 2, true);
        chVine(x0 + sd * w * 0.165, h * 0.26, h * 0.84, 7, 0.9, sd > 0 ? 1.5 : 3.5, false);
    }
    chVine(0, h * 0.08, h * 0.86, 7, 0.9, 0, true); chVine(w * 0.5, h * 0.08, h * 0.86, 7, 0.9, 1, true);
    chVine(w * 0.75, h * 0.3, h * 0.86, 10, 1.1, 0, true); chVine(w * 0.67, h * 0.2, h * 0.84, 8, 0.9, 2, false); chVine(w * 0.83, h * 0.2, h * 0.84, 8, 0.9, 4, false);
    chFan(w * 0.69, h * 0.2, -Math.PI / 2 - 0.3, 84, 1.3, 10); chFan(w * 0.81, h * 0.2, -Math.PI / 2 + 0.3, 84, 1.3, 10); chFlower(w * 0.75, h * 0.24, 22, 1.6, 0);
    // the opening: lapels edged in gold, with the white shirt on top and the vest under it
    ctx.save(); ctx.beginPath(); ctx.moveTo(x0 - vw, vh - 2); ctx.lineTo(x0 + vw, vh - 2); ctx.lineTo(x0, ap); ctx.closePath(); ctx.clip();
    ctx.fillStyle = '#f4eee2'; ctx.fillRect(x0 - vw, vh - 2, vw * 2, h * 0.1);
    for (let y = vh; y < vh + h * 0.1; y += 4) ln(x0 - vw, y, x0 + vw, y, 1, (y >> 2) % 2 ? 'rgba(120,92,56,0.06)' : 'rgba(255,255,255,0.12)');
    chWool(w, h, '#3f0610', '#5a0a15', '#470711', 7); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.moveTo(x0 - vw, vh - 2); ctx.lineTo(x0 + vw, vh - 2); ctx.lineTo(x0, ap); ctx.closePath(); ctx.clip();
    ctx.fillStyle = '#f4eee2'; ctx.fillRect(x0 - vw, vh - 2, vw * 2, h * 0.1); for (let y = vh; y < vh + h * 0.1; y += 4) ln(x0 - vw, y, x0 + vw, y, 1, (y >> 2) % 2 ? 'rgba(120,92,56,0.06)' : 'rgba(255,255,255,0.12)');
    ln(x0 - vw, vh + h * 0.1, x0 + vw, vh + h * 0.1, 2.5, CH_G);   // the vest's gold top edge
    chButton(x0, vh + h * 0.17, 11); chButton(x0, vh + h * 0.29, 10);
    ctx.restore();
    for (const sd of [-1, 1]) {   // gold piping along the lapels
        const ax = x0 + sd * vw, ay = vh, bx = x0, by = ap; ln(ax, ay, bx, by, 6, CH_GD); ln(ax, ay, bx, by, 3.6, CH_G); ln(ax - sd * 1, ay, bx - sd * 1, by, 1.2, CH_GH);
        const dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy), nx = sd * dy / L, ny = -sd * dx / L;
        for (let t = 0.06; t < 0.96; t += 0.09) { const px = ax + dx * t + nx * 9, py = ay + dy * t + ny * 9; chLeaf(px, py, Math.atan2(dy, dx) + 0.5 * sd, 10, 3, 0.8); }
    }
    ln(x0, ap, x0, h * 0.9, 4, 'rgba(20,0,4,0.7)'); ln(x0 + 2, ap, x0 + 2, h * 0.9, 1.4, 'rgba(255,160,160,0.18)');   // the jacket closes here
    chButton(x0, h * 0.68, 17); chButton(x0, h * 0.79, 17);
    ctx.fillStyle = '#430610'; ctx.fillRect(0, h * 0.9, w, h * 0.1);   // the vest below the short jacket
    ln(0, h * 0.9, w, h * 0.9, 5, CH_GD); ln(0, h * 0.9, w, h * 0.9, 3, CH_G); for (let x = 0; x < w; x += 16) { ln(x, h * 0.915, x + 8, h * 0.93, 1.6, CH_G); ln(x + 8, h * 0.93, x + 16, h * 0.915, 1.6, CH_G); }
    for (const sd of [-1, 1]) chButton(x0 + sd * 0, h * 0.95, 13);
}
function txSleeve(w, h) {   // charro jacket sleeve: red wool, a gold vine down the arm, a gold-edged hem and the white shirt cuff
    chWool(w, h, '#5e0816', '#8a1322', '#6f0c1a', 23);
    for (const fx of [0.25, 0.75]) chVine(w * fx, h * 0.06, h * 0.8, 6, 0.55, fx * 8, true);
    ln(2, 0, 2, h, 3, 'rgba(30,0,6,0.35)');
    ctx.lineCap = 'round'; for (let k = 0; k < 8; k++) { const y = h * (0.42 + k * 0.018); ctx.strokeStyle = k % 2 ? 'rgba(255,170,170,0.07)' : 'rgba(20,0,4,0.16)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(0, y); ctx.bezierCurveTo(w * 0.3, y + 3, w * 0.7, y - 3, w, y); ctx.stroke(); } ctx.lineCap = 'butt';
    ctx.fillStyle = '#f2ead8'; ctx.fillRect(0, h * 0.9, w, h * 0.1); for (let y = h * 0.9; y < h; y += 3) ln(0, y, w, y, 1, (y / 3 | 0) % 2 ? 'rgba(110,86,52,0.06)' : 'rgba(255,255,255,0.1)');
    ln(0, h * 0.885, w, h * 0.885, 5, CH_GD); ln(0, h * 0.885, w, h * 0.885, 3, CH_G); ln(0, h * 0.875, w, h * 0.875, 1.2, CH_GH);
}
function txDenim(w, h) {   // charro trousers: red wool, a gold vine either side of the outer seam, a row of silver buttons on it (u = .5)
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); chWool(w, h, '#5a0715', '#86121f', '#6c0b19', 11); ctx.restore();
    ctx.scale(w / 16, h / 17);
    for (const [x, ph] of [[5.9, 0], [10.1, 3]]) chVine(x, 1.0, 14.6, 0.45, 0.06, ph, true);
    ctx.fillStyle = 'rgba(20,0,4,0.5)'; ctx.fillRect(7.6, 0, 0.8, 15.4);
    for (let k = 0; k < 11; k++) stud(8, 0.9 + k * 1.3, 0.42, '#b9bec4', '#f4f6f8');
    ctx.fillStyle = CH_G; ctx.fillRect(0, 15.4, 16, 0.4); ctx.fillStyle = CH_GD; ctx.fillRect(0, 15.8, 16, 0.2);
}
function txLeather(w, h, c0, c1, seed) {   // generic stitched leather: dye, grain, burnished edge and a row of stitches
    const R = mulberry(seed || 41), g = ctx.createLinearGradient(0, 0, w, h); g.addColorStop(0, c0); g.addColorStop(1, c1); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    for (let k = 0; k < 30; k++) { const x = R() * w, y = R() * h, r = 8 + R() * 30, rg = ctx.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, R() < 0.5 ? 'rgba(20,8,2,0.14)' : 'rgba(220,160,100,0.10)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = rg; ctx.fillRect(x - r, y - r, r * 2, r * 2); }
    for (let k = 0; k < Math.min(3600, w * h / 4); k++) { const x = R() * w, y = R() * h, a = R() * TAU, l = 1.5 + R() * 3.5; ln(x, y, x + Math.cos(a) * l, y + Math.sin(a) * l, 0.7, R() < 0.55 ? 'rgba(20,8,2,0.15)' : 'rgba(255,215,165,0.09)'); }
    ctx.fillStyle = 'rgba(15,6,2,0.45)'; ctx.fillRect(0, 0, w, 3); ctx.fillRect(0, h - 3, w, 3); ctx.fillRect(0, 0, 3, h); ctx.fillRect(w - 3, 0, 3, h);
    ctx.strokeStyle = 'rgba(232,205,150,0.85)'; ctx.lineWidth = 1.4; ctx.setLineDash([5, 4]); ctx.strokeRect(8, 8, w - 16, h - 16); ctx.setLineDash([]);
}
function txBelt(w, h) {   // charro piteado belt: honey leather worked with pita-fibre floral embroidery, braided edges
    const R = mulberry(31), g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#8a5a2c'); g.addColorStop(0.12, '#c99a5a'); g.addColorStop(0.5, '#d9ae6e'); g.addColorStop(0.88, '#c99a5a'); g.addColorStop(1, '#7a4c22'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    for (let k = 0; k < 2600; k++) { const x = R() * w, y = R() * h; ln(x, y, x + 3 + R() * 5, y + (R() - 0.5) * 1.2, 0.8, R() < 0.5 ? 'rgba(255,235,190,0.2)' : 'rgba(90,50,15,0.18)'); }   // pita fibre
    for (const y of [4, h - 4]) { ln(0, y, w, y, 6, '#4a2810'); for (let x = 0; x < w; x += 5) ln(x, y - 2.5, x + 3, y + 2.5, 1.2, 'rgba(230,190,120,0.5)'); }   // braided edges
    for (let x = 0; x < w; x += 64) {   // a flower with leaves, repeated, stitched in brown, red and cream fibre
        const cx = x + 32, cy = h / 2;
        for (const sd of [-1, 1]) for (const [dy, a] of [[-4, -0.5], [4, 0.5]]) { ctx.save(); ctx.translate(cx + sd * 6, cy + dy); ctx.rotate((sd > 0 ? 0 : Math.PI) + a * sd); ctx.fillStyle = '#4e5a24'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(10, -4, 22, 0); ctx.quadraticCurveTo(10, 4, 0, 0); ctx.fill(); ln(2, 0, 19, 0, 0.9, 'rgba(240,220,150,0.6)'); ctx.restore(); }
        for (let k = 0; k < 6; k++) { const a = k * TAU / 6; ctx.save(); ctx.translate(cx, cy); ctx.rotate(a); ctx.fillStyle = k % 2 ? '#7c1520' : '#5a2a12'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(7, -4, 12, 0); ctx.quadraticCurveTo(7, 4, 0, 0); ctx.fill(); ctx.restore(); }
        dot(cx, cy, 3.2, '#f3dfa0'); dot(cx, cy, 1.6, '#8a5a12');
        for (const dx of [-32, 0]) { dot(x + dx + 64 * 0.5 + 32 * (dx ? 0 : 0), h - 9, 1.6, '#7c1520'); }
    }
    for (let x = 16; x < w; x += 16) { dot(x, 11, 1.1, 'rgba(70,35,10,0.7)'); dot(x, h - 11, 1.1, 'rgba(70,35,10,0.7)'); }
}
function txBuckle(w, h) {   // silver charro buckle: a dished field with engraved flowers and gold inlay, beaded border
    const R = mulberry(7), g = ctx.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#f4f6f8'); g.addColorStop(0.35, '#c4c9cf'); g.addColorStop(0.7, '#8d939b'); g.addColorStop(1, '#e6e9ed'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const rr = (x, y, ww, hh, r) => { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + ww, y, x + ww, y + hh, r); ctx.arcTo(x + ww, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + ww, y, r); ctx.closePath(); };
    ctx.fillStyle = '#5b6168'; rr(w * 0.12, h * 0.14, w * 0.76, h * 0.72, 18); ctx.fill(); const g2 = ctx.createLinearGradient(0, h * 0.14, 0, h * 0.86); g2.addColorStop(0, '#9aa0a8'); g2.addColorStop(1, '#6b7178'); ctx.fillStyle = g2; rr(w * 0.14, h * 0.16, w * 0.72, h * 0.68, 16); ctx.fill();
    ctx.save(); ctx.translate(w / 2, h / 2); for (let k = 0; k < 8; k++) { ctx.save(); ctx.rotate(k * TAU / 8); ctx.fillStyle = CH_G; ctx.beginPath(); ctx.moveTo(18, 0); ctx.quadraticCurveTo(46, -16, 78, 0); ctx.quadraticCurveTo(46, 16, 18, 0); ctx.fill(); ln(24, 0, 70, 0, 1, CH_GH); ctx.restore(); } ctx.restore();
    for (const sd of [-1, 1]) chFlower(w / 2 + sd * 88, h / 2, 14, 0.8, 0.3);
    for (let k = 0; k < 44; k++) { const t = k / 44 * TAU; dot(w / 2 + Math.cos(t) * w * 0.43, h / 2 + Math.sin(t) * h * 0.43, 1.7, 'rgba(255,255,255,0.85)'); }
    for (let k = 0; k < 500; k++) ln(R() * w, R() * h, R() * w, R() * h, 0.4, 'rgba(255,255,255,0.05)');
}
function txGrip(w, h) { const g = ctx.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#d9ccb0'); g.addColorStop(0.5, '#f4ead2'); g.addColorStop(1, '#cdbf9f'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); const R = mulberry(3); for (let k = 0; k < 40; k++) { const x = R() * w; ctx.strokeStyle = 'rgba(120,95,55,0.18)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, 0); ctx.bezierCurveTo(x + 8, h * 0.3, x - 8, h * 0.6, x + 4, h); ctx.stroke(); } }
function txRope(w, h) { ctx.fillStyle = '#c8a768'; ctx.fillRect(0, 0, w, h); for (let x = -h; x < w; x += 4) ln(x, 0, x + h, h, 1.8, 'rgba(90,62,26,0.55)'); for (let x = -h; x < w; x += 4) ln(x + 2, 0, x + 2 + h, h, 0.9, 'rgba(255,235,180,0.35)'); }
// ---- the model ----
function h3Init() {
    if (H3.ok !== null) return H3.ok;
    H3.ok = false;
    try {
        const cv = document.createElement('canvas'); cv.width = 16; cv.height = 16;
        const gl = cv.getContext('webgl', { antialias: !window.__noAA, alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: false });
        if (!gl) return false;
        const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
        const p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, H3_VS)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, H3_FS)); gl.bindAttribLocation(p, 0, 'aP'); gl.bindAttribLocation(p, 1, 'aN'); gl.bindAttribLocation(p, 2, 'aUV'); gl.linkProgram(p);
        if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
        H3.cv = cv; H3.gl = gl; H3.prog = p; gl.useProgram(p);
        {   // one shared 256x256 white-noise texture on unit 2 (units 0 and 1 belong to the skin textures and the post pass)
            const N = 256, px = new Uint8Array(N * N * 4); let sd = 1234567; for (let i = 0; i < px.length; i++) { sd = (sd * 1664525 + 1013904223) >>> 0; px[i] = sd >>> 24; }
            const nt = gl.createTexture(); gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, nt); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, N, N, 0, gl.RGBA, gl.UNSIGNED_BYTE, px);
            gl.generateMipmap(gl.TEXTURE_2D); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT); gl.activeTexture(gl.TEXTURE0); H3.nz = nt;
        }
        for (const n of ['uM', 'uVP', 'uNM', 'uTex', 'uUseTex', 'uCol', 'uSpec', 'uShin', 'uRim', 'uHoop', 'uH0', 'uH1', 'uPh', 'uGlow', 'uBulge', 'uFn', 'uFa', 'uFb', 'uCm', 'uCl', 'uAr', 'uCw', 'uSk', 'uB0', 'uB1', 'uB2', 'uN0', 'uN1', 'uN2', 'uBw', 'uSw', 'uBr', 'uHd', 'uHQ', 'uSkinD', 'uProj', 'uHI', 'uLidSh', 'uNz', 'uAS', 'uASr']) H3.U[n] = gl.getUniformLocation(p, n);
        // post-processing program (bloom + supersample resolve); if it fails we simply run the direct path
        try {
            const pp = gl.createProgram(); gl.attachShader(pp, sh(gl.VERTEX_SHADER, H3_PVS)); gl.attachShader(pp, sh(gl.FRAGMENT_SHADER, H3_PFS)); gl.bindAttribLocation(pp, 0, 'aQ'); gl.linkProgram(pp);
            if (!gl.getProgramParameter(pp, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pp));
            const PU = {}; for (const n of ['uT0', 'uT1', 'uMode', 'uSc', 'uSc2', 'uTx', 'uTx2', 'uOff', 'uDir', 'uG', 'uSS']) PU[n] = gl.getUniformLocation(pp, n);
            const qb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, qb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
            H3.post = { p: pp, U: PU, qb }; H3.S = {}; H3.b1 = {}; H3.b2 = {}; H3.b3 = {};
        } catch (e) { H3.post = null; if (typeof console !== 'undefined') console.warn('3D hero post-fx unavailable:', e && e.message); }
        gl.useProgram(p); gl.uniform1i(H3.U.uNz, 2);
        H3.A = { aP: gl.getAttribLocation(p, 'aP'), aN: gl.getAttribLocation(p, 'aN'), aUV: gl.getAttribLocation(p, 'aUV') };
        gl.enable(gl.DEPTH_TEST); gl.enable(gl.SCISSOR_TEST);
        cv.addEventListener('webglcontextlost', e => { e.preventDefault(); H3.ok = false; });
        // meshes (hero units, y up, origin at the waist)
        const M = H3.M = {};
        const poncho = mkParam(128, 30, (u, v) => {   // shoulder capelet (serape) that hangs to mid-chest
            const y = 17.7 + (12.0 - 17.7) * v, k = 1 + 0.03 * v * Math.sin(u * TAU * 9) + 0.02 * v * Math.sin(u * TAU * 5 + 1.3), rx = crPt(CAPE_X, v)[1] * k, rz = crPt(CAPE_Z, v)[1] * k, a = u * TAU;
            return [rx * Math.cos(a), y, rz * Math.sin(a), u, v];
        }, -1);
        M.poncho = poncho;
        H3.raw = true; const tr = mkParam(128, 56, (u, v) => {   // shirt + vest: sloped shoulders, chest, ribcage, narrow waist, hips; soft cloth folds gather above the belt
            const y = 17.6 - 21.4 * v, a = u * TAU, fold = 1 + 0.03 * Math.exp(-Math.pow((y - 3.2) / 3.4, 2)) * Math.sin(a * 13 + y * 0.9 + 1.7 * Math.sin(a * 3)), rx = crPt(TOR_X, v)[1] * fold, rz = crPt(TOR_Z, v)[1] * fold * (1 + 0.1 * Math.max(0, Math.sin(a)) * Math.exp(-Math.pow((y - 11.5) / 3.2, 2)));
            return [rx * Math.cos(a), y, rz * Math.sin(a), u, v];
        }, -1); H3.raw = false;
        for (let q = 1; q < tr.V.length; q += 8) tr.V[q] = (tr.V[q] + 3.8) / 21.4;   // y -> t in 0..1 for the skinning shader
        M.torso = h3Up(tr.V, tr.I);
        M.tassels = (() => { const V = [], I = []; for (let k = 0; k < 44; k++) { const a = k / 44 * TAU, x = 8.55 * Math.cos(a), z = 4.95 * Math.sin(a), l = 1.2 + 0.35 * Math.sin(k * 2.1); for (const [dx, dy, u, nrm] of [[-0.22, 0, 0, 0], [0.22, 0, 1, 0], [-0.1, -l, 0, 1], [0.1, -l, 1, 1]]) { const ca = Math.cos(a), sa = Math.sin(a); V.push(x - sa * dx * 0.9, 12.0 + dy, z + ca * dx * 0.5, ca * 0.6, 0.2, sa, u, nrm); } const b = k * 4; I.push(b, b + 1, b + 2, b + 1, b + 3, b + 2); } return h3Up(V, I); })();
        M.head = mkSuper(5.6, 6.5, 5.7, 2.5, 2.3, 112, 82, (x, y) => [(x + 7) / 14, (31 - y - 22.7) / 14], 0.24);
        M.sphere = mkEllipsoid(1, 1, 1, 26, 18);
        M.sphereHi = mkEllipsoid(1, 1, 1, 40, 26);
        M.tube = mkFrustum(1, 1, 28); M.cone = mkFrustum(1, 0.0, 28);
        M.box = mkBox(1, 1, 1);
        M.torus = mkLoop(1, 1, 0.12, 56, 14);
        const BRIM = [[0, 0.35], [5.5, 0.3], [10.5, 0.1], [14.6, 0.0], [16.6, 0.55], [17.45, 1.55], [17.6, 1.05], [17.2, 0.4], [14.6, -0.3], [10.5, -0.4], [5.5, -0.3], [0, -0.3]];
        M.brim = mkParam(120, 80, (u, v) => { const q = crPt(BRIM, v), a = u * TAU; return [q[0] * Math.cos(a), q[1] + 0.7 * Math.cos(2 * a) * Math.pow(q[0] / 17.6, 3), q[0] * Math.sin(a), u, v]; }, -1);   // sides curl up, front/back droop
        const CROWN = [[6.45, 0.2], [6.3, 2.5], [5.75, 6.2], [4.95, 9.6], [3.9, 11.6], [2.5, 12.4], [1.1, 12.6], [0, 12.5]];
        M.crown = mkParam(96, 60, (u, v) => {
            const q = crPt(CROWN, v), a = u * TAU, r = q[0], dent = q[0] < 2.6 ? 0.45 * (1 - (q[0] / 2.6) * (q[0] / 2.6)) : 0;
            return [r * Math.cos(a), q[1] - dent, r * Math.sin(a), u, v];
        }, 1);   // pinched front + dented top
        M.band = mkLathe([[6.5, 1.2], [6.62, 1.4], [6.62, 3.3], [6.45, 3.5]], 1, 56);
        M.hoop = mkLoop(1, 1, 0.1, 96, 14);
        // bandolier ribbon draped over the poncho
        M.bando = (() => {
            const V = [], I = [], N = 18, surf = (x, y) => {
                let rx = crPt(TOR_X, (17.6 - y) / 21.4)[1], rz = crPt(TOR_Z, (17.6 - y) / 21.4)[1];
                if (y < 17.7 && y > 12.0) { const t = (17.7 - y) / 5.7, cx = crPt(CAPE_X, t)[1], cz = crPt(CAPE_Z, t)[1]; if (cz > rz) { rx = cx; rz = cz; } }
                const q = Math.max(0, 1 - (x / rx) * (x / rx)); return { z: rz * Math.sqrt(q) + 0.28, nx: x / (rx * rx), nz: Math.sqrt(q) / rz };
            };
            h3Grid(V, I, N, 1, (u, v) => { const x = -5.6 + 11.2 * u, y = 15.0 - 14.2 * u, w = (v - 0.5) * 2.4, px = x + w * 0.74, py = y + w * 0.67, s = surf(px, py); return [px, py, s.z, s.nx, 0.2, s.nz, u, v]; });
            return h3Up(V, I);
        })();
        // ---- torso accessories rebuilt: belt band + keepers, framed buckle, bound lapels, pouches, holster/gun, star ----
        H3.torZ = (x, y) => { let rx = crPt(TOR_X, (17.6 - y) / 21.4)[1], rz = crPt(TOR_Z, (17.6 - y) / 21.4)[1]; if (y < 17.7 && y > 12.0) { const t = (17.7 - y) / 5.7, cx = crPt(CAPE_X, t)[1], cz = crPt(CAPE_Z, t)[1]; if (cz > rz) { rx = cx; rz = cz; } } return rz * Math.sqrt(Math.max(0, 1 - (x / rx) * (x / rx))); };
        const sgp = (t, e) => Math.sign(t) * Math.pow(Math.abs(t), e);
        const beltM = (u0, u1, dr, dh, nu) => mkParam(nu, 14, (u, v) => { const uu = u0 + (u1 - u0) * u, a = uu * TAU, f = v * TAU, rr = (0.34 + dr) * sgp(Math.cos(f), 0.5), hh = (0.85 + dh) * sgp(Math.sin(f), 0.5); return [(4.95 + rr) * Math.cos(a), 0.3 + hh, (3.5 + rr) * Math.sin(a), uu, 0.5 + hh / (2 * (0.85 + dh))]; }, 1);
        M.belt = beltM(0, 1, 0, 0, 96); M.keepA = beltM(0.138, 0.162, 0.07, 0.2, 6); M.keepB = beltM(0.338, 0.362, 0.07, 0.2, 6);
        const BA = 2.2, BB = 1.65, bsq = (t) => Math.sign(t) * Math.pow(Math.abs(t), 2 / 3.4), ss = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
        M.buckle = mkParam(56, 16, (u, v) => { const a = u * TAU, px = BA * bsq(Math.cos(a)), py = BB * bsq(Math.sin(a)), z = 0.03 + 0.2 * ss(0.74, 0.88, v) - 0.17 * ss(0.9, 1, v); return [px * v, py * v, z, 0.5 + px * v / (2 * BA), 0.5 - py * v / (2 * BB)]; }, 1);
        M.rbox = mkSuper(1, 1, 1, 4, 4, 22, 16);
        const lapel = s => mkParam(26, 6, (u, v) => { const y = 13.4 - 7.9 * u, ex = 3.05 * (1 - u) - 0.08, wd = 1.15 * (1 - 0.5 * u), ox = ex + wd * v * 0.9, oy = y + wd * v * 0.45, px = s * ox; return [px, oy, H3.torZ(px, oy) + 0.05 + 0.2 * Math.pow(Math.sin(Math.PI * v), 0.6), u, v]; }, -s);
        M.lapelR = lapel(1); M.lapelL = lapel(-1);
        M.star = (() => {   // five-point tin star: bevelled prism
            const V = [], I = [], R0 = 2.15, R1 = 0.92, T = 0.28, P = []; for (let i = 0; i < 10; i++) { const a = Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? R1 : R0; P.push([r * Math.cos(a), r * Math.sin(a)]); }
            V.push(0, 0, T, 0, 0, 1, 0.5, 0.5); for (const p of P) { const l = Math.hypot(p[0], p[1]); V.push(p[0], p[1], T * 0.45, p[0] / l * 0.55, p[1] / l * 0.55, 0.8, 0.5 + p[0] / 4, 0.5 - p[1] / 4); } for (const p of P) { const l = Math.hypot(p[0], p[1]); V.push(p[0], p[1], 0, p[0] / l, p[1] / l, 0, 0.5 + p[0] / 4, 0.5 - p[1] / 4); }
            for (let i = 0; i < 10; i++) { const a = 1 + i, b = 1 + (i + 1) % 10, c = 11 + i, d = 11 + (i + 1) % 10; I.push(0, a, b, a, c, b, b, c, d); }
            return h3Up(V, I);
        })();
        M.xBelt = null;
        M.hatStuds = h3Merged((() => { const L = [], sp = () => mkEllipsoid(1, 1, 1, 18, 12);
            for (let k = 0; k < 9; k++) { const a = Math.PI * (0.12 + 0.76 * k / 8); L.push([sp, m4.chain(m4.T(Math.cos(a) * 6.75, 2.35, Math.sin(a) * 6.75), m4.S(0.6, 0.6, 0.6))]); }
            
            L.push([sp, m4.chain(m4.T(0, 12.6, 0), m4.S(0.8, 0.6, 0.8))]); return L; })());
        // skinned limbs (bent in the vertex shader around t = .5): sleeve, two denim legs (stud seam mirrored), fingers that curl
        M.sleeve = mkLimb(t => 1.6 + 0.42 * t * t, 13.2, 16, 18);
        const legR = t => 2.95 - 0.75 * Math.min(1, t / 0.5) + 0.3 * Math.sin(Math.max(0, Math.min(1, (t - 0.5) / 0.4)) * Math.PI) - 0.1 * Math.max(0, t - 0.8) * 5;   // thigh -> knee -> calf -> ankle
        // one-piece leg: the thigh swells into a rounded glute at the back (local +z = behind), flares at the hip and closes into a dome that sits inside the pelvis, so seat and thigh are the same surface
        const legGeo = (sd, us) => {
            const V = [], I = [], KY = 24.4;
            const P = (u, v) => {
                const a = (u + us) * TAU, c = Math.cos(a), sn = Math.sin(a), g = Math.exp(-Math.pow((v - 0.1) / 0.1, 2)), back = Math.pow(Math.max(0, sn), 1.3), out = Math.max(0, c * sd);
                let r = legR(v) + 0.2 * Math.exp(-Math.pow(v / 0.12, 2)) + 1.9 * g * back + 0.55 * g * out * (1 - back);   // glute behind, a little hip flare outside
                const dome = v < 0.05 ? Math.sqrt(Math.max(0, 1 - Math.pow((0.05 - v) / 0.05, 2))) : 1;
                r *= dome;
                return [r * c, v * KY, r * sn - 0.7 * g];
            };
            h3Grid(V, I, 28, 34, (u, v) => {
                const p = P(u, v), du = P(u + 0.004, v), dv = P(u, Math.min(1, v + 0.004)), t1 = [du[0] - p[0], du[1] - p[1], du[2] - p[2]], t2 = [dv[0] - p[0], dv[1] - p[1], dv[2] - p[2]];
                return [p[0], v, p[2], t2[1] * t1[2] - t2[2] * t1[1], t2[2] * t1[0] - t2[0] * t1[2], t2[0] * t1[1] - t2[1] * t1[0], u, v];
            });
            return h3Up(V, I);
        };
        M.legSk = { '-1': legGeo(-1, 0), '1': legGeo(1, 0.5) };
        {   // hand: one three-bone finger mesh (knuckle swells at the joints, rounded tip), a three-bone thumb, a flattened palm and a thenar pad
            const jn = (t, c) => Math.exp(-Math.pow((t - c) / 0.055, 2));
            M.palm = (() => {   // squarish slab: super-ellipse cross-section (flat back and front, squared sides), narrow at the wrist, flat knuckle edge
                const V = [], I = [], n = 6, pr = t => (0.78 + 0.22 * Math.min(1, t / 0.7)) * Math.pow(Math.max(0, 1 - Math.pow(2 * t - 1, 30)), 0.5), ky = 2.8, e = 0.02;
                h3Grid(V, I, 28, 18, (u, v) => {
                    const a = u * TAU, c = Math.cos(a), sn = Math.sin(a), r = pr(v), v0 = Math.max(0, v - e), v1 = Math.min(1, v + e), dr = (pr(v1) - pr(v0)) / (v1 - v0);
                    const px = Math.sign(c) * Math.pow(Math.abs(c), 2 / n), pz = Math.sign(sn) * Math.pow(Math.abs(sn), 2 / n);
                    let nx = Math.sign(px) * Math.pow(Math.abs(px), n - 1), nz = Math.sign(pz) * Math.pow(Math.abs(pz), n - 1), nl = Math.hypot(nx, nz) || 1; nx /= nl; nz /= nl;
                    const m = Math.hypot(1, dr / ky);
                    return [r * px, v, r * pz, nx / m, -dr / ky / m, nz / m, u, v];
                });
                return h3Up(V, I);
            })();
            M.finger3 = mkLimb(t => 0.49 * (1 - 0.3 * t) * (1 + 0.08 * jn(t, 1 / 3) + 0.07 * jn(t, 2 / 3)) * Math.sqrt(Math.max(0, 1 - Math.pow(t, 10))), 2.4, 12, 24);
            M.thumb3 = mkLimb(t => 0.62 * (1 - 0.26 * t) * (1 + 0.1 * jn(t, 1 / 3) + 0.08 * jn(t, 2 / 3)) * Math.sqrt(Math.max(0, 1 - Math.pow(t, 10))), 2.5, 12, 24);
        }
        M.fingerSk = (() => { const V = [], I = []; for (let k = 0; k < 4; k++) limbGeo(V, I, t => 0.5 * (1 - 0.22 * t) * Math.sqrt(Math.max(0, 1 - Math.pow(t, 9))), 2.3, 10, 12, 0, (k - 1.5) * 0.9, 0.3); return h3Up(V, I); })();
        M.eye = mkParam(64, 44, (u, v) => {   // eyeball: dense ellipsoid with a domed cornea over the iris (so the highlights sit on a real bulge)
            const ph = u * TAU, th = v * Math.PI, st = Math.sin(th), ct = Math.cos(th), x = 1.45 * st * Math.cos(ph), y = 1.2 * ct, z = st * Math.sin(ph);
            const al = Math.acos(Math.max(-1, Math.min(1, z))), q = Math.max(0, Math.min(1, (0.62 - al) / 0.5)), b = 0.05 * q * q * (3 - 2 * q);
            return [x * (1 + b * 0.6), y * (1 + b * 0.6), z * (1 + b * 1.7), u, v];
        }, -1);
        const eyeSurf = (dx, dy, dz) => { const al = Math.acos(Math.max(-1, Math.min(1, dz))), q = Math.max(0, Math.min(1, (0.62 - al) / 0.5)), b = 0.05 * q * q * (3 - 2 * q); return [1.45 * dx * (1 + b * 0.6), 1.2 * dy * (1 + b * 0.6), dz * (1 + b * 1.7)]; };   // eyeball surface in eye-local space for a unit direction
        M.eyeSurf = eyeSurf;
        M.pupil = (() => { const V = [], I = []; h3Grid(V, I, 32, 6, (u, v) => { const al = 0.27 * v, ps = u * TAU, d = [Math.sin(al) * Math.cos(ps), Math.sin(al) * Math.sin(ps), Math.cos(al)], p = eyeSurf(d[0], d[1], d[2]); return [p[0], p[1], p[2] + 0.008, d[0] / 1.45, d[1] / 1.2, d[2], u, v]; }); return h3Up(V, I); })();   // dark disc cut from the cornea surface itself; scaled in x/y to dilate
        {   // lid-edge furniture, all in lid-local space (drawn with the lid's matrix): rim, wet waterline, upper crease, and real lash rows
            const ELX = 1.55, ELZ = 1.1, edge = (ph, k) => [ELX * Math.cos(ph) * k, 0, ELZ * Math.sin(ph) * k];
            const tube = (k, y, r, n) => { const pts = []; for (let i = 0; i <= n; i++) { const p = edge(Math.PI * i / n, k); p[1] = y; pts.push(p); } return { pts, rad: pts.map((p, i) => r * (0.3 + 0.7 * Math.sin(Math.PI * i / n))) }; };
            M.lidRim = mkTubes([tube(1.0, 0.0, 0.055, 32)], 8);
            M.waterline = mkTubes([tube(0.93, -0.045, 0.05, 32)], 8);
            M.crease = (() => { const pts = [], th = 0.6 * Math.PI / 2; for (let i = 0; i <= 28; i++) { const ph = Math.PI * (0.04 + 0.92 * i / 28); pts.push([ELX * Math.sin(th) * Math.cos(ph) * 1.01, 1.3 * Math.cos(th) * 1.01, ELZ * Math.sin(th) * Math.sin(ph) * 1.01]); } return mkTubes([{ pts, rad: pts.map((p, i) => 0.045 * Math.sin(Math.PI * i / 28) + 0.008) }], 6); })();
            const lash = (N, len, curl, p0, p1, seed) => {
                const R = mulberry(seed), L = [];
                for (let k = 0; k < N; k++) {
                    const tt = (k + 0.5) / N, ph = Math.PI * (p0 + (p1 - p0) * tt), cx = Math.cos(ph), sz = Math.sin(ph), nl = Math.hypot(cx / ELX, sz / ELZ), ox = cx / ELX / nl, oz = sz / ELZ / nl, ln = len * (0.5 + 0.6 * (1 - tt)) * (0.85 + 0.3 * R());
                    let p = [ELX * cx * 0.97, 0, ELZ * sz * 0.97]; const pts = [p.slice()];
                    for (let i = 1; i <= 4; i++) { const s = i / 4, dx = ox * (0.75 - 0.4 * s * curl), dy = 0.3 + 0.9 * s * curl, dz = oz * (0.75 - 0.4 * s * curl), dl = Math.hypot(dx, dy, dz); p = [p[0] + dx / dl * ln / 4, p[1] + dy / dl * ln / 4, p[2] + dz / dl * ln / 4]; pts.push(p.slice()); }
                    L.push({ pts, rad: [0.034, 0.031, 0.025, 0.015, 0.004] });
                }
                return mkTubes(L, 4);
            };
            M.lashU = lash(46, 0.5, 1.0, 0.05, 0.95, 91); M.lashL = lash(12, 0.17, 0.25, 0.18, 0.86, 92);
        }
        M.stubble = (() => {   // ~1100 tiny three-sided hairs rooted on the jaw/chin surface, pointing down and out (head-local; drawn with the jaw-stretch matrix so they ride the jaw)
            const R = mulberry(311), V = [], I = []; let n = 0;
            for (let k = 0; k < 24000 && n < 1900; k++) {
                const y = -6.2 + R() * 4.8, x = (R() * 2 - 1) * 4.1;
                if (Math.abs(x) < 1.2 && y > -3.05) continue;   // philtrum / upper-lip centre stays clean
                const z = h3Zs(x, y); if (z <= 0.4) continue;
                const ramp = Math.min(1, Math.max(0, (-y - 2.3) / 2.3)), dens = ramp * ramp * (3 - 2 * ramp) * (Math.abs(x) < 2.6 ? 1 : 0.7) * (1 - 0.5 * Math.max(0, Math.abs(x) - 3.0)); if (R() > dens) continue;   // smoothstep fade-in from the cheek down: no hard top edge
                const nx = x * 0.16, ny = (y - 1.5) * 0.1, nz = z, nl = Math.hypot(nx, ny, nz), ux = nx / nl, uy = ny / nl, uz = nz / nl, len = 0.11 + R() * 0.08, rd = 0.022 + R() * 0.01;
                const tx = ux * 0.5 + 0.12 * (x > 0 ? 1 : -1), ty = uy * 0.5 - 0.5, tz = uz * 0.7, tl = Math.hypot(tx, ty, tz), dx = tx / tl, dy = ty / tl, dz = tz / tl, b = V.length / 8;
                const ax = uy * dz - uz * dy, ay = uz * dx - ux * dz, az = ux * dy - uy * dx, al = Math.hypot(ax, ay, az) || 1, sx = ax / al, sy = ay / al, sz = az / al, qx = dy * sz - dz * sy, qy = dz * sx - dx * sz, qz = dx * sy - dy * sx;
                for (let j = 0; j < 3; j++) { const a = j / 3 * TAU, c = Math.cos(a), s = Math.sin(a); V.push(x + (sx * c + qx * s) * rd, y + (sy * c + qy * s) * rd, z - 0.03 + (sz * c + qz * s) * rd, ux, uy, uz, 0, 0); }
                V.push(x + dx * len, y + dy * len, z - 0.03 + dz * len, ux, uy, uz, 0, 1);
                I.push(b, b + 1, b + 3, b + 1, b + 2, b + 3, b + 2, b, b + 3); n++;
            }
            return h3Up(V, I);
        })();
        M.lid = (() => { const V = [], I = [], rx = 1.55, ry = 1.3, rz = 1.1; h3Grid(V, I, 24, 10, (u, v) => { const ph = u * TAU, th = v * Math.PI / 2, x = rx * Math.sin(th) * Math.cos(ph), y = ry * Math.cos(th), z = rz * Math.sin(th) * Math.sin(ph); return [x, y, z, x / (rx * rx), y / (ry * ry), z / (rz * rz), u, v]; }); return h3Up(V, I); })();
        M.scalp = (() => {   // hair cap with a real hairline: the front sinks into the skull below the forehead so skin and brows stay clear
            const rx = 5.8, ry = 6.4, rz = 6.2, V = [], I = [], sm = (a, b, v) => { const q = Math.max(0, Math.min(1, (v - a) / (b - a))); return q * q * (3 - 2 * q); };
            h3Grid(V, I, 72, 48, (u, v) => {
                const ph = u * TAU, th = v * Math.PI, x = rx * Math.sin(th) * Math.cos(ph), y = ry * Math.cos(th), z = rz * Math.sin(th) * Math.sin(ph);
                const yy = y + 2.1, hl = 4.95 + 0.7 * Math.pow(Math.abs(x) / 5, 2) - 0.3 * Math.exp(-x * x / 2.5), keep = 1 - sm(0.3, 2.6, z + 1.0) * (1 - sm(hl - 0.45, hl + 0.35, yy));
                return [x * (0.9 + 0.1 * keep), y, z > -1.0 ? -1.0 + (z + 1.0) * (0.4 + 0.6 * keep) : z, x / (rx * rx), y / (ry * ry), z / (rz * rz), u, v];
            });
            return h3Up(V, I);
        })();
        M.locks = (() => {   // hair: ~70 tapered locks falling from the scalp behind and beside the head (head-local space)
            const R = mulberry(77), L = [];
            for (let k = 0; k < 72; k++) {
                const a = (105 + 150 * (k / 71) + (R() - 0.5) * 6) * Math.PI / 180, y0 = 1.5 + R() * 4.2, ln = 9 + R() * 8, sw = (R() - 0.5) * 1.6, sd = Math.sin(a), cd = Math.cos(a), pts = [], rad = [];
                for (let i = 0; i < 7; i++) { const t = i / 6, yy = y0 - ln * t * (0.35 + 0.65 * t), rr = 1.0 + 0.04 * Math.sin(t * 3 + k) - 0.18 * Math.min(1, t * 1.4) + 0.04 * t; pts.push([6.0 * sd * rr + sw * t * 0.6, yy, 5.9 * cd * rr * (1 - 0.18 * t) - 1.0 - t * 0.6]); rad.push(0.62 * (1 - 0.8 * t * t) + 0.08); }
                L.push({ pts, rad });
            }
            return mkTubes(L, 7);
        })();
        // hair layers: a second, shorter and thinner underlayer, sun-lit highlight strands, face-framing locks, and a beaded braid (all head-local)
        const hairLayer = (seed, N, a0, a1, yA, yB, lnA, lnB, rad, push, sway, nu) => {
            const R = mulberry(seed), L = [];
            for (let k = 0; k < N; k++) {
                const a = (a0 + (a1 - a0) * (k / (N - 1)) + (R() - 0.5) * 5) * Math.PI / 180, y0 = yA + R() * (yB - yA), ln = lnA + R() * (lnB - lnA), sw = (R() - 0.5) * sway, sd = Math.sin(a), cd = Math.cos(a), pts = [], rd = [];
                for (let i = 0; i < 7; i++) { const t = i / 6, yy = y0 - ln * t * (0.4 + 0.6 * t), rr = push + 0.05 * Math.sin(t * 4 + k) - 0.1 * Math.min(1, t * 1.4); pts.push([6.0 * sd * rr + sw * t * 0.8 + 0.25 * Math.sin(k * 1.7 + t * 5) * t, yy, 5.9 * cd * rr * (1 - 0.15 * t) - 1.0 - t * 0.5 + (cd > 0.3 ? 0.4 : 0)]); rd.push(rad * (1 - 0.85 * t * t) + 0.05); }
                L.push({ pts, rad: rd });
            }
            return mkTubes(L, 5);
        };
        M.locks2 = hairLayer(78, 96, 100, 260, 0.2, 4.6, 5, 11, 0.42, 1.09, 1.4);
        M.locksHi = hairLayer(79, 34, 108, 252, 1.8, 5.8, 9, 17, 0.2, 1.13, 2.4);
        M.locksDark = hairLayer(83, 70, 108, 252, 1.6, 5.0, 12, 19, 0.62, 0.98, 1.0);   // inner shadow layer: longer, darker, tucked close to the skull
        M.locksMid = hairLayer(82, 150, 98, 262, 0.4, 5.4, 7, 15, 0.5, 1.05, 1.9);
        M.locksTop = hairLayer(84, 80, 100, 260, 4.6, 6.2, 4, 9, 0.4, 1.17, 1.3);   // fuller crown and nape
        M.locksHi2 = hairLayer(85, 48, 104, 256, 1.2, 6.0, 8, 19, 0.15, 1.2, 3.6);   // fine flyaway highlights
        M.fringe2 = (() => { const L = [], R = mulberry(123); for (let k = 0; k < 34; k++) { const t0 = k / 33, x = -4.6 + 9.2 * t0 + (R() - 0.5) * 0.35, hl = 5.5 + 0.9 * Math.pow(Math.abs(x) / 5, 2) - 0.3 * Math.exp(-x * x / 3), ln = 0.9 + R() * 0.6, sd = (x < 0 ? -1 : 1) * (0.2 + R() * 0.6) * Math.min(1, Math.abs(x) / 2) + (R() - 0.5) * 0.5, pts = [], rd = []; for (let i = 0; i < 5; i++) { const t = i / 4, px = x + sd * t, py = hl + 0.9 - (0.9 + ln) * t; pts.push([px, py, h3Zs(px, py) + 0.28 + 0.12 * Math.sin(t * 2.4)]); rd.push(0.2 * (1 - 0.85 * t * t) + 0.03); } L.push({ pts, rad: rd }); } return mkTubes(L, 5); })();
        M.fringe = (() => { const L = [], R = mulberry(86); for (let k = 0; k < 18; k++) { const x = -4.2 + 8.4 * k / 17 + (R() - 0.5) * 0.4, y0 = 6.55 - 0.3 * Math.abs(x) / 4.2, z0 = h3Zs(x, y0 - 0.6) + 0.35, ln = 1.3 + R() * 1.4, sd = (R() - 0.5) * 1.4, pts = [], rd = []; for (let i = 0; i < 5; i++) { const t = i / 4; pts.push([x + sd * t * 0.8, y0 - ln * t, z0 + 0.25 * Math.sin(t * 3) + 0.1 * t]); rd.push(0.26 * (1 - 0.8 * t * t) + 0.04); } L.push({ pts, rad: rd }); } return mkTubes(L, 5); })();
        M.locksFront = (() => { const L = [], R = mulberry(81); for (const sx of [-1, 1]) for (let k = 0; k < 7; k++) { const t0 = k / 6, x = sx * (5.55 + 0.25 * R()), z = 0.2 + R() * 1.0 - 0.5 * t0, y0 = 4.3 - 0.8 * t0, ln = 7 + R() * 4 + t0 * 2, pts = [], rd = []; for (let i = 0; i < 6; i++) { const t = i / 5; pts.push([x + sx * (0.25 * Math.sin(t * 2.6 + k) + 0.5 * t), y0 - ln * t, z + 0.3 * Math.sin(t * 3 + k * 2) - 0.2 * t]); rd.push(0.34 * (1 - 0.8 * t * t) + 0.05); } L.push({ pts, rad: rd }); } return mkTubes(L, 5); })();
        M.nose = mkParam(44, 48, (u, v) => { const x = -1.9 + 3.8 * u, y = 3.0 - 5.0 * v; return [x, y, h3Zs(x, y) + h3NoseH(x, y), (x + 7) / 14, (8.3 - y) / 14]; }, 1);   // (same planar UVs as the head, so it samples the face texture and blends in) one sculpted surface over the face: bridge, tip, alae, underside
        M.ear = h3Merged([[() => mkEllipsoid(1, 1, 1, 28, 18), m4.chain(m4.T(0, 0, 0), m4.S(0.55, 1.75, 1.15))], [() => mkLoop(1, 1, 0.16, 20, 6), m4.chain(m4.T(0.25, 0, 0), m4.RZ(Math.PI / 2), m4.S(1.75, 1, 1.15))], [() => mkEllipsoid(1, 1, 1, 12, 8), m4.chain(m4.T(0.1, -1.75, 0.05), m4.S(0.55, 0.65, 0.62))], [() => mkEllipsoid(1, 1, 1, 12, 8), m4.chain(m4.T(0.38, 0.1, 0.1), m4.S(0.22, 0.9, 0.5))]]);
        M.thumbSk = mkLimb(t => 0.62 * (1 - 0.2 * t) * Math.sqrt(Math.max(0, 1 - Math.pow(t, 9))), 1.9, 16, 16);
        M.knuckle = h3Merged([0, 1, 2, 3].map(k => [() => mkEllipsoid(1, 1, 1, 16, 12), m4.chain(m4.T((k - 1.5) * 0.9, 0.62, 0.3), m4.S(0.5, 0.42, 0.5))]));
        M.bootBase = {}; M.fingers = {}; M.neckSk = mkLimb(t => 2.3 - 0.15 * t, 5.2, 14, 10);
        for (const sx of [-1, 1]) {
            M.bootBase[sx] = h3Merged([[() => mkEllipsoid(1, 1, 1, 28, 14), m4.chain(m4.T(sx * 0.9, -26.85, 2.3), m4.RY(sx * 0.3), m4.S(2.15, 0.7, 3.7))]]);   // forefoot sole (bends at the toes)
            M.bootHeel = M.bootHeel || {}; M.bootHeel[sx] = h3Merged([[() => mkBox(1, 1, 1), m4.chain(m4.T(0, -26.9, -1.2), m4.S(2.7, 1.4, 2.2))]]);
        }
        // ---- boots, rebuilt: a flared shaft that follows the shin, and a lofted last (heel counter, instep, ball, pointed toe), welt sole, stacked heel and silver toe cap ----
        {
            const ip = (pts, z) => { if (z <= pts[0][0]) return pts[0][1]; for (let i = 1; i < pts.length; i++) if (z <= pts[i][0]) { const t = (z - pts[i - 1][0]) / (pts[i][0] - pts[i - 1][0]), e = t * t * (3 - 2 * t); return pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * e; } return pts[pts.length - 1][1]; };
            const WU = [[-3.4, 1.5], [-2.5, 2.25], [-1, 2.5], [1, 2.6], [2.2, 2.85], [3.6, 2.6], [5, 1.95], [6, 1.15], [6.55, 0.2]];   // half width along the foot
            const YT = [[-3.4, -24.9], [-2.6, -23.9], [-1.5, -23.1], [0.5, -22.9], [1.8, -23.7], [3.2, -24.7], [4.6, -25.3], [5.8, -25.7], [6.55, -25.95]];   // top line: heel counter up to the instep and down to the toe box
            const YB = [[-3.4, -25.5], [-0.4, -25.55], [1.2, -26.15], [2, -26.4], [4.8, -26.4], [5.8, -26.0], [6.55, -25.9]];   // underside: raised heel, flat ball, a little toe spring
            const loft = (z0, z1, wf, yt, yb, ex, capA, capB, nv) => {
                const V = [], I = [], P = (u, v) => {
                    const z = z0 + (z1 - z0) * v, a = u * TAU, c = Math.cos(a), sn = Math.sin(a); let w = wf(z), hh = (yt(z) - yb(z)) / 2; const yc = (yt(z) + yb(z)) / 2;
                    const cap = (zz, e) => Math.sqrt(Math.max(0, 1 - Math.pow(Math.max(0, 0.9 - Math.abs(zz - e)) / 0.9, 2)));
                    let k = 1; if (capA) k *= z < z0 + 0.9 ? cap(z, z0) : 1; if (capB) k *= z > z1 - 0.9 ? cap(z, z1) : 1; w *= k; hh *= k;
                    return [w * Math.sign(c) * Math.pow(Math.abs(c), 2 / ex), yc + hh * Math.sign(sn) * Math.pow(Math.abs(sn), 2 / ex), z];
                };
                h3Grid(V, I, 26, nv, (u, v) => {
                    const p = P(u, v), du = P(u + 0.004, v), dv = P(u, Math.min(1, v + 0.004)), a = [du[0] - p[0], du[1] - p[1], du[2] - p[2]], b = [dv[0] - p[0], dv[1] - p[1], dv[2] - p[2]];
                    return [p[0], p[1], p[2], a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0], u, 0.12 + 0.76 * v];
                });
                return h3Up(V, I);
            };
            const wU = z => ip(WU, z), yT = z => ip(YT, z), yB = z => ip(YB, z), ZS = 2.0;
            M.bUR = loft(-3.4, ZS, wU, yT, yB, 2.5, true, false, 12); M.bUF = loft(ZS, 6.55, wU, yT, yB, 2.5, false, true, 14);
            M.bSR = loft(-3.4, ZS, z => wU(z) + 0.1, z => yB(z) + 0.25, z => yB(z) - (z < -0.2 ? 0.4 : 0.5 - 0.1 * Math.max(0, Math.min(1, (z + 0.2) / 1.5))), 4, true, false, 12);   // welt / sole slab
            M.bSF = loft(ZS, 6.55, z => wU(z) + 0.1, z => yB(z) + 0.25, z => yB(z) - 0.5, 4, false, true, 14);
            M.bHeel = loft(-3.05, -0.3, z => 1.85 + 0.35 * Math.max(0, Math.min(1, (z + 3) / 1.2)), z => -25.7, z => -26.95, 5, true, true, 8);   // stacked leather heel
            M.bToe = loft(4.6, 6.62, z => wU(z) + 0.09, z => yT(z) + 0.1, z => yB(z) - 0.04, 2.5, false, true, 10);   // silver toe cap
            // shaft: flares at the top, tapers to the ankle, V-scoop at the front and back of the top edge, rolled lip. y runs 0 (top) .. 8.6 (ankle), local +z = behind the leg
            const SH = 8.6, shP = (u, v) => {
                const a = u * TAU, c = Math.cos(a), sn = Math.sin(a), r = 2.55 + 0.62 * Math.pow(1 - v, 1.6) + 0.12 * Math.exp(-Math.pow(v / 0.035, 2)), dip = 0.95 * sn * sn;
                return [r * c, v * SH + dip * (1 - v) * (1 - v), r * 1.06 * sn];
            };
            { const V = [], I = []; h3Grid(V, I, 30, 22, (u, v) => { const p = shP(u, v), du = shP(u + 0.004, v), dv = shP(u, Math.min(1, v + 0.004)), a = [du[0] - p[0], du[1] - p[1], du[2] - p[2]], b = [dv[0] - p[0], dv[1] - p[1], dv[2] - p[2]]; return [p[0], p[1], p[2], b[1] * a[2] - b[2] * a[1], b[2] * a[0] - b[0] * a[2], b[0] * a[1] - b[1] * a[0], u, v]; }); M.bSh = h3Up(V, I); }
        }
        H3.ok = true;
    } catch (e) { H3.ok = false; if (typeof console !== 'undefined') console.warn('3D hero unavailable:', e && e.message); }
    return H3.ok;
}
const H3D = { mesh: null, spec: -1, shin: -1, rim: -1, hoop: -1, glow: -1, useTex: -1, sd: -1, pj: -1, ls: 0, col: null };   // last-set GL state, so a run of same-mesh draws only changes what differs
function h3Dirty() { H3D.mesh = null; H3D.spec = H3D.shin = H3D.rim = H3D.hoop = H3D.glow = H3D.useTex = H3D.sd = H3D.pj = -1; H3D.col = null; }   // call whenever anything else touched the buffers/uniforms
function h3Draw(mesh, M, o) {
    const gl = H3.gl, U = H3.U, A = H3.A, D = H3D;
    if (D.mesh !== mesh) {
        gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vb); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.ib);
        gl.enableVertexAttribArray(A.aP); gl.vertexAttribPointer(A.aP, 3, gl.FLOAT, false, 32, 0);
        gl.enableVertexAttribArray(A.aN); gl.vertexAttribPointer(A.aN, 3, gl.FLOAT, false, 32, 12);
        gl.enableVertexAttribArray(A.aUV); gl.vertexAttribPointer(A.aUV, 2, gl.FLOAT, false, 32, 24);
        D.mesh = mesh;
    }
    if (H3ROOT) M = m4.mul(H3ROOT, M);
    gl.uniformMatrix4fv(U.uM, false, M); gl.uniformMatrix3fv(U.uNM, false, m4NormalInto(M));
    if (o.tex) { gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, o.tex); if (D.useTex !== 1) { gl.uniform1i(U.uTex, 0); gl.uniform1f(U.uUseTex, 1); D.useTex = 1; } }
    else { if (D.useTex !== 0) { gl.uniform1f(U.uUseTex, 0); D.useTex = 0; } const c = o.col || H3_MAGENTA; if (D.col !== c) { gl.uniform3fv(U.uCol, c); D.col = c; } }
    const sp = o.spec || 0, sh = o.shin || 12, rm = o.rim === undefined ? 0.2 : o.rim, hp = o.hoop ? 1 : 0, gw = o.glow || 0;
    if (D.spec !== sp) { gl.uniform1f(U.uSpec, sp); D.spec = sp; }
    if (D.shin !== sh) { gl.uniform1f(U.uShin, sh); D.shin = sh; }
    if (D.rim !== rm) { gl.uniform1f(U.uRim, rm); D.rim = rm; }
    if (D.hoop !== hp) { gl.uniform1f(U.uHoop, hp); D.hoop = hp; }
    if (D.glow !== gw) { gl.uniform1f(U.uGlow, gw); D.glow = gw; }
    if (o.fd) { const n = o.fd[0].length / 4; gl.uniform4fv(U.uFa, o.fd[0]); gl.uniform4fv(U.uFb, o.fd[1]); gl.uniform1f(U.uFn, n); D.fdn = n; } else if (D.fdn) { gl.uniform1f(U.uFn, 0); D.fdn = 0; }
    if (o.lidSh) { gl.uniform2f(U.uLidSh, o.lidSh[0], o.lidSh[1]); D.ls = 1; } else if (D.ls) { gl.uniform2f(U.uLidSh, 0, 0); D.ls = 0; }
    const pj = o.proj ? 1 : 0; if (D.pj !== pj) { gl.uniform1f(U.uProj, pj); D.pj = pj; } if (pj) { gl.uniform3fv(U.uCol, o.col); D.col = null; }   // face add-on: sample the face texture in head space, tinted by col
    const sd = (o.skin || 0) * (H3.skinAmt || 0); if (D.sd !== sd) { gl.uniform1f(U.uSkinD, sd); D.sd = sd; }   // pore / tone micro-detail on skin pieces only
    if (hp) { gl.uniform3fv(U.uH0, o.h0); gl.uniform3fv(U.uH1, o.h1); gl.uniform1f(U.uPh, o.ph || 0); }
    gl.drawElements(gl.TRIANGLES, mesh.n, gl.UNSIGNED_SHORT, 0);
}
const H3_MAGENTA = [1, 0, 1];
function h3NoseH(x, y) {   // nose relief above the head surface (head-local): dorsum ridge widening toward a rounded tip, alar wings, flattened underside, nostril dimples; blends to just under the skin at the patch edge
    const ss = (a, b, v) => { const q = Math.max(0, Math.min(1, (v - a) / (b - a))); return q * q * (3 - 2 * q); }, ax = Math.abs(x), g = (a, b) => Math.exp(-(a * a + b * b));
    const ramp = ss(3.0, -0.15, y), bh = 0.06 + 0.4 * ramp, wb = 0.3 + 0.2 * ramp;
    let h = bh * Math.exp(-Math.pow(ax / wb, 2.4)) + 0.42 * bh * Math.exp(-Math.pow(ax / (wb * 2.4), 2));   // ridge + sloping sides
    h += 0.64 * g(x / 0.55, (y + 0.42) / 0.46);                                                                // tip
    h += 0.48 * g((ax - 0.88) / 0.36, (y + 0.6) / 0.4);                                                     // alae
    h -= 0.36 * g((ax - 0.5) / 0.22, (y + 1.02) / 0.15);                                                       // nostril dimples
    h *= ss(-1.75, -1.08, y) * ss(1.95, 1.2, ax) * ss(3.0, 2.3, y);
    return h - 0.06;
}
const H3DYN = { gl: null, vb: null, ib: null, n: 0, V: new Float32Array(40 * 14 * 8), I: new Uint16Array(40 * 13 * 6), P: [] };
function h3Ribbon(nS, nC, f, M, o) {   // one smooth swept band (lips, brows, mustache): f(0..1) -> [x, y, z, halfHeight, halfDepth] along the curve, elliptical cross-section, built per frame
    const gl = H3.gl, D = H3DYN, V = D.V, I = D.I, P = D.P;
    if (D.gl !== gl) { D.gl = gl; D.vb = gl.createBuffer(); D.ib = gl.createBuffer(); }
    for (let i = 0; i < nS; i++) P[i] = f(i / (nS - 1));
    let vi = 0, ii = 0;
    for (let i = 0; i < nS; i++) {
        const a = P[Math.max(0, i - 1)], b = P[Math.min(nS - 1, i + 1)], p = P[i], tx = b[0] - a[0], ty = b[1] - a[1], tl = Math.hypot(tx, ty) || 1, nx = -ty / tl, ny = tx / tl, h = Math.max(p[3], 0.02), d = Math.max(p[4], 0.02);
        for (let j = 0; j <= nC; j++) {
            const an = j / nC * 6.2831853, c = Math.cos(an), s = Math.sin(an), gx = nx * c / h, gy = ny * c / h, gz = s / d, gn = Math.hypot(gx, gy, gz) || 1;
            V[vi++] = p[0] + nx * h * c; V[vi++] = p[1] + ny * h * c; V[vi++] = p[2] + d * s; V[vi++] = gx / gn; V[vi++] = gy / gn; V[vi++] = gz / gn; V[vi++] = i / (nS - 1); V[vi++] = j / nC;
        }
    }
    for (let i = 0; i < nS - 1; i++) for (let j = 0; j < nC; j++) { const a = i * (nC + 1) + j, c = a + nC + 1; I[ii++] = a; I[ii++] = c; I[ii++] = a + 1; I[ii++] = a + 1; I[ii++] = c; I[ii++] = c + 1; }
    gl.bindBuffer(gl.ARRAY_BUFFER, D.vb); gl.bufferData(gl.ARRAY_BUFFER, V.subarray(0, vi), gl.DYNAMIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, D.ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, I.subarray(0, ii), gl.DYNAMIC_DRAW);
    D.n = ii; H3D.mesh = null;   // buffers were rebound here: make h3Draw re-point the attributes
    h3Draw(D, M, o);
}
function h3Skin(mesh, M, B0, B1, bw, o) {   // draw a two-bone skinned tube: B0 = upper bone, B1 = lower bone (each maps the local unit Y-segment into hero space)
    const gl = H3.gl, U = H3.U;
    const d0 = Math.hypot(B0[4], B0[5], B0[6]) || 1, d1 = Math.hypot(B1[4], B1[5], B1[6]) || 1, cs = (B0[4] * B1[4] + B0[5] * B1[5] + B0[6] * B1[6]) / (d0 * d1);
    gl.uniform1f(U.uBulge, o.bulge ? Math.min(0.4, 1 / Math.max(0.6, Math.sqrt((1 + cs) / 2)) - 1) : 0);
    gl.uniform1f(U.uSk, 1); gl.uniform1f(U.uBw, bw);
    gl.uniformMatrix4fv(U.uB0, false, B0); gl.uniformMatrix4fv(U.uB1, false, B1);
    gl.uniformMatrix3fv(U.uN0, false, m4NormalMat(B0)); gl.uniformMatrix3fv(U.uN1, false, m4NormalMat(B1));
    h3Draw(mesh, M, o); gl.uniform1f(U.uSk, 0); gl.uniform1f(U.uBulge, 0);
}
function h3Skin3(mesh, M, B0, B1, B2, bw, o) {   // spine: three bones
    const gl = H3.gl, U = H3.U;
    gl.uniform1f(U.uBulge, 0); gl.uniform1f(U.uSk, 2); gl.uniform1f(U.uBw, bw);
    gl.uniformMatrix4fv(U.uB0, false, B0); gl.uniformMatrix4fv(U.uB1, false, B1); gl.uniformMatrix4fv(U.uB2, false, B2);
    gl.uniformMatrix3fv(U.uN0, false, m4NormalMat(B0)); gl.uniformMatrix3fv(U.uN1, false, m4NormalMat(B1)); gl.uniformMatrix3fv(U.uN2, false, m4NormalMat(B2));
    h3Draw(mesh, M, o); gl.uniform1f(U.uSk, 0);
}
function h3Target(T, w, h, depth) {   // grow-only render target (texture + optional depth)
    if (T.tex && T.w >= w && T.h >= h) return T;
    const gl = H3.gl, W = Math.max(T.w || 0, w), Hh = Math.max(T.h || 0, h);
    if (T.tex) { gl.deleteTexture(T.tex); gl.deleteFramebuffer(T.fbo); if (T.rb) gl.deleteRenderbuffer(T.rb); T.rb = null; }
    T.w = W; T.h = Hh; T.tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, T.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, W, Hh, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    T.fbo = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, T.fbo); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, T.tex, 0);
    if (depth) { T.rb = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, T.rb); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, W, Hh); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, T.rb); }
    T.ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
    gl.bindTexture(gl.TEXTURE_2D, null); gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    return T;
}
// bright-pass -> 2x -> 4x down -> gaussian blur -> composite (scene + bloom) into the canvas; the scene was drawn at SS x the output size, so the resolve is also the anti-aliasing
function h3Post(sw, sh, pw, ph) {
    const gl = H3.gl, P = H3.post, u = P.U, S = H3.S;
    const w1 = Math.max(2, Math.ceil(pw / 2)), h1 = Math.max(2, Math.ceil(ph / 2)), w2 = Math.max(2, Math.ceil(w1 / 2)), h2 = Math.max(2, Math.ceil(h1 / 2));
    const B1 = h3Target(H3.b1, w1, h1, false), B2 = h3Target(H3.b2, w2, h2, false), B3 = h3Target(H3.b3, w2, h2, false);
    gl.disable(gl.DEPTH_TEST); gl.useProgram(P.p); h3Dirty();
    gl.bindBuffer(gl.ARRAY_BUFFER, P.qb); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0); gl.disableVertexAttribArray(1); gl.disableVertexAttribArray(2);
    gl.uniform1i(u.uT0, 0); gl.uniform1i(u.uT1, 1);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, null); gl.activeTexture(gl.TEXTURE0);
    const pass = (mode, src, sw_, sh_, dst, dw, dh, off, dir) => {
        gl.bindFramebuffer(gl.FRAMEBUFFER, dst ? dst.fbo : null); gl.viewport(0, 0, dw, dh); gl.scissor(0, 0, dw, dh);
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, src.tex);
        gl.uniform1f(u.uMode, mode); gl.uniform2f(u.uSc, sw_ / src.w, sh_ / src.h); gl.uniform2f(u.uTx, 1 / src.w, 1 / src.h); gl.uniform1f(u.uOff, off || 0); gl.uniform2f(u.uDir, dir ? dir[0] : 0, dir ? dir[1] : 0);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
    pass(0, S, sw, sh, B1, w1, h1, (sw / w1) * 0.25);
    pass(1, B1, w1, h1, B2, w2, h2, (w1 / w2) * 0.25);
    const st = Math.max(0.5, Math.min(2.0, 0.0125 * w2));
    pass(2, B2, w2, h2, B3, w2, h2, 0, [st / B2.w, 0]);
    pass(2, B3, w2, h2, B2, w2, h2, 0, [0, st / B3.h]);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, B2.tex); gl.uniform2f(u.uSc2, w2 / B2.w, h2 / B2.h); gl.uniform2f(u.uTx2, 1 / B2.w, 1 / B2.h); gl.uniform1f(u.uG, 0.55);
    gl.uniform1f(u.uSS, Math.max(1, sw / pw)); pass(3, S, sw, sh, null, pw, ph, 0);
    gl.bindTexture(gl.TEXTURE_2D, null); gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, null); gl.activeTexture(gl.TEXTURE0);
    gl.enable(gl.DEPTH_TEST); gl.useProgram(H3.prog); h3Dirty();
}
// ---- procedural life: gaze saccades, blinks, and a spring-lagged cloth state (shared; only one hero is ever on screen at full detail) ----
const H3F = { gx: 0, gy: 0, tx: 0, ty: 0, nx: 0, b0: -1e9, bn: 0, last: 0 }, H3C = { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, bx: 0, by: 0, byw: 0, ph: 0 };
function h3Life(bx, by, byw) {
    const now = performance.now(); let dt = (now - H3F.last) / 1000; const fresh = dt > 0.25 || dt <= 0; if (fresh) dt = 1 / 60; dt = Math.min(dt, 0.05); H3F.last = now;
    if (now > H3F.nx) {   // idle eye wander: the emotion sets how wide, how often and which way he looks
        const f = H3X.fam || 'calm', A = { fear: [1.5, 0.55, 0], anger: [0.25, 1.6, 0], surprise: [0.15, 2, 0], thought: [1, 1, 0.12], sad: [0.6, 1.3, -0.12], fatigue: [0.5, 1.4, -0.06], joy: [1.1, 0.8, 0.03] }[f] || [1, 1, 0];
        const pr = n => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }; H3F.n3 = (H3F.n3 | 0) + 1;
        H3F.nx = now + (700 + pr(H3F.n3) * 1800) * A[1]; H3F.tx = (pr(H3F.n3 + 17) - 0.5) * 0.6 * A[0]; H3F.ty = (pr(H3F.n3 + 31) - 0.5) * 0.22 * A[0] + A[2]; }
    const gx = VQ.gx !== undefined ? VQ.gx : H3F.tx, gy = VQ.gy !== undefined ? VQ.gy : H3F.ty, k = Math.min(1, dt * 16);
    H3F.gx += (gx - H3F.gx) * k; H3F.gy += (gy - H3F.gy) * k;
    if (now > H3F.bn) { const f = H3X.fam || 'calm'; H3F.b0 = now; H3F.n2 = (H3F.n2 | 0) + 1; H3F.bn = now + (H3BL[f] || 3400) * (0.8 + 0.4 * Math.abs(Math.sin(H3F.n2 * 12.9898))); if (f === 'fear' && H3F.n2 % 3 === 0) H3F.bn = now + 260; }
    const bt = (now - H3F.b0) / (H3X.fam === 'fatigue' ? 320 : (H3X.fam === 'fear' || H3X.fam === 'pain') ? 120 : 160), blink = bt >= 0 && bt < 1 ? 1 - Math.abs(2 * bt - 1) : 0;
    // cloth: target lag opposes the body's velocity, an underdamped spring chases it
    const C = H3C; if (fresh) { C.bx = bx; C.by = by; C.byw = byw; C.x = C.y = C.z = C.vx = C.vy = C.vz = 0; }
    const vx = (bx - C.bx) / dt, vy = (by - C.by) / dt, vz = (byw - C.byw) / dt; C.bx = bx; C.by = by; C.byw = byw;
    const cl = (v, m) => Math.max(-m, Math.min(m, v)), tx = cl(-vx * 0.05, 1.1), ty = cl(-vy * 0.05, 0.7), tz = cl(-vz * 1.1, 0.6);
    for (const a of ['x', 'y', 'z']) { const t = a === 'x' ? tx : a === 'y' ? ty : tz; C['v' + a] += ((t - C[a]) * 170 - C['v' + a] * 8.5) * dt; C[a] += C['v' + a] * dt; C[a] = cl(C[a], 1.4); }
    C.ph += dt * 5.5; return blink;
}

// ---- gestures: arm targets (hero units, shoulder-relative world = body space), body pose and leg mode. T = frames. ----
const h3LP = T => { const E = 0.15 + 0.85 * Math.pow(Math.max(0, Math.sin(T * 0.04)), 0.6), pu = 0.5 + 0.5 * Math.sin(T * 0.42); return { E, pu, ha: E * pu, inh: 1 - E }; };
// ---- dance timing: his illness shows only in the rhythm and in small asides, never in the steps themselves ----
//  w  beat time: drifts a little ahead and behind, and stalls for ~5 frames once every 520, then hurries to catch up
//  li "listening": for about a second the upper body stills and the head tilts toward something only he hears, while the feet keep dancing
//  tc a hand brushes at the neck as if shooing something off (every ~12 s)
const h3Dn = T => {
    const S = x => { x = Math.min(1, Math.max(0, x)); return x * x * (3 - 2 * x); }, u = ((T % 520) + 520) % 520, v = ((T % 731) + 731) % 731;
    const lag = 5 * S((u - 300) / 5) * (1 - S((u - 340) / 100));
    return { w: T - lag + 2.2 * Math.sin(T * 0.019), li: S((u - 150) / 16) * (1 - S((u - 205) / 16)), tc: S((v - 400) / 5) * (1 - S((v - 424) / 8)) };
};
const H3G = (() => {
    const sn = Math.sin, cs = Math.cos, ab = Math.abs, PI = Math.PI, mx = Math.max;
    const cl = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x)), S = x => { x = cl(x); return x * x * (3 - 2 * x); };
    const ph = (T, per, off = 0) => { const u = T / per + off; return u - Math.floor(u); };
    const win = (u, a, b) => S((u - a) / (b - a)), bump = (u, a, b, c, d) => win(u, a, b) * (1 - win(u, c, d));
    const ov = u => { u = cl(u); const c1 = 1.7, c3 = c1 + 1; return 1 + c3 * Math.pow(u - 1, 3) + c1 * Math.pow(u - 1, 2); };   // ease-out with overshoot
    const lp = (a, b, t) => a + (b - a) * t, v3 = (a, b, t) => [lp(a[0], b[0], t), lp(a[1], b[1], t), lp(a[2], b[2], t)];
    const G = {};
    // def(name, arm(sx,T,phase,V) -> {w,pl,curl,fl}, body(T,phase,V) -> skeleton params, foot(sx,T,phase,V,f) mutates the foot pose)
    //  body: cr crouch | jy air | bob | pitch yaw lean | hy hp hr head | py pr hx pelvis | lp tp lumbar/thoracic pitch (- = arch) | ly ty twist (- = right shoulder fwd)
    //        ls ts side-bend (+ = toward screen right) | sh shL shR shrug | leg stance mode
    const def = (n, arm, body, foot) => { G[n] = { arm, body, foot }; };
    G.hula = { body: (T, p) => ({ ty: sn(p * 2) * 0.14, ly: -sn(p * 2) * 0.05, tp: sn(p * 2 + 1) * 0.04, ls: -sn(p) * 0.07, pr: cs(p) * 0.09, hr: sn(p) * 0.05 }),
        foot: (sx, T, p, V, f) => { f.y = 0.9 * mx(0, -sx * cs(p)); f.rz = sx * 0.05 * sn(p); } };

    // ---- idle: weight drifts from hip to hip; the left hand now and then touches the hat brim, the right thumbs the belt ----
    def('idle', (sx, T) => {
        const rest = [sx * 8.3 + sn(T * 0.03 + sx) * 0.3, 3 + sn(T * 0.05 + sx) * 0.5, 1.6];
        if (sx < 0) { const tip = bump(ph(T, 560), 0.86, 0.9, 0.93, 0.97); return { w: v3(rest, [-3.6, 24.6, 4.4], tip), pl: [lp(-0.5, -1, tip), -1, lp(-0.4, 0.2, tip)], curl: 0.3 }; }
        const fid = bump(ph(T, 380, 0.4), 0.5, 0.56, 0.62, 0.7);
        return { w: v3(rest, [7.2, 6.2, 3.2], fid), pl: [0.5, -1, -0.4], curl: lp(0.35, 0.9, fid) };
    }, T => { const s = sn(ph(T, 300) * 2 * PI);
        return { hula: 0, hx: s * 0.9, pr: s * 0.04, ls: -s * 0.025, ty: sn(T * 0.009) * 0.07, hy: sn(T * 0.013) * 0.3, hr: sn(T * 0.011) * 0.03, tp: sn(T * 0.05) * 0.012, sh: 0.03, leg: 'stand' }; },
    (sx, T, p, V, f) => { const s = sn(ph(T, 300) * 2 * PI), free = mx(0, -sx * s); f.ry += sx * 0.12 * free; f.x += sx * 0.5 * free; f.r += 0.1 * free; });

    // ---- power: slow inhale swells the chest, then the fists burst tight and shake ----
    def('power', (sx, T) => { const u = ph(T, 170), sw = 0.5 - 0.5 * cs(u * 2 * PI), ex = bump(u, 0.62, 0.7, 0.74, 0.9);
        return { w: [sx * (8.6 + 1.2 * ex) + sn(T * 2.4) * 0.15 * ex, 23.5 + 1.5 * sw + sn(T * 0.9) * 0.15, 2.6], pl: [sx, 0, -0.3], curl: 1.5 }; },
    T => { const u = ph(T, 170), sw = 0.5 - 0.5 * cs(u * 2 * PI), ex = bump(u, 0.62, 0.7, 0.74, 0.9);
        return { hula: 0, cr: 1.4 + 0.8 * ex, tp: -0.1 - 0.08 * sw + sn(T * 2.5) * 0.012 * ex, lp: -0.06, sh: 0.1 + 0.15 * sw + 0.12 * ex, hp: -0.2, ty: sn(T * 0.04) * 0.05, leg: 'wide' }; },
    (sx, T, p, V, f) => { const ex = bump(ph(T, 170), 0.62, 0.7, 0.74, 0.9); f.r = 0.06 * ex; });

    // ---- flex: alternates showing each bicep; torso turns into it, head turns to admire, shoulder rides up ----
    def('flex', (sx, T) => { const u = ph(T, 220), m = sx > 0 ? bump(u, 0, 0.1, 0.4, 0.5) : bump(u, 0.5, 0.6, 0.9, 1);
        return { w: v3([sx * 7.4, 14.5, 2.2], [sx * 10.8, 22 + sn(T * 0.5) * 0.4 * m, 1.2], m), pl: [sx, lp(-0.2, -0.6, m), -0.1], curl: lp(0.5, 1.5, m) }; },
    T => { const u = ph(T, 220), R = bump(u, 0, 0.1, 0.4, 0.5), L = bump(u, 0.5, 0.6, 0.9, 1), d = R - L;
        return { hula: 0, cr: 1 + 0.4 * (R + L), tp: -0.08, lp: -0.05, ty: -d * 0.2, ts: d * 0.07, shR: R * 0.25, shL: L * 0.25, sh: 0.08, hy: d * 0.5, hr: -d * 0.1, hp: -0.08, py: d * 0.08, leg: 'wide' }; },
    (sx, T, p, V, f) => { const u = ph(T, 220), m = sx > 0 ? bump(u, 0, 0.1, 0.4, 0.5) : bump(u, 0.5, 0.6, 0.9, 1); f.y += 0.6 * m; f.r += 0.2 * m; });

    // ---- cheer: crouch, launch with arms thrown up, hang, land and absorb; repeats ----
    def('cheer', (sx, T) => { const u = ph(T, 96), cr = win(u, 0, 0.2) * (1 - win(u, 0.2, 0.26)), up = bump(u, 0.22, 0.34, 0.62, 0.72);
        return { w: v3(v3([sx * 9, 14, 1], [sx * 8, 5, -4], cr), [sx * 10, 29, 1], up), pl: [sx * 0.3, 0, -0.6], curl: lp(0.3, 0.9, up) }; },
    T => { const u = ph(T, 96), cr = win(u, 0, 0.2) * (1 - win(u, 0.2, 0.26)), air = bump(u, 0.26, 0.4, 0.52, 0.66), land = bump(u, 0.62, 0.68, 0.72, 0.9);
        return { hula: 0, cr: 3.2 * cr + 2.4 * land, jy: 5.2 * air, tp: 0.2 * cr - 0.22 * air + 0.1 * land, lp: -0.2 * air + 0.08 * cr, sh: 0.35 * air, hp: -0.1 - 0.2 * air, ls: sn(T * 0.07) * 0.05, leg: 'stand' }; },
    (sx, T, p, V, f) => { const u = ph(T, 96), air = bump(u, 0.26, 0.4, 0.52, 0.66); f.r += 0.55 * air; f.tb -= 0.3 * air; f.y += 1.2 * air; f.x += sx * 0.8 * air; });

    // ---- point: coil back, snap the arm out as the chest uncoils, jab, retract; the eyes arrive first ----
    def('point', (sx, T) => {
        if (sx < 0) return { w: [-4.4, 5.4, 3.6], pl: [-1, 0.1, -0.3], curl: 1.5 };
        const u = ph(T, 200), wind = win(u, 0.05, 0.22) * (1 - win(u, 0.22, 0.27)), ext = win(u, 0.22, 0.3) * (1 - win(u, 0.84, 0.97));
        const w = v3(v3([8.5, 11, 1.6], [9, 16.5, -2.5], wind), [19.5, 17.8, 3.2], ext); w[2] += sn(T * 0.5) * 0.4 * ext; return { w, pl: [0, -1, 0.1], curl: 0.35 };
    }, T => { const u = ph(T, 200), wind = win(u, 0.05, 0.22) * (1 - win(u, 0.22, 0.27)), ext = win(u, 0.22, 0.3) * (1 - win(u, 0.84, 0.97)), eye = win(u, 0.12, 0.24) * (1 - win(u, 0.86, 0.97));
        return { hula: 0, ty: lp(0.2 * wind, -0.34, ext), py: 0.14 * ext, tp: 0.05 + 0.04 * wind, sh: 0.05, shR: 0.1 * ext, hy: 0.35 * eye, cr: 0.8 + 0.4 * wind, leg: 'stagger' }; });

    // ---- pointup: arm rises with overshoot, two skyward jabs, chest arches away ----
    def('pointup', (sx, T) => {
        if (sx < 0) return { w: [-6.4, 3.2, 3.2], pl: [-1, -0.2, -0.3], curl: 1.5 };
        const u = ph(T, 210), up = ov((u - 0.05) / 0.15) * (1 - win(u, 0.88, 0.98)), jab = bump(u, 0.46, 0.5, 0.5, 0.55) + bump(u, 0.6, 0.64, 0.64, 0.69);
        return { w: [lp(9, 8, up), lp(8, 30, up) + 1.6 * jab, 2 + sn(T * 0.2)], pl: [0.6, 0, -0.5], curl: 0.35 };
    }, T => { const u = ph(T, 210), up = ov((u - 0.05) / 0.15) * (1 - win(u, 0.88, 0.98)), jab = bump(u, 0.46, 0.5, 0.5, 0.55) + bump(u, 0.6, 0.64, 0.64, 0.69);
        return { hula: 0, ty: -0.14 * up, tp: -0.22 * up - 0.05 * jab, lp: -0.1 * up, ts: -0.08 * up, hp: -0.35 * up, shR: 0.25 * up, pr: 0.06 * up, hx: -0.6 * up, leg: 'contra' }; });

    // ---- hips: sassy weight shifts, hip pops, the free foot taps ----
    def('hips', (sx, T) => { const s = sn(ph(T, 240) * 2 * PI);
        return { w: [sx * (7.9 + 0.4 * mx(0, sx * s)), 3.9, 0.6], pl: [sx, 0.1, -0.3], curl: 0.5, wb: -sx * 0.4, wz: 0.7, wt: 0.9 }; },
    T => { const s = sn(ph(T, 240) * 2 * PI);
        return { hula: 0, hx: s * 1.0, pr: s * 0.08, ts: -s * 0.06, ls: s * 0.05, hr: -s * 0.07, ty: sn(T * 0.03) * 0.1, tp: 0.03, shR: mx(0, s) * 0.12, shL: mx(0, -s) * 0.12, hp: -0.12, leg: 'wide' }; },
    (sx, T, p, V, f) => { const s = sn(ph(T, 240) * 2 * PI), free = cl(-sx * s); f.z += 2 * free; f.ry += sx * 0.3 * free; f.x += sx * 0.8 * free; f.r -= 0.3 * free * (0.5 + 0.5 * sn(T * 0.4)); });

    // ---- draw: tense ready stance, fingers twitch, lightning draw with a lunge, recoil kick, holster ----
    def('draw', (sx, T) => { const u = ph(T, 210), d = win(u, 0.62, 0.68), hold = d * (1 - win(u, 0.86, 0.97)), rec = bump(u, 0.7, 0.72, 0.72, 0.8);
        if (sx > 0) return { w: v3([9.5, 6.5, 2.2 + 0.3 * sn(T * 0.4)], [15 + 0.8 * rec, 18.5 + 1.5 * rec, 6.5], hold), pl: [0.2, -1, 0.2], curl: lp(0.9 + 0.5 * sn(T * 0.5), 1.5, hold) };
        return { w: v3([-8.8, 5.6, 1.2], [-6.5, 13.5, -1.2], hold), pl: [-0.8, -1, 0.3], curl: 1.5 };
    }, (T, p) => { const u = ph(T, 210), d = win(u, 0.62, 0.68), hold = d * (1 - win(u, 0.86, 0.97)), rec = bump(u, 0.7, 0.72, 0.72, 0.8);
        return { hula: 0, cr: 1.6 + 0.7 * hold, ty: lp(0.1, -0.32, hold), py: 0.12 * hold, ly: -0.1 * hold, tp: 0.06 + 0.12 * rec, hp: -0.06 * rec, hy: 0.3 * hold, sh: 0.08, leg: 'stagger' }; },
    (sx, T, p, V, f) => { const u = ph(T, 210), hold = win(u, 0.62, 0.68) * (1 - win(u, 0.86, 0.97)); if (sx > 0) f.z += 2.2 * hold; });

    // ---- fireup: charging; the raised fist trembles harder as V.fire rises, the whole frame arches and braces ----
    def('fireup', (sx, T, p, V) => { const k = mx(0, V.fire || 0), tr = sn(T * 2.1) * (0.12 + 0.3 * k);
        return sx > 0 ? { w: [7.8 - k * 0.4 + tr, 28.5 - k * 1.5 + tr * 0.6, 4], pl: [0.7, 0, -0.4], curl: 1.5 } : { w: [-8.6, 20 + sn(T * 1.9) * 0.2 * k, 2.2], pl: [-1, -0.5, -0.3], curl: 0.5 }; },
    (T, p, V) => { const k = mx(0, V.fire || 0);
        return { hula: 0, ty: -0.18, tp: -0.12 - 0.1 * k + sn(T * 2.4) * 0.012 * k, lp: -0.06, ts: -0.07, shR: 0.2 + 0.2 * k, cr: 0.6 + 1.2 * k, hp: -0.2 * k, leg: 'stagger' }; });

    // ---- guard: boxer's bob and weave, tucked chin, a lead jab every few beats ----
    def('guard', (sx, T) => { const jab = bump(ph(T, 160), 0.7, 0.74, 0.76, 0.82);
        if (sx > 0) return { w: [lp(3.4, 9, jab), lp(19.8 + 0.7 * sn(T * 0.3), 19, jab), lp(7, 13, jab)], pl: [0.8, -1, 0], curl: 1.5 };
        return { w: [-3.4, 20.5 + 0.7 * sn(T * 0.3 + 1), 7], pl: [-0.8, -1, 0], curl: 1.5 }; },
    T => { const jab = bump(ph(T, 160), 0.7, 0.74, 0.76, 0.82), w = sn(T * 0.15);
        return { hula: 0, cr: 2.2 + 0.5 * ab(sn(T * 0.2)), ty: w * 0.28 - 0.2 * jab, py: -w * 0.1, ts: sn(T * 0.15 + 1.5) * 0.08, tp: 0.12, lp: 0.08, sh: 0.2, pr: w * 0.04, hp: 0.02, leg: 'stagger' }; },
    (sx, T, p, V, f) => { f.y += 0.6 * mx(0, sn(T * 0.4 + (sx > 0 ? 0 : PI))); });

    // ---- recoil: a hit lands, the body folds and flies back, arms fling, then it drags itself back to guard ----
    def('recoil', (sx, T) => { const h = bump(ph(T, 170), 0, 0.05, 0.05, 0.35);
        return { w: v3([sx * 3, 19.5 + sn(T * 0.9) * 0.3, 6], [sx * 9.5, 22, -1], h), pl: [sx, 0.6, 0.5], curl: 1.5 }; },
    T => { const u = ph(T, 170), h = bump(u, 0, 0.05, 0.05, 0.35), wob = sn(T * 0.6) * 0.03 * (1 - win(u, 0, 0.7));
        return { hula: 0, tp: 0.1 + 0.3 * h + wob, lp: 0.2 * h - 0.1, hp: -0.35 * h, cr: 2.2 + 1.8 * h, ty: 0.3 * h, py: -0.1 * h, sh: 0.3 + 0.1 * h, ts: 0.1 * h, leg: 'brace' }; },
    (sx, T, p, V, f) => { const h = bump(ph(T, 170), 0, 0.05, 0.05, 0.35); f.z -= 3 * h; f.y += 0.8 * h; });

    // ---- cower: curled and shaking; he peeks over his arms, then flinches back down ----
    def('cower', (sx, T) => { const u = ph(T, 260), peek = bump(u, 0.55, 0.62, 0.7, 0.78);
        return { w: [-sx * 1.6 + sn(T * 1.1 + sx) * 0.3, 21.5 - 2 * peek + sn(T * 1.1) * 0.3, 5.8], pl: [sx, 0.6, 0.5], curl: 1.5 }; },
    T => { const u = ph(T, 260), peek = bump(u, 0.55, 0.62, 0.7, 0.78), fl = bump(u, 0.78, 0.8, 0.8, 0.9);
        return { hula: 0, tp: 0.36 - 0.15 * peek + 0.15 * fl, lp: 0.1, cr: 3.2 + 0.8 * fl, ls: sn(T * 1.3) * 0.045, ty: sn(T * 1.1) * 0.05, sh: 0.45, hp: -0.25 * peek, leg: 'stand' }; },
    (sx, T, p, V, f) => { f.x -= sx * 1.2; f.ry = -sx * 0.3; f.rz = sn(T * 1.2 + sx) * 0.04; });

    // ---- clutch: one hand to the heart, wheezing breaths, knees going, the occasional gasp ----
    def('clutch', (sx, T) => ({ w: [sx * 1.4, 15.6 + sn(T * 0.3) * 0.3 + sn(T * 0.2) * 0.4, 5.4], pl: [sx * 0.9, -0.6, 0.2], curl: 1.2 }),
    T => { const gasp = bump(ph(T, 300), 0.7, 0.74, 0.78, 0.86);
        return { hula: 0, tp: 0.34 + 0.06 * sn(T * 0.2) - 0.15 * gasp, lp: 0.2, cr: 3.2 + 1.2 * sn(T * 0.15), sh: 0.22, ls: sn(T * 0.1) * 0.06, ts: 0.1, ty: sn(T * 0.08) * 0.05, hx: sn(T * 0.1) * 1.2, hp: -0.3 * gasp, leg: 'wide' }; });

    // ---- laugh: bursts of "ha" with an inhale between; belly-clutch + tear-wipe, folding and arching spine ----
    def('laugh', (sx, T) => { const L = h3LP(T), p = L.ha;
        return sx > 0 ? { w: [3.8 + sn(T * 0.21) * 0.5 * L.E, 7.2 + p * 1.3 - L.inh * 0.8, 5.6 + p * 0.8], pl: [0.9, -0.6, -0.2], curl: 0.35 }
            : { w: [-5.4 + sn(T * 0.21) * 0.7 * L.E, 19.4 + p * 1.0 + sn(T * 0.42) * 0.3, 4.4], pl: [-1, -0.3, 0.2], curl: 0.35 }; },
    T => { const L = h3LP(T), p = L.ha, E = L.E;
        return { hula: 0, cr: 0.8 + E * (1.4 + 2.4 * L.pu), bob: E * L.pu * 0.9, pitch: 0.02 + E * 0.17, hp: -0.2 - 0.3 * L.inh + 0.18 * p, lean: sn(T * 0.05) * 0.05, leg: 'wide',
            tp: -0.16 * L.inh + 0.26 * p + 0.04, lp: -0.12 * L.inh + 0.18 * p, sh: 0.1 + 0.32 * p, ts: sn(T * 0.21) * 0.1 * E, ty: sn(T * 0.1) * 0.1 * E, pr: sn(T * 0.21) * 0.05 * E, hx: sn(T * 0.21) * 0.5 * E }; });

    // ---- locomotion: opposite arm swings with the opposite leg, shoulders counter-twist the pelvis, the body bobs ----
    const gait = (n, per, amp, lean, mode) => {
        def(n, (sx, T) => { const s = sn(T * per + (sx > 0 ? PI : 0));
            return n === 'walk' ? { w: [sx * 7, 6.5 + 0.6 * cs(T * per), 1.5 + 3.6 * s], pl: [sx * 0.3, -1, -0.3], curl: 0.3 }
                : { w: [sx * (6.4 - (n === 'dash' ? 1.4 : 1) * mx(0, s)), (n === 'dash' ? 9.5 : 11.2) + (n === 'dash' ? 3.8 : 3) * s, 2 + (n === 'dash' ? 7 : 5.5) * s], pl: [sx * 0.9, -1, -0.2], curl: 1.5 }; },
        T => { const a = T * per, s = sn(a), r = n === 'walk';
            return { hula: 0, ty: s * amp, py: -s * amp * 0.65, ly: s * amp * 0.25, pr: s * (r ? 0.04 : 0.06), hx: r ? s * 0.4 : 0, jy: (r ? 0.5 : n === 'dash' ? 1.6 : 1.0) * (0.5 - 0.5 * cs(2 * a)), cr: r ? 0.8 : n === 'dash' ? 2.8 : 2.2 + 0.4 * cs(2 * a),
                tp: lean, lp: lean * 0.6, sh: r ? 0.02 : 0.12, hp: r ? 0.02 * sn(2 * a) : -0.04, leg: mode }; });
    };
    gait('run', 0.35, 0.3, 0.12, 'run'); gait('walk', 0.4, 0.14, 0.03, 'walk'); gait('dash', 0.5, 0.26, 0.24, 'sprint');

    // ---- crossed: defiant arms, impatient foot tap, weight shifting, now and then a head-turn "hmph" ----
    def('crossed', (sx, T) => ({ w: [-sx * 4.4, 11.4 + (sx > 0 ? 0 : 1), 6.2 - (sx > 0 ? 0 : 0.8)], pl: [sx * 0.2, -0.8, 0.7], curl: 1.5 }),
    T => { const u = ph(T, 360), hm = bump(u, 0.5, 0.55, 0.6, 0.7), sg = bump(u, 0.78, 0.84, 0.88, 0.95);
        return { hula: 0, tp: 0.05 + 0.1 * sg, pr: 0.05, hx: 0.6 + sn(T * 0.02) * 0.6, ty: 0.1, ts: 0.04, hy: 0.5 * hm, hp: -0.12 * hm - 0.1 * sg, hr: 0.1 * hm, leg: 'contra' }; },
    (sx, T, p, V, f) => { if (sx > 0) { const tap = mx(0, sn(T * 0.3)); f.r -= 0.3 * tap; f.y += 0.4 * tap; } });

    // ---- stoic: a statue that still breathes; a slow shoulder roll and a minute hat-nod ----
    def('stoic', (sx, T) => ({ w: [sx * 8.4, 4.6, 1.7], pl: [sx, -0.3, -0.4], curl: 1.5 }),
    T => { const u = ph(T, 480), rl = bump(u, 0.7, 0.76, 0.8, 0.88);
        return { hula: 0, cr: 1, tp: -0.05 + sn(T * 0.04) * 0.01, lp: -0.03, ls: sn(T * 0.02) * 0.012, ty: sn(T * 0.01) * 0.05, sh: 0.1 * rl, hp: 0.05 - 0.08 * bump(ph(T, 700), 0.4, 0.45, 0.5, 0.58), leg: 'wide' }; });

    // ---- hold: carrying something heavy forward; leans back to counter it, hands readjust, eyes check it ----
    def('hold', (sx, T) => ({ w: [sx * 2.6 + sx * sn(T * 0.05) * 0.3, 10.5 + sn(T * 0.07 + sx) * 0.4, 6.4], pl: [sx * 0.8, -0.6, 0], curl: 0.8 }),
    T => ({ hula: 0, cr: 0.6 + 0.3 * ab(sn(T * 0.08)), tp: -0.08, lp: -0.05, hp: 0.1 + 0.12 * sn(T * 0.04), hx: sn(T * 0.06) * 0.5, sh: 0.06, leg: 'stand' }));

    // ---- oath: hand rises to the heart, presses, a solemn nod, lowers ----
    def('oath', (sx, T) => { const u = ph(T, 360), rs = win(u, 0.05, 0.2) * (1 - win(u, 0.88, 0.97)), pr = bump(u, 0.4, 0.44, 0.44, 0.5);
        return sx > 0 ? { w: v3([8.2, 4.4, 1.6], [3.2, 13.6 + sn(T * 0.06) * 0.2, 5.4 + 0.5 * pr], rs), pl: [lp(1, 0.9, rs), -0.8, 0], curl: lp(0.4, 0.3, rs) } : { w: [-8.4, 4, 1.6], pl: [-0.8, -0.5, -0.4], curl: 1.5 }; },
    T => { const u = ph(T, 360), rs = win(u, 0.05, 0.2) * (1 - win(u, 0.88, 0.97)), nod = bump(u, 0.45, 0.5, 0.5, 0.58);
        return { hula: 0, tp: -0.1 * rs, lp: -0.06, ty: -0.14 * rs, shR: 0.1 * rs, hp: -0.12 + 0.2 * nod, pr: 0.03 * rs, leg: 'stand' }; });

    // ---- grab: greedy alternating scoops; each hand reaches, closes, drags in; chest and head dart after it ----
    const scoop = (sx, T) => { const u = ph(T, 180, sx > 0 ? 0 : 0.5), out = win(u, 0, 0.28) * (1 - win(u, 0.3, 0.55)), pull = win(u, 0.3, 0.55) * (1 - win(u, 0.7, 0.9)), grip = win(u, 0.25, 0.35) * (1 - win(u, 0.7, 0.8));
        return { out, pull, grip, w: v3(v3([sx * 7, 9, 3], [sx * 4, 13.5, 11.8], out), [sx * 3, 12, 5], pull) }; };
    def('grab', (sx, T) => { const q = scoop(sx, T); return { w: q.w, pl: [sx * 0.4, -1, -0.1], curl: lp(0.2, 1.5, q.grip) }; },
    T => { const R = scoop(1, T), L = scoop(-1, T);
        return { hula: 0, ty: -(R.out - L.out) * 0.32, tp: 0.2 + 0.1 * (R.out + L.out), lp: 0.15, sh: 0.1, hp: -0.18, hy: sn(T * 0.1) * 0.4, cr: 2 + 0.6 * (R.pull + L.pull), leg: 'wide' }; },
    (sx, T, p, V, f) => { f.z += 1.5 * scoop(sx, T).out; });

    // ---- triumph: gather breath, then burst into a V with a roar; one boot up on a rock, fists shaking ----
    def('triumph', (sx, T) => { const u = ph(T, 300), g = bump(u, 0.1, 0.35, 0.4, 0.5), t = ov((u - 0.42) / 0.1) * (1 - win(u, 0.9, 0.99));
        return { w: v3(v3([sx * 9, 12, 1], [sx * 5.5, 9, 3.5], g), [sx * 12.5, 24 + sn(T * 1.2) * 0.5 * cl(t), 0], cl(t, 0, 1.15)), pl: [sx * 0.5, 0, -0.5], curl: lp(0.3, 1.4, cl(t)) }; },
    T => { const u = ph(T, 300), g = bump(u, 0.1, 0.35, 0.4, 0.5), t = cl(ov((u - 0.42) / 0.1) * (1 - win(u, 0.9, 0.99)), 0, 1.1);
        return { hula: 0, tp: -0.2 * t + 0.15 * g, lp: -0.16 * t, cr: 0.6 + 1.2 * g, hp: -0.3 * t, sh: 0.18 * t, ts: sn(T * 0.04) * 0.04, hx: -0.8 * t, leg: 'wide' }; },
    (sx, T, p, V, f) => { const t = cl(ov((ph(T, 300) - 0.42) / 0.1) * (1 - win(ph(T, 300), 0.9, 0.99)), 0, 1); if (sx > 0) { f.y += 3 * t; f.z += 3 * t; f.r -= 0.2 * t; } });

    // ---- kneel: a knight's pledge; head bowed, hand on thigh, and a fist to the chest on the beat ----
    def('kneel', (sx, T) => { const sal = bump(ph(T, 400), 0.3, 0.4, 0.6, 0.7);
        return sx > 0 ? { w: v3([12.5, 8, 4.5 + sn(T * 0.1) * 0.3], [3, 14.5, 5.5], sal), pl: [0.3, -1, 0.2], curl: lp(0.4, 1.5, sal) } : { w: [-6.6, 3.2, 3.5], pl: [-1, -0.2, -0.2], curl: 1.5 }; },
    T => { const sal = bump(ph(T, 400), 0.3, 0.4, 0.6, 0.7);
        return { hula: 0, cr: 9.5, tp: 0.12 + 0.14 * sal, lp: 0.14, ty: -0.2, hy: 0.4 - 0.3 * sal, hp: -0.05 + 0.1 * sal, leg: 'kneel' }; });

    // ---- break-dance routine inside the dance (36 s loop): toprock -> six-step -> helicopter spin -> windmill -> freeze -> worm -> toprock. Each move is a set of root-transform / spine / arm / foot targets blended over the salsa. ----
    const BRKP = 2200, SCH = { six: [0.12, 0.15, 0.24, 0.27], spin: [0.30, 0.33, 0.42, 0.45], wind: [0.48, 0.52, 0.64, 0.68], frz: [0.71, 0.74, 0.80, 0.83], worm: [0.86, 0.88, 0.96, 0.98] }, MVS = ['six', 'spin', 'wind', 'frz', 'worm'];
    const brk = (T, f) => { const o = { six: 0, spin: 0, wind: 0, frz: 0, worm: 0, aS: 0, aW: 0 }; if (f) { o[f] = 1; if (f === 'spin') o.aS = (T * 0.16) % 6.2832; if (f === 'wind') o.aW = (T * 0.14) % 6.2832; return o; }
        const u = ph(T, BRKP); for (const k of MVS) { const c = SCH[k]; o[k] = bump(u, c[0], c[1], c[2], c[3]); } o.aS = 6.2832 * 3 * S((u - 0.34) / 0.07); o.aW = 6.2832 * 4 * S((u - 0.53) / 0.10); return o; };   // aS / aW end on whole turns, so the rotation never has to be un-wound
    const MVB = { six: a => ({ ht: -1.57, rp: 1.38, ry: -18.6, rz: -0.14, hp: -0.55, rsx: 0.5 * sn(a * 0.5), tp: 0.1 * sn(a) }), spin: () => ({ cr: 1.6, tp: 0.1, rz: -0.02 }),   // standing pirouette: low, tucked, spun on the ball of one foot
        wind: () => ({ ht: 2.35, rp: -1.9, ry: -16.5, rz: -0.15, hp: 0.3 }), frz: a => ({ ht: -1.57, rp: 1.2, ry: -17.5, rz: -0.15, rl: 0.2, hp: -0.5, rsx: 0.55 + 0.04 * sn(a) }),
        worm: a => ({ ht: -1.3, ro: 1.5708, rl: -1.5708 + 0.13 * sn(a - 2.4), ry: -21, rx: -1 + 3 * sn(a * 0.25), rz: -0.12, tp: -0.2 + 0.6 * sn(a), lp: 0.5 * sn(a - 1.5), py: 0.25 * sn(a - 2.2), hp: -0.55 + 0.2 * sn(a - 0.6) }) };
    const brkBody = (T, B, f) => { const k = brk(T, f); let wb = 0; for (const m of MVS) wb += k[m]; wb = Math.min(1, wb); if (wb < 0.002) return B;
        for (const q in B) if (typeof B[q] === 'number') B[q] *= 1 - wb;
        const a = T * 0.17; B.rs = k.aS + k.aW;
        for (const m of MVS) if (k[m] > 0.002) { const v = MVB[m](a); for (const q in v) { if (q === 'rsx') B.rs += v[q] * k[m]; else B[q] = (B[q] || 0) + v[q] * k[m]; } }
        return B; };
    const brkArm = (sx, T, A, f) => { const k = brk(T, f), a = T * 0.17; let wb = 0; for (const m of MVS) wb += k[m]; if (wb < 0.002) return A;
        const AT = { six: () => [sx * 6.8, 14.2, 12.25 - 3.2 * mx(0, sn(a * 0.5 + (sx > 0 ? 0 : PI)))], spin: () => [-sx * 4.2, 12.2 + (sx > 0 ? 0 : 0.8), 6.1], wind: () => [sx * 6.8, 20.6, -12], frz: () => sx > 0 ? [6.8, 12.1, 11.6] : [-8.5, 24 + sn(a) * 0.8, 3], worm: () => [sx * 7.2, 13.8, 7.6 - 1.6 * mx(0, sn(a - 0.9 + (sx > 0 ? 0 : PI)))] };
        let w = A.w; for (const m of MVS) if (k[m] > 0.002) w = v3(w, AT[m](), k[m]);
        A.w = w; let pl = A.pl || [sx * 0.8, -0.5, -0.2]; for (const m of MVS) if (k[m] > 0.002) pl = v3(pl, m === 'spin' ? [sx * 0.2, -0.8, 0.7] : [sx * 0.9, 0, -0.4], k[m]); A.pl = pl; A.curl = lp(A.curl, 0.6, Math.min(1, wb)); return A; };
    const brkFoot = (sx, T, ft, f) => { const k = brk(T, f), a = T * 0.17, to = (m, t) => { const w = k[m]; if (w < 0.002) return; for (const q in t) ft[q] = lp(ft[q], t[q], w); };
        const c = a + (sx > 0 ? 0 : PI);
        to('six', { x: sx * 4 + 5 * cs(c), z: -3 + 4 * sn(c), y: 1.5 + 1.5 * mx(0, sn(c + 1)), ry: sx * 0.3, r: 0.2, tb: 0 }); to('spin', sx > 0 ? { x: -3, z: 0.3, y: 0, ry: 0, r: 0, tb: 0 } : { x: 4.6, z: 3.2, y: 7, ry: -0.5, r: 0.5, tb: 0 });
        to('wind', { x: sx * 9, z: 0, y: 3, ry: sx * 0.4, r: 0.1, tb: 0 }); to('frz', { x: sx * 1.4, z: -1, y: 3.5, ry: sx * 0.2, r: 0.6, tb: 0 });
        to('worm', { x: sx * 2.4, z: 2.6 * sn(a - 3.1 + sx * 0.25), y: 0, ry: sx * 0.1, r: 1.35 + 0.3 * sn(a - 3.6 + sx * 0.3), tb: 0 }); };
    const brkDef = (n, f) => def(n, (sx, T) => brkArm(sx, T, { w: [sx * 5, 8, 3], pl: [sx * 0.8, -0.5, -0.2], curl: 0.8 }, f), T => brkBody(T, { hula: 0, leg: 'dance' }, f), (sx, T, p, V, f2) => brkFoot(sx, T, f2, f));
    // ---- dance: salsa step -- hips swing, shoulders shimmy alternately, arms trade high/low, heels tap ----
    def('dance', (sx, T) => { const Q = h3Dn(T), bt = Q.w * 0.2, li = Q.li, side = sx > 0 ? 0 : PI, n = Math.floor(bt / (8 * PI)), pp = ph(bt, 8 * PI), amp = sx > 0 ? 1 : 0.8;
        // arms swing at waist-to-chest height in counter-phase with the hips; once per 8-count one arm (or, every third phrase, both) comes in for an accent
        const m = lp(0.5 + 0.5 * sn(bt + side - 0.4), 0.5, 0.8 * li), dp = 0.5 + 0.5 * cs(2 * bt), kind = n % 3, acc = bump(pp, 0.62, 0.74, 0.86, 0.97);
        let w = [sx * (5 + m * amp), 7.4 + 4.4 * m * amp - 0.5 * dp, 3.2 + 1.5 * m], pl = [sx * 0.8, -0.5, -0.2], curl = lp(0.95, 0.5, m);
        if ((kind === 0 && sx > 0) || (kind === 1 && sx < 0)) { w = v3(w, [sx * 9.5, 23.5 + sn(bt * 2) * 0.8, 2], acc); pl = [sx * 0.9, 0, -0.2]; curl = lp(curl, 0.25, acc); }
        else if (kind === 2) { w = v3(w, [sx * 3.2, 12.5 + sn(bt * 4) * 0.5, 5.8], acc * 0.8); }
        if (sx > 0) { w = v3(w, [4.8, 23, 1.6], 0.5 * li); w = v3(w, [3.4, 19.5, 3.5], Q.tc); }
        w[0] += 0.07 * sn(T * 0.55 + sx); w[1] += 0.06 * sn(T * 0.5 + 2);   // a faint tremor
        return brkArm(sx, T, { w, pl, curl }); },
    T => { const Q = h3Dn(T), bt = Q.w * 0.2, s = sn(bt), li = Q.li, fr = 1 - 0.8 * li, dip = 0.5 + 0.5 * cs(2 * bt);
        // weight shifts hip to hip, the pelvis leads and the chest counter-rotates a beat late, the knees dip between steps
        return brkBody(T, { hula: 0, cr: 0.9 + 0.6 * dip, hx: s * 1.5, pr: s * 0.11, py: -sn(bt - 0.5) * 0.12 * fr, ty: sn(bt - 0.9) * 0.2 * fr, ls: -s * 0.05 * fr, ts: s * 0.06 * fr, tp: 0.04 + 0.05 * (1 - dip) + 0.05 * li, sh: 0.1 * li,
            shL: mx(0, sn(2 * bt + PI)) * 0.07 * fr, shR: mx(0, sn(2 * bt)) * 0.07 * fr, hp: -0.04 + 0.05 * cs(2 * bt - 0.5) + 0.04 * li, hy: sn(bt * 0.5 - 0.3) * 0.18 - 0.28 * li, hr: -s * 0.05 + 0.17 * li, leg: 'dance' }); },
    (sx, T, p, V, f) => brkFoot(sx, T, f));
    for (const n of MVS) brkDef(n === 'wind' ? 'windmill' : n === 'frz' ? 'freeze' : n, n);

    // ---- clap: 4 front claps then 1 overhead; hops on the beat, head nods along ----
    def('clap', (sx, T) => { const c = ab(cs(T * 0.3)), o = bump(ph(T, 100), 0.66, 0.74, 0.9, 0.98);
        return { w: v3([sx * (1.2 + 2.6 * c), 15.5, 6.5], [sx * (1 + 2.6 * c), 26, 2.5], o), pl: [sx * 0.5, -0.6, 0], curl: 0.3 }; },
    T => { const c = ab(cs(T * 0.3)), o = bump(ph(T, 100), 0.66, 0.74, 0.9, 0.98);
        return { hula: 0, jy: 0.8 * (1 - c), tp: 0.08 * (1 - c) - 0.1 * o, sh: 0.06 + 0.1 * (1 - c), hy: sn(T * 0.05) * 0.3, hp: -0.1 + 0.08 * (1 - c), leg: 'dance' }; });

    // ---- reach: climbing stretch, arms alternate up and pull; spine lengthens, body lifts on the opposite toe ----
    def('reach', (sx, T) => { const a = T * 0.12, m = sx > 0 ? 0.5 + 0.5 * sn(a) : 0.5 - 0.5 * sn(a);
        return { w: [sx * 3.2, lp(23.5, 31, m), lp(3.5, 1.4, m)], pl: [sx * 0.3, 0, -0.5], curl: lp(0.9, 0.3, m) }; },
    T => { const a = T * 0.12, d = sn(a) * 0.5;
        return { hula: 0, tp: -0.32, lp: -0.16, ts: d * 0.2, ty: -d * 0.28, shR: (0.5 + d) * 0.4, shL: (0.5 - d) * 0.4, hp: -0.5, pr: d * 0.06, leg: 'tiptoe' }; },
    (sx, T, p, V, f) => { f.y += 1.1 * mx(0, sn(T * 0.12 + (sx > 0 ? PI : 0) + 0.8)); });

    // ---- visor: shades his eyes and scans the horizon; the eyes sweep first, the chest follows, then he leans in on a sighting ----
    def('visor', (sx, T) => sx > 0 ? { w: [3.6, 23.2, 5.6], pl: [0.9, 0, 0], curl: 0.2, fl: 0.2 } : { w: [-7.4, 3.2, 2.4], pl: [-1, 0, -0.3], curl: 1.5 },
    T => { const u = ph(T, 420), sc = sn(u * 2 * PI), spot = bump(u, 0.7, 0.72, 0.74, 0.8);
        return { hula: 0, hy: sc * 0.6, ty: sn(u * 2 * PI - 0.6) * 0.26, py: -sc * 0.06, tp: 0.05 + 0.1 * spot, shR: 0.1, hx: sc * 0.4, leg: 'stagger' }; });

    // ---- surf: low wobbling board stance, arms windmilling for balance, knees pumping, riding the swell ----
    def('surf', (sx, T) => ({ w: [sx * 14.5, 16 + sx * sn(T * 0.15) * 3 + sn(T * 0.11 + sx) * 1.2, 0], pl: [sx * 0.3, -1, 0], curl: 0.3 }),
    T => ({ hula: 0, cr: 3.5 + 0.8 * sn(T * 0.2), pr: sn(T * 0.12) * 0.1, ty: sn(T * 0.09) * 0.25, tp: 0.12, lp: 0.12, ts: sn(T * 0.12) * 0.12, sh: 0.05, hy: sn(T * 0.06) * 0.3, leg: 'lunge' }),
    (sx, T, p, V, f) => { f.ry = sx * 0.8; f.rz = sn(T * 0.12) * 0.1; });

    // ---- wave: friendly sweeping wave, head tilting into it, weight on the other hip, a big wave every few seconds ----
    def('wave', (sx, T) => { if (sx < 0) return { w: [-8.2, 3.2 + sn(T * 0.1) * 0.3, 1.6], pl: [-1, -0.3, -0.4], curl: 0.3 };
        const big = 1 + 0.8 * bump(ph(T, 300), 0.4, 0.45, 0.6, 0.7); return { w: [11 + 3 * big * sn(T * 0.4), 25 + (big - 1) * 2, 2], pl: [0.8, -0.2, -0.3], curl: 0.1 }; },
    T => { const big = bump(ph(T, 300), 0.4, 0.45, 0.6, 0.7);
        return { hula: 0, hx: -0.5, ts: sn(T * 0.1) * 0.05, shR: 0.16 + 0.1 * sn(T * 0.4) + 0.1 * big, ty: -0.06, hr: -0.12 - 0.05 * big, hy: 0.15, pr: 0.05, hp: -0.05, leg: 'contra' }; });

    // ---- smoke: sitting on a ledge, legs dangling; the scene's state {rise, drag, hold, fit, c, wipe} drives the joint, the lungs and the cough ----
    def('smoke', (sx, T, p, V) => { const m = V.sm || {}, rise = m.rise || 0, hold = m.hold || 0, fit = m.fit || 0, c = m.c || 0, wipe = m.wipe || 0, bz = m.bz || 0;   // bz: the stash scene (pocket, bag, chop, bill) takes the pose over like a toke does
        const tk = m.tk || 0, ta = m.ta || 1, gs = tk * (0.55 + 0.45 * sn(T * 0.09)), br = sn(T * 0.2);
        if (sx > 0) { const ln = (m.ln || 0) * (1 - Math.min(1, Math.max(rise, hold, fit, c, wipe, bz))), up0 = Math.min(1, Math.max(rise, hold, fit, c, wipe, bz)); let w = v3([lp(8.4, 5.2, ln) + 0.3 * br * tk, lp(4.9, 5.2, ln), lp(7.0, 11.2, ln)], [0.5, 22.5, 3.9], rise); w[1] += 0.8 * (m.gb || 0) * (1 - up0); w = v3(w, [4.6, 14.5, 6.4], hold); w = v3(w, [12, 16, 3.2 + 1.5 * c], fit); w[1] += 2 * c * fit; w = v3(w, [7, 4.5, 2.5], m.pk || 0); w = v3(w, [3.4, 12.5, 10.5], m.bg || 0); w = v3(w, [3.2, 9, 10.8], m.bend || 0); w[0] += sn(T * 1.3) * 1.5 * (m.chop || 0); w = v3(w, [2.8, 21.8, 4.9], m.bill || 0); const tw = m.tw || 0; w[0] += sn(T * 1.7) * 0.35 * tw; w[1] += sn(T * 2.3 + 1) * 0.3 * tw; const up = Math.max(rise, fit, hold, bz); return { w, pl: [lp(lp(0.5, 1.4, ln), 0.5, up), lp(lp(-0.6, -0.1, ln), -0.6, up), lp(lp(0.1, -0.45, ln), 0.1, up)], curl: 0.85, fl: 0.04 }; }
        const ln = (m.ln || 0) * (1 - Math.min(1, Math.max(rise, hold, fit, c, wipe, bz))), gb = (m.gb || 0) * (1 - Math.min(1, Math.max(rise, hold, fit, c, wipe, bz))); let w = v3([lp(-8.4, -5.2, ln), lp(4.6, 5.2, ln), lp(6.8, 11.2, ln)], (m.gk === 0 ? [-12.5, 11.8, 8.2] : m.gk === 1 ? [-8, 10.4, 10] : m.gk === 2 ? [-1.6, 14.8, 6.6] : m.gk === 4 ? [-3.2, 19.4, 9.4] : m.gk === 5 ? [-5.4, 25, 3.6] : [-6.8, 8.6, 9.4]), Math.min(1, gb)); w = v3(w, [-3.2, 12.5 - 1.5 * c, 5.8], fit); w = v3(w, [-6, 8.8, 10.4], m.bend || 0); w = v3(w, [-2.4, 22.4, 5.2], wipe); const pt = m.pt || 0; w = v3(w, [-15.5, 15.4, 3.0], pt); const R = { w, pl: [lp(lp(-0.5, -1.4, ln), m.gk === 4 ? -0.1 : m.gk === 0 ? -0.7 : -1, gb), lp(lp(-0.6, -0.1, ln), m.gk === 4 ? 0.15 : -0.4, gb), lp(lp(0.1, -0.45, ln), m.gk === 4 ? 1 : m.gk === 0 ? 0.6 : 0.1, gb)], curl: lp(0.45, m.gk === 0 ? 0.35 : m.gk === 2 ? 0.7 : m.gk === 4 ? 0.3 + 0.12 * sn(T * 0.05) : 0.25, gb) + 0 * 0 + (fit > 0 ? (1.2 - 0.45) * fit : 0) }; if (pt > 0) { R.pl = [lp(R.pl[0], -0.35, pt), lp(R.pl[1], -1, pt), lp(R.pl[2], 0.15, pt)]; R.curl = lp(R.curl, 0.3, pt); R.wb = -0.38 * pt; R.wt = 1.4 * pt; } return R; },   // pt: a brief bent-arm point toward the ghost
    (T, p, V) => { const m = V.sm || {}, drag = m.drag || 0, hold = m.hold || 0, fit = m.fit || 0, c = m.c || 0, smk = Math.min(1, Math.max(m.rise || 0, drag, hold, fit, c, m.wipe || 0, m.bz || 0)), tk = (m.tk || 0) * (1 - smk), ta = m.ta || 1, ln = (m.ln || 0) * (1 - smk);   // smk: the old smoking pose takes over completely during a toke, rip or cough
        return { hula: 0, cr: 10.4 + 1.0 * fit + 1.3 * c + 1.3 * (m.bend || 0) + 0.9 * (m.wr || 0), tp: lp(0.04 + 0.3 * ln, 0.12, smk) + 0.02 * tk * ta * sn(T * 0.16) + 0.03 * (m.gb || 0) * (1 - smk) - 0.12 * drag + 0.04 * hold + 0.4 * fit + 0.28 * c + 0.3 * (m.bend || 0) - 0.15 * (m.rec || 0) + 0.1 * (m.post || 0) + 0.1 * (m.lf || 0) * sn(T * 0.62) + sn(T * 0.03) * 0.012, lp: 0.2 + 0.18 * fit + 0.14 * c, sh: -0.1 + 0.18 * (m.gb || 0) * (1 - smk) + 0.3 * drag + 0.25 * hold + 0.2 * fit + 0.4 * c + 0.4 * (m.lf || 0) * (0.5 + 0.5 * sn(T * 0.62 + 1)),
            hp: -0.5 * (1 - smk) - 0.95 * ln - 0.12 * (m.gb || 0) * (1 - smk) - 0.1 * drag + 0.06 * hold + 0.08 * fit + 0.2 * c + 0.22 * (m.bend || 0) - 1.1 * (m.rec || 0) - 0.06 * (m.post || 0) - 0.16 * (m.lf || 0) - 0.04 * tk * ta, hy: -0.3 * (1 - fit) + 0.55 * (m.look || 0) + 0.24 * (m.wr || 0) + 0.14 * tk * ta * sn(T * 0.07 + 2) + 0.12 * (m.post || 0) * sn(T * 0.011), hr: -0.05 - 0.08 * fit + 0.12 * (m.wr || 0) * sn(T * 5) + 0.09 * (m.post || 0) * sn(T * 0.017 + 1) + 0.05 * tk * ta * sn(T * 0.11 + 1), ty: 0.08, ls: 0.05 + 0.05 * sn(T * 0.9) * fit, leg: 'stand' }; },
    (sx, T, p, V, f) => { const m = V.sm || {}, c = m.c || 0, sw = sn(T * 0.04 + sx * 1.3);
        f.z = 11.8 + 1.4 * sw + 2.2 * c * (sx > 0 ? 1 : 0.6); f.y = 1.0 + 0.5 * sw + 1.5 * c + 1.6 * (m.wr || 0) * (sx > 0 ? 1 : 0.4); f.r = 0.5; f.ry = sx * 0.18; f.x = sx * 0.2; });
    return G;
})();
function h3Foot(mode, sx, T, p) {   // per-foot pose: offset x,y,z, ankle pitch r (+ = toes down), toe bend tb, toe-out ry, roll rz
    const f = { x: 0, y: 0, z: 0, r: 0, tb: 0, ry: sx * 0.1, rz: 0 };
    if (mode === 'wide') { f.x = sx * 3.0; f.ry = sx * 0.3; }
    else if (mode === 'tiptoe') { f.x = sx * 1.0; f.y = 1.7; f.r = 0.55; f.tb = -0.45; f.ry = sx * 0.08; }
    else if (mode === 'stagger') { const fr = sx > 0; f.z = fr ? 4.2 : -4.2; f.x = sx * 2.2; f.ry = sx * 0.35; if (fr) { f.r = -0.1; f.tb = 0.1; } else { f.r = 0.4; f.tb = -0.35; f.y = 1.1; } }
    else if (mode === 'contra') { if (sx > 0) { f.z = 2.6; f.x = 2.4; f.ry = 0.42; f.r = 0.14; f.tb = 0.12; f.rz = 0.05; } else { f.x = -0.8; f.ry = -0.18; } }
    else if (mode === 'brace') { f.x = sx * 3.8; f.z = -1; f.ry = sx * 0.5; f.r = -0.06; }
    else if (mode === 'lunge') { const fr = sx > 0; f.z = fr ? 6.5 : -6.5; f.x = sx * 2.4; f.ry = sx * 0.3; if (fr) { f.r = -0.15; f.tb = 0.15; } else { f.r = 0.55; f.tb = -0.5; f.y = 1.8; } }
    else if (mode === 'run' || mode === 'walk' || mode === 'sprint') {
        const k = mode === 'sprint' ? 1.5 : mode === 'run' ? 1 : 0.5, a = T * (mode === 'sprint' ? 0.5 : mode === 'run' ? 0.35 : 0.4) + (sx > 0 ? 0 : Math.PI), u = Math.cos(a), z = Math.sin(a) * 6 * k;
        f.z = z; f.ry = sx * 0.06;
        if (u > 0) { f.y = u * 6 * k; f.r = -0.2 * u + 0.15; f.tb = 0.1; }   // swing: foot lifted, toes relaxed
        else { const p = -z / (6 * k);   // stance: -1 = foot in front (heel strike) .. +1 = foot behind (toe-off)
            if (p < -0.4) { const h = Math.min(1, (-p - 0.4) / 0.6); f.r = -0.32 * h; f.tb = 0.22 * h; }
            else if (p > 0.3) { const h = Math.min(1, (p - 0.3) / 0.7); f.r = 0.55 * h; f.tb = -0.5 * h; f.y = 1.7 * h * k; } }
    }
    else if (mode === 'dance') { const bt = h3Dn(T).w * 0.2 + (sx > 0 ? 0 : Math.PI), a = Math.sin(bt), up = Math.max(0, a); f.x = sx * 1.5 + sx * 0.7 * up; f.z = 1.5 * Math.cos(bt); f.y = Math.pow(up, 1.3) * 2.2; f.r = -up * 0.35; f.tb = up * 0.3; f.ry = sx * 0.12 * a; f.rz = sx * 0.06 * a; }
    else if (mode === 'kneel') { if (sx > 0) { f.z = 5.5; f.x = 1.5; f.ry = 0.25; } else { f.z = -9; f.y = 1.5; f.r = 1.15; f.tb = -0.3; f.x = -1; } }
    return f;
}
// ---- expressions: every parameter is continuous, so the face morphs between them (and micro-expressions ride on top) ----
//  mo jaw open | mw mouth width | sm smile(+)/frown(-) | sk smirk (+ lifts the viewer-right corner) | tt teeth | tg tongue | pu pucker | pf lip press
//  bo/bi outer/inner brow raise (+) or lower (-), boL boR biL biR per side | lid upper-lid opening (.5 normal), lidL lidR | sq cheek squint | ew eye size
//  gx gy gaze | fix (hold the gaze still) | hr hp hy head roll/pitch/yaw | ns nose scrunch | nf nostril flare | ch cheek puff | nb suppress blinking
const H3E_D = { mo: 0, mw: 0, sm: 0.1, sk: 0, tt: 0, tg: 0, pu: 0, pf: 0, bo: 0, bi: 0, boL: 0, boR: 0, biL: 0, biR: 0, lid: 0.5, lidL: 0, lidR: 0, sq: 0, ew: 0, gx: 0, gy: 0, fix: 0, hr: 0, hp: 0, hy: 0, ns: 0, nf: 0, ch: 0, nb: 0 };
const H3E = {};
(() => {
    const X = (n, str) => { const o = {}; for (const kv of str.split(/\s+/)) { if (!kv) continue; const [k, v] = kv.split('='); o[k] = parseFloat(v); } if (o.hp > 0) o.hp *= 0.35; H3E[n] = o; };
    X('neutral', 'sm=0');
    X('smile', 'sm=.55 mw=.1 sq=.1'); X('grin', 'sm=.9 mo=.25 tt=1 mw=.5 sq=.3'); X('big_grin', 'sm=1.1 mo=.55 tt=1 mw=.9 sq=.5 bo=.2');
    X('smirk', 'sk=.9 sm=.15 pf=.2 sq=.15 boR=.35'); X('smirk_left', 'sk=-.9 sm=.15 pf=.2 sq=.15 boL=.35');
    X('smug', 'sm=.4 sk=.5 lid=.35 bo=.15 hp=-.1 sq=.2 pf=.3'); X('cocky', 'sm=.5 sk=.7 lid=.38 boL=.5 hp=-.12 hr=.08 tt=.3');
    X('laugh', 'mo=.8 sm=1 tt=1 tg=.3 sq=.8 lid=.3 mw=.7'); X('roar_laugh', 'mo=1.2 sm=1.1 tt=1 tg=.5 sq=1 lid=.15 mw=1 hp=-.25 nb=1');
    X('giggle', 'mo=.3 sm=.9 tt=1 sq=.6 lid=.3 hr=.1 hp=.05'); X('chuckle', 'mo=.12 sm=.6 sq=.4 lid=.4 hp=.05 nf=.3');
    X('wink', 'lidL=-.7 sm=.8 sk=.4 tt=.5 sq=.3 hr=.1'); X('wink_right', 'lidR=-.7 sm=.8 sk=-.4 tt=.5 sq=.3 hr=-.1');
    X('kiss', 'pu=1 mw=-.7 sm=0 bo=.2 lid=.4 hr=.08'); X('tongue_out', 'tg=1 mo=.45 sm=.7 ew=.2 sq=.2');
    X('raspberry', 'tg=.9 mo=.35 ch=.5 sq=.6 lid=.3 sm=.2'); X('cheeky', 'tg=.5 mo=.3 sm=.8 sk=.4 boL=.4 hr=.1');
    X('playful', 'sm=.8 sk=.3 mo=.15 bo=.4 lid=.6 hr=.1'); X('proud', 'sm=.35 hp=-.18 lid=.4 bo=.25 pf=.2');
    X('happy', 'sm=.75 mo=.1 sq=.2 bo=.15'); X('joy', 'sm=1 mo=.5 tt=1 sq=.5 bo=.45 lid=.6 mw=.7');
    X('delight', 'sm=1 mo=.3 tt=1 bo=.7 bi=.3 lid=.75 mw=.6'); X('triumph', 'sm=.95 mo=.8 tt=1 bo=.1 bi=-.3 lid=.5 hp=-.2 mw=.8 sq=.35');
    X('battle_cry', 'mo=1.1 sm=-.2 tt=1 bi=-.9 bo=-.1 lid=.35 sq=.5 mw=.8 ns=.4 hp=-.1'); X('roar', 'mo=1.3 sm=-.35 tt=1 tg=.3 bi=-1 lid=.3 sq=.7 mw=1 ns=.5 hp=-.2');
    X('rage', 'mo=.7 sm=-.6 tt=1 bi=-1 bo=-.3 lid=.28 sq=.6 ns=.8 nf=.8 mw=.4 hp=.06'); X('fury', 'mo=.5 sm=-.8 tt=1 bi=-1 bo=-.5 lid=.22 sq=.8 ns=1 nf=1 mw=.5 hp=.1');
    X('snarl', 'mo=.25 sk=.8 sm=-.4 tt=1 ns=1 nf=.7 bi=-.8 lid=.3 sq=.5'); X('glare', 'pf=.5 sm=-.2 bi=-.8 lid=.32 sq=.3 fix=1');
    X('scowl', 'sm=-.55 bi=-.7 bo=-.2 lid=.38 pf=.3 sq=.2'); X('determined', 'pf=.6 sm=0 bi=-.55 lid=.42 sq=.15 hp=-.04');
    X('focused', 'pf=.4 bi=-.3 lid=.35 sq=.25 fix=1 mw=-.2'); X('fierce', 'sm=-.1 pf=.3 mo=.15 bi=-.8 lid=.4 sq=.35 tt=.5');
    X('menace', 'sm=.3 sk=.4 pf=.2 bi=-.7 lid=.28 sq=.3 hp=.12'); X('grit', 'mo=.12 mw=.7 tt=1 sm=-.15 bi=-.7 lid=.38 sq=.6 ns=.4');
    X('bite_lip', 'pu=.2 sm=-.1 pf=.7 bi=-.4 sq=.3 lid=.38'); X('stern', 'pf=.8 sm=-.2 bi=-.25 lid=.4 hp=-.05');
    X('stoic', 'pf=.5 sm=0 lid=.42'); X('deadpan', 'pf=.3 sm=0 lid=.35 fix=1');
    X('bored', 'sm=-.1 lid=.28 bo=-.2 hp=.05 hy=.15 fix=1 gy=-.2'); X('sleepy', 'lid=.12 sm=-.05 mo=.08 hp=.1 bo=-.3');
    X('tired', 'lid=.2 sm=-.25 bo=-.2 bi=.3 hp=.12'); X('exhausted', 'lid=.1 mo=.3 sm=-.4 bi=.5 bo=-.3 hp=.2 hr=.06');
    X('sad', 'sm=-.6 bi=.8 bo=-.35 lid=.38 hp=.08 mo=.03'); X('sorrow', 'sm=-.8 bi=1 bo=-.5 lid=.3 hp=.12 hr=.05 mo=.08 pf=.2');
    X('grief', 'sm=-1 mo=.5 bi=1 bo=-.6 lid=.2 sq=.9 hp=.1 mw=-.1'); X('sob', 'sm=-1 mo=.8 bi=1 bo=-.6 lid=.12 sq=1 mw=.3 tt=.4 hp=.15');
    X('pout', 'pu=.7 sm=-.5 bi=.4 lid=.4 mw=-.4 hp=.05'); X('worried', 'sm=-.3 bi=.7 bo=.1 lid=.55 pf=.2');
    X('anxious', 'sm=-.25 bi=.8 bo=.3 lid=.7 mo=.12 gx=.3 mw=.3 tt=.3'); X('afraid', 'mo=.5 sm=-.2 bi=.9 bo=.7 lid=.95 ew=.5 mw=.4 tt=.5');
    X('terror', 'mo=1 sm=-.3 bi=1 bo=.9 lid=1 ew=.8 mw=.6 tt=.7 hp=-.1 nb=1'); X('shock', 'mo=.7 bi=.8 bo=.9 lid=1 ew=.6 mw=.1 nb=1 hp=-.08');
    X('surprise', 'mo=.5 bi=.6 bo=.8 lid=.95 ew=.4 pu=.3 mw=-.3'); X('gasp', 'mo=.65 bi=.7 bo=.9 lid=1 ew=.5 pu=.4 mw=-.2 hp=-.1');
    X('awe', 'mo=.35 bi=.4 bo=.7 lid=.85 ew=.3 sm=.15 hp=-.18 gy=.5'); X('amazed', 'mo=.4 sm=.5 bo=.8 lid=.9 ew=.3 tt=.5 hp=-.1');
    X('confused', 'sm=-.1 boL=.6 biR=-.3 lid=.5 hr=.15 pu=.15 mw=-.3'); X('puzzled', 'sm=-.15 boR=.7 bi=.2 hr=-.1 lid=.5 hp=.05 pf=.2');
    X('skeptical', 'sm=-.15 sk=.2 boL=.9 biR=-.5 lid=.4 pf=.5 hp=-.05'); X('paranoid', 'lid=.95 ew=.45 bi=.6 bo=.3 sm=-.14 pf=.35 sq=.14 nf=.3 ns=.12 hp=.07 fix=1 nb=1 mw=-.1'); X('suspicious', 'pf=.6 sm=-.2 bi=-.4 lid=.28 sq=.45 gx=.5 hy=.12 fix=1');
    X('doubt', 'sm=-.3 boL=.5 pf=.3 lid=.42 hr=-.08'); X('disbelief', 'mo=.25 boL=.8 boR=.8 bi=.2 lid=.7 sm=-.2 hr=.1 hp=-.05');
    X('disgust', 'sm=-.8 ns=1 nf=.5 mo=.15 bi=-.4 lid=.3 sq=.7 tt=.4 hp=-.08 sk=.3'); X('yuck', 'mo=.35 sm=-1 ns=1 tg=.6 bi=-.3 lid=.2 sq=1 mw=.4 hp=-.1');
    X('sour', 'pu=.6 sm=-.7 ns=.4 lid=.3 sq=.7 mw=-.5'); X('smell', 'ns=1 nf=.6 sm=-.4 lid=.3 sq=.5 hp=-.05 sk=.4 mo=.05');
    X('pain', 'mo=.45 sm=-.8 tt=1 bi=.9 bo=-.3 lid=.1 sq=1 ns=.6 mw=.5'); X('wince', 'sm=-.5 mo=.1 tt=1 bi=.7 lid=.08 sq=1 ns=.5 pf=.1');
    X('dizzy', 'mo=.2 sm=-.2 lid=.4 gx=.4 hr=.15 hp=.05 bi=.3 sk=.5'); X('drunk', 'sm=.55 sk=.5 mo=.2 lid=.18 bo=.15 hr=.12 hp=.1 tg=.2');
    X('daydream', 'sm=.3 lid=.3 gy=.5 gx=.3 hr=.1 hp=-.08 fix=1'); X('thinking', 'pf=.4 sm=-.05 boR=.4 lid=.45 gx=.45 gy=.4 hr=.07 sk=-.3');
    X('sly', 'sm=.5 sk=-.6 lid=.3 bi=-.4 boL=.4 sq=.3 hp=.05'); X('devious', 'sm=.8 sk=.4 mo=.12 tt=1 bi=-.7 lid=.3 sq=.4 hp=.1');
    X('mischief', 'sm=.9 sk=.5 mo=.15 tt=1 bi=-.4 bo=.2 lid=.55 sq=.3 hr=.1'); X('flirt', 'sm=.5 sk=.3 lid=.3 boL=.4 hr=.15 pu=.1 hp=-.05');
    X('relief', 'sm=.4 mo=.3 lid=.25 bi=.5 bo=-.1 hp=-.1'); X('sigh', 'mo=.4 sm=-.2 lid=.2 bi=.4 hp=.1 pu=.4 ch=.3');
    X('hopeful', 'sm=.4 bi=.7 bo=.5 lid=.75 hp=-.1 gy=.35'); X('pleading', 'sm=-.3 bi=1 bo=.4 lid=.9 ew=.3 pu=.2 hp=.1 mw=-.2');
    X('guilty', 'sm=-.2 bi=.6 lid=.4 hp=.2 gy=-.4 gx=-.3 sk=.2 hr=.06'); X('embarrassed', 'sm=.35 sk=.3 bi=.5 lid=.4 hp=.15 hr=.1 gy=-.3 sq=.3');
    X('numb', 'lid=.3 sm=-.15 fix=1 pf=.2 bo=-.1'); X('hollow', 'lid=.38 sm=-.3 fix=1 mo=.02 bo=-.2 bi=.3 gy=-.1');
    X('betrayed', 'sm=-.55 bi=.9 bo=-.1 lid=.55 mo=.12 ew=.2 hp=.05 sq=.2'); X('resolve', 'pf=.6 bi=-.35 lid=.45 hp=-.08 sm=.05');
    X('smolder', 'pf=.2 sm=.15 sk=.3 lid=.25 bi=-.2 hp=.1 hy=.1'); X('whistle', 'pu=1 mw=-.9 mo=.1 bo=.3 lid=.5 gy=.2');
    X('yawn', 'mo=1.3 lid=.05 sq=1 bi=.4 mw=.2 hp=-.2 tg=.4 sm=-.2');
    X('wired', 'lid=.95 ew=.5 bo=.45 bi=.3 sm=.4 tt=.8 mo=.14 mw=.55 sq=.05 nb=1 nf=.7 pf=-.1'); X('stoned', 'lid=.2 sm=.35 sk=.25 mo=.03 bo=-.1 sq=.15 gy=-.05'); X('smoke_drag', 'lid=.25 pf=.55 sq=.3 sm=.05 ch=.15 mw=-.3'); X('hold_breath', 'ch=1 pf=.7 sq=.35 lid=.6 bo=.3 ew=.3 sm=0 mw=-.2');
    // ---- the rest of the human range: contempt, despair, shame, tenderness, nervous and forced smiles, panic, hysteria and more ----
    X('contempt', 'sk=.6 sm=-.1 pf=.3 lid=.4 hp=-.1 hy=.1 nf=.2'); X('sneer', 'sk=.8 ns=.7 sm=-.2 tt=.5 lid=.4 bi=-.3 nf=.3'); X('disdain', 'sm=-.3 pf=.4 lid=.3 hp=-.15 hy=.15 bo=-.1 sk=.2');
    X('haughty', 'pf=.3 sm=.05 lid=.3 hp=-.22 bo=.15 hy=-.1'); X('condescending', 'sm=.3 sk=.3 lid=.32 boL=.4 hp=-.15 hr=.08'); X('gloat', 'sm=.75 sk=.6 tt=.6 lid=.38 hp=-.15 bo=.2 sq=.25');
    X('sarcastic', 'sk=.6 sm=.2 boL=.7 lid=.4 hr=.1'); X('seductive', 'sm=.25 sk=.35 lid=.22 bi=-.1 hp=.08 hy=.08 mo=.05'); X('creepy', 'sm=.8 sk=.3 mo=.1 tt=1 lid=.9 ew=.5 bi=-.2 bo=.1 fix=1 nb=1 hp=.08');
    X('greedy', 'sm=.6 sk=.3 tt=.8 mo=.1 bo=.4 lid=.85 ew=.3 hp=.05 fix=1'); X('teasing', 'sm=.7 sk=.4 tg=.25 boL=.5 lid=.5 hr=.1 sq=.2'); X('coy', 'sm=.5 sk=.3 bi=.4 lid=.35 gy=-.2 gx=.3 hr=.12 hp=.05');
    X('amused', 'sm=.5 sk=.3 mo=.05 sq=.25 bo=.2 lid=.45 nf=.2'); X('gleeful', 'sm=1 mo=.4 tt=1 sq=.5 bo=.35 lid=.6 mw=.7 hp=-.05'); X('ecstasy', 'sm=1.1 mo=.6 tt=1 bo=.6 bi=.3 lid=.85 sq=.6 mw=.9 hp=-.2');
    X('bliss', 'sm=.7 lid=.12 sq=.5 mo=.08 hp=-.08 bo=.1'); X('content', 'sm=.45 lid=.35 sq=.15 mo=.03'); X('admiration', 'sm=.4 mo=.12 bo=.5 bi=.3 lid=.75 hp=-.08 gy=.2');
    X('grateful', 'sm=.5 bi=.6 bo=.1 lid=.55 sq=.25 hp=.1'); X('tender', 'sm=.4 bi=.5 bo=.1 lid=.4 hr=.1 hp=.04 sq=.2'); X('love', 'sm=.55 lid=.35 bi=.4 bo=.2 hr=.12 sq=.25 mo=.05 hp=.03');
    X('manic', 'sm=1 mo=.5 tt=1 lid=.95 ew=.6 bo=.6 bi=.3 sq=.2 mw=.8 nb=1 hr=.1'); X('hysterical', 'mo=1 sm=.9 tt=1 bi=.5 bo=.3 lid=.7 ew=.4 mw=.9 sq=.4 hp=-.15 nb=1'); X('hungry', 'mo=.12 tg=.2 sm=.2 lid=.7 bo=.2 fix=1 pu=.1');
    X('compassion', 'sm=-.1 bi=.7 bo=.05 lid=.55 hr=.12 hp=.05 pf=.1'); X('longing', 'sm=-.1 bi=.6 lid=.4 gy=.3 gx=.3 hp=-.03 mo=.04 fix=1'); X('wistful', 'sm=.15 bi=.5 lid=.32 gy=.3 hr=.1 fix=1');
    X('melancholy', 'sm=-.4 bi=.6 bo=-.2 lid=.3 hp=.1 fix=1 gy=-.15'); X('despair', 'sm=-.9 mo=.2 bi=1 bo=-.4 lid=.2 hp=.18 fix=1 gy=-.3'); X('anguish', 'sm=-1 mo=.7 bi=1 bo=-.3 lid=.15 sq=1 mw=.5 tt=.5 hp=.05 ns=.3');
    X('disappointed', 'sm=-.4 bi=.4 bo=-.2 lid=.35 hp=.1 pf=.2 gy=-.2'); X('resigned', 'sm=-.15 lid=.28 bi=.25 bo=-.15 hp=.08 fix=1 pf=.15'); X('defeated', 'sm=-.5 lid=.2 bi=.6 bo=-.4 hp=.18 gy=-.35 mo=.05');
    X('remorse', 'sm=-.5 bi=.9 bo=-.1 lid=.35 hp=.15 gy=-.4 pf=.2'); X('somber', 'sm=-.2 bi=.3 lid=.35 pf=.3 hp=.04 fix=1'); X('laugh_cry', 'sm=.6 mo=.7 tt=.8 bi=.9 bo=-.3 lid=.15 sq=1 mw=.6 hr=.1');
    X('bittersweet', 'sm=.35 bi=.7 bo=-.2 lid=.35 hp=.05 sq=.2'); X('shame', 'sm=-.3 bi=.6 lid=.3 hp=.22 gy=-.5 hr=.08 pf=.3 sq=.15'); X('sheepish', 'sm=.4 sk=.3 bi=.5 lid=.4 hp=.1 hr=.12 gy=-.25 gx=-.2 sq=.2');
    X('shy', 'sm=.3 bi=.5 lid=.4 gy=-.3 gx=.3 hr=.12 hp=.1 sq=.15'); X('nervous_smile', 'sm=.4 mw=.4 tt=.6 bi=.6 bo=.2 lid=.7 gx=.25 sq=-.1'); X('forced_smile', 'sm=.5 mw=.5 tt=.8 sq=-.1 lid=.55 bi=.2 pf=-.1 fix=1');
    X('trembling', 'sm=-.4 mo=.12 bi=.7 lid=.65 pf=.3 mw=.2 ew=.15'); X('panic', 'mo=.8 sm=-.4 bi=1 bo=.8 lid=1 ew=.7 mw=.6 tt=.6 hp=-.05 nb=1 nf=.6'); X('horror', 'mo=1.1 sm=-.5 bi=1 bo=.9 lid=1 ew=.8 mw=.5 tt=.8 hp=-.15 ns=.2 nb=1');
    X('apologetic', 'sm=.1 bi=.8 bo=.1 lid=.5 hp=.12 hr=.1 pf=.15'); X('startled', 'mo=.3 bi=.7 bo=.9 lid=1 ew=.5 hp=-.12 nb=1 mw=-.1'); X('stunned', 'mo=.15 bi=.3 bo=.3 lid=.7 fix=1 sm=0 hp=-.04 nb=1');
    X('speechless', 'mo=.35 bi=.5 bo=.4 lid=.8 fix=1 mw=-.1 sm=-.05 nb=1'); X('bemused', 'sm=.25 sk=.4 boL=.5 lid=.45 hr=.1 sq=.1'); X('bewildered', 'mo=.2 boL=.6 boR=.8 bi=.4 lid=.65 hr=.12 sm=-.2 gx=.3');
    X('curious', 'sm=.1 boR=.5 bi=.2 lid=.65 hr=.12 gx=.35 hp=-.03 fix=1'); X('intrigued', 'sm=.2 sk=.3 boL=.5 lid=.4 hp=.03 hr=.08 pf=.1'); X('concentrating', 'pf=.5 bi=-.35 lid=.4 sq=.2 fix=1 gy=-.1 mw=-.2 hp=.05');
    X('pensive', 'sm=-.05 bi=.2 lid=.35 gy=-.2 hp=.06 fix=1'); X('impatient', 'pf=.5 sm=-.15 lid=.4 bi=-.2 nf=.4 gx=.4 hy=.1 sk=-.2'); X('annoyed', 'sm=-.3 pf=.4 lid=.3 bi=-.4 ns=.2 nf=.3 hy=.1');
    X('exasperated', 'mo=.3 sm=-.4 lid=.25 bi=.2 bo=-.2 hp=-.2 nf=.7 pu=.2 ch=.2'); X('indignant', 'mo=.2 sm=-.4 bi=-.5 bo=.3 lid=.7 ns=.2 nf=.6 hp=-.12 mw=.2'); X('defiant', 'pf=.7 sm=0 bi=-.5 lid=.4 hp=-.15 sq=.2 fix=1');
    X('vengeful', 'sm=.2 sk=.5 tt=.6 bi=-.8 lid=.3 sq=.4 fix=1 hp=.1'); X('hateful', 'sm=-.4 pf=.4 bi=-.9 lid=.28 sq=.5 ns=.6 nf=.5 fix=1 tt=.4'); X('jealous', 'sm=-.3 sk=.3 pf=.5 lid=.3 bi=-.4 sq=.3 gx=.5 hy=.12 fix=1');
    X('bitter', 'sm=-.5 sk=.3 pf=.4 lid=.3 bi=-.2 ns=.3 hp=-.04'); X('cringe', 'sm=-.3 mo=.1 tt=.8 bi=.6 lid=.3 sq=.8 ns=.5 mw=.5 hp=.05 hr=.1'); X('nauseous', 'sm=-.5 mo=.12 ns=.4 bi=.5 lid=.25 pf=.3 hp=.1 ch=.3');
    X('gag', 'mo=.7 sm=-.7 tg=.6 ns=.8 sq=.9 lid=.1 hp=.05 ch=.3'); X('eye_roll', 'lid=.35 gy=.9 sm=-.2 pf=.3 hp=-.1 bo=.15'); X('unimpressed', 'pf=.35 sm=-.15 lid=.3 bo=-.1 fix=1 hy=.08 hp=-.05');
    X('calm', 'sm=.1 lid=.4 pf=.05'); X('serenity', 'sm=.3 lid=.3 pf=.1 bo=.05'); X('polite_smile', 'sm=.3 pf=.3 sq=0 lid=.5 bo=.05');
    X('cold', 'pf=.4 sm=-.05 lid=.3 bi=-.15 fix=1 hp=-.06');
    // ---- added: attractive, easy, confident faces ----
    X('charming', 'sm=.5 sk=.4 lid=.4 boL=.25 hp=-.05 hr=.06 sq=.15 mo=.04'); X('confident', 'sm=.3 sk=.2 lid=.42 hp=-.08 pf=.1 bo=.05'); X('sultry', 'lid=.26 sm=.1 sk=.2 mo=.12 pu=.1 bi=-.12 hy=.06 hp=-.02'); X('warm', 'sm=.6 sq=.35 lid=.45 bi=.15 mw=.1 mo=.04');
})();
// micro-expressions: tiny, brief involuntary flickers added on top of whatever the face is doing
const H3M = {
    brow_flash: { bo: 0.5, bi: 0.3 }, brow_flick_L: { boL: 0.7 }, brow_flick_R: { boR: 0.7 }, furrow_blip: { bi: -0.5, sq: 0.2 }, worry_blip: { bi: 0.5 },
    lip_twitch_R: { sk: 0.5 }, lip_twitch_L: { sk: -0.5 }, nostril_flare: { nf: 1, ns: 0.15 }, squint_blip: { sq: 0.5, lid: -0.08 }, eye_widen: { lid: 0.3, ew: 0.2 },
    glance_L: { gx: -0.55 }, glance_R: { gx: 0.55 }, glance_up: { gy: 0.45 }, glance_down: { gy: -0.45 }, lip_press: { pf: 0.6, mo: -0.05 },
    lip_lick: { tg: 0.35, mo: 0.18 }, jaw_shift: { mo: 0.14, hy: 0.07 }, head_nod: { hp: 0.09 }, head_tilt: { hr: 0.07 }, cheek_tense: { sq: 0.3, sm: 0.2 },
    swallow: { mo: 0.08, hp: -0.05, pf: 0.3 }, sniff: { ns: 0.5, nf: 0.8, hp: -0.03 }, smirk_leak: { sk: 0.6, sm: 0.2 }, eyelid_droop: { lid: -0.15 }, brow_drop: { bo: -0.3, bi: -0.2 },
};
// ---- 50 emotion-bound micro-expressions. _d = duration ms, _s = envelope (0 bump, 1 snap-hold, 2 tremble) ----
Object.assign(H3M, {
    // joy
    cheek_pulse: { sq: 0.35, sm: 0.25, _d: 260 }, brow_bounce: { bo: 0.45, bi: 0.2, hp: -0.04, _d: 200 }, eye_sparkle: { ew: 0.3, lid: 0.2, gy: 0.12, _d: 340 },
    grin_surge: { sm: 0.35, mw: 0.3, tt: 0.5, _d: 300 }, happy_bob: { hp: 0.1, hr: 0.06, sq: 0.15, _d: 260 },
    // pride / smugness / mischief
    chin_lift: { hp: -0.14, lid: -0.08, _d: 420, _s: 1 }, slow_blink_smug: { lid: -0.4, _d: 520 }, smirk_flick: { sk: 0.55, boR: 0.3, _d: 240 },
    brow_arch_L: { boL: 0.8, sk: -0.15, _d: 340, _s: 1 }, nostril_pride: { nf: 0.6, hp: -0.05, sm: 0.12, _d: 300 },
    // anger / resolve
    jaw_clench: { pf: 0.7, mw: 0.4, sq: 0.25, tt: 0.5, _d: 420, _s: 1 }, brow_snap: { bi: -0.7, bo: -0.3, _d: 180, _s: 1 }, nostril_blast: { nf: 1, ns: 0.35, mo: 0.06, _d: 260 },
    eye_lock: { lid: -0.12, fix: 1, sq: 0.3, _d: 520, _s: 1 }, lip_snarl_blip: { ns: 0.7, sk: 0.5, tt: 0.8, _d: 200 },
    // fear / anxiety
    eye_dart_L: { gx: -0.7, lid: 0.2, ew: 0.15, _d: 140 }, eye_dart_R: { gx: 0.7, lid: 0.2, ew: 0.15, _d: 140 }, lip_tremble: { mw: 0.2, mo: 0.06, sm: -0.1, _d: 520, _s: 2 },
    breath_catch: { mo: 0.25, hp: -0.06, bo: 0.2, _d: 240 }, flinch_blink: { lid: -0.45, hp: 0.08, hr: 0.05, _d: 140, _s: 1 },
    // sadness / grief
    chin_quiver: { mo: 0.08, pf: 0.4, sm: -0.25, _d: 520, _s: 2 }, glisten: { ew: 0.2, lid: 0.15, bi: 0.2, _d: 620 }, gaze_drop: { gy: -0.55, hp: 0.1, lid: -0.1, _d: 520, _s: 1 },
    grief_swallow: { mo: 0.1, pf: 0.45, hp: -0.04, bi: 0.25, _d: 360 }, sniffle: { ns: 0.6, nf: 0.5, hp: -0.04, bi: 0.15, _d: 260 },
    // disgust
    lip_lift: { ns: 0.9, sk: 0.3, sm: -0.2, _d: 300, _s: 1 }, gag_flinch: { mo: 0.3, hp: -0.1, ch: 0.3, lid: -0.2, _d: 240 }, nose_crinkle: { ns: 1, sq: 0.45, bi: -0.2, _d: 260 },
    head_recoil: { hp: -0.12, hy: 0.08, _d: 300, _s: 1 }, tongue_curl: { tg: 0.45, mo: 0.2, ns: 0.3, _d: 280 },
    // surprise / awe
    brow_pop: { bo: 0.9, bi: 0.5, _d: 220, _s: 1 }, jaw_slack: { mo: 0.3, mw: -0.15, _d: 340 }, eye_snap: { lid: 0.4, ew: 0.35, _d: 200, _s: 1 },
    head_jerk_back: { hp: -0.14, _d: 200 }, double_take: { hy: 0.18, lid: 0.25, bo: 0.3, _d: 360 },
    // thought / doubt
    gaze_up_left: { gx: -0.5, gy: 0.5, fix: 0.6, _d: 600, _s: 1 }, lip_purse: { pu: 0.35, pf: 0.3, mw: -0.3, _d: 420, _s: 1 }, brow_lift_one: { boR: 0.7, _d: 360 },
    head_tilt_slow: { hr: 0.12, _d: 700 }, scan_narrow: { lid: -0.12, sq: 0.25, gx: 0.45, _d: 520 },
    // fatigue / boredom
    slow_blink_long: { lid: -0.5, _d: 700 }, head_nod_off: { hp: 0.18, lid: -0.2, _d: 620 }, lid_flutter: { lid: -0.2, _d: 420, _s: 2 },
    mouth_slack: { mo: 0.14, mw: -0.1, _d: 520 }, gaze_drift: { gx: 0.35, gy: -0.15, _d: 640 },
    // pain / strain
    wince_pulse: { sq: 0.7, lid: -0.3, ns: 0.3, _d: 260 }, teeth_bare: { tt: 1, mo: 0.15, mw: 0.5, _d: 240, _s: 1 }, breath_hiss: { mo: 0.12, mw: 0.3, tt: 0.6, hp: 0.05, _d: 300 },
    brow_pinch: { bi: 0.7, bo: -0.2, sq: 0.3, _d: 300, _s: 1 }, jaw_set: { pf: 0.6, mw: 0.2, hy: 0.04, _d: 380, _s: 1 },
});
// which emotional family each expression belongs to
const H3FAM = {};
for (const [f, names] of Object.entries({
    joy: 'smile grin big_grin laugh roar_laugh giggle chuckle wink wink_right kiss tongue_out raspberry cheeky playful happy joy delight triumph amazed relief hopeful whistle teasing coy amused gleeful ecstasy bliss content admiration grateful tender love manic hysterical hungry',
    smug: 'smirk smirk_left smug cocky proud sly devious mischief flirt smolder contempt sneer disdain haughty condescending gloat sarcastic seductive creepy greedy',
    anger: 'battle_cry roar rage fury snarl glare scowl determined focused fierce menace grit bite_lip stern resolve impatient annoyed exasperated indignant defiant vengeful hateful jealous',
    fear: 'paranoid afraid terror anxious worried pleading guilty embarrassed shame sheepish shy nervous_smile forced_smile trembling panic horror apologetic',
    sad: 'sad sorrow grief sob pout hollow betrayed numb compassion longing wistful melancholy despair anguish disappointed resigned defeated remorse somber laugh_cry bittersweet',
    disgust: 'disgust yuck sour smell bitter cringe nauseous gag',
    surprise: 'surprise gasp awe shock disbelief startled stunned speechless',
    thought: 'confused puzzled skeptical suspicious doubt thinking daydream bemused bewildered curious intrigued concentrating pensive',
    fatigue: 'bored sleepy tired exhausted sigh yawn dizzy drunk stoned smoke_drag eye_roll unimpressed',
    pain: 'pain wince hold_breath',
})) for (const n of names.split(' ')) H3FAM[n] = f;
for (const [n, f] of [['charming', 'smug'], ['confident', 'smug'], ['sultry', 'smug'], ['warm', 'joy'], ['wired', 'surprise']]) H3FAM[n] = f;
// redundant near-duplicates folded into one: the old names still work (cutscenes use some) but resolve to the kept expression and are hidden from listings
for (const [r, k] of Object.entries({ calm: 'neutral', serenity: 'neutral', gleeful: 'joy', concentrating: 'focused', unimpressed: 'deadpan', cold: 'deadpan', intrigued: 'bemused', love: 'tender', content: 'smile', somber: 'resigned', sheepish: 'embarrassed', seductive: 'smolder', resolve: 'determined', horror: 'terror', gasp: 'surprise', speechless: 'stunned', hollow: 'resigned' })) {
    const e = H3E[k], f = H3FAM[k]; delete H3E[r]; delete H3FAM[r];
    Object.defineProperty(H3E, r, { value: e, enumerable: false, configurable: true }); if (f) Object.defineProperty(H3FAM, r, { value: f, enumerable: false, configurable: true });
}
for (const k of ['brow_flick_L', 'brow_flick_R', 'lip_twitch_L', 'glance_up', 'glance_down', 'lip_lick', 'head_tilt', 'sniff', 'smirk_leak', 'brow_drop']) delete H3M[k];   // never scheduled by any family
for (const k in H3M) if (H3M[k].hp > 0) H3M[k].hp *= 0.35;   // chin-down micros would drop the hat brim over his eyes
// each family plays its micros in a fixed order, "name@ms until the next beat" (faster when the emotion runs hot) -- nothing random
const H3S = {
    joy: ['cheek_pulse@900', 'eye_sparkle@700', 'brow_bounce@1000', 'happy_bob@800', 'grin_surge@1200', 'cheek_tense@900'],
    smug: ['smirk_flick@1100', 'brow_arch_L@1400', 'chin_lift@1300', 'slow_blink_smug@1200', 'nostril_pride@1500', 'lip_twitch_R@1000'],
    anger: ['jaw_clench@800', 'nostril_blast@650', 'brow_snap@900', 'eye_lock@1100', 'lip_snarl_blip@1000', 'furrow_blip@600'],
    fear: ['eye_dart_L@500', 'breath_catch@600', 'eye_dart_R@450', 'lip_tremble@700', 'flinch_blink@800', 'swallow@600'],
    sad: ['gaze_drop@1500', 'glisten@1300', 'chin_quiver@1400', 'sniffle@1700', 'grief_swallow@1500', 'worry_blip@1200'],
    disgust: ['lip_lift@900', 'nose_crinkle@800', 'head_recoil@1100', 'gag_flinch@1300', 'tongue_curl@1000', 'nostril_flare@900'],
    surprise: ['eye_snap@900', 'brow_pop@800', 'jaw_slack@1100', 'head_jerk_back@1000', 'double_take@1500', 'eye_widen@900'],
    thought: ['gaze_up_left@1500', 'lip_purse@1300', 'brow_lift_one@1200', 'head_tilt_slow@1600', 'scan_narrow@1400', 'jaw_shift@1200'],
    fatigue: ['slow_blink_long@1800', 'head_nod_off@2000', 'lid_flutter@1500', 'mouth_slack@1900', 'gaze_drift@1700', 'eyelid_droop@1500'],
    pain: ['wince_pulse@700', 'breath_hiss@800', 'teeth_bare@900', 'brow_pinch@700', 'jaw_set@1000', 'squint_blip@700'],
    calm: ['head_nod@2600', 'lip_press@2400', 'glance_L@2200', 'brow_flash@3000', 'glance_R@2400', 'swallow@3200'],
};
// blink rhythm (ms) and duration by emotion: fear blinks fast, anger and shock stare, fatigue blinks slow and long
const H3BL = { joy: 3000, smug: 4200, anger: 5200, fear: 1700, sad: 2600, disgust: 2800, surprise: 6500, thought: 3600, fatigue: 2400, pain: 2200, calm: 3400 };
// posture the emotion leans the whole body into, breathing (hz, depth) and limb tremor
const H3P = {
    joy: { tp: -0.06, lp: -0.04, sh: 0.06, hp: -0.04 }, smug: { tp: -0.1, lp: -0.06, sh: -0.02, hp: -0.1 }, anger: { tp: 0.05, lp: -0.02, sh: 0.14, hp: -0.06, cr: 0.3 },
    fear: { tp: 0.1, lp: 0.06, sh: 0.3, hp: -0.09, cr: 0.6 }, sad: { tp: 0.14, lp: 0.08, sh: -0.12, hp: -0.1, cr: 0.5 }, disgust: { tp: 0.06, lp: -0.06, sh: 0.1, hp: -0.04 },
    surprise: { tp: -0.08, lp: -0.1, sh: 0.18, hp: -0.05 }, thought: { tp: 0.04, hp: 0.03 }, fatigue: { tp: 0.15, lp: 0.1, sh: -0.1, hp: -0.13, cr: 0.7 },
    pain: { tp: 0.13, lp: 0.08, sh: 0.22, hp: -0.15, cr: 0.8 }, calm: {},
};
const H3BR = { joy: [0.45, 0.03], smug: [0.3, 0.03], anger: [0.35, 0.06], fear: [0.9, 0.025], sad: [0.22, 0.05], disgust: [0.4, 0.03], surprise: [0.2, 0.012], thought: [0.3, 0.03], fatigue: [0.2, 0.06], pain: [0.7, 0.04], calm: [0.3, 0.03] };
const H3TR = { fear: 0.22, pain: 0.15, anger: 0.08, sad: 0.05 };
const H3PS = { tp: 0, lp: 0, sh: 0, hp: 0, cr: 0, ph: 0, last: 0 };
function h3Posture(P, fam, now, GT) {   // emotion -> posture bias, breathing and tremor, layered on the gesture pose
    const S = H3PS, dt = Math.min(0.1, Math.max(0.001, (now - S.last) / 1000)); S.last = now;
    const t = H3P[fam] || H3P.calm, k = 1 - Math.exp(-dt * 4);
    for (const q of ['tp', 'lp', 'sh', 'hp', 'cr']) S[q] += ((t[q] || 0) - S[q]) * k;
    const br = H3BR[fam] || H3BR.calm; S.ph += dt * Math.PI * 2 * br[0]; const b = Math.sin(S.ph) * br[1], B = P.B;
    B.tp += S.tp - b; B.lp += S.lp; B.sh += S.sh + b * 0.8; B.hp += S.hp; B.cr += S.cr;
    const tr = H3TR[fam] || 0; if (tr) P.arms.forEach((a, i) => { a.w[0] += Math.sin(GT * 1.9 + i * 2.1) * tr; a.w[1] += Math.cos(GT * 2.3 + i) * tr; });
}
const H3XMAP = { hula: 'grin', idle: 'smile', power: 'battle_cry', flex: 'proud', cheer: 'joy', point: 'determined', pointup: 'fierce', hips: 'smug', draw: 'focused', fireup: 'grit', guard: 'fierce', recoil: 'pain', cower: 'terror', clutch: 'betrayed', laugh: 'roar_laugh', run: 'afraid', walk: 'neutral', dash: 'determined', crossed: 'stern', stoic: 'resolve', hold: 'sad', oath: 'resolve', grab: 'devious', triumph: 'triumph', kneel: 'sorrow', dance: 'joy', spin: 'joy', six: 'gleeful', windmill: 'joy', freeze: 'smug', worm: 'smug', clap: 'delight', reach: 'awe', visor: 'puzzled', surf: 'delight', wave: 'smile' };
const H3X = { cur: null, last: 0, mics: [], nextMic: 0, fam: 'calm', idx: 0, ar: 0 };
function h3Expr(name, V) {
    const now = performance.now(); let dt = (now - H3X.last) / 1000; const fresh = !H3X.cur || dt > 0.3; H3X.last = now; dt = Math.min(Math.max(dt, 0.001), 0.05);
    const tgt = Object.assign({}, H3E_D, H3E[name] || H3E.neutral);
    const speech = V.sp != null ? V.sp : (V.mo || 0);
    if (speech > 0.02) { tgt.mo = Math.max(tgt.mo, speech * 1.3); tgt.mw += (V.mw || 0) * 1.3; if (!/^(sad|anger|fear|thought|fatigue|pain|disgust)$/.test(H3FAM[name] || 'calm')) tgt.tt = Math.max(tgt.tt, 0.35); }
    if (V.sp == null && V.brow) tgt.bo += V.brow * 0.5;
    if (V.g === 'smoke' || V.g === 'fireup') tgt.hp = Math.min(tgt.hp, 0) - 0.04;
    if (V.sm && V.sm.kw > 0.02) { const kw = V.sm.kw; tgt.fix = Math.max(tgt.fix, kw * 0.9); const fs = (V.hf || 1) < 0 ? -1 : 1; tgt.gx = -0.6 * kw * fs; tgt.gy = -0.05 * kw; tgt.hy = (tgt.hy || 0) - 0.35 * kw * fs; }   // the kid is talking: eyes and head turn to him
    if (V.sm && V.sm.up > 0.02) { const up = V.sm.up; tgt.fix = Math.max(tgt.fix, up); tgt.gy = 1.3 * up; tgt.gx = 0.15 * up * ((V.hf || 1) < 0 ? -1 : 1); tgt.hp = Math.min(tgt.hp, 0) - 0.26 * up; tgt.lid = Math.max(tgt.lid, 0.55); tgt.sm = Math.max(tgt.sm, 0.05); }   // looking up at the sky: eyes and head tip back
    if (V.sm && V.sm.gz > 0.02) { tgt.fix = Math.max(tgt.fix, V.sm.gz); tgt.gx = -0.5 * V.sm.gz; tgt.gy = -0.12 * V.sm.gz; tgt.lid = Math.min(tgt.lid, 0.4); tgt.hp += 0.2 * V.sm.gz; }
    if (V.sm && V.sm.tk > 0.02) { const T = (V.gt != null ? V.gt : now * 0.06), a = V.sm.tk * (V.sm.ta || 1); tgt.bo += a * 0.28 * (0.5 + 0.5 * Math.sin(T * 0.19)); tgt.boL += a * 0.12 * Math.max(0, Math.sin(T * 0.11 + 1)); tgt.sk += a * 0.1 * Math.sin(T * 0.07); tgt.ew += a * 0.08; }
    if (name === 'paranoid') {   // eyes dart from spot to spot in quick jumps and never settle, the head follows a beat late, and a fine tremor runs through the face
        const hsh = n => { const x = Math.sin(n * 12.9898) * 43758.5453; return (x - Math.floor(x)) * 2 - 1; }, k = Math.floor(now / 430), u = Math.min(1, (now - k * 430) / 70), j = (a, b) => a + (b - a) * u;
        tgt.gx = j(hsh(k - 1) * 0.8, hsh(k) * 0.8); tgt.gy = j(hsh(k + 76) * 0.3, hsh(k + 77) * 0.3) + 0.05; tgt.hy += tgt.gx * 0.3; tgt.hr += Math.sin(now * 0.045) * 0.014; tgt.sk += Math.sin(now * 0.031) * 0.1; tgt.bi += 0.12 * Math.sin(now * 0.02);
    }
    if (V.g === 'laugh') { const L = h3LP(V.gt != null ? V.gt : now * 0.06); tgt.mo = Math.max(tgt.mo, 0.2 + 0.7 * L.ha); tgt.sq += 0.35 * L.ha; tgt.lid -= 0.12 * L.E; tgt.mw += 0.2 * L.ha; }
    const fam = H3FAM[name] || 'calm';
    if (fam !== H3X.fam || fresh) { H3X.fam = fam; H3X.idx = 0; H3X.nextMic = now + 140; H3X.mics.length = 0; }   // a new emotion leaks its first micro right away
    {   // shape every expression of a family toward what the morphing face can actually show: a real smile lifts the cheeks and narrows the eyes; sadness tips the inner brows up; anger drives them down; fear opens everything
        const M = Math.max, m = Math.min;
        if (fam === 'joy') { tgt.sq = M(tgt.sq, 0.4 * M(0, tgt.sm)); tgt.bi = M(tgt.bi, -0.05); tgt.mw = M(tgt.mw, 0.25 * M(0, tgt.sm)); }
        else if (fam === 'sad') { tgt.bi = M(tgt.bi, 0.75); tgt.sm = m(tgt.sm, -0.4); tgt.lid = m(tgt.lid, 0.38); tgt.bo = m(tgt.bo, 0.05); tgt.pf = M(tgt.pf, 0.15); }
        else if (fam === 'anger') { tgt.bi = m(tgt.bi, -0.6); tgt.sm = m(tgt.sm, -0.1); tgt.sq = M(tgt.sq, 0.35); tgt.nf = M(tgt.nf, 0.25); tgt.ns = M(tgt.ns, 0.2); }
        else if (fam === 'fear') { tgt.bi = M(tgt.bi, 0.65); tgt.bo = M(tgt.bo, 0.45); tgt.lid = M(tgt.lid, 0.9); tgt.ew = M(tgt.ew, 0.3); tgt.sm = m(tgt.sm, -0.15); }
        else if (fam === 'disgust') { tgt.ns = M(tgt.ns, 0.55); tgt.sq = M(tgt.sq, 0.4); tgt.sm = m(tgt.sm, -0.2); tgt.bi = m(tgt.bi, -0.3); }
        else if (fam === 'pain') { tgt.sq = M(tgt.sq, 0.6); tgt.bi = M(tgt.bi, 0.55); tgt.pf = M(tgt.pf, 0.3); }
        else if (fam === 'surprise') { tgt.bo = M(tgt.bo, 0.6); tgt.lid = M(tgt.lid, 0.95); tgt.ew = M(tgt.ew, 0.4); tgt.bi = M(tgt.bi, 0.15); }
        else if (fam === 'smug') { tgt.sq = M(tgt.sq, 0.2); tgt.lid = m(tgt.lid, 0.4); }
        for (const k of ['sm', 'bi', 'bo', 'sq', 'ns', 'pf', 'mo', 'mw']) tgt[k] = Math.max(-1.1, Math.min(1.3, tgt[k]));
    }
    const ar = Math.min(1, (tgt.mo + Math.abs(tgt.sm) + Math.abs(tgt.bi) + Math.max(0, tgt.bo)) / 2.2); H3X.ar = ar;
    if (now >= H3X.nextMic) { const sc = H3S[fam] || H3S.calm, e = sc[H3X.idx++ % sc.length].split('@'); H3X.mics.push({ k: e[0], t0: now, a: (0.22 + 0.18 * ar) * (speech > 0.1 ? 0 : 1) }); H3X.nextMic = now + (+e[1]) * (2.6 - 0.9 * ar); }
    for (let i = H3X.mics.length - 1; i >= 0; i--) {
        const m = H3X.mics[i], d = H3M[m.k], dur = d ? (d._d || 220) : 0, u = d ? (now - m.t0) / dur : 2;
        if (u >= 1 || u < 0) { H3X.mics.splice(i, 1); continue; }
        const sh = d._s | 0, env = sh === 1 ? (u < 0.15 ? u / 0.15 : u > 0.7 ? (1 - u) / 0.3 : 1) : sh === 2 ? Math.sin(Math.PI * u) * (0.55 + 0.45 * Math.sin(u * dur * 0.06)) : Math.sin(Math.PI * u);
        for (const k in d) if (k[0] !== '_') tgt[k] += d[k] * env * m.a;
    }
    if (!H3X.cur) H3X.cur = Object.assign({}, tgt);
    const c = H3X.cur, k = fresh ? 1 : 1 - Math.exp(-dt * 13), km = fresh ? 1 : 1 - Math.exp(-dt * 32);
    for (const key in tgt) c[key] += (tgt[key] - c[key]) * (key === 'mo' || key === 'mw' ? km : k);
    return c;
}
function h3Zs(x, y) {   // z of the head surface (head-local) at (x, y): the same super-ellipsoid + chin taper the head mesh uses
    const a = 5.6, b = 6.5, c = 5.7, n1 = 2.5, n2 = 2.3, tp = headW(y), ay = Math.min(0.999, Math.abs(y) / b);
    const f = Math.pow(1 - Math.pow(ay, n1), n2 / n1) - Math.pow(Math.min(1, Math.abs(x) / (a * tp)), n2);
    return f > 0 ? c * tp * Math.pow(f, 1 / n2) : 0;
}

function h3Pose(name, T, phase, V) {   // everything the rig needs for one gesture at time T: body angles, arm targets, feet
    const GD = H3G[name] || H3G.hula, GB = GD.body ? GD.body(T, phase, V) : null, hu = GB && GB.hula != null ? GB.hula : 1;
    const B = Object.assign({ cr: 0, lean: 0, pitch: 0, yaw: 0, hy: 0, hp: 0, bob: 0, leg: 'stand', py: 0, pr: 0, hx: 0, lp: 0, tp: 0, ly: 0, ty: 0, ls: 0, ts: 0, sh: 0, shL: 0, shR: 0, hr: 0, jy: 0, rs: 0, rp: 0, ro: 0, rl: 0, rx: 0, ry: 0, rz: 0, ht: 0 }, GB || {});
    if (VQ.sm && VQ.sm.up > 0.02) { B.hp -= 0.5 * VQ.sm.up; B.pitch -= 0.06 * VQ.sm.up; }   // looking at the stars: the whole head tips back
    if (VQ.ill && VQ.g !== 'dance') { const Qi = h3Dn(VQ.ill - 1).li; B.hr += 0.17 * Qi; B.hy -= 0.28 * Qi; B.hp += 0.04 * Qi; B.sh += 0.1 * Qi; }   // VQ.ill = a clock: any gesture can carry the listening aside (the menu does)
    const arms = [-1, 1].map(sx => {
        const AG = GD.arm ? GD.arm(sx, T, phase, V) : null;
        if (AG) return { w: AG.w.slice(), pl: (AG.pl || [sx * 0.45, -1, 0.25]).slice(), curl: AG.curl != null ? AG.curl : AG.fist ? 1.5 : 0.35, fl: AG.fl != null ? AG.fl : 0.12, wb: AG.wb || 0, wz: AG.wz || 0, wt: AG.wt || 0, ag: 1 };
        return { w: [sx * 12.6 + Math.cos(phase) * 1.7, 22.0 - sx * Math.sin(phase) * 2.8, 1.3], pl: [sx * 0.45, -1, 0.25], curl: 0.18 + 0.5 * (0.5 + 0.5 * Math.sin(phase * 2 + sx * 1.3)), fl: 0.42, wb: 0, wz: 0, wt: 0, ag: 0 };
    });
    if (V && V.sm && V.sm.bird > 0.01) { const bs = (V.hf || 1) < 0 ? 1 : -1, a = arms[bs > 0 ? 1 : 0], k = Math.min(1, V.sm.bird), tw = [bs * 11, 25.5, 6], tp = [bs * 0.35, -1, 0.3]; a.w = a.w.map((v, i) => v + (tw[i] - v) * k); a.pl = a.pl.map((v, i) => v + (tp[i] - v) * k); a.curl += (0.35 - a.curl) * k; a.wb = (a.wb || 0) * (1 - k); a.wz = (a.wz || 0) * (1 - k); a.wt = -1.1 * k; a.ag = 1; }   // the middle finger: the arm on the side toward the target bends and the forearm stands up, finger to the sky, as in a real flip-off
    return { B, hu, arms, feet: [-1, 1].map(sx => { const f = h3Foot(B.leg, sx, T, phase); if (GD.foot) GD.foot(sx, T, phase, V, f); return f; }) };
}
function h3Mix(a, b, w) {   // pose a -> pose b by w (w may overshoot 1: follow-through)
    const m = (p, q) => p + (q - p) * w, o = { B: {}, hu: m(a.hu, b.hu), arms: [], feet: [] };
    for (const k of ['cr', 'lean', 'pitch', 'yaw', 'hy', 'hp', 'bob', 'py', 'pr', 'hx', 'lp', 'tp', 'ly', 'ty', 'ls', 'ts', 'sh', 'shL', 'shR', 'hr', 'jy', 'rs', 'rp', 'ro', 'rl', 'rx', 'ry', 'rz', 'ht']) o.B[k] = m(a.B[k], b.B[k]);
    o.B.leg = w < 0.5 ? a.B.leg : b.B.leg;
    for (let i = 0; i < 2; i++) {
        const p = a.arms[i], q = b.arms[i];
        o.arms.push({ w: p.w.map((v, j) => m(v, q.w[j])), pl: p.pl.map((v, j) => m(v, q.pl[j])), curl: m(p.curl, q.curl), fl: m(p.fl, q.fl), wb: m(p.wb || 0, q.wb || 0), wz: m(p.wz || 0, q.wz || 0), wt: m(p.wt || 0, q.wt || 0), ag: m(p.ag, q.ag) });
        const f = {}; for (const k in p === a.arms[i] ? a.feet[i] : {}) f[k] = m(a.feet[i][k], b.feet[i][k]); o.feet.push(f);
    }
    return o;
}
const H3Q = { cur: null, prev: null, t0: 0, last: 0 }, H3L = { hy: 0, hp: 0, last: 0 };
const H3_VIEW = { halfW: 28, halfH: 39, cy: 9, D: 130, pitch: 0.27 };   // maps hero units (x, y-up) onto the 56 x 78 unit blit rectangle
const MUS_LIT = [0.66, 0.44, 0.29].map(v => v * 1.03), MUS_SHD = [0.66, 0.44, 0.29].map(v => v * 0.55), MUS_MID = [0.66, 0.44, 0.29].map(v => v * 0.95), MUS_MS = { spec: 0.08, shin: 14, rim: 0.22, skin: 1 };   // face-muscle tones (skin shade variants), built once
let H3Last = null, H3PIP = false, csFrameN = 0;   // last full-opacity hero draw (for the cutscene close-up portrait) and a flag while that portrait itself is being drawn
function drawVaqueroGL(x, y, s, facing, phase, alpha) {
    const gl = H3.gl, Mh = H3.M, V = H3_VIEW;
    if (!H3PIP && alpha >= 0.9) H3Last = { f: csFrameN, eff: s * ctx.getTransform().a * W / ctx.canvas.width, vq: Object.assign({}, VQ), facing, phase };   // full snapshot of the hero's animation state, so the cutscene portrait can replay exactly it
    const dens = Math.min(RES * s, 1950 / 78, 1400 / 56), pw = Math.max(8, Math.ceil(56 * dens)), ph = Math.max(8, Math.ceil(78 * dens));
    if (H3.cw < pw || H3.ch < ph) { H3.cw = Math.max(H3.cw, pw); H3.ch = Math.max(H3.ch, ph); H3.cv.width = H3.cw; H3.cv.height = H3.ch; }
    // quality path: supersampled offscreen scene + bloom; lo path (after a slow-device downgrade): straight to the canvas
    const hi = !H3.lo && H3.post, hqv = H3.lo ? 0 : Math.max(0, (OPT.hq == null ? 1 : OPT.hq) - QG.hq); let SS = 1; if (hi) for (let q = Math.min([2, 3, 4][hqv], VQ.ssCap || 9); q >= 2; q--) if (pw * ph * q * q <= [2600000, 4200000, 6600000][hqv]) { SS = q; break; }
    const sw = pw * SS, shh = ph * SS;
    if (hi) { const T = h3Target(H3.S, sw, shh, true); if (!T.ok) { H3.lo = true; } }
    const useFbo = hi && !H3.lo;
    gl.bindFramebuffer(gl.FRAMEBUFFER, useFbo ? H3.S.fbo : null);
    const vw = useFbo ? sw : pw, vh = useFbo ? shh : ph;
    gl.viewport(0, 0, vw, vh); gl.scissor(0, 0, vw, vh); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const VP = m4.chain(m4.persp(2 * Math.atan(V.halfH / V.D), V.halfW / V.halfH, 20, 400), m4.T(0, 0, -V.D), m4.RX(V.pitch), m4.T(0, -V.cy, 0));
    gl.uniformMatrix4fv(H3.U.uVP, false, VP); gl.uniform1f(H3.U.uHQ, hqv); h3Dirty();
    // pose
    const hc = hoopColors(), eq = save.cos.eq.hat, hs = HAT_STYLES[eq % HAT_STYLES.length], hcol = hatCol(hs);
    const GT = VQ.gt != null ? VQ.gt : performance.now() * 0.06, nowMs = performance.now(), gname = VQ.g || 'hula';
    let POSE = h3Pose(gname, GT, phase, VQ);
    if (!VQ.snap) {   // gestures blend into each other (eased, with a little follow-through) instead of popping
        if (nowMs - H3Q.last > 600 || H3Q.cur == null) { H3Q.cur = gname; H3Q.prev = null; }
        H3Q.last = nowMs;
        if (H3Q.cur !== gname) { H3Q.prev = H3Q.cur; H3Q.cur = gname; H3Q.t0 = nowMs; }
        const u = (nowMs - H3Q.t0) / 300;
        if (H3Q.prev && u < 1) { const c1 = 1.1, c3 = c1 + 1, w = 1 + c3 * Math.pow(u - 1, 3) + c1 * Math.pow(u - 1, 2); POSE = h3Mix(h3Pose(H3Q.prev, GT, phase, VQ), POSE, w); const ant = Math.sin(Math.PI * u); POSE.B.cr += ant * 0.9; POSE.B.tp += ant * 0.07; POSE.B.sh += ant * 0.06; }
    }
    const hu = POSE.hu, B = POSE.B, clampJ = (v, m) => Math.max(-m, Math.min(m, v));
    h3Posture(POSE, H3FAM[VQ.x || H3XMAP[VQ.g || 'hula'] || 'neutral'] || 'calm', nowMs, GT);
    B.pitch = Math.max(-0.55, Math.min(0.75, B.pitch)); B.lean = clampJ(B.lean, 0.45); B.yaw = clampJ(B.yaw, 0.9); B.hp = clampJ(B.hp, 0.7); B.hy = clampJ(B.hy, 1.0);   // joint limits
    const pyv = clampJ(B.py, 0.4), prv = clampJ(B.pr, 0.16), lpv = clampJ(B.pitch * 0.45 + B.lp, 0.5), tpv = clampJ(B.pitch * 0.55 + B.tp, 0.6), lyv = clampJ(B.yaw * 0.25 + B.ly, 0.5), tyv = clampJ(B.yaw * 0.75 + B.ty, 0.8);
    const wob = Math.cos(phase) * 3 * hu, tilt = Math.sin(phase) * 0.15 * hu, sway = Math.sin(phase) * 1.2 * hu, hip = wob * 0.6 + B.hx, lean = -wob * 0.024 + B.lean + (VQ.tilt || 0) * 0.7, bob = Math.sin(phase * 2) * 0.55 * hu + B.bob * Math.abs(Math.sin(GT * 0.35)) * 0.8;
    const JP = (Math.max(0, VQ.jump || 0) / s + Math.max(0, B.jy || 0)) * (1 - Math.min(1, (Math.abs(B.rp) + Math.abs(B.ro)) / 1.2)), crT = B.cr + (VQ.squash || 0) * 30;
    const XN = VQ.x || H3XMAP[VQ.g || 'hula'] || 'neutral', X = h3Expr(XN, VQ);
    const hcx = wob * 1.25, hcy = 2 + bob + crT, hrx = 19 + Math.cos(phase) * 0.8 * hu, yaw = Math.sin(phase) * 0.22 * hu + B.yaw;
    const skin = [0.66, 0.44, 0.29], hair = [0.07, 0.045, 0.035], white = [0.96, 0.94, 0.90], gold = [1.0, 0.82, 0.25], leather = [0.36, 0.22, 0.10], cream = [0.91, 0.86, 0.75];
    const sk = (o) => Object.assign({ col: skin, spec: 0.1, shin: 16, rim: 0.28, skin: 0.3 }, o);
    let skp = null;   // face add-on material (needs the face texture, set below)
    // ---- rig: body group, head and hat frames come first so the shadow casters are known to every draw ----
    const pyT = -yaw * 0.2 + pyv, Pm = m4.chain(m4.T(hip + sway, -bob - crT + JP, 0), m4.RY(pyT), m4.RZ(prv));   // pelvis: follows the hips; the legs are IK'd to planted feet
    const J1 = 3.333, J2 = 10.467, br = Math.sin(GT * 0.06) * 0.012;
    const C1 = m4.chain(Pm, m4.T(0, J1, 0), m4.RZ(-(lean * 0.4 + B.ls)), m4.RX(lpv + br * 0.45), m4.RY(lyv), m4.T(0, -J1, 0));   // lumbar
    const U = m4.chain(C1, m4.T(0, J2, 0), m4.RZ(-(lean * 0.6 + B.ts)), m4.RX(tpv + br * 0.55), m4.RY(tyv), m4.T(0, -J2, 0));   // thoracic: arms, capelet and neck ride on this
    // head: eyes lead, the head follows a beat later; partly counter-rotates the chest so he keeps looking where he means to
    { const dtL = Math.min(0.1, Math.max(0.001, (nowMs - H3L.last) / 1000)); H3L.last = nowMs; const kk = 1 - Math.exp(-dtL * 7); H3L.hy += (H3F.gx * 0.45 * (1 - X.fix) + X.gx * 0.25 - H3L.hy) * kk; H3L.hp += (H3F.gy * 0.3 * (1 - X.fix) + X.gy * 0.15 - H3L.hp) * kk; }
    const nHy = clampJ(B.hy + X.hy * 0.3 + H3L.hy - (lyv + tyv + pyT) * 0.4, 1.0), nHp = clampJ(B.hp + X.hp * 0.35 + H3L.hp - (lpv + tpv) * 0.3, 0.7), nHr = clampJ(X.hr * 0.3 + lean * 0.35 + B.hr, 0.5);
    const N1 = m4.chain(U, m4.T(0, 16.6, 0), m4.RY(nHy * 0.4), m4.RX(nHp * 0.4), m4.RZ(nHr * 0.4));
    const N2 = m4.chain(N1, m4.T(0, 2.6, 0), m4.RY(nHy * 0.6), m4.RX(nHp * 0.6), m4.RZ(nHr * 0.6));
    const HS = 0.69, jaw = Math.max(0, Math.min(1.3, X.mo)), HP = m4.chain(N2, m4.T(0, 4.5, 0), m4.RX(-0.05 * jaw), m4.S(HS * 0.93, HS * 1.02, HS * 0.95));
    const HAT = 0.74, HB = (VQ.sm ? (VQ.sm.ln || 0) * 0.2 + (VQ.sm.tk || 0) * 0.04 : 0) * (VQ.sm && VQ.sm.rise > 0.3 ? 0 : 1), HT = m4.chain(N2, m4.T(0, 8.7, 0), m4.T(0, -4.2, 0), m4.RX(B.ht), m4.T(0, 4.2, 0), m4.RZ(lean * 0.9 - sway * 0.02), m4.T(0, -0.6 * HB * 5, 0), m4.T(0, -1.5, -3.6), m4.RX(-HB), m4.T(0, 1.5, 3.6), m4.S(HAT, HAT, HAT));   // hat pushed back off the face while he leans or talks
    const blink = h3Life(hip + sway, -bob, yaw) * (1 - X.nb), CL = H3C, cmode = m => gl.uniform1f(H3.U.uCm, m);
    gl.uniform3f(H3.U.uCl, CL.x, CL.y, CL.z); gl.uniform2f(H3.U.uCw, Math.min(0.5, 0.1 + 0.035 * (Math.abs(CL.vx) + Math.abs(CL.vy))), CL.ph);
    H3ROOT = null; if (Math.abs(B.rp) + Math.abs(B.ro) + Math.abs(B.rl) + Math.abs(B.ry) + Math.abs(B.rx) + Math.abs(B.rz) > 0.003) { const sc = 1 + B.rz, R0 = m4.chain(m4.S(sc, sc, sc), m4.RZ(B.rl), m4.RY(B.rs), m4.RX(B.rp), m4.RY(B.ro));
        // auto-ground: lowest of feet, hands, belly/back, head and hat (in rotated space) is set exactly onto the floor, so nothing sinks in or hovers, whatever the pose
        const pts = [], rx = (y, z, r) => [y * Math.cos(r) - z * Math.sin(r), y * Math.sin(r) + z * Math.cos(r)];
        for (const sx of [-1, 1]) { const f = POSE.feet[sx < 0 ? 0 : 1], fx = sx * 3.4 + f.x, fy = -24.5 + f.y, fz = f.z; for (const [oy, oz] of [[-2.9, 6.5], [-2.9, -3.4]]) { const q = rx(oy, oz, f.r); pts.push([fx, fy + q[0], fz + q[1]]); }
            const w = POSE.arms[sx < 0 ? 0 : 1].w, dh = [w[0] - sx * 5.5, w[1] - 16.6, w[2]], dl = Math.hypot(dh[0], dh[1], dh[2]) || 1; pts.push([w[0] + dh[0] / dl * 5, w[1] + dh[1] / dl * 5, w[2] + dh[2] / dl * 5]); pts.push([sx * 8.5, 15, 5], [sx * 8.5, 15, -5], [sx * 4, 16, 4.6], [sx * 4, 16, -4.6], [sx * 3.6, 0, 4], [sx * 3.6, 0, -4]); }
        pts.push([0, 22, 4.5], [0, 22, -4.5]); for (const [ox, oy, oz] of [[10.7, 0, 0], [-10.7, 0, 0], [0, 0, 10.7], [0, 0, -10.7], [0, 6, 0], [0, 9, 0], [8, 3, 8], [-8, 3, 8], [8, 3, -8], [-8, 3, -8]]) { const q = rx(4.2 + oy, oz, B.ht); pts.push([ox, 23.7 + q[0], q[1]]); }   // hat: rim points + crown, rotated about the head centre like the hat itself
        let mnY = 1e9; for (const p of pts) mnY = Math.min(mnY, R0[1] * p[0] + R0[5] * p[1] + R0[9] * p[2]);
        H3ROOT = m4.chain(m4.T(B.rx, -26.9 - mnY + 1.2, 0), R0); }
    gl.uniform3fv(H3.U.uAS, H3AS); gl.uniform1f(H3.U.uASr, H3AS[17] > -900 && !H3.lo && !H3ROOT ? 2.3 * Math.hypot(U[0], U[1], U[2]) : 0);   // arm shadows from the previous frame's pose
    gl.uniform4f(H3.U.uBr, HT[12], HT[13] - 0.1, HT[14], H3ROOT ? 0 : 14.4 * HAT); gl.uniform4f(H3.U.uHd, HP[12], HP[13], HP[14], H3ROOT ? 0 : 4.2); gl.uniformMatrix4fv(H3.U.uHI, false, m4Inv(H3ROOT ? m4.mul(H3ROOT, HP) : HP));   // rotated bodies drop the up-is-up analytic shadows
    // hoop
    const hoopM = m4.chain(m4.T(hcx, -hcy + JP, 0), m4.RZ(-tilt), m4.S(hrx, 1, hrx * 0.97));
    if (!VQ.nohoop && !H3ROOT) { h3Draw(Mh.hoop, m4.chain(m4.T(hcx, -hcy + JP, 0), m4.RZ(-tilt), m4.S(hrx, hrx, hrx * 0.97)), { hoop: true, h0: cssRgb(hc[0]), h1: cssRgb(hc[1]), ph: phase * 0.8, spec: 0.8, shin: 28, rim: 0.4 }); }
    // legs: hip -> knee -> ankle, two-bone IK so the knees flex with the hula bounce; skinned so the denim bends smoothly
    const denim = h3Tex('denim', 128, 256, txDenim), I4 = m4.id(), LEG = [null, null];   // LEG: hip / knee / ankle per leg, kept as collision capsules for the arms
    for (const sx of [-1, 1]) {
        const ft = POSE.feet[sx < 0 ? 0 : 1], top = [sx * 2.7 * Math.cos(prv) * Math.cos(pyT) + hip + sway, -0.4 - bob * 1.4 - crT + JP + sx * 2.7 * Math.sin(prv), -sx * 2.7 * Math.sin(pyT)], ank = [sx * 3.4 + ft.x, -24.2 + ft.y + JP * 0.8, 0.3 + ft.z];
        { const dx = ank[0] - top[0], dy = ank[1] - top[1], dz = ank[2] - top[2], D = Math.hypot(dx, dy, dz), mx = 24.0; if (D > mx) { const f = mx / D; ank[0] = top[0] + dx * f; ank[1] = top[1] + dy * f; ank[2] = top[2] + dz * f; } }   // knee never locks out
        const k = ik2(top, ank, 12.2, 12.2, [sx * 0.2, 0, 1]); LEG[sx < 0 ? 0 : 1] = [top, k.j, k.e];
        h3Skin(Mh.legSk[sx], I4, m4.frame(top, k.j, 1, [1, 0, 0]), m4.frame(k.j, k.e, 1, [1, 0, 0]), 0.2, { tex: denim, spec: 0.05, shin: 8, rim: 0.2 });
    }
    // hips: a denim pelvis mass between belt and thighs, so the torso widens into the hips and both legs grow out of one body (it follows the pelvis, the thighs swing under it)
    h3Draw(Mh.sphere, m4.chain(Pm, m4.T(0, -2.3, -0.15), m4.S(5.5, 3.6, 3.5)), { tex: denim, spec: 0.05, shin: 8, rim: 0.2 });
    // boots + spurs
    for (const sx of [-1, 1]) {
        const li = sx < 0 ? 0 : 1, lc = sx < 0 ? '#1c1512' : '#241a16', bt = h3Tex('boot' + lc, 128, 64, txBoot(lc)), bx = sx * 3.4, ft = POSE.feet[li], A = LEG[li][2], Kn = LEG[li][1];
        // the whole boot hangs off the REAL ankle (after the IK / knee-lock clamp), and the shaft runs along the shin, so it can never come loose from the leg
        const FT = m4.chain(m4.T(A[0] - bx, A[1] + 24.2, A[2] - 0.3), m4.T(bx, -24.2, 0.3), m4.RY(ft.ry), m4.RZ(ft.rz), m4.RX(ft.r), m4.T(-bx, 24.2, -0.3));
        const FTo = m4.chain(FT, m4.T(bx, -25.5, 2.0), m4.RX(ft.tb), m4.T(-bx, 25.5, -2.0));   // forefoot bends at the toes
        const sd = [Kn[0] - A[0], Kn[1] - A[1], Kn[2] - A[2]], sl = Math.hypot(sd[0], sd[1], sd[2]) || 1, T0 = [A[0] + sd[0] / sl * 5.4, A[1] + sd[1] / sl * 5.4, A[2] + sd[2] / sl * 5.4];
        const fr1 = (p0, p1) => { const L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]) || 1; return m4.chain(m4.frame(p0, p1, 1, [1, 0, 0]), m4.S(1, 1 / L, 1)); };
        const SHF = fr1(T0, A), WELT = { col: [0.04, 0.03, 0.025], spec: 0.3, shin: 20, rim: 0.1 }, LEA = { tex: bt, spec: 0.6, shin: 42, rim: 0.3 };
        h3Draw(Mh.bSh, SHF, LEA);
        h3Draw(Mh.bUR, m4.chain(FT, m4.T(bx, 0, 0)), LEA); h3Draw(Mh.bUF, m4.chain(FTo, m4.T(bx, 0, 0)), LEA);
        h3Draw(Mh.bSR, m4.chain(FT, m4.T(bx, 0, 0)), WELT); h3Draw(Mh.bSF, m4.chain(FTo, m4.T(bx, 0, 0)), WELT); h3Draw(Mh.bHeel, m4.chain(FT, m4.T(bx, 0, 0)), WELT);
        h3Draw(Mh.sphere, m4.chain(FT, m4.T(bx - sx * 0.3, -26.2, -2.9), m4.S(0.8, 0.8, 0.8)), { col: [0.78, 0.78, 0.8], spec: 0.95, shin: 40, rim: 0.3 });
        // silver: toe cap, a band under the top lip, the spur strap round the ankle, the spur arm and its rowel
        const SIL = [0.82, 0.82, 0.86], MET = { col: SIL, spec: 0.95, shin: 38, rim: 0.3 };
        
        h3Draw(Mh.torus, m4.chain(fr1(T0, A), m4.T(0, 0.15, 0), m4.S(2.7, 0.5, 2.85)), { col: [0.05, 0.035, 0.03], spec: 0.5, shin: 30, rim: 0.15 });
        h3Draw(Mh.torus, m4.chain(fr1(T0, A), m4.T(0, 4.6, 0), m4.S(2.64, 0.8, 2.82)), MET);   // top band
        h3Draw(Mh.tube, m4.chain(FT, m4.seg([bx, -24.8, -2.5], [bx - sx * 0.1, -26.3, -3.55], 0.22)), MET);
        h3Draw(Mh.xRowel || (Mh.xRowel = h3Merged((() => { const L = [[() => mkFrustum(1, 1, 20), m4.chain(m4.RZ(Math.PI / 2), m4.T(0, -0.1, 0), m4.S(1, 0.2, 1))]]; for (let k = 0; k < 8; k++) L.push([() => mkFrustum(1, 0, 8), m4.chain(m4.RX(k * TAU / 8), m4.T(0, 0.8, 0), m4.S(0.2, 0.5, 0.2))]); return L; })())), m4.chain(FT, m4.T(bx - sx * 0.1, -26.4, -3.75), m4.RX(phase * 0.7 + sx), m4.S(0.9, 0.9, 0.9)), { col: SIL, spec: 0.95, shin: 38, rim: 0.3 });
    }
    // upper body: shirt + vest torso, shoulder capelet, belt, holster
    h3Skin3(Mh.torso, m4.id(), m4.chain(Pm, m4.frame([0, -3.8, 0], [0, J1, 0], 1, [1, 0, 0])), m4.chain(C1, m4.frame([0, J1, 0], [0, J2, 0], 1, [1, 0, 0])), m4.chain(U, m4.frame([0, J2, 0], [0, 17.6, 0], 1, [1, 0, 0])), 0.3, { tex: h3Tex('shirt', 1024, 1024, txShirt), spec: 0.12, shin: 10, rim: 0.25 });
    {   // how far each shoulder rises (same formula as the arm rig below) so the poncho can lift with it
        const AL = [0, 0];
        for (const sx of [-1, 1]) { const A = POSE.arms[sx < 0 ? 0 : 1], w1 = A.w[1], e0 = Math.max(-0.2, Math.min(0.52, (w1 - 14.9) * (w1 > 14.9 ? 0.03 : 0.012) + 0.015 * Math.sin(GT * 0.07) + B.sh + (sx < 0 ? B.shL : B.shR))); AL[sx < 0 ? 0 : 1] = Math.max(0, 16.6 + 4.72 * Math.sin(-0.37 + e0) - 15.4); }
        gl.uniform2f(H3.U.uAr, AL[0], AL[1]);
    }
    gl.uniform3f(H3.U.uSw, 0.5 + Math.abs(sway) * 0.25, phase * 1.7, 0);   // tassels swing
    gl.uniform3f(H3.U.uSw, 0, 0, 0); cmode(0);
    // belt: stamped, stitched leather band that follows the hips, two keepers, concho studs, a framed and engraved trophy buckle with a ruby
    h3Draw(Mh.belt, Pm, { tex: h3Tex('belt', 1024, 64, txBelt), spec: 0.32, shin: 22, rim: 0.2 });
    h3Draw(Mh.keepA, Pm, { tex: h3Tex('belt', 1024, 64, txBelt), spec: 0.3, shin: 20, rim: 0.2 }); h3Draw(Mh.keepB, Pm, { tex: h3Tex('belt', 1024, 64, txBelt), spec: 0.3, shin: 20, rim: 0.2 });
    h3Draw(Mh.xBelt || (Mh.xBelt = h3Merged((() => { const L = [], sp = () => mkEllipsoid(1, 1, 1, 14, 10); for (let k = 0; k < 19; k++) { const a = (0.06 + 0.88 * k / 18) * Math.PI, x = 5.3 * Math.cos(a); if (Math.abs(x) < 2.9) continue; L.push([sp, m4.chain(m4.T(x, 0.3, 3.86 * Math.sin(a)), m4.S(0.3, 0.3, 0.18))]); } return L; })())), Pm, { col: gold, spec: 0.95, shin: 36, rim: 0.3 });
    {
        const BK = m4.chain(Pm, m4.T(0, 0.3, 3.88)), GOLD = { col: gold, spec: 0.95, shin: 36, rim: 0.3 };
        h3Draw(Mh.buckle, BK, { tex: h3Tex('buckle', 256, 256, txBuckle), spec: 0.9, shin: 40, rim: 0.3 });
        h3Draw(Mh.torus, m4.chain(BK, m4.T(0, 0, 0.3), m4.RX(Math.PI / 2), m4.S(0.98, 1.5, 0.78)), { col: [0.86, 0.87, 0.9], spec: 1, shin: 44, rim: 0.3 });
        h3Draw(Mh.sphere, m4.chain(BK, m4.T(0, 0, 0.36), m4.S(0.8, 0.62, 0.34)), { col: [0.85, 0.07, 0.12], spec: 1, shin: 50, rim: 0.4 });
        for (const sx of [-1, 1]) for (const sy of [-1, 1]) h3Draw(Mh.sphere, m4.chain(BK, m4.T(sx * 1.78, sy * 1.18, 0.2), m4.S(0.16, 0.16, 0.12)), GOLD);
    }
    // pouches: rounded leather boxes with a snap flap
    {   // holster on the right hip: tapered stitched leather, belt tab with rivet, tie-down thong, and the pistol: ivory grip, steel frame, hammer, trigger guard
        const HM = m4.chain(Pm, m4.T(5.35, -0.4, 1.35), m4.RY(0.65), m4.RZ(-0.05)), HL = { tex: h3Tex('lea4', 128, 256, (w, h) => txLeather(w, h, '#573219', '#3b200d', 61)), spec: 0.38, shin: 24, rim: 0.2 }, STEEL = { col: [0.52, 0.54, 0.58], spec: 0.9, shin: 40, rim: 0.3 };
        h3Draw(Mh.hbody || (Mh.hbody = mkFrustum(0.55, 1, 22, 0.78)), m4.chain(HM, m4.T(0, -5.6, 0), m4.S(1.55, 5.9, 1.55)), HL);
        h3Draw(Mh.rbox, m4.chain(HM, m4.T(0, 0.15, 0.05), m4.S(1.7, 0.9, 1.3)), HL);
        h3Draw(Mh.rbox, m4.chain(HM, m4.T(0, 0.95, -0.15), m4.S(1.5, 1.2, 0.3)), { tex: h3Tex('lea3', 128, 128, (w, h) => txLeather(w, h, '#654020', '#472812', 53)), spec: 0.4, shin: 24, rim: 0.2 });
        h3Draw(Mh.sphere, m4.chain(HM, m4.T(0, 0.95, 0.02), m4.S(0.24, 0.24, 0.14)), { col: gold, spec: 0.95, shin: 36, rim: 0.3 });
        h3Draw(Mh.tube, m4.chain(HM, m4.seg([-1.5, -5.1, 0.2], [1.5, -5.1, 0.2], 0.16)), { col: [0.28, 0.17, 0.08], spec: 0.3, shin: 20, rim: 0.2 });
        h3Draw(Mh.sphere, m4.chain(HM, m4.T(0, 2.0, 0), m4.RX(-0.32), m4.S(0.88, 1.9, 0.72)), { tex: h3Tex('grip', 64, 128, txGrip), spec: 0.5, shin: 34, rim: 0.3 });
        h3Draw(Mh.rbox, m4.chain(HM, m4.T(0, 3.5, 0.18), m4.S(0.62, 0.85, 0.9)), STEEL);
        h3Draw(Mh.rbox, m4.chain(HM, m4.T(0, 1.9, -0.72), m4.RX(-0.32), m4.S(0.34, 1.6, 0.2)), STEEL);
        h3Draw(Mh.tube, m4.chain(HM, m4.seg([0, 3.9, -0.55], [0, 4.5, -0.9], 0.2)), STEEL);
        h3Draw(Mh.torus, m4.chain(HM, m4.T(0, 2.95, 0.65), m4.RZ(Math.PI / 2), m4.S(0.55, 1.2, 0.55)), STEEL);
    }
    // neck, bandana, collar, chain, medallion
    h3Skin(Mh.neckSk, m4.id(), m4.chain(N1, m4.frame([0, 0, 0], [0, 2.6, 0], 1, [1, 0, 0])), m4.chain(N2, m4.frame([0, 0, 0], [0, 2.6, 0], 1, [1, 0, 0])), 0.3, sk({ col: [0.58, 0.375, 0.24], skin: 0.6 }));
    {   // neck anatomy as real geometry: the two sternocleidomastoid cords, the Adam's apple and the jugular veins; they tense with shouting, strain and turning the head
        const cz = (v, lo, hi2) => Math.max(lo, Math.min(hi2, v)), tw0 = VQ.sm && VQ.sm.tw ? VQ.sm.tw : 0;
        const strain = cz(Math.max(0, -X.bi) * 0.6 + Math.min(1.3, X.mo) * 0.55 + X.ns * 0.3 + X.sq * 0.15 + tw0 * 0.7, 0, 1.3), pitchBack = cz(-nHp, 0, 0.7), turn = cz(nHy, -1, 1);
        const rN = y => 1.85 - 0.12 * (y / 2.6), cordCol = skin.map(v => Math.min(1, v * 1.05)), veinCol = [skin[0] * 0.74, skin[1] * 0.68, skin[2] * 0.78];
        for (const sx of [-1, 1]) {
            const side = sx * turn, ten = cz(0.2 + 0.5 * cz(side, 0, 1) + 0.35 * strain + 0.15 * pitchBack, 0, 1.2);   // the cord on the side opposite the turn stands out most
            h3Ribbon(9, 8, u => { const y = 2.55 - u * 2.25, th = (1.1 - 0.8 * u) * (0.97 + 0.03 * Math.sin(u * 3)), r = rN(y) + 0.05; return [sx * r * Math.sin(th), y, r * Math.cos(th) + 0.03, 0.13 + 0.1 * ten * Math.sin(Math.PI * Math.min(1, u * 0.9 + 0.1)), 0.05 + 0.1 * ten]; }, N1, sk({ col: cordCol, spec: 0.08, shin: 14, rim: 0.3 }));   // behind the ear down to the notch above the breastbone
            const vs = cz((strain - 0.2) / 0.6, 0, 1);
            if (vs > 0.03) h3Ribbon(9, 6, u => { const y = 2.3 - u * 1.9, th = 0.95 - 0.55 * u + 0.12 * Math.sin(u * 5.5), r = rN(y) + 0.06; return [sx * r * Math.sin(th), y, r * Math.cos(th) + 0.04, 0.025 + 0.05 * vs, 0.018 + 0.05 * vs]; }, N1, sk({ col: veinCol, spec: 0.12, shin: 18, rim: 0.2 }));   // the jugular, swelling under strain
        }
        const jawO = cz(X.mo, 0, 1.3), ay = 1.3 + 0.35 * pitchBack + 0.12 * jawO + 0.05 * Math.sin(GT * 0.05);   // Adam's apple rises when the jaw drops and the head tips back
        h3Draw(Mh.sphere, m4.chain(N1, m4.T(0, ay, rN(ay) - 0.02), m4.S(0.34, 0.5 + 0.12 * pitchBack, 0.27 + 0.18 * pitchBack + 0.06 * strain)), sk({ col: cordCol, spec: 0.1, shin: 16, rim: 0.3 }));
        h3Draw(Mh.sphere, m4.chain(N1, m4.T(0, ay + 0.52, rN(ay + 0.5) - 0.08), m4.S(0.26, 0.1, 0.12)), sk({ col: skin.map(v => v * 0.72), spec: 0, rim: 0.05 }));   // the notch above it
    }
    {   // white shirt collar and a cream lazo bow tie
        const CRM = { col: [0.96, 0.93, 0.83], spec: 0.1, shin: 10, rim: 0.3 }, CR2 = { col: [0.88, 0.84, 0.72], spec: 0.05, shin: 8, rim: 0.2 };
        h3Draw(Mh.bcone || (Mh.bcone = mkFrustum(0.2, 1, 18)), m4.chain(U, m4.T(0, 15.8, 0.4), m4.S(2.7, 2.7, 2.4)), { col: [1.0, 0.98, 0.93], spec: 0.05, shin: 8, rim: 0.05 });
        const BZ = 3.0, BY = 15.7;
        for (const sx of [-1, 1]) {
            h3Draw(Mh.sphere, m4.chain(U, m4.T(sx * 1.75, BY + 0.1, BZ), m4.RZ(sx * -0.22), m4.S(1.55, 0.95, 0.55)), CRM);
            h3Draw(Mh.sphere, m4.chain(U, m4.T(sx * 1.55, BY + 0.1, BZ + 0.18), m4.RZ(sx * -0.22), m4.S(1.05, 0.55, 0.35)), CR2);
            h3Draw(Mh.rbox, m4.chain(U, m4.T(sx * 0.55, BY - 1.5, BZ - 0.05), m4.RZ(sx * 0.18), m4.S(0.55, 1.25, 0.2)), CRM);   // the two tails
        }
        h3Draw(Mh.sphere, m4.chain(U, m4.T(0, BY, BZ + 0.15), m4.S(0.62, 0.7, 0.55)), CR2);
    }
    // arms: shoulder -> elbow -> wrist by IK (skinned white sleeve that really bends), gold + leather cuffs on the forearm, wrist-flexing hand with curling fingers
    // collision shapes for the arms: thigh and shin capsules, the hat brim (a thin disc) and the crown (a tapering cylinder), all tested in root space
    const HTi = m4Inv(HT), mP = (M, p) => [M[0] * p[0] + M[4] * p[1] + M[8] * p[2] + M[12], M[1] * p[0] + M[5] * p[1] + M[9] * p[2] + M[13], M[2] * p[0] + M[6] * p[1] + M[10] * p[2] + M[14]], mD = (M, d) => [M[0] * d[0] + M[4] * d[1] + M[8] * d[2], M[1] * d[0] + M[5] * d[1] + M[9] * d[2], M[2] * d[0] + M[6] * d[1] + M[10] * d[2]];
    const capPush = (a, b, R, p, r) => {
        const ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], ap = [p[0] - a[0], p[1] - a[1], p[2] - a[2]], t = Math.max(0, Math.min(1, (ap[0] * ab[0] + ap[1] * ab[1] + ap[2] * ab[2]) / (ab[0] * ab[0] + ab[1] * ab[1] + ab[2] * ab[2] || 1)));
        const d = [ap[0] - ab[0] * t, ap[1] - ab[1] * t, ap[2] - ab[2] * t], L = Math.hypot(d[0], d[1], d[2]), need = R + r - L;
        if (need <= 0) return null; if (L < 1e-4) return [0, need, 0];
        return [d[0] / L * need, d[1] / L * need, d[2] / L * need];
    };
    const Ui = m4Inv(U);
    const crownR = y => y < 2.2 ? 6.4 : y < 5 ? 6.4 - (y - 2.2) * 0.21 : y < 7.6 ? 5.8 - (y - 5) * 0.27 : y < 9.2 ? 5.1 - (y - 7.6) * 0.56 : 4.2 - (y - 9.2) * 2;
    const collide = (p, r) => {
        let best = null; const take = v => { if (v && (!best || Math.hypot(v[0], v[1], v[2]) > Math.hypot(best[0], best[1], best[2]))) best = v; };
        for (const L of LEG) if (L) { take(capPush(L[0], L[1], 3.0, p, r)); take(capPush(L[1], L[2], 2.3, p, r)); }
        { const pl = mP(Ui, p), v = capPush([0, -1, 0], [0, 15, 0], 4.7, [pl[0], pl[1], pl[2] * 1.25], r); if (v) take(mD(U, [v[0], v[1], v[2] / 1.25])); }   // torso: an upright capsule, deeper than it is wide, so hands on the hips rest on the body instead of sinking into it
        const q = mP(HTi, p), rl = r / HAT, rr = Math.hypot(q[0], q[2]);
        if (rr < 14.7 + rl && Math.abs(q[1] - 0.27) < 0.65 + rl) take(mD(HT, [0, q[1] >= 0.27 ? 0.92 + rl - q[1] : -(q[1] - (-0.38 - rl)), 0]));   // brim: stay above or below it
        if (q[1] > 0.9 && q[1] < 9.9 + rl) { const rc = crownR(Math.min(q[1], 9.9)) + rl; if (rr < rc) { const dr = rc - rr, dy = 9.9 + rl - q[1]; take(mD(HT, dy < dr && q[1] > 7 ? [0, dy, 0] : (rr > 1e-3 ? [q[0] / rr * dr, 0, q[2] / rr * dr] : [dr, 0, 0]))); } }
        return best;
    };
    for (const sx of [-1, 1]) {
        const AGp = POSE.arms[sx < 0 ? 0 : 1], AG = AGp.ag > 0.5 ? AGp : null, wt = AGp.w.slice(); if (VQ.ill && sx > 0 && VQ.g !== 'dance') { const Qi = h3Dn(VQ.ill - 1), a1 = 0.45 * Qi.li, e1 = [4.8, 23, 1.6], e2 = [3.4, 19.5, 3.5]; for (let q = 0; q < 3; q++) { wt[q] += (e1[q] - wt[q]) * a1; wt[q] += (e2[q] - wt[q]) * Qi.tc; } } if (sx > 0 && VQ.joint != null) { const kw = Math.max(0, Math.min(1, (wt[1] - 7) / 5)); wt[0] -= H3HJ[0] * kw; wt[1] -= H3HJ[1] * kw; wt[2] -= H3HJ[2] * kw; { const rr = VQ.sm ? Math.min(1, VQ.sm.rise || 0) : 0; if (rr > 0.6 && H3MT.m && H3MT.t) { for (let q = 0; q < 2; q++) H3MF[q] = Math.max(-4, Math.min(4, H3MF[q] + (H3MT.m[q] - H3MT.t[q]) * 0.15)); } else { H3MF[0] *= 0.92; H3MF[1] *= 0.92; } wt[0] += H3MF[0] * kw; wt[1] += H3MF[1] * kw; } } else if (sx > 0) { H3HJ[0] = H3HJ[1] = H3HJ[2] = 0; }
        // collarbone: the shoulder lifts when the hand goes up and pushes forward when it reaches out
        const el0 = Math.max(-0.2, Math.min(0.52, (wt[1] - 14.9) * (wt[1] > 14.9 ? 0.03 : 0.012) + 0.015 * Math.sin(GT * 0.07) + B.sh + (sx < 0 ? B.shL : B.shR))), pr0 = Math.max(-0.2, Math.min(0.25, (wt[2] - 0.4) * 0.045)), th = -0.37 + el0;
        const sh = [sx * (1.6 + 4.72 * Math.cos(th)), 16.6 + 4.72 * Math.sin(th), 0.4 + pr0 * 3.2];
        if (!AG) { const dx = wt[0] - sh[0], dy = wt[1] - sh[1], dz = wt[2] - sh[2], D = Math.hypot(dx, dy, dz); if (D < 9.8) { const f = 9.8 / D; wt[0] = sh[0] + dx * f; wt[1] = sh[1] + dy * f; wt[2] = sh[2] + dz * f; } }   // never fold the elbow tighter than ~100 degrees
        let k = ik2(sh, wt, 6.6, 6.6, AGp.pl);
        {   // keep hand, forearm and elbow out of the legs and the hat: probe, nudge the wrist target, re-solve; the nudge is smoothed so it never pops
            const CP = H3CP[sx < 0 ? 0 : 1], w0 = wt.slice(), acc = [0, 0, 0];
            for (let it = 0; it < 3; it++) {
                const e = k.j, w = k.e, fl0 = Math.hypot(w[0] - e[0], w[1] - e[1], w[2] - e[2]) || 1, f = [(w[0] - e[0]) / fl0, (w[1] - e[1]) / fl0, (w[2] - e[2]) / fl0];
                const probes = [[w, 1.4, 1], [[w[0] + f[0] * 2.2, w[1] + f[1] * 2.2, w[2] + f[2] * 2.2], 1.1, 1], [[w[0] + f[0] * 3.9, w[1] + f[1] * 3.9, w[2] + f[2] * 3.9], 0.6, 1], [[(e[0] + w[0]) / 2, (e[1] + w[1]) / 2, (e[2] + w[2]) / 2], 1.6, 2], [e, 1.6, 1.5]];
                let best = null;
                for (const [p, r, wgt] of probes) { const v = collide(mP(U, p), r); if (v) { const vw = [v[0] * wgt, v[1] * wgt, v[2] * wgt]; if (!best || Math.hypot(vw[0], vw[1], vw[2]) > Math.hypot(best[0], best[1], best[2])) best = vw; } }
                if (!best) break;
                acc[0] += (U[0] * best[0] + U[1] * best[1] + U[2] * best[2]) * 0.8; acc[1] += (U[4] * best[0] + U[5] * best[1] + U[6] * best[2]) * 0.8; acc[2] += (U[8] * best[0] + U[9] * best[1] + U[10] * best[2]) * 0.8;
                wt[0] = w0[0] + acc[0]; wt[1] = w0[1] + acc[1]; wt[2] = w0[2] + acc[2]; k = ik2(sh, wt, 6.6, 6.6, AGp.pl);
            }
            const up = Math.hypot(acc[0], acc[1], acc[2]) > Math.hypot(CP[0], CP[1], CP[2]);
            for (let q = 0; q < 3; q++) { CP[q] += (acc[q] - CP[q]) * (up ? 0.6 : 0.2); wt[q] = w0[q] + CP[q]; }
            k = ik2(sh, wt, 6.6, 6.6, AGp.pl);
        }
        { const q0 = sx < 0 ? 0 : 9, a = mP(U, sh), b = mP(U, k.j), c = mP(U, k.e); for (let q = 0; q < 3; q++) { H3AS[q0 + q] = a[q]; H3AS[q0 + 3 + q] = b[q]; H3AS[q0 + 6 + q] = c[q]; } }
        const W = k.e, el = k.j, fl = Math.hypot(W[0] - el[0], W[1] - el[1], W[2] - el[2]) || 1, fa = [(W[0] - el[0]) / fl, (W[1] - el[1]) / fl, (W[2] - el[2]) / fl];
        const WS = H3WR[sx < 0 ? 0 : 1];   // automatic wrist: the hand drags behind the wrist's motion (spring), so every pose and gesture gets a loose, secondary-motion wrist
        if (WS.gt !== (nowMs / 8 | 0)) {
            const vx = WS.has ? W[0] - WS.x : 0, vy = WS.has ? W[1] - WS.y : 0, vz = WS.has ? W[2] - WS.z0 : 0, cl = (v, m) => Math.max(-m, Math.min(m, v));
            if (!WS.has || Math.hypot(vx, vy, vz) > 4) { WS.b = WS.z = WS.bv = WS.zv = 0; }
            else {
                const tb = cl(-0.55 * (-vx * fa[1] + vy * fa[0]), 0.7), tz = cl(-0.4 * vz, 0.45);
                WS.bv = WS.bv * 0.8 + (tb - WS.b) * 0.14; WS.b += WS.bv; WS.zv = WS.zv * 0.8 + (tz - WS.z) * 0.14; WS.z += WS.zv;
            }
            WS.x = W[0]; WS.y = W[1]; WS.z0 = W[2]; WS.has = 1; WS.gt = nowMs / 8 | 0;
        }
        const wbA = (AGp.wb || 0) + WS.b, wzA = (AGp.wz || 0) + WS.z;
        const flex = Math.sin(phase * 2 + (sx > 0 ? 0 : 1.7)) * AGp.fl, cf = Math.cos(flex), sf = Math.sin(flex), wbend = flex + wbA, cb = Math.cos(wbend), sb = Math.sin(wbend), hdir = [fa[0] * cb - fa[1] * sb, fa[0] * sb + fa[1] * cb, fa[2] + Math.sin(wzA)];   // wrist: bend in the screen plane (wb + the idle flex), tilt toward / away from the viewer (wz), twist about the hand axis (wt)
        { const hl = Math.hypot(hdir[0], hdir[1], hdir[2]) || 1; hdir[0] /= hl; hdir[1] /= hl; hdir[2] /= hl; }
        const at = q => [W[0] + fa[0] * q, W[1] + fa[1] * q, W[2] + fa[2] * q], hd = [W[0] + hdir[0] * 2.1, W[1] + hdir[1] * 2.1, W[2] + hdir[2] * 2.1];
        h3Skin(Mh.sleeve, U, m4.frame(sh, el, 1, [0, 0, 1]), m4.frame(el, W, 1, [0, 0, 1]), 0.2, { tex: h3Tex('sleeve', 256, 256, txSleeve), spec: 0.05, shin: 8, rim: 0.3, bulge: true });
        {   // collarbone / trapezius bridge: runs from the base of the neck down and out to the shoulder joint at the sleeve's own radius, and rises with the arm, so the shoulder is one continuous slope and the sleeve never hangs off the jacket
            const JK = { tex: h3Tex('yokeT', 256, 128, (w, h) => chWool(w, h, '#5e0816', '#8a1322', '#6f0c1a', 23)), spec: 0.05, shin: 8, rim: 0.22 };
            const nk = [sx * 3.0, 14.7, 0.1], md = [(nk[0] + sh[0]) / 2, (nk[1] + sh[1]) / 2, (nk[2] + sh[2]) / 2], dv = [sh[0] - nk[0], sh[1] - nk[1], sh[2] - nk[2]], hl = Math.hypot(dv[0], dv[1], dv[2]) / 2 * 1.12 || 1, uv = [dv[0] / (hl / 1.12 * 2) * hl, dv[1] / (hl / 1.12 * 2) * hl, dv[2] / (hl / 1.12 * 2) * hl];
            h3Draw(Mh.sphere, m4.chain(U, m4.seg(md, [md[0] + uv[0], md[1] + uv[1], md[2] + uv[2]], 1.5)), JK);   // a soft rounded pad (no straight edges), fading into the torso at one end and the sleeve at the other
        }
        h3Draw(Mh.sphere, m4.chain(U, m4.T(sh[0] + (el[0] - sh[0]) * 0.12, sh[1] + (el[1] - sh[1]) * 0.12, sh[2] + (el[2] - sh[2]) * 0.12), m4.S(1.62, 1.62, 1.62)), { col: [0.48, 0.06, 0.11], spec: 0.05, rim: 0.3 });
        h3Draw(Mh.sphere, m4.chain(U, m4.T(el[0], el[1], el[2]), m4.S(1.6, 1.6, 1.6)), { col: [0.5, 0.05, 0.1], spec: 0.05, rim: 0.3 });   // elbow cap hides the bend seam
        h3Draw(Mh.tube, m4.chain(U, m4.seg(at(-1.1), at(-0.2), 1.62)), { col: [0.95, 0.92, 0.84], spec: 0.05, shin: 8, rim: 0.2 });
        h3Draw(Mh.tube, m4.chain(U, m4.seg(at(-0.2), at(0.2), 1.5)), { col: [0.95, 0.92, 0.84], spec: 0.05, shin: 8, rim: 0.2 });   // the shirt cuff ends at the wrist, clear of the hand
        {   // slim wrist: a short tube out of the cuff, a small joint, and a segment along the hand's own direction into the palm
            const WS = sk({ col: [0.71, 0.47, 0.305], skin: 0 }), wj = at(0.4), pb = [wj[0] + hdir[0] * 0.9, wj[1] + hdir[1] * 0.9, wj[2] + hdir[2] * 0.9];
            h3Draw(Mh.tube, m4.chain(U, m4.seg(at(-0.5), wj, 0.8)), WS);
            h3Draw(Mh.sphere, m4.chain(U, m4.T(wj[0], wj[1], wj[2]), m4.S(0.8, 0.8, 0.8)), WS);
            h3Draw(Mh.tube, m4.chain(U, m4.seg(wj, pb, 0.8)), WS);
            h3Draw(Mh.sphere, m4.chain(U, m4.T(pb[0], pb[1], pb[2]), m4.S(0.95, 0.8, 0.6)), WS);
        }
        const ang = Math.atan2(-hdir[0], hdir[1]), nat0 = sx > 0 && (VQ.prop || VQ.joint != null), RM = (() => {   // 3D hand frame: fingers along the hand direction, palm turned the way a relaxed human arm turns it (hanging: palm in toward the thigh; level: palm down; raised: palm forward); prop poses keep the palm toward the viewer
            const nat = nat0 ? 0 : 1, e = fa[1], md = (p, q, k) => [p[0] + (q[0] - p[0]) * k, p[1] + (q[1] - p[1]) * k, p[2] + (q[2] - p[2]) * k];
            let n = e < 0 ? md([0, -1, 0], [-sx, -0.15, 0.1], Math.min(1, -e * 1.3)) : md([0, -1, 0], [-sx * 0.25, 0, 1], Math.min(1, e * 1.2));
            n = md([0, 0, 1], n, nat);
            if (sx > 0 && VQ.joint != null && VQ.sm && VQ.sm.rise > 0) { const rk0 = Math.min(1, VQ.sm.rise); n = md(n, [-0.7, 0.1, 0.7], rk0); }   // hand at the mouth: turned so the thumb-and-index pinch faces the face, as in a real drag
            const yz = hdir[2] * 0.45, yl = Math.hypot(hdir[0], hdir[1], yz) || 1, y = [hdir[0] / yl, hdir[1] / yl, yz / yl], pj = (v) => { const d = v[0] * y[0] + v[1] * y[1] + v[2] * y[2], r = [v[0] - d * y[0], v[1] - d * y[1], v[2] - d * y[2]], l = Math.hypot(r[0], r[1], r[2]); return [r, l]; };
            let [z, zl] = pj(n); if (zl < 0.25) [z, zl] = pj([0, 0, 1]); z = [z[0] / zl, z[1] / zl, z[2] / zl];
            const x = [y[1] * z[2] - y[2] * z[1], y[2] * z[0] - y[0] * z[2], y[0] * z[1] - y[1] * z[0]];
            return [x[0], x[1], x[2], 0, y[0], y[1], y[2], 0, z[0], z[1], z[2], 0, 0, 0, 0, 1];
        })(), HO = nat0 ? hd : [W[0] + RM[4] * 2.1, W[1] + RM[5] * 2.1, W[2] + RM[6] * 2.1], Hm = m4.chain(m4.T(HO[0], HO[1], HO[2]), RM, m4.RY((AGp.wt || 0) * (sx < 0 ? -1 : 1)), m4.S(0.8, 0.8, 0.8)), ptf = sx < 0 && VQ.sm ? Math.min(1, VQ.sm.pt || 0) : 0, bd = VQ.sm && sx === ((VQ.hf || 1) < 0 ? 1 : -1) ? Math.min(1, VQ.sm.bird || 0) : 0, curl = AGp.curl;
        let TIPI = null, TIPT = null, TIPM = null;
        {   // palm + thenar pad, then four independently curling three-joint fingers and a three-joint thumb
            const SKC = sk({ col: [0.71, 0.47, 0.305], skin: 0 }), FC = SKC, NAIL = { col: [0.84, 0.64, 0.57], spec: 0.55, shin: 40, rim: 0.2 };
            h3Draw(Mh.palm, m4.chain(U, Hm, m4.T(0, -2.4, 0.1), m4.S(1.95, 3.2, 0.5)), SKC);
            h3Draw(Mh.sphere, m4.chain(U, Hm, m4.T(-sx * 1.05, -1.3, 0.36), m4.RZ(sx * 0.3), m4.S(0.78, 1.3, 0.34)), SKC);
            h3Draw(Mh.sphere, m4.chain(U, Hm, m4.T(sx * 1.4, -1.05, 0.3), m4.RZ(-sx * 0.1), m4.S(0.5, 1.1, 0.3)), SKC);   // pads at the base of the thumb and the little finger
            const lq = (p, q, k) => p + (q - p) * k, cc = Math.max(0, Math.min(1.6, AGp.curl)), rel = 1 - Math.min(1, cc / 1.5), KF = [0.88, 1, 1.05, 1.12], LEN = [2.75, 3.05, 2.85, 2.25];
            const digit = (mesh, root, lens, ang, nail) => {
                const [l0, l1, l2] = lens, [a0, a1, a2] = ang, R = m4.chain(Hm, root);
                h3Draw(Mh.sphere, m4.chain(U, R, m4.S(mesh === Mh.thumb3 ? 0.66 : 0.5, 0.5, 0.5)), FC);
                const R1 = m4.chain(R, m4.RX(a0), m4.T(0, l0, 0), m4.RX(a1)), R2 = m4.chain(R1, m4.T(0, l1, 0), m4.RX(a2));
                h3Skin3(mesh, U, m4.chain(R, m4.RX(a0), m4.S(1, l0, 1)), m4.chain(R1, m4.S(1, l1, 1)), m4.chain(R2, m4.S(1, l2, 1)), 0.1, FC);
                h3Draw(Mh.sphere, m4.chain(U, R2, m4.T(0, l2 * 0.62, -0.4), m4.S(0.31, 0.36, 0.1)), NAIL);
                const q = l2 * 0.8; return [R2[4] * q + R2[12], R2[5] * q + R2[13], R2[6] * q + R2[14]];
            };
            // joint grip: only the index finger and thumb hold it; the other three stay loose and open, fanning slightly
            const jh = nat0 && VQ.joint != null, rkF = VQ.sm ? Math.min(1, Math.max(0, VQ.sm.rise || 0)) : 0;   // holding the joint: pinched between the thumb and a bent index finger, the other fingers loosely curled
            for (let i = 0; i < 4; i++) {
                const px = sx * (i - 1.5) * 0.98, fb = cc * KF[i] + (1 - Math.min(1, cc / 0.9)) * (0.1 + 0.05 * i) + 0.035 * Math.sin(nowMs * 0.0011 + i * 1.7 + sx) * (1 - Math.min(1, cc / 1.2)), ci = lq(i === 0 ? lq(fb, 0.05, ptf) : lq(fb, 1.6, ptf), i === 1 ? 0.05 : 1.6, bd), L = LEN[i];   // relaxed hands: gentle finger cascade (pinky curls most) and a little idle movement
                
                const tp = digit(Mh.finger3, m4.chain(m4.T(px, 0.6, 0.1), m4.RZ(-px * 0.07 * (jh ? 0 : rel))), [L * 0.4, L * 0.33, L * 0.27], jh ? (i === 0 ? [1.0, 1.2, 0.8] : [[1.0 * (1 - rkF), 1.15 * (1 - rkF), 0.8 * (1 - rkF)], [0.8, 1.0, 0.65], [0.95, 1.1, 0.72], [0.6, 0.85, 0.5]][i]) : [0.9 * ci, 0.95 * ci, 0.6 * ci]); if (i === 0) TIPI = tp; if (i === 1) TIPM = tp;
            }
            const ct = lq(lq(cc, 0.9, ptf), 0.9, bd);
            TIPT = digit(Mh.thumb3, m4.chain(m4.T(-sx * 1.45, -1.75, 0.34), m4.RZ(sx * 0.7)), [1.7, 1.15, 0.9], jh ? [-0.1 + 0.3 * (1 - rkF), 1.4 - 0.7 * (1 - rkF), 1.1 - 0.5 * (1 - rkF)] : [0.25 * ct, 0.55 * ct, 0.5 * ct]);
        }
        if (sx > 0 && VQ.prop) {   // stash props held in the right hand: a little baggie, a card, a rolled bill
            const pr = VQ.prop, ax = [0.93, 0.1, 0.2], c0 = [hd[0] + 0.1, hd[1] - 0.15, hd[2] + 0.55], P = k2 => [c0[0] + ax[0] * k2, c0[1] + ax[1] * k2, c0[2] + ax[2] * k2];
            if (pr === 'bag') { const b0 = P(1.0); h3Draw(Mh.sphere, m4.chain(U, m4.T(b0[0], b0[1] - 1.6, b0[2] + 0.6), m4.S(2.6, 3.4, 0.4)), { col: [0.8, 0.88, 0.94], spec: 0.8, shin: 40, rim: 0.4 }); h3Draw(Mh.sphere, m4.chain(U, m4.T(b0[0], b0[1] - 3.0, b0[2] + 0.95), m4.S(1.8, 1.5, 0.35)), { col: [0.98, 0.98, 0.97], spec: 0.1, rim: 0.2 }); h3Draw(Mh.tube, m4.chain(U, m4.seg([b0[0] - 2.4, b0[1] + 1.7, b0[2] + 0.7], [b0[0] + 2.4, b0[1] + 1.7, b0[2] + 0.7], 0.25)), { col: [0.25, 0.5, 0.9], spec: 0.3, rim: 0.2 }); }
            else if (pr === 'card') h3Draw(Mh.sphere, m4.chain(U, m4.T(P(1.2)[0], P(1.2)[1], P(1.2)[2]), m4.RZ(0.15), m4.S(1.9, 0.95, 0.12)), { col: [0.86, 0.86, 0.92], spec: 0.6, shin: 30, rim: 0.3 });
            else { h3Draw(Mh.tube, m4.chain(U, m4.seg(P(-0.6), P(2.8), 0.4)), { col: [0.36, 0.58, 0.36], spec: 0.2, shin: 12, rim: 0.2 }); h3Draw(Mh.tube, m4.chain(U, m4.seg(P(2.7), P(2.95), 0.36)), { col: [0.82, 0.9, 0.78], spec: 0.1, rim: 0.2 }); }
        }
        if (sx > 0 && VQ.joint != null) {   // a fat joint pinched between thumb and fingers: twisted mouth end, wide lit end with a live ember
            const jb = VQ.joint, c00 = [hd[0] + 0.1, hd[1] - 0.15, hd[2] + 0.55];
            let ax = [0.93, 0.1, 0.2], c0 = c00, rk = 0;
            if (TIPI && TIPT) {   // pinch point = between the thumb tip and the index tip; the joint runs across the fingers
                c0 = [(TIPI[0] + TIPT[0]) / 2, (TIPI[1] + TIPT[1]) / 2, (TIPI[2] + TIPT[2]) / 2];
                if (TIPM) { const rr = VQ.sm ? Math.min(1, Math.max(0, VQ.sm.rise || 0)) : 0, mm = [(TIPI[0] + TIPM[0]) / 2, (TIPI[1] + TIPM[1]) / 2, (TIPI[2] + TIPM[2]) / 2]; c0 = [mm[0] + (c0[0] - mm[0]) * rr, mm[1] + (c0[1] - mm[1]) * rr, mm[2] + (c0[2] - mm[2]) * rr]; }
                const xl = Math.hypot(RM[4], RM[5], RM[6]) || 1; ax = [-RM[4] / xl, -RM[5] / xl, -RM[6] / xl];   // at rest the joint stands up between the index and middle fingers, lit end up
                rk = VQ.sm ? Math.min(1, Math.max(0, VQ.sm.rise || 0)) : 0;   // hand up at the mouth: the twisted end goes between the lips and the lit end points out and forward, away from the face and the hand
                if (rk > 0) { const ao = [0.86, 0.2, 0.46]; ax = [ax[0] + (ao[0] - ax[0]) * rk, ax[1] + (ao[1] - ax[1]) * rk, ax[2] + (ao[2] - ax[2]) * rk]; const al = Math.hypot(ax[0], ax[1], ax[2]) || 1; ax = [ax[0] / al, ax[1] / al, ax[2] / al]; }
                for (let q = 0; q < 3; q++) H3HJ[q] += (c0[q] - c00[q] + (0.9 * (1 - rk) - 1.35 * rk) * ax[q] - H3HJ[q]) * 0.25;   // the joint is now shorter, so keep its mouth end where the old one reached
            }
            const P = k2 => [c0[0] + ax[0] * k2, c0[1] + ax[1] * k2, c0[2] + ax[2] * k2];
            const PAP = { col: [0.8, 0.77, 0.57], spec: 0.04, shin: 6, rim: 0.12 };   // a hand-rolled joint: tan-green paper, tapering from a twisted tip to a fatter lit end
            h3Draw(Mh.tube, m4.chain(U, m4.seg(P(-1.35), P(-1.05), 0.075)), { col: [0.68, 0.62, 0.46], spec: 0.02, shin: 4, rim: 0.1 });
            h3Draw(Mh.tube, m4.chain(U, m4.seg(P(-1.1), P(-0.2), 0.13)), PAP);
            h3Draw(Mh.tube, m4.chain(U, m4.seg(P(-0.25), P(0.7), 0.2)), PAP);
            h3Draw(Mh.tube, m4.chain(U, m4.seg(P(0.65), P(1.35), 0.27)), PAP);
            h3Draw(Mh.sphere, m4.chain(U, m4.T(P(1.38)[0], P(1.38)[1], P(1.38)[2]), m4.S(0.29, 0.29, 0.29)), { col: [0.32, 0.3, 0.28], spec: 0, rim: 0 });
            h3Draw(Mh.sphere, m4.chain(U, m4.T(P(1.5)[0], P(1.5)[1], P(1.5)[2]), m4.S(0.25, 0.25, 0.25)), { col: [1, 0.36, 0.08], spec: 0, rim: 0, glow: 0.7 + jb * 1.3 });
            { const t0 = P(-1.35); VQ.tipP = H3MT.t = [U[0] * t0[0] + U[4] * t0[1] + U[8] * t0[2] + U[12], U[1] * t0[0] + U[5] * t0[1] + U[9] * t0[2] + U[13]]; }
            const e = P(1.6); VQ.emberP = [U[0] * e[0] + U[4] * e[1] + U[8] * e[2] + U[12], U[1] * e[0] + U[5] * e[1] + U[9] * e[2] + U[13]];
        }
    }
    { const q = [0, -2.5, 4.6]; VQ.mouthP = H3MT.m = [HP[0] * q[0] + HP[4] * q[1] + HP[8] * q[2] + HP[12], HP[1] * q[0] + HP[5] * q[1] + HP[9] * q[2] + HP[13]]; if (!H3PIP && H3Last) H3Last.mp = VQ.mouthP; }
    // head: textured ellipsoid + hair cap + sideburns + ears + nose + earring
    H3.skinAmt = s >= 2.6 ? 1 : s >= 1.6 ? 0.5 : 0;
    const FD = s >= 2.2;   // close-up detail level: below this the face is only a few dozen pixels, so lashes, creases, pores, catchlights etc. are skipped (saves CPU, invisible anyway)
    const ex = { rig: true, mo: 0, mw: 0, brow: 0, bold: s < 1.0 ? 3 : s < 1.6 ? 2 : s < 2.6 ? 1 : 0 };
    const face = h3Tex('facer0_' + ex.bold, ex.bold ? 512 : 1024, ex.bold ? 512 : 1024, (w, h) => { ctx.fillStyle = '#a9714a'; ctx.fillRect(0, 0, w, h); ctx.setTransform(w / 14, 0, 0, h / 14, 7 * w / 14, 31 * h / 14); hvHead(ex, true); });
    skp = (col, o) => Object.assign({ col, tex: face, proj: 1, spec: 0.1, shin: 16, rim: 0.28, skin: 1 }, o);
    h3Draw(Mh.scalp, m4.chain(HP, m4.T(0, 2.1, -1.0)), { col: hair, spec: 0.5, shin: 30, rim: 0.35 });
    cmode(4);   // hair swings
    h3Draw(Mh.locks, HP, { col: [0.09, 0.055, 0.04], spec: 0.6, shin: 22, rim: 0.4 });
    h3Draw(Mh.locksDark, HP, { col: [0.045, 0.028, 0.022], spec: 0.5, shin: 20, rim: 0.3 });
    h3Draw(Mh.locksMid, HP, { col: [0.13, 0.075, 0.045], spec: 0.65, shin: 24, rim: 0.4 });
    h3Draw(Mh.locks2, HP, { col: [0.17, 0.1, 0.06], spec: 0.7, shin: 26, rim: 0.45 });   // under-layer: a warmer brown, so the hair reads in depth
    h3Draw(Mh.locksTop, HP, { col: [0.11, 0.065, 0.045], spec: 0.7, shin: 26, rim: 0.45 });
    h3Draw(Mh.fringe2, HP, { col: [0.075, 0.045, 0.032], spec: 0.35, shin: 18, rim: 0.12 });
    h3Draw(Mh.fringe, HP, { col: [0.09, 0.055, 0.04], spec: 0.6, shin: 24, rim: 0.4 });
    h3Draw(Mh.locksHi2, HP, { col: [0.5, 0.3, 0.15], spec: 0.85, shin: 32, rim: 0.55 });
    h3Draw(Mh.locksHi, HP, { col: [0.36, 0.21, 0.1], spec: 0.8, shin: 30, rim: 0.5 });   // sun-lit strands on top
    h3Draw(Mh.locksFront, HP, { col: [0.1, 0.06, 0.04], spec: 0.65, shin: 24, rim: 0.4 });   // locks framing the face, in front of the ears
    cmode(0);
    { const br = (sx) => { let px = sx * 5.9, py = 1.4, pz = -2.2; for (let k = 0; k < 11; k++) { const t = k / 10, nx = sx * (5.9 + 0.6 * t) + Math.sin(k * 1.4) * 0.35, ny = 1.4 - 10.5 * t, nz = -2.2 - 1.3 * t + Math.cos(k * 1.4) * 0.25; h3Draw(Mh.sphere, m4.chain(HP, m4.T(nx, ny, nz), m4.S(0.62 - 0.22 * t, 0.62, 0.55 - 0.18 * t)), { col: k % 2 ? [0.12, 0.07, 0.05] : [0.2, 0.12, 0.07], spec: 0.6, shin: 24, rim: 0.4 }); } };
      br(1);   // a braid down the viewer-right side with gold beads and a leather tie
      h3Draw(Mh.sphere, m4.chain(HP, m4.T(6.4, -4.2, -3.2), m4.S(0.5, 0.5, 0.5)), { col: gold, spec: 1, shin: 36, rim: 0.3 });
      h3Draw(Mh.sphere, m4.chain(HP, m4.T(6.5, -8.9, -3.4), m4.S(0.55, 0.55, 0.55)), { col: gold, spec: 1, shin: 36, rim: 0.3 });
      h3Draw(Mh.tube, m4.chain(HP, m4.T(6.5, -9.6, -3.4), m4.S(0.42, 0.7, 0.42)), { col: [0.55, 0.12, 0.1], spec: 0.3, shin: 16, rim: 0.2 }); }
    const headM = m4.chain(HP, m4.T(0, 6.4, 0), m4.S(1, 1 + 0.15 * jaw, 1), m4.T(0, -6.4, 0));
    const FDA = new Float32Array(80), FDB = new Float32Array(80); let FDN = 0;
    {   // face morph targets: every muscle the old add-on blobs stood for, now bending the skin itself
        const c = (v, a, b) => Math.max(a, Math.min(b, v)), push = (x, y, sg, dx, dy, dz) => { if (FDN >= 20 || Math.abs(dx) + Math.abs(dy) + Math.abs(dz) < 0.004) return; const i = FDN++ * 4; FDA[i] = x; FDA[i + 1] = y; FDA[i + 2] = Math.max(0.7, sg); FDB[i] = dx * 1.6; FDB[i + 1] = dy * 1.6; FDB[i + 2] = dz * 1.6; };
        const cLm = c(X.sm - 0.62 * X.sk, -0.9, 1.15), cRm = c(X.sm + 0.62 * X.sk, -0.9, 1.15), sqz = c(X.sq, 0, 1.2), nsz = c(X.ns, 0, 1), pf2 = c(X.pf, 0, 1), fr = c(-X.sm, 0, 1.2), chk = c(X.ch, 0, 1.2);
        const biA = X.bi + (X.biL + X.biR) / 2, boA = X.bo + (X.boL + X.boR) / 2, ten = c(0.7 * pf2 + 0.55 * c(-biA, 0, 1) + 0.35 * fr + 0.25 * nsz, 0, 1.3), wm = (1.55 + 0.62 * X.mw) * (1 - 0.5 * c(X.pu, 0, 1));
        for (const sx of [-1, 1]) {
            const cs = sx < 0 ? cLm : cRm, sm = c(cs, 0, 1.2), bi = X.bi + (sx < 0 ? X.biL : X.biR), bo = X.bo + (sx < 0 ? X.boL : X.boR);
            const ca = c(sm * 0.85 + sqz * 0.3, 0, 1.2), q = c(sqz * 0.85 + sm * 0.55, 0, 1.3), nl = c(0.1 + 0.7 * sm + 0.55 * nsz + 0.25 * X.mo, 0, 1.4), dn = c(-bi, 0, 1.2), up = c(bo, 0, 1.2);
            push(sx * 3.3, -0.9 + 0.8 * ca, 1.15, sx * 0.06 * ca, 0.34 * ca, 0.26 * ca);   // zygomaticus + malar fat pad: the cheek climbs and swells
            push(sx * 3.6, -1.4, 1.4, sx * 0.1 * chk, 0, 0.32 * chk);   // cheek puff
            push(sx * 2.2, -1.7, 0.7, -sx * 0.06 * nl, -0.04 * nl, -0.13 * nl);   // nasolabial crease
            push(sx * (wm + 0.7), -2.5 + cs * 0.85, 0.75, sx * 0.1 * (sm - c(-cs, 0, 1) * 0.6), 0.18 * cs, 0.12 * Math.abs(cs));   // skin bunching beside the mouth corner
            push(sx * 2.6, 0.25, 0.75, 0, 0.1 * q, 0.14 * q);   // lower-lid pad pushed up by the squint
            push(sx * 4.5, 1.7, 0.8, sx * 0.05 * q, 0, -0.07 * q);   // crow's feet
            push(sx * 2.4, 4.3, 1.1, 0, -0.1 * dn, 0.09 * dn);   // brow ridge pressed down
            push(sx * 2.4, 4.8, 1.3, 0, 0.12 * up, 0.07 * up);   // frontalis lifts the brow arch
            push(sx * 4.2, -2.4, 1.0, 0, 0, 0.12 * ten);   // masseter clench
        }
        push(0, 3.95, 0.8, 0, -0.08 * c(-biA, 0, 1), 0.12 * c(-biA, 0, 1));   // glabella bunching
        push(0, 5.6, 1.7, 0, 0.1 * c(boA, 0, 1.2), 0.08 * c(boA, 0, 1.2));   // forehead lifts and bulges
        push(0, -4.35, 1.0, 0, 0.2 * c(pf2 * 0.8 + fr * 0.8 + 0.3 * c(X.bi, 0, 1), 0, 1.3), 0.14 * c(pf2 * 0.8 + fr * 0.8 + 0.3 * c(X.bi, 0, 1), 0, 1.3));   // mentalis: chin boss pushes up
    }
    const fdz = (x, y) => { let z = 0; for (let i = 0; i < FDN; i++) { const dx = x - FDA[i * 4], dy = y - FDA[i * 4 + 1], sg = FDA[i * 4 + 2]; z += FDB[i * 4 + 2] * Math.exp(-(dx * dx + dy * dy) / (2 * sg * sg)); } return z; };   // how far the morph has pushed the skin out at (x, y): everything that sits on the face follows it
    h3Draw(Mh.head, headM, { tex: face, spec: 0.12, shin: 18, rim: 0.3, skin: 1, fd: FDN ? [FDA.subarray(0, FDN * 4), FDB.subarray(0, FDN * 4)] : null });
    if (s >= 0.9) h3Draw(Mh.stubble, headM, { col: [0.17, 0.1, 0.065], spec: 0.05, shin: 8, rim: 0.12 });   // 3D stubble
    {
        const hs2 = 1 + 0.15 * jaw, fy = y => 6.4 + (y - 6.4) * hs2, zA = (x, y) => h3Zs(x, 6.4 + (y - 6.4) / hs2) + fdz(x, 6.4 + (y - 6.4) / hs2), cl = (v, a, b) => Math.max(a, Math.min(b, v));
        const eyeT = h3Tex('eye', 1024, 512, txEye), lidT = h3Tex('lid', 8, 64, txLid), cL = cl(X.sm - 0.62 * X.sk, -0.9, 1.15), cR = cl(X.sm + 0.62 * X.sk, -0.9, 1.15);
        // eyes: tracking balls, expression-driven lids (opening, squint, slant from the brows) and per-side brows built from two angled pieces
        for (const sx of [-1, 1]) {
            const Ls = sx < 0, lidv = cl(X.lid + (Ls ? X.lidL : X.lidR), -0.25, 1.1) * 0.86, upOpen = -0.12 - 1.24 * lidv, upA = upOpen + (0.46 - upOpen) * blink;
            const bo = X.bo + (Ls ? X.boL : X.boR), bi = X.bi + (Ls ? X.biL : X.biR), cheek = cl((Ls ? cL : cR), 0, 1) * 0.22;
            const loA = -0.62 + 0.32 * cl(X.sq, 0, 1.2) + cheek + (0.5 - 0.5 * cl(X.sq, 0, 1) - cheek) * blink * 0.55;
            const ec = m4.chain(HP, m4.T(sx * 2.4, fy(1.7), 4.78)), es = (1 + 0.12 * X.ew) * 1.02, slant = sx * -bi * 0.22 + sx * X.sq * 0.04;
            const gx = H3F.gx * (1 - X.fix) + X.gx * 0.6, gy = H3F.gy * (1 - X.fix) + X.gy * 0.35;
            const bm = m4.chain(ec, m4.RY(gx), m4.RX(-gy), m4.S(0.84 * es, 0.8 * es, 0.8 * es)), pd = cl(0.82 + 0.34 * X.ew + 0.12 * cl(X.sq, 0, 1) * 0 - 0.1 * blink, 0.55, 1.4);
            h3Draw(Mh.eye, bm, { tex: eyeT, spec: 0.5, shin: 60, rim: 0.05, lidSh: [fy(1.7) - 0.924 * es * Math.sin(upA), 0.22] });
            h3Draw(Mh.pupil, m4.chain(bm, m4.S(pd, pd, 1)), { col: [0.012, 0.008, 0.006], spec: 0.8, shin: 90, rim: 0 });   // dilating pupil
            for (const [cdx, cdy, ctw, gl2] of FD ? [[-0.3, 0.36, 1, 1.5], [0.32, -0.3, 0.5, 0.8]] : [[-0.3, 0.36, 1.3, 1.5]]) {   // window catchlights on the cornea (follow the gaze partly)
                const dx = cdx + 0.35 * Math.sin(gx), dy = cdy + 0.35 * Math.sin(gy), dz = Math.sqrt(Math.max(0.05, 1 - dx * dx - dy * dy)), sp = Mh.eyeSurf(dx, dy, dz);
                h3Draw(Mh.sphere, m4.chain(ec, m4.T(sp[0] * 0.84 * es, sp[1] * 0.8 * es, sp[2] * 0.8 * es), m4.S(0.13 * ctw + 0.03, 0.09 * ctw + 0.03, 0.04)), { col: [1, 0.98, 0.94], spec: 0, rim: 0, glow: gl2 });
            }
            if (FD) h3Draw(Mh.sphere, m4.chain(ec, m4.T(-sx * 1.13, -0.12, 0.42), m4.S(0.2, 0.17, 0.2)), { col: [0.8, 0.42, 0.38], spec: 0.55, shin: 30, rim: 0.1 });   // caruncle (tear duct)
            const lu = m4.chain(ec, m4.RZ(slant), m4.S(0.86 * es, 0.84 * es, 0.84 * es), m4.RX(upA)), ll = m4.chain(ec, m4.RZ(slant * 0.4), m4.S(0.86 * es, 0.84 * es, 0.84 * es), m4.RX(-loA), m4.S(1, -1, 1));
            const luM = m4.chain(ec, m4.RZ(slant), m4.S(0.86 * es * sx, 0.84 * es, 0.84 * es), m4.RX(upA)), llM = m4.chain(ec, m4.RZ(slant * 0.4), m4.S(0.86 * es * sx, 0.84 * es, 0.84 * es), m4.RX(-loA), m4.S(1, -1, 1));
            h3Draw(Mh.lid, lu, skp([0.66, 0.44, 0.29], { spec: 0.12, shin: 16, rim: 0.2 }));
            h3Draw(Mh.lid, ll, skp([0.66, 0.44, 0.29], { spec: 0.12, shin: 16, rim: 0.2 }));
            const rimC = { col: [0.44, 0.25, 0.17], spec: 0.2, shin: 20, rim: 0.05 }, wetC = { col: [0.86, 0.6, 0.56], spec: 0.9, shin: 70, rim: 0 }, lashC = { col: [0.17, 0.1, 0.07], spec: 0.35, shin: 26, rim: 0.1 };
            h3Draw(Mh.lidRim, lu, rimC); h3Draw(Mh.lidRim, ll, rimC);
            if (FD) { h3Draw(Mh.waterline, lu, wetC); h3Draw(Mh.waterline, ll, wetC); h3Draw(Mh.crease, lu, { col: skin.map(v => v * 0.55), spec: 0, rim: 0.05 }); h3Draw(Mh.lashU, luM, lashC); h3Draw(Mh.lashL, llM, lashC); }
            const yi = 3.05 + 1.15 * bi + 0.2 * bo, yo = 3.35 + 0.75 * bo, xi = sx * (1.5 - 0.25 * cl(-bi, 0, 1)), xo = sx * 3.2, arch = 0.3 + 0.12 * cl(bo - bi, 0, 1) + 0.1 * cl(-bi, 0, 1);
            h3Ribbon(15, 10, u => {   // one tapered, arched brow: blunt inner end, thick body, thin tail that sweeps down
                const x = xi + (xo - xi) * u, y = yi + (yo - yi) * u + arch * Math.sin(Math.PI * Math.pow(u, 0.85)) - 0.32 * u * u * u, tp = Math.pow(Math.max(0, 1 - Math.pow(u, 1.7)), 0.7) * Math.min(1, 0.55 + 4 * u);
                return [x, fy(y), zA(x, fy(y)) - 0.01 + 0.04 * Math.sin(Math.PI * u), 0.06 + 0.38 * tp, 0.07 + 0.28 * tp];
            }, HP, { col: hair, spec: 0.35, shin: 24, rim: 0.2 });
        }
        // mouth: five lip pieces along a curve whose corners lift/drop independently, dark interior, teeth, tongue, pucker, press
        const w = (1.55 + 0.62 * X.mw) * (1 - 0.5 * cl(X.pu, 0, 1)), gap = Math.max(-0.12, 1.75 * X.mo - 0.18 * X.pf + (X.mo > 0.05 ? 0.26 * cl(X.tt, 0, 1) : 0)), yU = fy(-2.5) + 0.1 * X.sm, pu = cl(X.pu, 0, 1), pf = cl(X.pf, 0, 1);
        const cy = x => (x < 0 ? cL : cR) * 0.85 * Math.pow(Math.abs(x) / w, 2), lowY = x => (yU - gap) + (cy(x) + gap) * Math.pow(Math.abs(x) / w, 2);
        const lipU = [0.55, 0.24, 0.2], lipL = [0.7, 0.31, 0.26], inner = [0.13, 0.03, 0.03], teeth = [0.95, 0.92, 0.84], tong = [0.78, 0.3, 0.31];
        const zM = (x, y) => zA(x, y) + 0.04 + 0.35 * pu;
        if (gap <= 0.1 && X.tt > 0.3) {
            const th = cl(gap > 0.1 ? 0.22 + gap * 0.3 : 0.5, 0.2, 0.75) * (0.7 + 0.3 * cl(X.tt, 0, 1));
            h3Draw(Mh.box, m4.chain(HP, m4.T(0, yU - 0.2 - th / 2 + (gap > 0.1 ? 0 : -0.1), zA(0, yU - 0.5) - 0.02), m4.S(w * 1.5, th, 0.34)), { col: teeth, spec: 0.3, shin: 24, rim: 0.1 });
            if (gap > 0.9 && X.tt > 0.25) h3Draw(Mh.box, m4.chain(HP, m4.T(0, yU - gap + 0.3, zA(0, yU - gap) - 0.03), m4.S(w * 1.4, 0.4, 0.3)), { col: teeth, spec: 0.3, shin: 24, rim: 0.1 });
            if (gap <= 0.1) h3Draw(Mh.box, m4.chain(HP, m4.T(0, yU - 0.28, zA(0, yU) + 0.08), m4.S(w * 1.5, 0.05, 0.3)), { col: [0.35, 0.22, 0.18], spec: 0, rim: 0 });
            if (FD && gap > 0.1) {
                const yc = yU - 0.2 - th / 2, zt = x => zA(x, yU - 0.5) - 0.02 - 0.1 * Math.pow(x / (w * 0.8), 2);
                h3Draw(Mh.sphere, m4.chain(HP, m4.T(0, yU - 0.08, zA(0, yU - 0.3) - 0.1), m4.S(w * 0.93, 0.2, 0.3)), { col: [0.78, 0.36, 0.38], spec: 0.35, shin: 30, rim: 0.1 });
                for (let k = 0; k < 8; k++) {
                    const u = (k - 3.5) / 3.5, x = u * w * 0.72, c = Math.abs(u) < 0.2, tw = w * 1.5 / 8 * (c ? 1.15 : 0.92 - 0.1 * Math.abs(u)), tint = 0.93 + 0.05 * Math.sin(k * 2.3);
                    h3Draw(Mh.sphere, m4.chain(HP, m4.T(x, yc - (c ? 0 : 0.04 * Math.abs(u)), zt(x) + 0.14), m4.RZ(u * 0.08), m4.S(tw * 0.5, th * (c ? 0.55 : 0.5), 0.2)), { col: [0.97 * tint, 0.95 * tint, 0.88 * tint], spec: 0.55, shin: 40, rim: 0.12 });
                }
            }
        }
        const tg = cl(X.tg, 0, 1);
        if (tg > 0.15) h3Draw(Mh.sphere, m4.chain(HP, m4.T(0, yU - gap + 0.1 - 0.5 * tg, zA(0, yU - gap) + 1.1 * tg), m4.RX(0.35 * tg), m4.S(0.82, 0.3, 0.55 + 0.75 * tg)), { col: tong, spec: 0.3, shin: 20, rim: 0.15 });
        else if (gap > 0.5) { h3Draw(Mh.sphere, m4.chain(HP, m4.T(0, yU - gap * 0.8, zA(0, yU - gap) - 0.05), m4.S(w * 0.55, 0.28 + gap * 0.08, 0.35)), { col: tong, spec: 0.5, shin: 30, rim: 0.15 });
            if (FD) { h3Draw(Mh.sphere, m4.chain(HP, m4.T(0, yU - gap * 0.8 + 0.06, zA(0, yU - gap) + 0.08), m4.S(0.04, 0.05, w * 0.42)), { col: [0.5, 0.15, 0.17], spec: 0, rim: 0 }); h3Draw(Mh.sphere, m4.chain(HP, m4.T(0, yU - gap * 0.9, zA(0, yU - gap) - 0.3), m4.S(w * 0.6, 0.22 + gap * 0.07, 0.2)), { col: [0.5, 0.16, 0.19], spec: 0.1, rim: 0 }); } }
        const lipTp = s => Math.pow(Math.max(0, 1 - Math.pow(Math.abs(s), 3)), 0.8), kw = 1 - 0.18 * cl(X.mw, 0, 1.2);
        const hUf = s => (0.34 + 0.06 * pu) * (1 - 0.4 * pf) * lipTp(s) * kw + 0.004, hLf = s => (0.42 + 0.05 * pu) * (1 - 0.35 * pf) * lipTp(s) * (1 + 0.2 * (1 - s * s)) * kw + 0.004;
        const lipUc = (x, s) => yU + cy(x) + 0.12, lipLc = (x, s) => lowY(x) - 0.1 - 0.05 * (1 - s * s);
        if (gap > 0.1) {   // the open mouth is a lens between the two lips' inner edges: dark interior, then curved rows of teeth that follow the smile
            const opn = s => { const x = s * w, Ui = lipUc(x, s) - 0.78 * hUf(s), Li = lipLc(x, s) + 0.78 * hLf(s); return { x, Ui, Li, h: Math.max(0, (Ui - Li) / 2) + 0.1 * cl(X.tt, 0, 1) * lipTp(s) }; };
            h3Ribbon(27, 8, u => { const s = u * 2 - 1, o = opn(s), yc = (o.Ui + o.Li) / 2; return [o.x, yc, zM(o.x, yc) - 0.1, o.h + 0.03, 0.2]; }, HP, { col: inner, spec: 0.05, shin: 8, rim: 0 });
            const tt = cl(X.tt, 0, 1);
            if (gap > 0.2 || tt > 0.3) {
                const SR = 0.8, thU = s => Math.min(opn(s).h * 1.9, 0.52) * (0.75 + 0.25 * tt) * Math.pow(Math.max(0, 1 - Math.pow(Math.abs(s) / SR, 4)), 0.5);
                h3Ribbon(25, 8, u => { const s = (u * 2 - 1) * SR, o = opn(s), th = thU(s), yc = o.Ui - th / 2 + 0.02; return [o.x, yc, zM(o.x, yc) - 0.05 - 0.14 * s * s, th / 2 + 0.004, 0.17]; }, HP, { col: teeth, spec: 0.5, shin: 36, rim: 0.12 });
                if (FD) for (let k = -4; k <= 4; k++) { const s = k / 4 * SR * 0.92, o = opn(s), th = thU(s); if (th < 0.06) continue; const yc = o.Ui - th / 2 + 0.02; h3Draw(Mh.sphere, m4.chain(HP, m4.T(o.x, yc, zM(o.x, yc) - 0.05 - 0.14 * s * s + 0.14), m4.S(0.013, th * 0.46, 0.04)), { col: [0.5, 0.45, 0.4], spec: 0, rim: 0 }); }
                if (gap > 0.9 && tt > 0.25) { const SL = 0.66, thL = s => Math.min(opn(s).h * 1.1, 0.3) * Math.pow(Math.max(0, 1 - Math.pow(Math.abs(s) / SL, 4)), 0.5); h3Ribbon(21, 8, u => { const s = (u * 2 - 1) * SL, o = opn(s), th = thL(s), yc = o.Li + th / 2 - 0.02; return [o.x, yc, zM(o.x, yc) - 0.08 - 0.12 * s * s, th / 2 + 0.004, 0.15]; }, HP, { col: teeth, spec: 0.5, shin: 36, rim: 0.12 }); }
            }
        }
        h3Ribbon(27, 12, u => {   // upper lip: one band with a cupid's bow, tapering into the corners
            const s = u * 2 - 1, x = s * w, tp = lipTp(s), bow = 0.11 * Math.exp(-Math.pow((Math.abs(s) - 0.3) / 0.16, 2)) - 0.07 * Math.exp(-s * s / 0.012), y = yU + cy(x) + 0.12 + bow * (1 - 0.5 * pf);
            return [x, y, zM(x, y), hUf(s), (0.42 + 0.1 * pu) * (0.05 + 0.95 * tp)];
        }, HP, { col: lipU, spec: 0.3, shin: 20, rim: 0.2 });
        h3Ribbon(27, 12, u => {   // lower lip: fuller, with a soft centre
            const s = u * 2 - 1, x = s * w, tp = lipTp(s), y = lowY(x) - 0.1 - 0.05 * (1 - s * s);
            return [x, y, zM(x, y), hLf(s), (0.44 + 0.1 * pu) * (0.05 + 0.95 * tp)];
        }, HP, { col: lipL, spec: 0.35, shin: 22, rim: 0.2 });
        if (FD) {   // lip detail: wet highlight, lip border, lip lines, corner shadows, shadow under lip
            h3Ribbon(21, 8, u => { const s = u * 2 - 1, x = s * w * 0.78, tp = lipTp(s * 0.78), y = lowY(x) - 0.08 - 0.05 * (1 - s * s); return [x, y + 0.04, zM(x, y) + 0.1 * pu + 0.14, 0.07 * tp + 0.01, 0.08 * tp + 0.02]; }, HP, { col: [0.86, 0.5, 0.45], spec: 0.95, shin: 70, rim: 0.05 });
            for (let k = 0; k < 9; k++) { const u = (k - 4) / 4.4, x = u * w * 0.62, yl = lowY(x) - 0.12; h3Draw(Mh.sphere, m4.chain(HP, m4.T(x, yl, zM(x, yl) + 0.17), m4.S(0.012 + 0.006 * (k % 2), 0.15, 0.04)), { col: [0.4, 0.17, 0.15], spec: 0, rim: 0 }); }
            for (const sx of [-1, 1]) { const x = sx * (w + 0.05), y = yU + cy(w) * 0.9 + 0.05; h3Draw(Mh.sphere, m4.chain(HP, m4.T(x, y, zA(x, y) + 0.08), m4.S(0.2, 0.16, 0.14)), { col: [0.22, 0.09, 0.07], spec: 0, rim: 0 }); }
            h3Draw(Mh.sphere, m4.chain(HP, m4.T(0, lowY(0) - 0.62, zM(0, lowY(0)) - 0.1), m4.S(1.05, 0.14, 0.3)), { col: [0.4, 0.22, 0.15], spec: 0, rim: 0 });
        }
        if (gap <= 0.1) h3Ribbon(21, 6, u => {   // closed-mouth seam following the curve between the lips
            const s = u * 2 - 1, x = s * w * 0.98, tp = lipTp(s), y = (yU + cy(x) + lowY(x)) / 2 + 0.01;
            return [x, y, zM(x, y) + 0.3 * Math.sqrt(tp), 0.045 * tp + 0.01, 0.05 * tp + 0.01];
        }, HP, { col: [0.3, 0.11, 0.1], spec: 0, rim: 0 });
        {   // mustache + philtrum on the upper lip
            const hc = [0.13, 0.08, 0.055];
            h3Draw(Mh.sphere, m4.chain(HP, m4.T(0, yU + 0.5, zA(0, yU + 0.5) - 0.02), m4.S(0.5, 0.55, 0.3)), skp([0.6, 0.39, 0.26], { spec: 0.08, shin: 12, rim: 0.2 }));
            for (const sx of [-1, 1]) {
                const c2 = cl(sx < 0 ? cL : cR, -0.5, 1.2);
                h3Ribbon(17, 10, u => {   // one tapered, drooping mustache wing per side (thick at the nose, fine at the tip)
                    const x = sx * (0.06 + u * (w + 0.25)), yl = yU + cy(Math.min(Math.abs(x), w) * Math.sign(x)) * 0.4 + 0.82 + (0.28 * Math.max(0, c2) + 0.2 * cl(X.nf, 0, 1)) * u * u - 0.1 * Math.sin(u * 3) - 0.18 * u * u, tp = Math.pow(Math.max(0, 1 - Math.pow(u, 2.6)), 0.8);
                    return [x, yl + 0.1, zA(x, yl) + 0.03 + 0.02 * (1 - u), 0.04 + 0.27 * tp, 0.05 + 0.24 * tp];
                }, HP, { col: hc, spec: 0.12, shin: 14, rim: 0.12 });
            }
        }
        {   // skin detail as real geometry: under-eye creases, smile (nasolabial) folds, the scarred cheek with its stitches
            const crease = skin.map(v => v * 0.5), faint = skin.map(v => v * 0.68), sqz = cl(X.sq, 0, 1);
            if (FD) for (const sx of [-1, 1]) {
                const cs = cl(sx < 0 ? cL : cR, -0.3, 1.2), x0 = sx * 2.4;
                h3Ribbon(11, 6, u => { const x = x0 + (u - 0.5) * 2.2, y = 0.6 + 0.15 * sqz - 0.25 * Math.sin(Math.PI * u), e = Math.sin(Math.PI * u); return [x, fy(y), zA(x, fy(y)) - 0.01, 0.03 + 0.03 * sqz * e, 0.05 * e + 0.01]; }, HP, { col: crease, spec: 0, rim: 0.05 });
                h3Ribbon(11, 6, u => { const x = x0 + (u - 0.5) * 2.4, y = 0.05 + 0.12 * sqz - 0.28 * Math.sin(Math.PI * u), e = Math.sin(Math.PI * u); return [x, fy(y), zA(x, fy(y)) - 0.01, 0.025 + 0.02 * sqz * e, 0.04 * e + 0.01]; }, HP, { col: faint, spec: 0, rim: 0.05 });
                const ex1 = sx * (w + 1.15), ey1 = yU + cy(w) * 0.9 - 0.25, f = 0.05 + 0.09 * cl(cs, 0, 1.2);
                h3Ribbon(13, 6, u => { const a = (1 - u) * (1 - u), b = 2 * u * (1 - u), c = u * u, x = a * sx * 2.5 + b * sx * (3.1 + 0.4 * cs) + c * ex1, y = a * fy(-0.9) + b * fy(-2.0) + c * ey1, e = Math.sin(Math.PI * Math.min(1, u * 1.1)); return [x, y, zA(x, y) + 0.0, f * e + 0.01, f * 0.8 * e + 0.01]; }, HP, { col: faint, spec: 0, rim: 0.05 });
            }
            const sc = [0.74, 0.4, 0.31], P0 = [3.2, 0.7], P1 = [4.2, -1.1];   // scar on the viewer-right cheek
            h3Ribbon(9, 8, u => { const x = P0[0] + (P1[0] - P0[0]) * u, y = fy(P0[1] + (P1[1] - P0[1]) * u), e = Math.sin(Math.PI * u); return [x, y, zA(x, y) + 0.03, 0.07 + 0.15 * Math.pow(e, 0.6), 0.06 + 0.12 * Math.pow(e, 0.6)]; }, HP, { col: sc, spec: 0.25, shin: 18, rim: 0.2 });
            if (FD) for (let k = 0; k < 4; k++) {   // stitches across it
                const t = 0.16 + 0.23 * k, cx = P0[0] + (P1[0] - P0[0]) * t, cy2 = P0[1] + (P1[1] - P0[1]) * t;
                h3Ribbon(3, 6, u => { const x = cx + (u - 0.5) * 0.52 * 0.874, y = fy(cy2 + (u - 0.5) * 0.52 * 0.486), e = Math.sin(Math.PI * u); return [x, y, zA(x, y) + 0.1, 0.025 + 0.02 * e, 0.04 + 0.04 * e]; }, HP, { col: [0.9, 0.82, 0.72], spec: 0.15, shin: 14, rim: 0.1 });
            }
        }
        if (false) for (const sx of [-1, 1]) h3Draw(Mh.sphere, m4.chain(HP, m4.T(sx * 3.1, fy(-1.9), zA(sx * 3.1, -1.9) - 0.55), m4.S(0.9 + 0.55 * X.ch, 0.95 + 0.5 * X.ch, 0.55 + 0.5 * X.ch)), skp([0.68, 0.45, 0.3]));
        // ---- facial muscles: skin volumes that bunch, stretch and crease with the expression (cheek lift, eye ring, brow knit, forehead lines, nasolabial + marionette folds, masseter, chin) ----
        {
            const lit = MUS_LIT, shd = MUS_SHD, mid = MUS_MID, MS = MUS_MS;
            const vol = (x, y, rx, ry, pr, rot, col, ry2) => { return; pr *= 0.3; rx *= 1.25; ry *= 1.25; const rz = Math.max(0.35, pr * 2.4); h3Draw(Mh.sphere, m4.chain(HP, m4.T(x, fy(y), zA(x, y) + pr - rz), m4.RY(ry2 || 0), m4.RZ(rot || 0), m4.S(rx, ry, rz)), skp(col, MS)); };   // pr = how far the swell stands proud of the skin
            const fold = (ax, ay, bx, by, th, col, dz) => { const mx = (ax + bx) / 2, my = (ay + by) / 2, L = Math.hypot(bx - ax, by - ay) / 2 + th, a = Math.atan2(by - ay, bx - ax); h3Draw(Mh.sphere, m4.chain(HP, m4.T(mx, fy(my), zA(mx, my) - 0.06), m4.RZ(a), m4.S(L, th, th * 1.6)), skp(col, MS)); };
            const fr = cl(-X.sm, 0, 1.2), pf2 = cl(X.pf, 0, 1), sqz = cl(X.sq, 0, 1.2), nsz = cl(X.ns, 0, 1), biA = (X.bi + (X.biL + X.biR) / 2), boA = (X.bo + (X.boL + X.boR) / 2);
            const ten = cl(0.7 * pf2 + 0.55 * cl(-biA, 0, 1) + 0.35 * fr + (X.tt > 0.5 && X.mo < 0.35 ? 0.4 : 0) + 0.25 * nsz, 0, 1.3);
            for (const sx of [-1, 1]) {
                const Ls = sx < 0, sm = cl(Ls ? cL : cR, 0, 1.2), bi = X.bi + (Ls ? X.biL : X.biR), bo = X.bo + (Ls ? X.boL : X.boR), cs = Ls ? cL : cR;
                // zygomaticus + malar fat pad: the cheek mound climbs toward the eye and swells on a smile
                const ca = cl(sm * 0.85 + sqz * 0.3 - 0.4, 0, 1.2); if (ca > 0.1) vol(sx * (3.1 + 0.15 * sm), -0.7 + 0.8 * ca, 1.0, 0.7 + 0.18 * ca, 0.2 * ca, 0, mid);
                // orbicularis oculi: the lower-lid ring pushes up when the eye squints; crow's feet fan out from the corner
                const q = cl(sqz * 0.85 + sm * 0.55 - 0.1, 0, 1.3);
                if (q > 0.1) vol(sx * 2.5, 0.8, 1.5, 0.32 + 0.22 * q, 0.16 * q, sx * -0.08, mid);
                if (q > 0.4) { const c = cl((q - 0.4) * 1.4, 0, 1); for (const dy of [0.35, 0, -0.35]) fold(sx * 3.95, 1.75 + dy * 0.7, sx * 4.85, 1.75 + dy * 2.0, 0.03 + 0.035 * c, shd); }
                // nasolabial fold (levator labii + zygomaticus pull) from the nose wing to the mouth corner, deeper with smiles, sneers and open mouths
                const cornY = yU + cs * 0.85, nl = cl(0.15 + 0.7 * sm + 0.55 * nsz + 0.25 * X.mo, 0, 1.4);
                fold(sx * 1.55, -0.95, sx * (2.35 + 0.25 * sm), -1.95, 0.03 + 0.05 * nl, shd); fold(sx * (2.35 + 0.25 * sm), -1.95, sx * (w + 0.75), cornY + 0.9, 0.03 + 0.05 * nl, shd);
                // depressor anguli oris: marionette line and a dragged-down corner on frowns
                if (fr > 0.12) fold(sx * (w + 0.3), cornY - 0.1, sx * (w + 0.05), cornY - 1.5 - 0.5 * fr, 0.03 + 0.07 * fr, shd);
                // masseter: a clenched jaw bulges at the hinge
                if (ten > 0.15) vol(sx * 3.75, -2.7, 0.6, 1.1, 0.1 * ten, sx * -0.12, mid);
                // brow depressors: a heavy supraorbital shelf and the knitted inner corner when the brow comes down
                const dn = cl(-bi, 0, 1.2); if (dn > 0.12) { vol(sx * 2.35, 4.3 - 0.2 * dn, 2.3, 0.45 + 0.25 * dn, 0.2 * dn, sx * -0.12 * dn, mid); fold(sx * 0.55, 3.7, sx * (0.35 + 0.1 * dn), 5.2, 0.04 + 0.05 * dn, shd); }
                // frontalis: brows lifting bulge the brow arch
                const up = cl(bo, 0, 1.2); if (up > 0.18) vol(sx * 2.4, 4.8 + 0.5 * up, 2.3, 0.32 + 0.2 * up, 0.16 * up, sx * 0.1, lit);
                // inner-brow raise (grief): the oblique crease above the inner corner
                const gr = cl(bi, 0, 1.2); if (gr > 0.3) fold(sx * 0.7, 4.7 + 0.5 * gr, sx * 1.6, 5.1 + 0.8 * gr, 0.035 + 0.04 * gr, shd);
                // levator: nose-bridge wrinkles on a sneer
                if (nsz > 0.25) fold(sx * 0.25, 2.1, sx * 0.9, 2.8 + 0.3 * nsz, 0.03 + 0.04 * nsz, shd);
            }
            if (cl(boA, 0, 1.2) > 0.2) for (const [y, k] of [[5.55, 1], [6.1, 0.8]]) fold(-2.8, y + 0.3 * boA, 2.8, y + 0.3 * boA, 0.03 + 0.03 * cl(boA, 0, 1), shd);   // forehead lines
            if (cl(-biA, 0, 1) > 0.25) vol(0, 3.95, 0.9, 0.6, 0.2 * cl(-biA, 0, 1), 0, lit);   // procerus / glabella bunching between the brows
            // mentalis: the chin boss pushes up and puckers on a frown, a hard press or a sob
            const mt = cl(pf2 * 0.8 + fr * 0.8 + 0.3 * cl(X.bi, 0, 1), 0, 1.3); if (mt > 0.12) vol(0, -4.35 + 0.25 * mt, 1.3 + 0.25 * mt, 0.45 + 0.25 * mt, 0.12 * mt, 0, mid);
            // orbicularis oris: the lip ring bulges around a pressed mouth
            if (pf2 > 0.25) vol(0, yU - 0.35, w * 1.05, 0.16 + 0.08 * pf2, 0.12 * pf2, 0, mid);
        }
        ex.nose = { s: 1 + 0.1 * X.nf, y: -0.12 * cl(X.ns, 0, 1) };
    }
    for (const sx of [-1, 1]) {
        h3Draw(Mh.ear, m4.chain(HP, m4.T(sx * 5.5, 0.4 - 0.9 * jaw, -0.3), m4.RY(sx * 0.35), m4.RZ(-sx * 0.12), m4.S(sx, 1, 1)), sk({ col: [0.6, 0.39, 0.25] }));
        h3Draw(Mh.box, m4.chain(HP, m4.T(sx * 5.0, 1.6 - 0.72 * jaw, 1.5), m4.RY(sx * -0.5), m4.S(0.8, 3.4, 1.4)), { col: hair, spec: 0.4, shin: 26, rim: 0.3 });
    }
    const noseM = m4.chain(HP, m4.T(0, 0.35 * X.ns - 1.1 * jaw, 0.1 * X.ns), m4.S(1 + 0.1 * X.nf + 0.06 * X.ns, 1 - 0.1 * X.ns, 1));
    h3Draw(Mh.nose, noseM, { tex: face, spec: 0.12, shin: 18, rim: 0.3, skin: 1 });
    for (const sx of [-1, 1]) {   // nostrils: recessed dark openings under the tip, widening with flare
        const nx = sx * (0.52 + 0.07 * X.nf), ny = -1.02, nz = h3Zs(nx, ny) + h3NoseH(nx, ny) - 0.02;
        h3Draw(Mh.sphere, m4.chain(noseM, m4.T(nx, ny, nz), m4.RZ(sx * -0.35), m4.RX(-0.5), m4.S(0.22 + 0.06 * X.nf, 0.12 + 0.04 * X.nf, 0.15)), { col: [0.13, 0.055, 0.04], spec: 0.04, shin: 8, rim: 0 });
        if (FD) h3Ribbon(9, 6, u => { const a = u * 1.0, x = sx * (1.08 + 0.12 * Math.sin(a * 2.4) - 0.06 * a * a), y = 0.15 - 1.15 * u; return [x, y, h3Zs(x, y) + h3NoseH(x, y) + 0.0, 0.03 * Math.sin(Math.PI * u) + 0.012, 0.035 * Math.sin(Math.PI * u) + 0.01]; }, noseM, { col: [0.5, 0.31, 0.2], spec: 0, rim: 0.05 });   // alar groove
    }
    h3Draw(Mh.sphere, m4.chain(HP, m4.T(5.65, -1.2 - 1.14 * jaw, -0.2), m4.S(0.62, 0.62, 0.62)), { col: gold, spec: 1.0, shin: 34, rim: 0.3 });
    // sombrero (tilts with the body)
    const rb = hs.rainbow;
    const brimC = cssRgb(hcol.brim), crownC = cssRgb(hcol.crown), bandC = cssRgb(hcol.band);
    const bt = rb ? null : h3Tex('brimf' + eq, 256, 128, txStraw(hcol.brim, hcol.trim)), ct = rb ? null : h3Tex('crownf' + eq, 256, 128, txCrown(hcol.crown, hcol.trim)), nt = rb ? null : h3Tex('band' + eq, 256, 64, txBand(hcol.band, hcol.trim));
    cmode(3); h3Draw(Mh.brim, HT, rb ? { col: brimC, spec: 0.1, shin: 10, rim: 0.3 } : { tex: bt, spec: 0.1, shin: 10, rim: 0.3 });
    cmode(0); h3Draw(Mh.crown, HT, rb ? { col: crownC, spec: 0.12, shin: 10, rim: 0.3 } : { tex: ct, spec: 0.12, shin: 10, rim: 0.3 });
    h3Draw(Mh.band, HT, rb ? { col: bandC, spec: 0.2, shin: 16, rim: 0.3 } : { tex: nt, spec: 0.2, shin: 16, rim: 0.3 });
    const tr = cssRgb(hcol.trim === undefined ? '#ffd32a' : hcol.trim);
    h3Draw(Mh.hatStuds, HT, { col: tr, spec: 0.95, shin: 34, rim: 0.3 });
    if (useFbo) h3Post(sw, shh, pw, ph);
    // blit into the 2D game
    ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y); ctx.scale(s * facing, s);
    ctx.drawImage(H3.cv, 0, H3.ch - ph, pw, ph, -28, -48, 56, 78);
    ctx.restore();
}

// if the 3D hero alone eats a whole 60 fps frame on this device, quietly fall back to the 2D hero
let h3N = 0, h3Ema = 0;
function h3Watch(ms) {
    if (++h3N <= 40) return;   // skip shader compile / first texture uploads
    h3Ema = h3Ema ? h3Ema * 0.95 + ms * 0.05 : ms;
    if (h3N > 160 && h3Ema > 16) { if (!H3.lo && H3.post) { H3.lo = true; h3N = 0; h3Ema = 0; } else { H3.ok = false; h3N = 0; } }
}