
// =====================================================================
//  RENDERING - helpers
// =====================================================================
function btn(x, y, w, h, label, fn, color = '#ff5e62', sub, fs = 17) {
    uiButtons.push({ x, y, w, h, fn });
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    roundRect(x, y + 3, w, h, 12); ctx.fill();
    const gr = ctx.createLinearGradient(0, y, 0, y + h);
    gr.addColorStop(0, shade(color, 0.22)); gr.addColorStop(1, color);
    ctx.fillStyle = gr;
    roundRect(x, y, w, h, 12); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.14)';
    roundRect(x + 2, y + 2, w - 4, h / 2 - 2, 10); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = 'bold ' + fs + 'px system-ui, sans-serif';
    ctx.fillText(label, x + w / 2, y + h / 2 + (sub ? -6 : 0), w - 10);
    if (sub) { ctx.font = '11px system-ui, sans-serif'; ctx.fillText(sub, x + w / 2, y + h / 2 + 11); }
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
}
function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
}
function wrapText(text, x, y, maxW, lh) {
    const words = String(text).split(' ');
    let line = '';
    for (const w of words) {
        const test = line ? line + ' ' + w : w;
        if (ctx.measureText(test).width > maxW && line) { ctx.fillText(line, x, y); line = w; y += lh; }
        else line = test;
    }
    if (line) { ctx.fillText(line, x, y); y += lh; }
    return y;
}
function hexA(h, a) { const c = hexToRgb(h); return `rgba(${c[0]},${c[1]},${c[2]},${a})`; }
function outlineText(txt, x, y, fill, stroke = 'rgba(0,0,0,0.55)', lw = 4) {
    ctx.lineJoin = 'round'; ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.strokeText(txt, x, y);
    ctx.fillStyle = fill; ctx.fillText(txt, x, y);
}
function glowSprite(col) {
    if (!/^#[0-9a-f]{6}$/i.test(col)) col = '#ffffff';
    let c = glowCache.get(col);
    if (!c) {
        c = document.createElement('canvas'); c.width = c.height = 64;
        const x = c.getContext('2d');
        const gr = x.createRadialGradient(32, 32, 0, 32, 32, 32);
        gr.addColorStop(0, col + 'ff'); gr.addColorStop(0.35, col + '66'); gr.addColorStop(1, col + '00');
        x.fillStyle = gr; x.fillRect(0, 0, 64, 64);
        glowCache.set(col, c);
    }
    return c;
}
let glowLeft = 0;
function drawGlow(x, y, r, col, a = 1) {
    if (!OPT.glow || OPT.gfx < 2 || glowLeft <= 0) return;
    glowLeft--;
    const prev = ctx.globalCompositeOperation, pa = ctx.globalAlpha;
    ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = pa * a;
    ctx.drawImage(glowSprite(col), x - r, y - r, r * 2, r * 2);
    ctx.globalCompositeOperation = prev; ctx.globalAlpha = pa;
}

// ---------- sky, parallax, weather ----------
function skyColors(f) {
    const i = biomeIdx(f), a = BIOMES[i], n = BIOMES[i + 1];
    if (!n) return a;
    const k = clamp((f - (n.at - 600)) / 600, 0, 1);
    if (k <= 0) return a;
    const s = k * k * (3 - 2 * k);
    return { top: lerpColor(a.top, n.top, s), mid: lerpColor(a.mid, n.mid, s), bot: lerpColor(a.bot, n.bot, s) };
}
function drawMesaLayer(yb, scale, col, rim) {
    ctx.fillStyle = col;
    for (const m of mesas) {
        const w = m.w * scale, h = m.h * scale;
        ctx.beginPath(); ctx.moveTo(m.x * scale, yb); ctx.lineTo(m.x * scale + 9, yb - h); ctx.lineTo(m.x * scale + w - 9, yb - h); ctx.lineTo(m.x * scale + w, yb); ctx.closePath(); ctx.fill();
    }
    ctx.fillStyle = rim;
    for (const m of mesas) { const w = m.w * scale, h = m.h * scale; ctx.fillRect(m.x * scale + 9, yb - h, w - 18, 2.5); }
}
function drawCactus(x, y, h, col) {
    ctx.fillStyle = col;
    roundRect(x - 3, y - h, 6, h, 3); ctx.fill();
    roundRect(x - 10, y - h * 0.62, 5, h * 0.3, 2.5); ctx.fill(); roundRect(x - 10, y - h * 0.4, 9, 4, 2); ctx.fill();
    roundRect(x + 5, y - h * 0.75, 5, h * 0.32, 2.5); ctx.fill(); roundRect(x + 1, y - h * 0.46, 9, 4, 2); ctx.fill();
}
let skyGrad = null, skyGradKey = '', skyGradCtx = null;
function drawSky(f) {
    const q = OPT.gfx, c = skyColors(f);
    const skyKey = c.top + c.mid + c.bot;
    if (skyKey !== skyGradKey || skyGradCtx !== ctx) { skyGradKey = skyKey; skyGradCtx = ctx; skyGrad = ctx.createLinearGradient(0, 0, 0, H); skyGrad.addColorStop(0, c.top); skyGrad.addColorStop(0.62, c.mid); skyGrad.addColorStop(1, c.bot); }
    ctx.fillStyle = skyGrad; ctx.fillRect(0, 0, W, H);
    const dark = clamp((f - 9000) / 7000, 0, 1);
    if (dark > 0.05) {
        for (const s of starsBg) {
            const a = (q >= 1 ? 0.45 + 0.55 * Math.abs(Math.sin(menuT * 0.03 * s.s + s.x)) : 1) * dark;
            ctx.fillStyle = `rgba(255,255,255,${a.toFixed(2)})`; ctx.fillRect(s.x, s.y, s.s, s.s);
        }
    }
    if (q >= 2 && f > 14000) {
        const na = clamp((f - 14000) / 5000, 0, 1) * 0.32;
        for (const b of [[80, 160, 190, '#7d3cff'], [290, 330, 210, '#ff3ca8'], [150, 520, 180, '#18c8ff']]) {
            const yy = b[1] + Math.sin(menuT * 0.006 + b[0]) * 12;
            const gr = ctx.createRadialGradient(b[0], yy, 0, b[0], yy, b[2]);
            gr.addColorStop(0, hexA(b[3], na)); gr.addColorStop(1, hexA(b[3], 0));
            ctx.fillStyle = gr; ctx.fillRect(b[0] - b[2], yy - b[2], b[2] * 2, b[2] * 2);
        }
    }
    // sun
    const sa = 1 - clamp((f - 2500) / 6500, 0, 1);
    if (sa > 0.02 && q >= 1) {
        const sx = W * 0.72, sy = 380 + f * 0.05;
        if (q >= 3) {
            ctx.save(); ctx.translate(sx, sy); ctx.rotate(menuT * 0.002);
            ctx.fillStyle = `rgba(255,240,190,${0.09 * sa})`;
            for (let k = 0; k < 12; k++) { ctx.rotate(TAU / 12); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(500, -22); ctx.lineTo(500, 22); ctx.closePath(); ctx.fill(); }
            ctx.restore();
        }
        const gr = ctx.createRadialGradient(sx, sy, 4, sx, sy, 130);
        gr.addColorStop(0, `rgba(255,240,190,${0.9 * sa})`); gr.addColorStop(0.3, `rgba(255,210,130,${0.35 * sa})`); gr.addColorStop(1, 'rgba(255,200,120,0)');
        ctx.fillStyle = gr; ctx.fillRect(sx - 130, sy - 130, 260, 260);
        ctx.fillStyle = `rgba(255,250,220,${sa})`; ctx.beginPath(); ctx.arc(sx, sy, 26, 0, TAU); ctx.fill();
    }
    // shooting stars
    for (const s of shooters) {
        const a = s.t / 26;
        ctx.strokeStyle = `rgba(255,255,255,${a})`; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x - s.vx * 5, s.y - s.vy * 5); ctx.stroke();
    }
    // desert scenery that falls away as you climb
    if (q >= 1 && f < 7000) {
        const fade = 1 - clamp(f / 6500, 0, 1);
        const yb1 = H - 70 + f * 0.25;
        drawMesaLayer(yb1, 1, hexA('#a25a6a', 0.9 * fade), hexA('#d88a7a', 0.9 * fade));
        const yb2 = H - 26 + f * 0.5;
        ctx.fillStyle = hexA('#5a2d48', fade); ctx.fillRect(0, yb2, W, H + 400);
        if (q >= 2) for (const cc of cacti) drawCactus(cc.x, yb2 + 2, cc.h, hexA('#3a1d36', fade));
    }
    // clouds
    const ca = 1 - clamp((f - 14000) / 5000, 0, 1);
    if (ca > 0.02) {
        for (const cl of clouds) {
            const al = (0.25 + 0.5 * (1 - dark)) * (0.4 + 0.6 * cl.z) * ca;
            if (cloudSprite && q >= 1) {
                ctx.globalAlpha = al; ctx.drawImage(cloudSprite, cl.x - cl.w / 2, cl.y - cl.w * 0.22, cl.w, cl.w * 0.4375); ctx.globalAlpha = 1;
            } else {
                ctx.fillStyle = `rgba(255,255,255,${(al * 0.8).toFixed(2)})`;
                ctx.beginPath();
                ctx.ellipse(cl.x, cl.y, cl.w * 0.4, cl.w * 0.14, 0, 0, TAU);
                ctx.ellipse(cl.x - cl.w * 0.18, cl.y + 3, cl.w * 0.24, cl.w * 0.11, 0, 0, TAU);
                ctx.ellipse(cl.x + cl.w * 0.2, cl.y + 2, cl.w * 0.22, cl.w * 0.12, 0, 0, TAU);
                ctx.fill();
            }
        }
    }
    // birds drifting across the lower sky
    if (q >= 2 && f < 9000) {
        const fa = 1 - clamp((f - 3500) / 5000, 0, 1);
        ctx.strokeStyle = `rgba(40,30,50,${0.7 * fa})`; ctx.lineWidth = 1.2; ctx.lineCap = 'round';
        for (let i = 0; i < 6; i++) {
            const bx = ((i * 83 + menuT * (0.7 + (i % 3) * 0.2)) % (W + 80)) - 40, by = 90 + (i % 3) * 70 + Math.sin(menuT * 0.03 + i) * 10, fl = Math.sin(menuT * 0.25 + i * 2) * 3.5;
            ctx.beginPath(); ctx.moveTo(bx - 6, by - fl); ctx.quadraticCurveTo(bx - 3, by - fl - 2, bx, by); ctx.quadraticCurveTo(bx + 3, by - fl - 2, bx + 6, by - fl); ctx.stroke();
        }
    }
    // storm lightning
    if (lightning.t > 0 && q >= 2) {
        const a = lightning.t / 14;
        if (!OPT.calm) { ctx.fillStyle = `rgba(220,230,255,${0.28 * a})`; ctx.fillRect(0, 0, W, H); }
        ctx.strokeStyle = `rgba(255,255,255,${a})`; ctx.lineWidth = 2.2; ctx.lineJoin = 'round';
        ctx.beginPath(); lightning.pts.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.stroke();
    }
    // floating embers / dust motes
}

// ---------- sombreros, mustaches ----------
function hatCol(st) {
    if (st.rainbow) { const h = (menuT * 3) % 360; return { brim: `hsl(${h},70%,45%)`, crown: `hsl(${(h + 40) % 360},80%,65%)`, band: `hsl(${(h + 180) % 360},80%,50%)`, trim: '#ffffff' }; }
    return st;
}
function lg(x0, y0, x1, y1, stops) {
    if (OPT.gfx < 1) return stops[0][1];
    const gr = ctx.createLinearGradient(x0, y0, x1, y1);
    for (const s of stops) gr.addColorStop(s[0], s[1]);
    return gr;
}
function rg(x0, y0, r0, x1, y1, r1, stops) {
    if (OPT.gfx < 1) return stops[0][1];
    const gr = ctx.createRadialGradient(x0, y0, r0, x1, y1, r1);
    for (const s of stops) gr.addColorStop(s[0], s[1]);
    return gr;
}
function conchoDot(x, y, r) {   // little silver/gold stud with a highlight
    ctx.fillStyle = '#b8860b'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.fillStyle = '#ffe066'; ctx.beginPath(); ctx.arc(x - r * 0.15, y - r * 0.15, r * 0.7, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.arc(x - r * 0.35, y - r * 0.4, r * 0.22, 0, TAU); ctx.fill();
}
function drawSombrero(x, y, s, tilt, idx) {
    const st0 = HAT_STYLES[idx % HAT_STYLES.length];
    if (st0.rainbow || s > 30 || s < 3) { drawSombreroRaw(x, y, s, tilt, idx); return; }
    const SR = Math.min(RES, 4), sb = Math.round(s * 2) / 2, hi = idx % HAT_STYLES.length;
    const e = cachedDraw(hatCache, hi + '|' + sb + '|' + SR + '|' + OPT.gfx, sb * 1.25, sb * 1.05, sb * 2.5, sb * 1.6, SR, () => drawSombreroRaw(0, 0, sb, 0, hi));
    ctx.save(); ctx.translate(x, y); if (tilt) ctx.rotate(tilt);
    ctx.drawImage(e.cv, -e.ox, -e.oy, e.w, e.h);
    ctx.restore();
}
function drawSombreroRaw(x, y, s, tilt, idx) {
    const st = hatCol(HAT_STYLES[idx % HAT_STYLES.length]), q = OPT.gfx;
    const det = q >= 1 && s > 9, big = q >= 1 && s > 17;
    ctx.save(); ctx.translate(x, y); ctx.rotate(tilt);
    const ry = s * 0.27, ch = s * 0.68, cw = s * 0.44;
    // soft shadow under the brim
    ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.beginPath(); ctx.ellipse(0, ry * 0.55, s * 1.03, ry * 1.05, 0, 0, TAU); ctx.fill();
    // brim base + upturned rim (lighter back edge, darker front underside)
    ctx.fillStyle = st.brim; ctx.beginPath(); ctx.ellipse(0, 0, s, ry, 0, 0, TAU); ctx.fill();
    if (det) {
        ctx.fillStyle = lg(0, -ry, 0, ry, [[0, 'rgba(255,255,255,0.28)'], [0.5, 'rgba(255,255,255,0)'], [1, 'rgba(0,0,0,0.32)']]);
        ctx.beginPath(); ctx.ellipse(0, 0, s, ry, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = lg(-s, 0, s, 0, [[0, 'rgba(0,0,0,0.3)'], [0.3, 'rgba(255,255,255,0.12)'], [0.7, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,0.34)']]);
        ctx.beginPath(); ctx.ellipse(0, 0, s, ry, 0, 0, TAU); ctx.fill();
        // woven straw rings
        ctx.strokeStyle = 'rgba(0,0,0,0.12)'; ctx.lineWidth = Math.max(0.3, s * 0.018);
        for (let k = 0.55; k < 0.95; k += 0.1) { ctx.beginPath(); ctx.ellipse(0, 0, s * k, ry * k, 0, 0, TAU); ctx.stroke(); }
        // embroidered trim: dashed thread + inner band ring
        ctx.strokeStyle = st.trim; ctx.lineWidth = Math.max(0.5, s * 0.045); ctx.setLineDash([s * 0.12, s * 0.09]);
        ctx.beginPath(); ctx.ellipse(0, 0, s * 0.91, ry * 0.9, 0, 0, TAU); ctx.stroke();
        ctx.setLineDash([]);
        ctx.strokeStyle = st.band; ctx.lineWidth = Math.max(0.5, s * 0.05);
        ctx.beginPath(); ctx.ellipse(0, 0, s * 0.74, ry * 0.74, 0, 0.1, Math.PI - 0.1); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.lineWidth = Math.max(0.5, s * 0.04);
    ctx.beginPath(); ctx.ellipse(0, 0, s, ry, 0, 0, TAU); ctx.stroke();
    if (det) {   // rim catch-light
        ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = Math.max(0.4, s * 0.03);
        ctx.beginPath(); ctx.ellipse(0, 0, s * 0.985, ry * 0.97, 0, Math.PI * 1.05, Math.PI * 1.7); ctx.stroke();
    }
    if (big) for (let k = 0; k < 9; k++) { const a = 0.3 + (Math.PI - 0.6) * k / 8; conchoDot(Math.cos(a) * s * 0.91, Math.sin(a) * ry * 0.9, Math.max(0.6, s * 0.036)); }
    else { ctx.fillStyle = st.trim; for (let k = 0; k < 6; k++) { const a = 0.3 + (Math.PI - 0.6) * k / 5; ctx.beginPath(); ctx.arc(Math.cos(a) * s * 0.88, Math.sin(a) * ry * 0.8, Math.max(0.5, s * 0.035), 0, TAU); ctx.fill(); } }
    // crown (pinched, with a dent at the top)
    const crown = () => {
        ctx.beginPath(); ctx.moveTo(-cw, -ry * 0.1); ctx.lineTo(-cw * 0.8, -ch * 0.82);
        ctx.quadraticCurveTo(-cw * 0.45, -ch * 1.12, -cw * 0.08, -ch * 1.02);
        ctx.quadraticCurveTo(0, -ch * 0.96, cw * 0.08, -ch * 1.02);
        ctx.quadraticCurveTo(cw * 0.45, -ch * 1.12, cw * 0.8, -ch * 0.82);
        ctx.lineTo(cw, -ry * 0.1); ctx.quadraticCurveTo(0, ry * 0.5, -cw, -ry * 0.1); ctx.closePath();
    };
    ctx.fillStyle = st.crown; crown(); ctx.fill();
    if (det) {
        ctx.fillStyle = lg(-cw, 0, cw, 0, [[0, 'rgba(0,0,0,0.32)'], [0.32, 'rgba(255,255,255,0.22)'], [0.62, 'rgba(255,255,255,0)'], [1, 'rgba(0,0,0,0.3)']]);
        crown(); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.2)'; ctx.lineWidth = Math.max(0.3, s * 0.025);   // pinch creases
        ctx.beginPath(); ctx.moveTo(-cw * 0.3, -ch * 0.98); ctx.quadraticCurveTo(-cw * 0.25, -ch * 0.6, -cw * 0.42, -ch * 0.2);
        ctx.moveTo(cw * 0.3, -ch * 0.98); ctx.quadraticCurveTo(cw * 0.25, -ch * 0.6, cw * 0.42, -ch * 0.2); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = Math.max(0.4, s * 0.03);
        ctx.beginPath(); ctx.moveTo(-cw * 0.62, -ch * 0.75); ctx.quadraticCurveTo(-cw * 0.4, -ch * 1.0, -cw * 0.12, -ch * 0.97); ctx.stroke();
    }
    // band with braided cord + conchos
    ctx.fillStyle = st.band;
    ctx.beginPath(); ctx.moveTo(-cw * 0.97, -ch * 0.18); ctx.lineTo(-cw * 0.9, -ch * 0.46); ctx.quadraticCurveTo(0, -ch * 0.36, cw * 0.9, -ch * 0.46); ctx.lineTo(cw * 0.97, -ch * 0.18); ctx.quadraticCurveTo(0, ry * 0.2, -cw * 0.97, -ch * 0.18); ctx.fill();
    if (det) {
        ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.beginPath(); ctx.moveTo(-cw * 0.97, -ch * 0.18); ctx.quadraticCurveTo(0, ry * 0.2, cw * 0.97, -ch * 0.18); ctx.lineTo(cw * 0.95, -ch * 0.25); ctx.quadraticCurveTo(0, ry * 0.1, -cw * 0.95, -ch * 0.25); ctx.fill();
        ctx.strokeStyle = st.trim; ctx.lineWidth = Math.max(0.3, s * 0.02);
        for (let k = -6; k <= 6; k++) { const bx = k * cw * 0.15, by = -ch * 0.33 + Math.abs(k) * ch * 0.005; ctx.beginPath(); ctx.moveTo(bx - cw * 0.05, by - ch * 0.07); ctx.lineTo(bx + cw * 0.05, by + ch * 0.07); ctx.stroke(); }
    }
    if (big) for (let k = -2; k <= 2; k++) conchoDot(k * cw * 0.36, -ch * 0.28 + Math.abs(k) * 0.02 * s, Math.max(0.7, s * 0.055));
    else { ctx.fillStyle = st.trim; for (let k = -2; k <= 2; k++) { ctx.beginPath(); ctx.arc(k * cw * 0.34, -ch * 0.27 + Math.abs(k) * 0.02 * s, Math.max(0.5, s * 0.03), 0, TAU); ctx.fill(); } }
    if (big) { ctx.fillStyle = st.trim; ctx.beginPath(); ctx.arc(0, -ch * 1.03, s * 0.05, 0, TAU); ctx.fill(); }   // crown button
    ctx.restore();
}
function drawStache(x, y, w) {
    // handlebar mustache: two thick lobes that sweep out and curl up at the tips
    const lw = Math.max(0.5, w * 0.16);
    ctx.save();
    ctx.fillStyle = '#2b1810';
    ctx.beginPath();
    ctx.moveTo(x, y - w * 0.2);
    ctx.bezierCurveTo(x + w * 0.35, y - w * 0.42, x + w * 0.8, y - w * 0.12, x + w * 1.0, y - w * 0.52);
    ctx.bezierCurveTo(x + w * 1.12, y - w * 0.1, x + w * 0.8, y + w * 0.34, x + w * 0.3, y + w * 0.3);
    ctx.bezierCurveTo(x + w * 0.1, y + w * 0.28, x, y + w * 0.16, x, y + w * 0.14);
    ctx.bezierCurveTo(x, y + w * 0.16, x - w * 0.1, y + w * 0.28, x - w * 0.3, y + w * 0.3);
    ctx.bezierCurveTo(x - w * 0.8, y + w * 0.34, x - w * 1.12, y - w * 0.1, x - w * 1.0, y - w * 0.52);
    ctx.bezierCurveTo(x - w * 0.8, y - w * 0.12, x - w * 0.35, y - w * 0.42, x, y - w * 0.2);
    ctx.fill();
    if (w > 3.5 && OPT.gfx >= 1) {   // hair strands + shine
        ctx.strokeStyle = '#6b4630'; ctx.lineWidth = Math.max(0.3, lw * 0.4); ctx.lineCap = 'round';
        for (const sx of [-1, 1]) for (let k = 0; k < 3; k++) {
            ctx.beginPath(); ctx.moveTo(x + sx * w * 0.08, y - w * 0.05 + k * w * 0.1);
            ctx.quadraticCurveTo(x + sx * w * 0.5, y - w * 0.22 + k * w * 0.1, x + sx * w * (0.85 - k * 0.04), y - w * 0.3 + k * w * 0.1); ctx.stroke();
        }
        ctx.strokeStyle = 'rgba(255,255,255,0.25)';
        ctx.beginPath(); ctx.moveTo(x - w * 0.6, y - w * 0.2); ctx.quadraticCurveTo(x - w * 0.3, y - w * 0.32, x - w * 0.05, y - w * 0.2); ctx.stroke();
    }
    ctx.restore();
}

// ---------- the vaquero ----------
function drawBoot(x, y, leather, dir) {   // front-view cowboy boot, toe splayed outward (dir = -1 left, +1 right)
    ctx.save(); ctx.translate(x, y); ctx.scale(dir, 1);
    const dk = shade(leather, -0.4), lt = shade(leather, 0.25);
    // shaft
    ctx.fillStyle = lg(-2.6, 0, 2.6, 0, [[0, dk], [0.4, lt], [1, dk]]);
    ctx.beginPath(); ctx.moveTo(-2.4, 0); ctx.lineTo(2.4, 0); ctx.lineTo(2.7, 3.6); ctx.lineTo(-2.7, 3.6); ctx.closePath(); ctx.fill();
    ctx.fillStyle = dk; ctx.beginPath(); ctx.moveTo(-2.4, 0); ctx.quadraticCurveTo(0, 1.2, 2.4, 0); ctx.lineTo(2.4, -0.5); ctx.lineTo(-2.4, -0.5); ctx.closePath(); ctx.fill();   // scalloped top
    // foot: rounded toe pointing outward
    ctx.fillStyle = lg(0, 3, 0, 7, [[0, lt], [0.5, leather], [1, dk]]);
    ctx.beginPath(); ctx.moveTo(-2.8, 3.3); ctx.lineTo(2.8, 3.3); ctx.bezierCurveTo(4.8, 3.5, 6.2, 4.6, 6.1, 6.0); ctx.quadraticCurveTo(6.0, 6.9, 5.0, 6.9); ctx.lineTo(-2.8, 6.9); ctx.closePath(); ctx.fill();
    ctx.fillStyle = shade(leather, -0.18); ctx.beginPath(); ctx.ellipse(4.5, 5.4, 1.7, 1.35, 0.3, 0, TAU); ctx.fill();            // toe cap
    ctx.fillStyle = '#25160b'; ctx.beginPath(); ctx.moveTo(-2.9, 6.5); ctx.lineTo(5.3, 6.5); ctx.quadraticCurveTo(6.4, 6.5, 6.1, 7.4); ctx.lineTo(-2.9, 7.4); ctx.closePath(); ctx.fill();   // sole
    ctx.fillStyle = '#1a0f07'; ctx.fillRect(-2.9, 6.9, 2.6, 1.1);                                                                 // heel block
    // stitching, embroidered star and shine
    ctx.strokeStyle = 'rgba(255,224,160,0.6)'; ctx.lineWidth = 0.35; ctx.setLineDash([0.8, 0.7]);
    ctx.beginPath(); ctx.moveTo(-1.7, 0.6); ctx.lineTo(-1.8, 3.3); ctx.moveTo(1.7, 0.6); ctx.lineTo(1.8, 3.3); ctx.moveTo(-2.5, 3.9); ctx.quadraticCurveTo(2.5, 3.5, 5.2, 4.7); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#f1c40f'; ctx.beginPath(); for (let k = 0; k < 10; k++) { const an = k * TAU / 10 - Math.PI / 2, rr = k % 2 ? 0.4 : 1.0; ctx.lineTo(Math.cos(an) * rr, 1.8 + Math.sin(an) * rr); } ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fillRect(-0.9, 0.5, 0.7, 2.6);
    ctx.fillStyle = 'rgba(255,255,255,0.22)'; ctx.beginPath(); ctx.ellipse(3.4, 4.7, 1.1, 0.4, 0.3, 0, TAU); ctx.fill();
    ctx.restore();
}
function drawArm(sx, sy, hx, hy, sleeve) {
    ctx.lineCap = 'round';
    ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 4.2; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(hx, hy); ctx.stroke();
    ctx.strokeStyle = sleeve; ctx.lineWidth = 3.4; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(hx, hy); ctx.stroke();
    const mx = sx + (hx - sx) * 0.82, my = sy + (hy - sy) * 0.82;
    ctx.strokeStyle = '#f1c40f'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(mx - 1.6, my + 0.6); ctx.lineTo(mx + 1.6, my - 0.6); ctx.stroke();   // gold cuff
    ctx.strokeStyle = '#5a3a1c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(hx, hy - 0.4, 2.6, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke();   // leather glove cuff
    ctx.fillStyle = '#a9714a'; ctx.beginPath(); ctx.arc(hx, hy - 1, 2.3, 0, TAU); ctx.fill();                                                       // hand
    ctx.fillStyle = '#c98c5f'; ctx.beginPath(); ctx.arc(hx - 0.4, hy - 1.5, 1.4, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(60,30,15,0.7)'; ctx.lineWidth = 0.35;
    for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(hx + k * 0.8, hy - 3); ctx.lineTo(hx + k * 0.8, hy - 1.6); ctx.stroke(); }  // fingers
}
function drawVaquero(x, y, s, facing, phase, alpha = 1) {
    if (OPT.hd && OPT.gfx >= 1) { if (h3Init() && H3.ok) { const t0 = performance.now(); drawVaqueroGL(x, y, s, facing, phase, alpha); h3Watch(performance.now() - t0); return; } drawVaqueroHD(x, y, s, facing, phase, alpha); return; }
    drawVaqueroClassic(x, y, s, facing, phase, alpha);
}
function drawVaqueroClassic(x, y, s, facing, phase, alpha = 1) {
    const HAIR = '#140b08', hc = hoopColors(), q = OPT.gfx;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(x, y);
    ctx.scale(s * facing, s);
    const wob = Math.cos(phase) * 3, tilt = Math.sin(phase) * 0.15, sway = Math.sin(phase) * 1.2;
    // hula physics: the hoop circles the waist, hips push toward it, shoulders lean the other way, knees bounce
    const hip = wob * 0.6, lean = -wob * 0.024, bob = Math.sin(phase * 2) * 0.55, hcx = wob * 1.25, hcy = 2 + bob, hrx = 19 + Math.cos(phase) * 0.8;
    if (!VQ.nohoop) {
    // hoop, back half: thick tube, inner highlight, spinning tape stripes
    ctx.lineCap = 'round'; ctx.lineWidth = 3.8; ctx.strokeStyle = hc[0];
    ctx.beginPath(); ctx.ellipse(hcx, hcy, hrx, 5, tilt, Math.PI, TAU); ctx.stroke();
    if (q >= 1) {
        ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.beginPath(); ctx.ellipse(hcx, hcy - 0.6, hrx, 4.6, tilt, Math.PI, TAU); ctx.stroke();
        ctx.lineWidth = 1.6; ctx.strokeStyle = hc[2]; ctx.setLineDash([3, 5]); ctx.lineDashOffset = -phase * 9;
        ctx.beginPath(); ctx.ellipse(hcx, hcy, hrx, 5, tilt, Math.PI, TAU); ctx.stroke(); ctx.setLineDash([]);
    }
    // wind streaks
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1.5;
    for (let i = -1; i <= 1; i++) {
        const off = ((phase * 6 + i * 7) % 14 + 14) % 14;
        ctx.beginPath(); ctx.moveTo(i * 9, 28 + off); ctx.lineTo(i * 9, 34 + off); ctx.stroke();
    }
    }
    // legs: charro trousers with silver side buttons and a slight flare
    ctx.save(); ctx.transform(1, 0, -hip / 16, 1, hip * 17 / 16, 0);   // legs shear: feet planted, hips swing
    for (const L of [{ x: -5.6, w: 5, y1: 17.2 }, { x: 0.6, w: 5, y1: 16.2 }]) {
        ctx.fillStyle = lg(L.x, 0, L.x + L.w, 0, [[0, '#26324f'], [0.5, '#4a5c8a'], [1, '#2a3656']]);
        ctx.beginPath(); ctx.moveTo(L.x, 1); ctx.lineTo(L.x + L.w, 1); ctx.lineTo(L.x + L.w + 0.8, L.y1); ctx.lineTo(L.x - 0.8, L.y1); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#d9d9d9';
        if (q >= 1) for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.arc(L.x + L.w - 0.7, 3 + k * 2.9, 0.55, 0, TAU); ctx.fill(); }
    }
    ctx.restore();
    drawBoot(-3.5, 15.4, '#6b4426', -1); drawBoot(3.5, 15.4, '#7c5232', 1);
    // poncho (swaying), with woven bands, zigzag, diamond motif, fringe and neck slit
    ctx.save(); ctx.translate(hip + sway, bob); ctx.translate(0, 2); ctx.rotate(lean); ctx.translate(0, -2);
    ctx.fillStyle = lg(-10, -18, 10, 3, [[0, '#ea5848'], [0.55, '#c0392b'], [1, '#7d1f17']]);
    ctx.beginPath(); ctx.moveTo(-4, -18); ctx.lineTo(4, -18); ctx.lineTo(10.8, 2.4); ctx.lineTo(-10.8, 2.4); ctx.closePath(); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.moveTo(-4, -18); ctx.lineTo(4, -18); ctx.lineTo(10.8, 2.4); ctx.lineTo(-10.8, 2.4); ctx.closePath(); ctx.clip();
    const band = (y, h, c) => { ctx.fillStyle = c; ctx.fillRect(-12, y, 24, h); };
    band(-4.4, 2, '#f1c40f'); band(-8.2, 1.7, '#27ae60'); band(-12, 1.3, '#2980b9');
    ctx.fillStyle = '#fff6d8';
    for (let k = -10.5; k < 12; k += 3) { ctx.beginPath(); ctx.arc(k, -3.4, 0.7, 0, TAU); ctx.fill(); }   // dot row
    ctx.fillStyle = '#16a085';
    for (let k = -10.5; k < 12; k += 3) { ctx.beginPath(); ctx.arc(k, -7.4, 0.7, 0, TAU); ctx.fill(); }
    if (q >= 1) {   // fold shading
        ctx.fillStyle = 'rgba(0,0,0,0.14)'; ctx.beginPath(); ctx.moveTo(-3, -17); ctx.lineTo(-2, 2.4); ctx.lineTo(-5, 2.4); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.beginPath(); ctx.moveTo(3, -17); ctx.lineTo(7, 2.4); ctx.lineTo(4.4, 2.4); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
    ctx.fillStyle = '#f1e6c8'; ctx.fillRect(-10.8, 2.2, 21.6, 1.9);   // solid hem band (no dangling fringe)
    ctx.fillStyle = '#c0392b'; for (let k = -9.6; k <= 9.6; k += 2.4) ctx.fillRect(k - 0.5, 2.6, 1, 1.1);
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(-10.8, 4.1, 21.6, 0.5);
    ctx.fillStyle = '#2b0d09'; ctx.beginPath(); ctx.moveTo(-3.2, -18.2); ctx.lineTo(3.2, -18.2); ctx.lineTo(0, -14); ctx.closePath(); ctx.fill();   // neck slit
    ctx.fillStyle = '#f5f1e8'; ctx.beginPath(); ctx.moveTo(-2.4, -18.2); ctx.lineTo(2.4, -18.2); ctx.lineTo(0, -15.2); ctx.closePath(); ctx.fill();   // shirt collar
    // bandolier across the chest
    ctx.strokeStyle = '#5a3a1c'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(-6.5, -15.5); ctx.lineTo(7, -0.5); ctx.stroke();
    ctx.fillStyle = '#e2b13c';
    for (let k = 0; k < 6; k++) { const t = (k + 0.5) / 6; ctx.fillRect(-6.5 + 13.5 * t - 0.5, -15.5 + 15 * t - 1.3, 1, 2.2); }
    // holster, gun grip and cartridge belt on the far hip
    ctx.fillStyle = '#4a2c14'; roundRect(5.2, -2.6, 5, 7.4, 1.4); ctx.fill();
    ctx.fillStyle = '#6b4426'; ctx.fillRect(5.6, -2.4, 4.2, 1.5);
    ctx.fillStyle = '#e8dcc0'; roundRect(6.6, -6.2, 2.6, 4.2, 0.8); ctx.fill();
    ctx.strokeStyle = '#8a7a5a'; ctx.lineWidth = 0.35; ctx.beginPath(); ctx.moveTo(6.8, -5.2); ctx.lineTo(9, -5.2); ctx.moveTo(6.8, -4.2); ctx.lineTo(9, -4.2); ctx.stroke();
    ctx.fillStyle = '#3a2410'; ctx.fillRect(-10.8, 0.4, 21.6, 1.8);
    ctx.fillStyle = '#e2b13c'; for (let k = -9; k <= 9; k += 2.4) ctx.fillRect(k, 0.7, 1, 1.2);
    // lasso coil on the hip
    ctx.strokeStyle = '#d9b97a'; ctx.lineWidth = 0.9;
    for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.ellipse(-7.2, -0.4, 2.8 - k * 0.55, 3.6 - k * 0.7, 0, 0, TAU); ctx.stroke(); }
    // arms up, riding the hoop
    drawArm(-4, -15, -12 + Math.cos(phase) * 1.5, -22 - Math.sin(phase) * 2.4, '#f4efe6');
    drawArm(4, -15, 12 + Math.cos(phase) * 1.5, -22 + Math.sin(phase) * 2.4, '#f4efe6');
    // neck + head
    ctx.fillStyle = '#8a5736'; ctx.fillRect(-2.2, -20, 4.4, 3.2);
    // red polka-dot bandana and a gold chain with a medallion
    ctx.fillStyle = '#d0182f'; ctx.beginPath(); ctx.moveTo(-3.6, -20.4); ctx.lineTo(3.6, -20.4); ctx.lineTo(0.4, -15.4); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.beginPath(); ctx.moveTo(-3.6, -20.4); ctx.lineTo(3.6, -20.4); ctx.lineTo(3, -19.2); ctx.lineTo(-3, -19.2); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#fff'; for (const d of [[-1.8, -19], [1.2, -18.8], [-0.4, -17.4], [0.6, -16.4]]) { ctx.beginPath(); ctx.arc(d[0], d[1], 0.38, 0, TAU); ctx.fill(); }
    ctx.strokeStyle = '#f1c40f'; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(-4.2, -17.8); ctx.quadraticCurveTo(0, -13.4, 4.2, -17.8); ctx.stroke();
    conchoDot(0, -14.1, 1.35);
    // ---- face: front view, symmetrical, natural proportions ----
    ctx.lineCap = 'round';
    ctx.fillStyle = HAIR; ctx.beginPath(); ctx.ellipse(0, -25.6, 6.5, 5.6, 0, Math.PI, TAU); ctx.fill();                                   // hair mass behind the hat
    for (const sx of [-1, 1]) {   // ears
        ctx.fillStyle = '#8a5736'; ctx.beginPath(); ctx.ellipse(sx * 5.7, -23.2, 1.2, 1.9, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#c98c5f'; ctx.beginPath(); ctx.ellipse(sx * 5.65, -23.3, 0.55, 1.1, 0, 0, TAU); ctx.fill();
    }
    ctx.fillStyle = rg(-1.5, -26, 1, 0, -23.5, 8, [[0, '#d6966a'], [0.7, '#a9714a'], [1, '#8a5736']]);
    ctx.beginPath(); ctx.ellipse(0, -23.6, 5.5, 6.3, 0, 0, TAU); ctx.fill();                                                              // head
    ctx.fillStyle = HAIR; ctx.fillRect(-5.5, -27.2, 1.4, 5.2); ctx.fillRect(4.1, -27.2, 1.4, 5.2);                                         // sideburns
    if (q >= 1) { ctx.fillStyle = 'rgba(224,90,70,0.28)'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sx * 3.5, -21.6, 1.5, 1, 0, 0, TAU); ctx.fill(); } }   // cheeks
    ctx.strokeStyle = 'rgba(40,20,10,0.2)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(0, -23.6, 5.1, 5.9, 0, 0.5, Math.PI - 0.5); ctx.stroke();   // jaw shade
    // eyes, brows
    for (const sx of [-1, 1]) {
        const ex = sx * 2.1, ey = -24.6, ek = 1 + VQ.brow * 0.4;
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.ellipse(ex, ey, 1.35, 1.15 * ek, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#5a3418'; ctx.beginPath(); ctx.arc(ex, ey, 0.82, 0, TAU); ctx.fill();
        ctx.fillStyle = '#0a0503'; ctx.beginPath(); ctx.arc(ex, ey, 0.44, 0, TAU); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.fillRect(ex - 0.5, ey - 0.6, 0.4, 0.4);
        ctx.strokeStyle = HAIR; ctx.lineWidth = 0.55; ctx.beginPath(); ctx.moveTo(ex - 1.5, ey - 0.35 - VQ.brow * 0.3); ctx.quadraticCurveTo(ex, ey - 1.55 - VQ.brow * 0.7, ex + 1.5, ey - 0.35 - VQ.brow * 0.3); ctx.stroke();   // upper lid
        ctx.strokeStyle = 'rgba(40,20,10,0.35)'; ctx.lineWidth = 0.3; ctx.beginPath(); ctx.moveTo(ex - 1.1, ey + 1.1); ctx.quadraticCurveTo(ex, ey + 1.6, ex + 1.1, ey + 1.1); ctx.stroke();   // lower lid
        ctx.strokeStyle = HAIR; ctx.lineWidth = 0.95;   // eyebrow, gap in the middle
        const bu = VQ.brow * 1.1; ctx.beginPath(); ctx.moveTo(sx * 0.9, -26.4 - bu * 0.6); ctx.quadraticCurveTo(sx * 2.4, -27.3 - bu, sx * 3.5, -26.6 - bu * 0.4); ctx.stroke();
    }
    // nose
    ctx.strokeStyle = 'rgba(70,35,18,0.3)'; ctx.lineWidth = 0.4; ctx.beginPath(); ctx.moveTo(-0.8, -24.2); ctx.lineTo(-1, -22.5); ctx.moveTo(0.8, -24.2); ctx.lineTo(1, -22.5); ctx.stroke();
    ctx.fillStyle = '#b87a52'; ctx.beginPath(); ctx.ellipse(0, -22.4, 1.15, 0.8, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,225,190,0.35)'; ctx.beginPath(); ctx.ellipse(-0.2, -22.7, 0.4, 0.25, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(40,15,8,0.65)'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sx * 0.55, -22.1, 0.28, 0.2, 0, 0, TAU); ctx.fill(); }
    // mouth: grin with teeth and a gold tooth, below the mustache
    const mw = 1.7 + VQ.mw, mb = -17.9 + VQ.mo * 2.3;
    const mouth = () => { ctx.beginPath(); ctx.moveTo(-mw, -19.9); ctx.quadraticCurveTo(0, -19.3, mw, -19.9); ctx.quadraticCurveTo(mw * 0.76, mb - 0.1, 0, mb); ctx.quadraticCurveTo(-mw * 0.76, mb - 0.1, -mw, -19.9); ctx.closePath(); };
    ctx.fillStyle = '#3a0d0a'; mouth(); ctx.fill();
    ctx.save(); mouth(); ctx.clip();
    ctx.fillStyle = '#e0605a'; ctx.beginPath(); ctx.ellipse(0, mb, 1.4, 0.8 + VQ.mo * 0.5, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#f7f2e6'; ctx.fillRect(-1.8, -20, 3.6, 1.05);
    ctx.fillStyle = '#ffd32a'; ctx.fillRect(0.55, -20, 0.65, 1.05);
    ctx.strokeStyle = 'rgba(90,60,40,0.55)'; ctx.lineWidth = 0.15;
    for (let k = -2; k <= 2; k++) { ctx.beginPath(); ctx.moveTo(k * 0.6, -20); ctx.lineTo(k * 0.6, -19); ctx.stroke(); }
    ctx.restore();
    ctx.strokeStyle = 'rgba(40,15,8,0.8)'; ctx.lineWidth = 0.3; mouth(); ctx.stroke();
    drawStache(0, -20.95, 3.2);
    ctx.strokeStyle = 'rgba(70,35,18,0.4)'; ctx.lineWidth = 0.35; ctx.beginPath(); ctx.moveTo(0, -17.5); ctx.lineTo(0, -17); ctx.stroke();       // chin cleft
    if (q >= 1) { ctx.fillStyle = 'rgba(20,10,6,0.35)'; for (let k = 0; k < 10; k++) ctx.fillRect(-2.4 + (k % 5) * 1.1, -17.9 + Math.floor(k / 5) * 0.9, 0.35, 0.35); }
    ctx.strokeStyle = 'rgba(150,60,40,0.6)'; ctx.lineWidth = 0.45; ctx.beginPath(); ctx.moveTo(3.2, -23.4); ctx.lineTo(4.2, -21.6); ctx.stroke();    // cheek scar
    ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.arc(5.7, -21.2, 0.7, 0, TAU); ctx.fill();                                                  // gold earring
    // sombrero
    drawSombrero(0, -32.5, 14.5, -lean * 0.9 + sway * 0.02, save.cos.eq.hat);
    ctx.restore();
    if (!VQ.nohoop) {
    // hoop, front half
    ctx.lineWidth = 3.8; ctx.strokeStyle = hc[1];
    ctx.beginPath(); ctx.ellipse(hcx, hcy, hrx, 5, tilt, 0, Math.PI); ctx.stroke();
    if (q >= 1) {
        ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.45)'; ctx.beginPath(); ctx.ellipse(hcx, hcy - 0.6, hrx, 4.6, tilt, 0.2, Math.PI - 0.2); ctx.stroke();
        ctx.lineWidth = 1.6; ctx.strokeStyle = hc[0]; ctx.setLineDash([3, 5]); ctx.lineDashOffset = phase * 9;
        ctx.beginPath(); ctx.ellipse(hcx, hcy, hrx, 5, tilt, 0, Math.PI); ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.strokeStyle = hc[2]; ctx.lineWidth = 2;
    for (let k = 0; k < 3; k++) {
        const a = (phase * 1.5 + k * 1.05) % Math.PI;
        ctx.beginPath(); ctx.ellipse(hcx, hcy, hrx, 5, tilt, a, a + 0.25); ctx.stroke();
    }
    }
    ctx.restore();
}

// ---------- balls ----------
function ballSprite(b) {
    if (b._sp && b._spG === spGen && b._spR === b.r && b._spT === b.type && b._spC === b.color) return b._sp;
    const s0 = ballSpriteSlow(b); b._sp = s0; b._spG = spGen; b._spR = b.r; b._spT = b.type; b._spC = b.color;
    return s0;
}
function ballSpriteSlow(b) {
    const SR = Math.min(RES, 8), key = b.type + '|' + b.color + '|' + b.r + '|' + SR;
    let s = spriteCache.get(key);
    if (s) return s;
    if (spriteCache.size > 120) spriteCache.clear();
    const R = b.r, big = b.type === 'elite' || b.type === 'boss' || b.type === 'boss2';
    const pad = big ? R * 0.34 : 3, half = R + pad, S = Math.ceil(half * 2 * SR);
    const c = document.createElement('canvas'); c.width = c.height = S;
    const x = c.getContext('2d'); const k = S / (half * 2); x.scale(k, k);
    const cx = half, cy = half, T = b.type;
    const base = b.armored ? '#9aa6ad' : b.color;
    // spikes / horns sit behind the body
    if (T === 'elite') {
        x.fillStyle = '#4a235a';
        for (let i = 0; i < 12; i++) { const a = i * TAU / 12 + 0.13; x.beginPath(); x.moveTo(cx + Math.cos(a - 0.17) * R * 0.95, cy + Math.sin(a - 0.17) * R * 0.95); x.lineTo(cx + Math.cos(a) * (R + pad * 0.95), cy + Math.sin(a) * (R + pad * 0.95)); x.lineTo(cx + Math.cos(a + 0.17) * R * 0.95, cy + Math.sin(a + 0.17) * R * 0.95); x.fill(); }
    }
    if (T === 'boss' || T === 'boss2') {
        x.fillStyle = T === 'boss' ? '#f1e6c8' : '#cfe8ff'; x.strokeStyle = 'rgba(0,0,0,0.5)'; x.lineWidth = 1;
        for (const sx of [-1, 1]) {
            x.beginPath(); x.moveTo(cx + sx * R * 0.55, cy - R * 0.8);
            x.quadraticCurveTo(cx + sx * R * 1.08, cy - R * 0.95, cx + sx * (R + pad * 0.7), cy - R * 1.25 - pad * 0.2);
            x.quadraticCurveTo(cx + sx * R * 0.95, cy - R * 0.62, cx + sx * R * 0.8, cy - R * 0.5); x.closePath(); x.fill(); x.stroke();
        }
    }
    const gr = x.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R * 1.05);
    gr.addColorStop(0, shade(base, 0.62)); gr.addColorStop(0.42, base); gr.addColorStop(0.85, shade(base, -0.38)); gr.addColorStop(1, shade(base, -0.62));
    x.fillStyle = gr; x.beginPath(); x.arc(cx, cy, R, 0, TAU); x.fill();
    // everything below is clipped to the body
    x.save(); x.beginPath(); x.arc(cx, cy, R, 0, TAU); x.clip();
    const seam = (a0, w) => { x.strokeStyle = 'rgba(0,0,0,0.2)'; x.lineWidth = Math.max(0.6, R * 0.05); x.beginPath(); x.ellipse(cx, cy, R * w, R * 1.02, a0, 0, TAU); x.stroke(); };
    if (T === 'basic' || T === 'big' || T === 'splitter') {
        seam(0, 0.5); seam(0, 0.86); seam(Math.PI / 2, 0.01 + 0.0);
        x.save(); x.translate(cx, cy); x.rotate(-0.5); x.fillStyle = 'rgba(255,255,255,0.32)'; x.fillRect(-R, -R * 0.18, R * 2, R * 0.36); x.restore();
    }
    if (T === 'fast') {
        x.fillStyle = 'rgba(255,255,255,0.5)';
        for (let i = -1; i <= 1; i++) { x.beginPath(); x.moveTo(cx + i * R * 0.5 - R * 0.35, cy + R * 0.9); x.lineTo(cx + i * R * 0.5, cy + R * 0.1); x.lineTo(cx + i * R * 0.5 + R * 0.35, cy + R * 0.9); x.lineTo(cx + i * R * 0.5, cy + R * 0.55); x.fill(); }
    }
    if (T === 'zig') {
        x.strokeStyle = 'rgba(255,255,255,0.65)'; x.lineWidth = R * 0.16; x.lineJoin = 'round'; x.beginPath();
        for (let i = 0; i <= 6; i++) { const px = cx - R + i * R / 3, py = cy + R * 0.62 + (i % 2 ? -R * 0.14 : R * 0.14); i ? x.lineTo(px, py) : x.moveTo(px, py); }
        x.stroke();
    }
    if (T === 'big') {
        x.fillStyle = 'rgba(0,0,0,0.32)'; x.fillRect(cx - R, cy + R * 0.38, R * 2, R * 0.26);    // champion belt
        x.fillStyle = '#f1c40f'; x.beginPath(); x.arc(cx, cy + R * 0.51, R * 0.2, 0, TAU); x.fill();
        x.fillStyle = '#c0392b'; x.beginPath(); x.arc(cx, cy + R * 0.51, R * 0.09, 0, TAU); x.fill();
    }
    if (T === 'pistolero') {
        x.strokeStyle = '#5a3a1c'; x.lineWidth = R * 0.2; x.beginPath(); x.arc(cx, cy - R * 0.2, R * 0.92, 0.35, Math.PI - 0.35); x.stroke();   // ammo belt
        x.fillStyle = '#e2b13c'; for (let i = 0; i < 7; i++) { const a = 0.5 + i * (Math.PI - 1) / 6; x.fillRect(cx + Math.cos(a) * R * 0.92 - R * 0.04, cy - R * 0.2 + Math.sin(a) * R * 0.92 - R * 0.09, R * 0.08, R * 0.18); }
        x.fillStyle = '#f1c40f'; x.beginPath(); for (let i = 0; i < 10; i++) { const a = i * TAU / 10 - Math.PI / 2, rr = i % 2 ? R * 0.07 : R * 0.18; x.lineTo(cx - R * 0.5 + Math.cos(a) * rr, cy + R * 0.42 + Math.sin(a) * rr); } x.fill();   // sheriff star
    }
    if (T === 'splitter') {
        x.strokeStyle = '#a3ffee'; x.lineWidth = R * 0.07; x.lineJoin = 'round'; x.beginPath(); x.moveTo(cx - R * 0.1, cy - R); x.lineTo(cx + R * 0.15, cy - R * 0.4); x.lineTo(cx - R * 0.12, cy + R * 0.05); x.lineTo(cx + R * 0.14, cy + R * 0.5); x.lineTo(cx, cy + R); x.stroke();
    }
    if (T === 'dive') {
        x.fillStyle = 'rgba(255,220,120,0.55)';
        for (let i = -2; i <= 2; i++) { x.beginPath(); x.moveTo(cx + i * R * 0.4 - R * 0.18, cy + R); x.quadraticCurveTo(cx + i * R * 0.4, cy + R * 0.2, cx + i * R * 0.4 + R * 0.18, cy + R); x.fill(); }
    }
    if (T === 'shielded') {
        x.strokeStyle = 'rgba(255,255,255,0.5)'; x.lineWidth = R * 0.06; x.beginPath(); x.arc(cx, cy, R * 0.76, 0, TAU); x.stroke();
        x.fillStyle = 'rgba(255,255,255,0.75)'; for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; x.beginPath(); x.arc(cx + Math.cos(a) * R * 0.76, cy + Math.sin(a) * R * 0.76, R * 0.07, 0, TAU); x.fill(); }
    }
    if (T === 'bomber') {
        x.fillStyle = '#c0392b'; x.fillRect(cx - R, cy + R * 0.38, R * 2, R * 0.3);
        x.fillStyle = '#fff'; x.font = `bold ${Math.max(3, R * 0.26)}px system-ui, sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('TNT', cx, cy + R * 0.54);
        x.strokeStyle = '#ff9f43'; x.lineWidth = R * 0.05; x.beginPath(); x.moveTo(cx - R * 0.8, cy - R * 0.3); x.lineTo(cx - R * 0.45, cy - R * 0.05); x.lineTo(cx - R * 0.6, cy + R * 0.2); x.stroke();
    }
    if (T === 'golden') {
        x.strokeStyle = 'rgba(120,80,0,0.5)'; x.lineWidth = R * 0.07; x.beginPath(); x.arc(cx, cy, R * 0.74, 0, TAU); x.stroke();
        x.strokeStyle = 'rgba(255,255,255,0.45)'; x.lineWidth = R * 0.04; x.beginPath(); x.arc(cx, cy, R * 0.66, 0, TAU); x.stroke();
    }
    if (T === 'elite') {
        x.strokeStyle = '#f1c40f'; x.lineWidth = R * 0.07; x.beginPath(); x.arc(cx, cy, R * 0.86, 0, TAU); x.stroke();
        x.fillStyle = '#f1c40f'; for (let i = 0; i < 12; i++) { const a = i * TAU / 12; x.beginPath(); x.arc(cx + Math.cos(a) * R * 0.86, cy + Math.sin(a) * R * 0.86, R * 0.05, 0, TAU); x.fill(); }
    }
    if (T === 'boss' || T === 'boss2') {
        x.strokeStyle = 'rgba(255,220,120,0.8)'; x.lineWidth = R * 0.05; x.beginPath(); x.arc(cx, cy, R * 0.9, 0, TAU); x.stroke();
        x.fillStyle = '#ffd32a'; for (let i = 0; i < 16; i++) { const a = i * TAU / 16; x.beginPath(); x.arc(cx + Math.cos(a) * R * 0.9, cy + Math.sin(a) * R * 0.9, R * 0.04, 0, TAU); x.fill(); }
        x.strokeStyle = 'rgba(0,0,0,0.3)'; x.lineWidth = R * 0.03; x.beginPath(); x.moveTo(cx + R * 0.45, cy - R * 0.55); x.lineTo(cx + R * 0.62, cy - R * 0.2); x.stroke();   // battle scar
    }
    // soft bounce light from below + rim darkening
    const bl = x.createRadialGradient(cx, cy + R * 0.95, 0, cx, cy + R * 0.95, R * 0.9);
    bl.addColorStop(0, 'rgba(255,255,255,0.22)'); bl.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = bl; x.fillRect(cx - R, cy - R, R * 2, R * 2);
    x.restore();
    if (b.armored) {
        x.strokeStyle = '#2d3436'; x.lineWidth = 2; x.beginPath(); x.arc(cx, cy, R * 0.68, 0, TAU); x.stroke();
        x.lineWidth = 1.2; x.beginPath(); x.moveTo(cx - R * 0.68, cy); x.lineTo(cx + R * 0.68, cy); x.moveTo(cx, cy - R * 0.68); x.lineTo(cx, cy + R * 0.68); x.stroke();
        x.fillStyle = '#dfe6e9';
        for (let i = 0; i < 8; i++) { const a = i * TAU / 8; x.beginPath(); x.arc(cx + Math.cos(a) * R * 0.84, cy + Math.sin(a) * R * 0.84, Math.max(0.8, R * 0.06), 0, TAU); x.fill(); }
    }
    x.strokeStyle = 'rgba(0,0,0,0.4)'; x.lineWidth = 1.2; x.beginPath(); x.arc(cx, cy, R - 0.4, 0, TAU); x.stroke();
    // specular highlights
    x.fillStyle = 'rgba(255,255,255,0.7)'; x.beginPath(); x.ellipse(cx - R * 0.36, cy - R * 0.42, R * 0.26, R * 0.16, -0.7, 0, TAU); x.fill();
    x.fillStyle = 'rgba(255,255,255,0.35)'; x.beginPath(); x.arc(cx + R * 0.42, cy + R * 0.5, R * 0.07, 0, TAU); x.fill();
    if (T === 'golden') {
        x.fillStyle = '#fff'; x.beginPath();
        for (let i = 0; i < 8; i++) { const a = i * TAU / 8, rr = i % 2 ? R * 0.1 : R * 0.32; x.lineTo(cx + R * 0.3 + Math.cos(a) * rr, cy - R * 0.4 + Math.sin(a) * rr); }
        x.fill();
    }
    s = { c, half }; spriteCache.set(key, s);
    return s;
}
function faceLower(r, state, stache) {   // static lower half of an enemy face (mouth, cheeks, mustache), drawn once per variant
        const my = 0 + r * 0.34;
        if (state === 0) {   // "ooh!"
            ctx.fillStyle = '#3a0d0d'; ctx.beginPath(); ctx.ellipse(0, my + r * 0.2, r * 0.13, r * 0.17, 0, 0, TAU); ctx.fill();
        } else if (state === 1) {   // snarl with teeth
            ctx.fillStyle = '#2b0b0b'; ctx.beginPath(); ctx.moveTo(0 - r * 0.3, my + r * 0.34); ctx.quadraticCurveTo(0, my - r * 0.04, 0 + r * 0.3, my + r * 0.34); ctx.quadraticCurveTo(0, my + r * 0.2, 0 - r * 0.3, my + r * 0.34); ctx.fill();
            if (r >= 12) { ctx.fillStyle = '#fff'; for (let i = -2; i <= 2; i++) ctx.fillRect(0 + i * r * 0.1 - r * 0.04, my + r * 0.24 - Math.abs(i) * r * 0.045, r * 0.08, r * 0.07); }
        } else {            // happy grin
            ctx.fillStyle = '#3a1410'; ctx.beginPath(); ctx.moveTo(0 - r * 0.28, my + r * 0.12); ctx.quadraticCurveTo(0, my + r * 0.5, 0 + r * 0.28, my + r * 0.12); ctx.closePath(); ctx.fill();
            if (r >= 12) { ctx.fillStyle = '#fff'; ctx.fillRect(0 - r * 0.18, my + r * 0.12, r * 0.36, r * 0.09); }
        }
        if (r >= 11) { ctx.fillStyle = 'rgba(255,90,110,0.28)'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.ellipse(0 + sx * r * 0.58, 0 + r * 0.22, r * 0.14, r * 0.09, 0, 0, TAU); ctx.fill(); } }   // cheeks
        if (stache) drawStache(0, 0 + r * 0.26, r * 0.44);
}
function drawFace(b) {
    const r = b.r, p = g ? g.player : null, T = b.type;
    let ex = 0, ey = 0;
    if (p) { const dx = p.x - b.x, dy = p.y - b.y, d = Math.sqrt(dx * dx + dy * dy) || 1; ex = dx / d; ey = dy / d; }
    const er = Math.max(1.9, r * 0.23), ox = r * 0.36, oy = -r * 0.1;
    const angry = b.elite || b.boss;
    const mean = angry || T === 'fast' || T === 'dive' || T === 'pistolero' || T === 'bomber' || T === 'armored';
    const blink = ((menuT + Math.floor(b.phase * 7)) % 170) < 6 && b.flash <= 0;
    const irisCol = b.boss ? '#c0392b' : T === 'golden' ? '#7a5200' : b.elite ? '#8e44ad' : '#4a2f1a';
    for (const sx of [-1, 1]) {
        const cx = b.x + sx * ox, cy = b.y + oy;
        ctx.fillStyle = '#fff'; ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 0.7;
        ctx.beginPath(); ctx.ellipse(cx, cy, er, blink ? er * 0.2 : er * 1.1, 0, 0, TAU); ctx.fill(); ctx.stroke();
        if (!blink) {
            const ix = cx + ex * er * 0.4, iy = cy + ey * er * 0.4;
            ctx.fillStyle = irisCol; ctx.beginPath(); ctx.arc(ix, iy, er * 0.66, 0, TAU); ctx.fill();
            ctx.fillStyle = '#050505'; ctx.beginPath(); ctx.arc(ix, iy, er * 0.34, 0, TAU); ctx.fill();
            if (er > 2.4) { ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ix - er * 0.2, iy - er * 0.24, er * 0.16, 0, TAU); ctx.fill(); }
        }
        ctx.strokeStyle = '#1a0f0a'; ctx.lineCap = 'round';
        if (mean) {   // furrowed brow
            ctx.lineWidth = Math.max(1.4, r * 0.08);
            ctx.beginPath(); ctx.moveTo(cx - sx * er * 1.25, cy - er * 1.1 - er * 0.7 * (sx < 0 ? 0 : 0)); ctx.lineTo(cx + sx * er * 1.25, cy - er * 1.1 + 0); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(cx - sx * er * 1.35, cy - er * 1.75); ctx.lineTo(cx + sx * er * 1.0, cy - er * 0.95); ctx.stroke();
        } else if (r >= 9) {
            ctx.lineWidth = Math.max(0.8, r * 0.05);
            ctx.beginPath(); ctx.arc(cx, cy - er * 0.4, er * 1.25, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
        }
    }
    if (r >= 9) {
        const state = b.flash > 0 ? 0 : (mean || b.burnT > 0) ? 1 : 2, rr = Math.round(r * 2) / 2, SR = Math.min(RES, 4), st = OPT.stache ? 1 : 0;
        const e = cachedDraw(faceCache, rr + '|' + state + '|' + st + '|' + OPT.gfx, rr * 1.1, rr * 0.35, rr * 2.2, rr * 1.5, SR, () => faceLower(rr, state, st));
        ctx.drawImage(e.cv, b.x - e.ox, b.y - e.oy, e.w, e.h);
    }
    if (b.elite) { ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(b.x + ox - er * 0.5, b.y + oy - er * 1.8); ctx.lineTo(b.x + ox + er * 0.6, b.y + oy + er * 1.5); ctx.stroke(); }   // scar
}

function drawBall(b) {
    const q = OPT.gfx, r = b.r;
    if (q >= 2) { ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.beginPath(); ctx.ellipse(b.x + r * 0.2, b.y + r * 0.24, r, r * 0.95, 0, 0, TAU); ctx.fill(); }
    if (b.type === 'golden') drawGlow(b.x, b.y, r * 3, '#f1c40f', 0.6);
    const ship = shipOf(b);
    if (ship) drawShip(b, ship);
    else if (q >= 1 && b.flash <= 0) {
        const sp = ballSprite(b);
        ctx.drawImage(sp.c, b.x - sp.half, b.y - sp.half, sp.half * 2, sp.half * 2);
    } else {
        ctx.beginPath(); ctx.arc(b.x, b.y, r, 0, TAU);
        ctx.fillStyle = b.flash > 0 ? '#ffffff' : b.color; ctx.fill();
        ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.stroke();
    }
    if (b.burnT > 0 || b.slowT > 0) {
        ctx.lineWidth = 2.5; ctx.strokeStyle = b.burnT > 0 ? '#ff7f27' : '#74b9ff';
        ctx.beginPath(); ctx.arc(b.x, b.y, r + 0.5, 0, TAU); ctx.stroke();
        if (b.burnT > 0) drawGlow(b.x, b.y, r * 2.4, '#ff7f27', 0.45);
    }
    if (b.shieldHp > 0) {
        ctx.fillStyle = 'rgba(116,185,255,0.18)'; ctx.beginPath(); ctx.arc(b.x, b.y, r + 4, 0, TAU); ctx.fill();
        ctx.strokeStyle = `rgba(150,205,255,${0.6 + 0.3 * Math.sin(menuT * 0.2)})`; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.arc(b.x, b.y, r + 4, 0, TAU); ctx.stroke();
    }
    if (b.type === 'bomber' && menuT % 12 < 6) drawGlow(b.x + r * 0.5, b.y - r * 0.95, 9, '#ffcc33', 1);
    if (OPT.faces && !ship) drawFace(b);
    if (OPT.hats && !ship) {
        const tilt = Math.sin((menuT + b.phase) * 0.08) * 0.1 + b.vx * 0.08;
        drawSombrero(b.x, b.y - r * 0.74, r * 1.2, tilt, b.hat);
    }
    if ((b.elite || b.boss) && !b.nobar) {
        const bw = r * 2;
        ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(b.x - bw / 2, b.y + r + 4, bw, 5);
        ctx.fillStyle = b.boss ? '#ff4757' : '#c56cf0'; ctx.fillRect(b.x - bw / 2, b.y + r + 4, bw * clamp(b.hp / b.maxHp, 0, 1), 5);
    }
}

// =====================================================================
//  RENDERING - world
// =====================================================================
let vigCanvas = null, lowVig = null;
function drawLowHp() {   // red edge pulse + heartbeat when you're nearly dead
    if (!g || g.player.hp <= 0 || g.player.hp / g.S.maxHp > 0.25) return;
    if (!lowVig) {
        lowVig = document.createElement('canvas'); lowVig.width = 90; lowVig.height = 160;
        const x = lowVig.getContext('2d'), gr = x.createRadialGradient(45, 80, 30, 45, 80, 100);
        gr.addColorStop(0, 'rgba(255,30,50,0)'); gr.addColorStop(1, 'rgba(255,30,50,0.6)'); x.fillStyle = gr; x.fillRect(0, 0, 90, 160);
    }
    const pulse = 0.5 + 0.5 * Math.sin(menuT * 0.12);
    ctx.globalAlpha = OPT.calm ? 0.35 : 0.3 + 0.5 * pulse; ctx.drawImage(lowVig, 0, 0, W, H); ctx.globalAlpha = 1;
    if (menuT % 52 === 0) sfx('beat');
}
function drawWorld() {
    const p = g.player, q = OPT.gfx;
    ctx.save();
    if (g.shake > 0 && OPT.shake) ctx.translate(rand(-g.shake, g.shake) * 0.4, rand(-g.shake, g.shake) * 0.4);

    drawBackdrop();
    // sunbeam
    if (g.beam) {
        const a = 0.35 + 0.25 * Math.sin(menuT * 0.5);
        const bg = ctx.createLinearGradient(p.x - g.beam.w / 2, 0, p.x + g.beam.w / 2, 0);
        bg.addColorStop(0, 'rgba(253,203,110,0)'); bg.addColorStop(0.5, `rgba(253,203,110,${a + 0.2})`); bg.addColorStop(1, 'rgba(253,203,110,0)');
        ctx.fillStyle = bg; ctx.fillRect(p.x - g.beam.w / 2 - 4, 0, g.beam.w + 8, p.y - 10);
        ctx.fillStyle = 'rgba(255,255,255,0.65)'; ctx.fillRect(p.x - g.beam.w / 6, 0, g.beam.w / 3, p.y - 10);
        drawGlow(p.x, p.y - 14, g.beam.w * 2.2, '#fdcb6e', 0.8);
    }
    // pickups
    for (const k of g.pickups) {
        const tw = 0.5 + 0.5 * Math.sin(k.t * 0.15 + k.x);
        if (k.type === 'xp') {
            const col = k.value >= 10 ? '#e056fd' : k.value >= 4 ? '#00d2d3' : '#48dbfb';
            drawGlow(k.x, k.y, 12, col, 0.75);
            const SRg = Math.min(RES, 4), ge = cachedDraw(hatCache, 'g|' + col + '|' + SRg, 5, 6.5, 10, 13, SRg, () => {
            ctx.fillStyle = shade(col, -0.45); ctx.beginPath(); ctx.moveTo(0, 0 - 5.6); ctx.lineTo(0 + 4, 0 - 1.2); ctx.lineTo(0, 0 + 5.6); ctx.lineTo(0 - 4, 0 - 1.2); ctx.closePath(); ctx.fill();
            ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, 0 - 5.6); ctx.lineTo(0 + 4, 0 - 1.2); ctx.lineTo(0, 0 + 0.4); ctx.closePath(); ctx.fill();
            ctx.fillStyle = shade(col, 0.55); ctx.beginPath(); ctx.moveTo(0, 0 - 5.6); ctx.lineTo(0 - 4, 0 - 1.2); ctx.lineTo(0, 0 + 0.4); ctx.closePath(); ctx.fill();
            ctx.fillStyle = shade(col, -0.2); ctx.beginPath(); ctx.moveTo(0 - 4, 0 - 1.2); ctx.lineTo(0, 0 + 0.4); ctx.lineTo(0, 0 + 5.6); ctx.closePath(); ctx.fill();
            });
            ctx.drawImage(ge.cv, k.x - ge.ox, k.y - ge.oy, ge.w, ge.h);
            if (q >= 2) { ctx.strokeStyle = `rgba(255,255,255,${0.35 + 0.6 * tw})`; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(k.x - 1, k.y - 7); ctx.lineTo(k.x - 1, k.y - 3); ctx.moveTo(k.x - 3, k.y - 5); ctx.lineTo(k.x + 1, k.y - 5); ctx.stroke(); }
        } else if (k.type === 'gold') {
            const sx = Math.abs(Math.cos(k.t * 0.12 + k.x)) * 0.8 + 0.2;
            drawGlow(k.x, k.y, 11, '#f1c40f', 0.6);
            ctx.fillStyle = '#a97c05'; ctx.beginPath(); ctx.ellipse(k.x + 0.6, k.y + 0.6, 4.2 * sx + 0.4, 4.2, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = '#f7d23c'; ctx.beginPath(); ctx.ellipse(k.x, k.y, 4 * sx + 0.4, 4, 0, 0, TAU); ctx.fill();
            ctx.strokeStyle = 'rgba(150,100,0,0.6)'; ctx.lineWidth = 0.7; ctx.beginPath(); ctx.ellipse(k.x, k.y, 2.6 * sx + 0.3, 2.6, 0, 0, TAU); ctx.stroke();
            ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.fillRect(k.x - 2.2 * sx, k.y - 2.8, 1.4, 1.4);
        } else if (k.type === 'heart') {
            drawGlow(k.x, k.y, 13, '#ff4757', 0.65);
            const pulse = 1 + 0.08 * Math.sin(k.t * 0.2);
            ctx.save(); ctx.translate(k.x, k.y); ctx.scale(pulse, pulse);
            ctx.fillStyle = lg(0, -5, 0, 7, [[0, '#ff7a8a'], [1, '#c8102e']]);
            ctx.beginPath(); ctx.moveTo(0, 6.4); ctx.bezierCurveTo(-8, 0.8, -6.4, -6, 0, -2.6); ctx.bezierCurveTo(6.4, -6, 8, 0.8, 0, 6.4); ctx.fill();
            ctx.strokeStyle = 'rgba(100,0,20,0.5)'; ctx.lineWidth = 0.8; ctx.stroke();
            ctx.fillStyle = 'rgba(255,255,255,0.65)'; ctx.beginPath(); ctx.ellipse(-3, -2.4, 1.8, 1.1, -0.6, 0, TAU); ctx.fill();
            ctx.restore();
        } else if (k.type === 'chest') {
            drawGlow(k.x, k.y, 20, '#ffd32a', 0.75);
            ctx.fillStyle = lg(k.x, k.y - 6, k.x, k.y + 7, [[0, '#a8692f'], [1, '#5e3515']]); roundRect(k.x - 9, k.y - 6, 18, 13, 2); ctx.fill();
            ctx.fillStyle = '#c98a45'; ctx.beginPath(); ctx.moveTo(k.x - 9, k.y - 1); ctx.lineTo(k.x - 9, k.y - 4); ctx.quadraticCurveTo(k.x, k.y - 11, k.x + 9, k.y - 4); ctx.lineTo(k.x + 9, k.y - 1); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 0.6; for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(k.x - 9, k.y + 2 + i * 2.6); ctx.lineTo(k.x + 9, k.y + 2 + i * 2.6); ctx.stroke(); }
            ctx.fillStyle = '#d4a017'; ctx.fillRect(k.x - 9, k.y - 1.6, 18, 1.6); ctx.fillRect(k.x - 6.5, k.y - 7, 2, 14); ctx.fillRect(k.x + 4.5, k.y - 7, 2, 14);
            ctx.fillStyle = '#ffe58a'; ctx.beginPath(); ctx.arc(k.x, k.y - 0.8, 2.1, 0, TAU); ctx.fill(); ctx.fillStyle = '#5e3515'; ctx.fillRect(k.x - 0.4, k.y - 1.4, 0.8, 1.8);
            if (q >= 2) { ctx.fillStyle = `rgba(255,255,255,${0.4 + 0.5 * tw})`; ctx.fillRect(k.x + 7, k.y - 9 - tw * 2, 1.4, 1.4); ctx.fillRect(k.x - 9, k.y - 8 + tw * 2, 1.2, 1.2); }
        } else if (k.type.startsWith('power:')) {
            const U = POWERUPS[k.type.slice(6)], pul = 1 + 0.1 * Math.sin(menuT * 0.2);
            drawGlow(k.x, k.y, 22 * pul, U.c, 0.95);
            ctx.fillStyle = rg(k.x - 2.5, k.y - 3, 1, k.x, k.y, 9 * pul, [[0, shade(U.c, 0.6)], [0.6, U.c], [1, shade(U.c, -0.45)]]);
            ctx.beginPath(); ctx.arc(k.x, k.y, 8.5 * pul, 0, TAU); ctx.fill();
            ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
            ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1.6; const ra = menuT * 0.08; ctx.beginPath(); ctx.arc(k.x, k.y, 12.5 * pul, ra, ra + 1.1); ctx.stroke(); ctx.beginPath(); ctx.arc(k.x, k.y, 12.5 * pul, ra + Math.PI, ra + Math.PI + 1.1); ctx.stroke();
            ctx.fillStyle = '#1b1b2e'; ctx.font = 'bold 11px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillText(U.g, k.x, k.y + 0.5); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
        }
    }
    // balls
    for (const b of g.balls) if (!b.dead && !drawSpecialBall(b)) drawBall(b);
    // enemy bullets
    for (const e of g.ebullets) {
        drawGlow(e.x, e.y, 14, '#ff4757', 0.9);
        ctx.fillStyle = '#ff6b6b'; ctx.beginPath(); ctx.arc(e.x, e.y, e.r, 0, TAU); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(e.x, e.y, e.r * 0.45, 0, TAU); ctx.fill();
    }
    // pet
    if (g.pet) drawBuzzard(g.pet, Math.sin(menuT * 0.35) * 5);
    // bullets
    for (const b of g.bullets) {
        if (b.kind === 'tumble') {
            ctx.strokeStyle = b.color; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(b.x - b.r, b.y); ctx.lineTo(b.x + b.r, b.y); ctx.moveTo(b.x, b.y - b.r); ctx.lineTo(b.x, b.y + b.r); ctx.stroke();
            ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 0.55, 0, TAU); ctx.stroke();
        } else if (b.kind === 'dyn') {
            ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(menuT * 0.3);
            ctx.fillStyle = '#ff7675'; ctx.fillRect(-2, -5, 4, 10); ctx.fillStyle = '#ffd32a'; ctx.fillRect(-1, -7, 2, 2); ctx.restore();
            drawGlow(b.x, b.y - 7, 8, '#ffd32a', 0.9);
        } else if (b.kind === 'boom') {
            ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(menuT * 0.45);
            ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.ellipse(0, 0, b.r * 1.7, b.r * 0.7, 0, 0, TAU); ctx.fill();
            ctx.fillStyle = '#e17055'; ctx.beginPath(); ctx.ellipse(0, -b.r * 0.15, b.r * 1.5, b.r * 0.38, 0, 0, TAU); ctx.fill();
            ctx.restore();
            drawGlow(b.x, b.y, b.r * 3.5, '#e17055', 0.5);
        } else {
            if (q >= 2) {
                ctx.strokeStyle = b.color; ctx.lineCap = 'round';
                ctx.globalAlpha = 0.18; ctx.lineWidth = b.r * 2.2; ctx.beginPath(); ctx.moveTo(b.x - b.vx * 5, b.y - b.vy * 5); ctx.lineTo(b.x, b.y); ctx.stroke();
                ctx.globalAlpha = 0.4; ctx.lineWidth = b.r * 1.3; ctx.beginPath(); ctx.moveTo(b.x - b.vx * 3, b.y - b.vy * 3); ctx.lineTo(b.x, b.y); ctx.stroke();
                ctx.globalAlpha = 0.8; ctx.strokeStyle = '#fff'; ctx.lineWidth = b.r * 0.5; ctx.beginPath(); ctx.moveTo(b.x - b.vx * 1.4, b.y - b.vy * 1.4); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.globalAlpha = 1;
            }
            drawGlow(b.x, b.y, b.r * 4.5, b.color, 0.7);
            ctx.fillStyle = b.color; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
            if (q >= 1) { ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(b.x - b.r * 0.25, b.y - b.r * 0.25, b.r * 0.4, 0, TAU); ctx.fill(); }
        }
    }
    // orbiting hoops
    if (g.weapons.hoops) {
        const L = g.weapons.hoops.lvl, n = Math.min(8, L + 1), R = (34 + L * 2) * g.S.aoe;
        for (let i = 0; i < n; i++) {
            const a = g.hoopAngle + i * TAU / n, hx = p.x + Math.cos(a) * R, hy = p.y + Math.sin(a) * R;
            drawGlow(hx, hy, 18, '#2ecc71', 0.6);
            ctx.strokeStyle = '#1e8449'; ctx.lineWidth = 3.4; ctx.beginPath(); ctx.arc(hx, hy, 8, 0, TAU); ctx.stroke();
            ctx.strokeStyle = '#2ecc71'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(hx, hy, 8, 0, TAU); ctx.stroke();
        }
    }
    // fx
    for (const f of g.fx) {
        const k = f.t / f.max;
        if (f.kind === 'p') {
            ctx.globalAlpha = k;
            if (f.ch) { ctx.fillStyle = f.color; ctx.font = `${f.sz}px system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.fillText(f.ch, f.x, f.y); ctx.textAlign = 'left'; }
            else if (f.rect) { ctx.fillStyle = f.color; ctx.fillRect(f.x - f.sz / 2, f.y - f.sz / 2, f.sz, f.sz * 0.6); }
            else if (q >= 2) { ctx.strokeStyle = f.color; ctx.lineCap = 'round'; ctx.lineWidth = Math.max(1, f.sz * 0.6); ctx.beginPath(); ctx.moveTo(f.x - f.vx * 2.6, f.y - f.vy * 2.6); ctx.lineTo(f.x, f.y); ctx.stroke(); drawGlow(f.x, f.y, f.sz * 3.4, f.color, 0.8); }
            else { drawGlow(f.x, f.y, f.sz * 3.2, f.color, 0.8); ctx.fillStyle = f.color; ctx.fillRect(f.x - f.sz / 2, f.y - f.sz / 2, f.sz, f.sz); }
        } else if (f.kind === 'ring') {
            ctx.globalAlpha = k; ctx.strokeStyle = f.color; ctx.lineWidth = 3 + 2 * k;
            ctx.beginPath(); ctx.arc(f.x, f.y, f.r * (1.15 - k * 0.4), 0, TAU); ctx.stroke();
            if (q >= 2) { ctx.fillStyle = hexA(/^#[0-9a-f]{6}$/i.test(f.color) ? f.color : '#ffffff', 0.12 * k); ctx.fill(); }
        } else if (f.kind === 'lasso') {
            ctx.globalAlpha = k; ctx.strokeStyle = '#d4a373'; ctx.lineWidth = 3; ctx.setLineDash([6, 4]);
            ctx.beginPath(); ctx.arc(p.x, p.y, f.r * (1 - k * 0.3), menuT * 0.3, menuT * 0.3 + TAU * (1 - k * 0.5)); ctx.stroke(); ctx.setLineDash([]);
        } else if (f.kind === 'ghost') { drawVaquero(f.x, f.y, 0.8, f.facing, 0, k * 0.35); }
        else if (f.kind === 'hat') { ctx.globalAlpha = Math.min(1, k * 2); ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.rot); drawSombrero(0, 0, f.s, 0, f.hat); ctx.restore(); }
        else if (f.kind === 'cone') {
            const rr = f.r * (1 - k * 0.25);
            ctx.globalAlpha = k * 0.5; ctx.fillStyle = '#f9ca24';
            ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.arc(f.x, f.y, rr, -Math.PI / 2 - f.half, -Math.PI / 2 + f.half); ctx.closePath(); ctx.fill();
            ctx.globalAlpha = k; ctx.strokeStyle = '#fff3a0'; ctx.lineWidth = 2;
            for (let w = 1; w <= 3; w++) { ctx.beginPath(); ctx.arc(f.x, f.y, rr * w / 3, -Math.PI / 2 - f.half, -Math.PI / 2 + f.half); ctx.stroke(); }
        }
        ctx.globalAlpha = 1;
    }
    // bolts
    for (const b of g.bolts) {
        ctx.strokeStyle = b.color; ctx.lineWidth = 2; ctx.globalAlpha = Math.min(1, b.t / 6);
        ctx.beginPath(); ctx.moveTo(b.x1, b.y1);
        if (b.jag) { const segs = 6; for (let i = 1; i < segs; i++) ctx.lineTo(b.x1 + (b.x2 - b.x1) * i / segs + rand(-8, 8), b.y1 + (b.y2 - b.y1) * i / segs); }
        ctx.lineTo(b.x2, b.y2); ctx.stroke(); ctx.globalAlpha = 1;
        drawGlow(b.x2, b.y2, 16, /^#[0-9a-f]{6}$/i.test(b.color) ? b.color : '#a5d8ff', Math.min(1, b.t / 6));
    }
    // player
    const blink = p.iframes > 0 && Math.floor(p.iframes / 4) % 2 === 0 && p.dash <= 0;
    if (q >= 2 && g.kind === 'shoot') { ctx.fillStyle = 'rgba(0,0,0,0.18)'; ctx.beginPath(); ctx.ellipse(p.x, p.y + 44, 15, 4, 0, 0, TAU); ctx.fill(); }
    if (g.shield > 0) {
        ctx.fillStyle = 'rgba(255,234,167,0.12)'; ctx.beginPath(); ctx.arc(p.x, p.y - 4, 22, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(255,234,167,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(p.x, p.y - 4, 22, 0, TAU); ctx.stroke();
    }
    if (g.buff) { ctx.strokeStyle = 'rgba(0,210,211,0.6)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(p.x, p.y - 4, 26 + Math.sin(menuT * 0.2) * 2, 0, TAU); ctx.stroke(); drawGlow(p.x, p.y - 4, 44, '#00d2d3', 0.4); }
    drawPlayerSprite(p, blink);
    if (g.cape) drawCape(p);
    if (g.kind === 'rpg') drawRpgFront();
    if (g.kind === 'race') drawRaceFront();
    // floating texts
    for (const t of g.texts) {
        ctx.globalAlpha = Math.min(1, t.t / 15);
        ctx.font = `bold ${t.size}px system-ui, sans-serif`;
        ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillText(t.txt, t.x + 1, t.y + 1);
        ctx.fillStyle = t.color; ctx.fillText(t.txt, t.x, t.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();

    if (g.timeSlow > 0) { ctx.fillStyle = 'rgba(162,155,254,0.12)'; ctx.fillRect(0, 0, W, H); }
    if (g.dust > 0) { ctx.fillStyle = 'rgba(212,163,115,0.15)'; ctx.fillRect(0, 0, W, H); }
    if (g.hurtFlash > 0 && !OPT.calm) { ctx.fillStyle = `rgba(255,71,87,${g.hurtFlash / 40})`; ctx.fillRect(0, 0, W, H); }
    if (g.bombFlash > 0) { ctx.fillStyle = `rgba(255,255,255,${g.bombFlash / 20})`; ctx.fillRect(0, 0, W, H); }
    if (g.levelFlash > 0 && !OPT.calm) { ctx.fillStyle = `rgba(255,240,170,${g.levelFlash / 50})`; ctx.fillRect(0, 0, W, H); }
    if (q >= 2) {   // lens vignette (gradient rendered once, scaled up)
        if (!vigCanvas) {
            vigCanvas = document.createElement('canvas'); vigCanvas.width = 90; vigCanvas.height = 160;
            const vx = vigCanvas.getContext('2d'), vg2 = vx.createRadialGradient(45, 80, 160 * 0.34, 45, 80, 160 * 0.78);
            vg2.addColorStop(0, 'rgba(10,8,30,0)'); vg2.addColorStop(1, 'rgba(10,8,30,0.34)');
            vx.fillStyle = vg2; vx.fillRect(0, 0, 90, 160);
        }
        ctx.drawImage(vigCanvas, 0, 0, W, H);
    }
    // low HP vignette
    const hpk = p.hp / g.S.maxHp;
    if (hpk < 0.3 && mode !== 'over') {
        const a = (0.2 + 0.15 * Math.sin(menuT * 0.15)) * (1 - hpk / 0.3);
        const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.28, W / 2, H / 2, H * 0.72);
        vg.addColorStop(0, 'rgba(255,0,30,0)'); vg.addColorStop(1, `rgba(255,0,30,${a.toFixed(3)})`);
        ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
    }
}

// =====================================================================
//  RENDERING - HUD and screens
// =====================================================================
function drawCape(p) {
    const C = g.cape, R = 40 + 8 * C.rank, k = Math.max(0.25, Math.min(1, C.t / 12, (C.max - C.t) / 6 + 0.25)), sw = Math.sin(menuT * 0.35);
    const cx = p.x, cy = p.y - 26;
    ctx.save(); ctx.globalAlpha = k;
    drawGlow(cx, cy - R * 0.4, R * 1.7, '#ff4757', 0.55);
    ctx.beginPath(); ctx.moveTo(cx - R * 0.12, cy + 12);
    ctx.quadraticCurveTo(cx - R * 1.15, cy - R * 0.15, cx - R * 0.9 + sw * 3, cy - R * 0.95);
    ctx.quadraticCurveTo(cx, cy - R * 1.3 + sw * 4, cx + R * 0.9 - sw * 3, cy - R * 0.95);
    ctx.quadraticCurveTo(cx + R * 1.15, cy - R * 0.15, cx + R * 0.12, cy + 12);
    ctx.quadraticCurveTo(cx, cy + 20 + sw * 4, cx - R * 0.12, cy + 12); ctx.closePath();
    ctx.fillStyle = lg(cx, cy - R * 1.2, cx, cy + 12, [[0, '#ff6b6b'], [0.6, '#d0182f'], [1, '#7d0d1c']]); ctx.fill();
    ctx.strokeStyle = '#ffd32a'; ctx.lineWidth = 2; ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.22)'; ctx.lineWidth = 1.2;
    for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(cx + i * R * 0.04, cy + 10); ctx.quadraticCurveTo(cx + i * R * 0.35, cy - R * 0.5, cx + i * R * 0.45 + sw * 2, cy - R * 0.98 + Math.abs(i) * R * 0.08); ctx.stroke(); }
    ctx.fillStyle = '#ffd32a'; for (let i = -3; i <= 3; i++) { ctx.beginPath(); ctx.arc(cx + i * R * 0.27, cy - R * (0.99 - Math.abs(i) * 0.07) + sw * (i * 0.4), 2.1, 0, TAU); ctx.fill(); }
    ctx.restore();
}
function drawHUD() {
    const S = g.S, p = g.player;
    // XP bar
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(0, 0, W, 6);
    const xg = ctx.createLinearGradient(0, 0, W, 0); xg.addColorStop(0, '#48dbfb'); xg.addColorStop(1, '#a29bfe');
    ctx.fillStyle = xg; ctx.fillRect(0, 0, W * clamp(g.xp / need(g.level), 0, 1), 6);
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(0, 0, W * clamp(g.xp / need(g.level), 0, 1), 2);
    drawGlow(W * clamp(g.xp / need(g.level), 0, 1), 3, 10, '#a29bfe', 0.9);
    // HP bar
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; roundRect(10, 12, 160, 16, 7); ctx.fill();
    const hpk = clamp(p.hp / S.maxHp, 0, 1);
    const hgr = ctx.createLinearGradient(0, 14, 0, 26);
    const hc = hpk > 0.5 ? ['#7bed9f', '#2ecc71'] : hpk > 0.25 ? ['#ffd166', '#f39c12'] : ['#ff7675', '#e74c3c'];
    hgr.addColorStop(0, hc[0]); hgr.addColorStop(1, hc[1]);
    ctx.fillStyle = hgr; roundRect(12, 14, Math.max(2, 156 * hpk), 12, 5); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.28)'; roundRect(13, 15, Math.max(2, 154 * hpk), 4.5, 3); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(12 + 40 * i, 14); ctx.lineTo(12 + 40 * i, 26); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(255,255,255,0.3)'; roundRect(10, 12, 160, 16, 7); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 10px system-ui, sans-serif';
    ctx.fillText(`HP ${Math.ceil(p.hp)}/${Math.round(S.maxHp)}`, 18, 24);
    for (let i = 0; i < S.maxShield; i++) {
        ctx.fillStyle = i < g.shield ? '#ffeaa7' : 'rgba(255,255,255,0.2)';
        ctx.beginPath(); ctx.arc(180 + i * 12, 20, 4.5, 0, TAU); ctx.fill();
    }
    // level / gold / time
    ctx.font = 'bold 13px system-ui, sans-serif';
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; roundRect(10, 34, 44, 17, 8); ctx.fill(); ctx.strokeStyle = '#ffd32a'; ctx.lineWidth = 1.2; roundRect(10, 34, 44, 17, 8); ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.fillText('Lv ' + g.level, 17, 47);
    ctx.fillStyle = '#d4a017'; ctx.beginPath(); ctx.arc(70, 42.5, 6.2, 0, TAU); ctx.fill(); ctx.fillStyle = '#f7d23c'; ctx.beginPath(); ctx.arc(70, 42.5, 4.8, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.fillRect(67.5, 39.5, 1.6, 1.6);
    ctx.fillStyle = '#f1c40f';
    ctx.fillText(String(g.gold), 80, 47);
    ctx.fillStyle = '#dfe6e9';
    ctx.font = '11px system-ui, sans-serif';
    ctx.fillText(hudSub(), 130, 46, 150);
    // combo meter
    if (g.combo >= 3) {
        ctx.fillStyle = '#ff9ff3'; ctx.font = 'bold 12px system-ui, sans-serif';
        ctx.fillText('COMBO ×' + g.combo + '  +' + Math.min(50, g.combo) + '% coins', 12, g.camp ? 84 : 62);
        const cw = Math.round(60 + S.comboTime);
        ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(12, g.camp ? 88 : 66, 110, 3);
        ctx.fillStyle = '#ff9ff3'; ctx.fillRect(12, g.camp ? 88 : 66, 110 * clamp(g.comboT / cw, 0, 1), 3);
    }
    if (g.buff) { ctx.fillStyle = '#00d2d3'; ctx.font = '11px system-ui, sans-serif'; ctx.fillText(g.buff.type + ' ' + Math.ceil(g.buff.t / 60) + 's', 160, 62); }
    // event banner
    if (g.event) {
        const e = g.event, ey = g.camp ? 96 : 74;
        ctx.font = 'bold 12px system-ui, sans-serif'; ctx.textAlign = 'center';
        const tw = ctx.measureText(e.name).width + 26;
        ctx.fillStyle = 'rgba(10,10,25,0.7)'; roundRect(W / 2 - tw / 2, ey, tw, 22, 8); ctx.fill();
        ctx.fillStyle = e.col; ctx.fillRect(W / 2 - tw / 2 + 6, ey + 19, (tw - 12) * clamp(e.t / e.max, 0, 1), 2);
        ctx.fillText(e.name, W / 2, ey + 15); ctx.textAlign = 'left';
    }
    // boss warning
    if (g.warn > 0 && Math.floor(g.warn / 10) % 2 === 0) {
        ctx.fillStyle = 'rgba(255,40,60,0.28)'; ctx.fillRect(0, 118, W, 34);
        ctx.fillStyle = '#fff'; ctx.font = 'bold 18px system-ui, sans-serif'; ctx.textAlign = 'center';
        outlineText('!! WARNING: BOSS INBOUND !!', W / 2, 142, '#ffd6d6'); ctx.textAlign = 'left';
    }
    // kill streak text
    if (g.streak) {
        const k = g.streak.t / g.streak.max, sc = 1 + Math.max(0, k - 0.8) * 3;
        ctx.save(); ctx.translate(W / 2, 200); ctx.scale(sc, sc); ctx.globalAlpha = Math.min(1, k * 3);
        ctx.textAlign = 'center'; ctx.font = 'bold 30px system-ui, sans-serif';
        outlineText(g.streak.txt, 0, 0, '#ffd32a', 'rgba(120,20,0,0.8)', 6);
        ctx.restore(); ctx.textAlign = 'left';
    }
    // pause button
    uiButtons.push({ x: W - 44, y: 10, w: 34, h: 34, fn: () => { mode = 'pause'; drag = null; } });
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; roundRect(W - 44, 10, 34, 34, 8); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.fillRect(W - 33, 19, 4, 16); ctx.fillRect(W - 25, 19, 4, 16);
    // active skills
    const ids = g.kind === 'convoy' ? [] : Object.keys(g.actives);
    ids.forEach((id, i) => {
        const a = g.actives[id], A = ACTIVES[id];
        const cx = W - 40 - i * 62, cy = H - 44, r = 25;
        uiButtons.push({ x: cx - r, y: cy - r, w: r * 2, h: r * 2, fn: () => useActive(id) });
        ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
        ctx.strokeStyle = A.color; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, cy, r - 2, 0, TAU); ctx.stroke();
        if (a.cd > 0) {
            const max = Math.round(A.cd(a.rank) * S.skillCd);
            ctx.fillStyle = 'rgba(0,0,0,0.55)';
            ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r - 2, -Math.PI / 2, -Math.PI / 2 + TAU * (a.cd / max)); ctx.closePath(); ctx.fill();
        } else drawGlow(cx, cy, 36, A.color, 0.5);
        ctx.fillStyle = a.cd > 0 ? '#999' : '#fff';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = 'bold 20px system-ui, sans-serif'; ctx.fillText(A.icon, cx, cy - 2);
        ctx.font = 'bold 8px system-ui, sans-serif'; ctx.fillText(a.cd > 0 ? Math.ceil(a.cd / 60) + 's' : activeName(id).toUpperCase(), cx, cy + 14);
        ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    });
    drawToasts();
}

function drawToasts() {
    let y = g.camp ? 122 : 104;
    for (const t of g.toasts) {
        const a = Math.min(1, t.t / 20, (t.max - t.t) / 10 + 0.2);
        ctx.globalAlpha = a;
        ctx.font = 'bold 12px system-ui, sans-serif';
        const tw = Math.min(W - 40, Math.max(ctx.measureText(t.title).width, t.text ? (ctx.font = '10px system-ui, sans-serif', ctx.measureText(t.text).width) : 0) + 24);
        const h = t.text ? 36 : 22;
        ctx.fillStyle = 'rgba(10,10,25,0.78)'; roundRect(W / 2 - tw / 2, y, tw, h, 8); ctx.fill();
        ctx.strokeStyle = t.color; ctx.lineWidth = 1.5; roundRect(W / 2 - tw / 2, y, tw, h, 8); ctx.stroke();
        ctx.textAlign = 'center';
        ctx.fillStyle = t.color; ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillText(t.title, W / 2, y + 15, tw - 12);
        if (t.text) { ctx.fillStyle = '#dfe6e9'; ctx.font = '10px system-ui, sans-serif'; ctx.fillText(t.text, W / 2, y + 29, tw - 12); }
        ctx.textAlign = 'left';
        y += h + 6;
    }
    ctx.globalAlpha = 1;
}

const RARITY_COL = { common: '#bdc3c7', rare: '#3498db', epic: '#9b59b6' };
function drawLevelUp() {
    ctx.fillStyle = 'rgba(8,8,20,0.78)'; ctx.fillRect(0, 0, W, H);
    ctx.textAlign = 'center';
    ctx.font = 'bold 28px system-ui, sans-serif';
    outlineText('LEVEL UP!', W / 2, 92, '#ffd32a');
    ctx.fillStyle = '#dfe6e9'; ctx.font = '13px system-ui, sans-serif';
    ctx.fillText(`Level ${g.level - g.pending + 1}${g.pending > 1 ? `  (+${g.pending - 1} more)` : ''} · choose one`, W / 2, 116);
    ctx.textAlign = 'left';
    g.choices.forEach((c, i) => {
        const x = 18, y = 140 + i * 132, w = W - 36, h = 120;
        uiButtons.push({ x, y, w, h, fn: () => chooseCard(i) });
        let border, label, name, desc, foot = '';
        if (c.kind === 'power') {
            const p = c.p;
            border = RARITY_COL[p.rarity];
            label = 'ATTACK POWER · ' + p.rarity.toUpperCase();
            name = p.name; desc = p.desc;
            if (p.weapon && g.weapons[p.weapon]) foot = `${wName(p.weapon)}: Lv ${g.weapons[p.weapon].lvl} → ${g.weapons[p.weapon].lvl + 1}`;
            else if (p.unlock) foot = 'NEW WEAPON';
            else if (p.max > 1) foot = `Stack ${(g.powerStacks[p.id] || 0) + 1}/${p.max}`;
        } else if (c.kind === 'relic') {
            border = '#e056fd'; label = 'RELIC · RANDOM EFFECT'; name = '? Mystery Relic ?';
            desc = 'Grants a random relic. Most help, some come with a catch.';
            foot = `${g.relics.length}/${RELICS.length} relics found`;
        } else {
            border = '#f1c40f'; label = 'BONUS'; name = 'Saddlebag'; desc = '+25 gold and heal 25 HP.';
        }
        const cg = ctx.createLinearGradient(0, y, 0, y + h); cg.addColorStop(0, 'rgba(44,47,80,0.97)'); cg.addColorStop(1, 'rgba(24,26,48,0.97)');
        ctx.fillStyle = cg; roundRect(x, y, w, h, 12); ctx.fill();
        drawGlow(x + w / 2, y + h / 2, 150, border, 0.12);
        ctx.strokeStyle = border; ctx.lineWidth = 2.5; roundRect(x, y, w, h, 12); ctx.stroke();
        ctx.fillStyle = border; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillText(label, x + 14, y + 20);
        ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillText(String(i + 1), x + w - 20, y + 20);
        ctx.fillStyle = '#fff'; ctx.font = 'bold 18px system-ui, sans-serif'; ctx.fillText(name, x + 14, y + 44);
        ctx.fillStyle = '#c8d6e5'; ctx.font = '13px system-ui, sans-serif';
        wrapText(desc, x + 14, y + 66, w - 28, 17);
        if (foot) { ctx.fillStyle = border; ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillText(foot, x + 14, y + h - 12); }
    });
    if (g.rerolls > 0) btn(W / 2 - 90, 548, 180, 44, `REROLL (${g.rerolls})`, rerollChoices, '#636e72');
    drawToasts();
}

function drawPause() {
    ctx.fillStyle = 'rgba(8,8,20,0.85)'; ctx.fillRect(0, 0, W, H);
    ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.font = 'bold 26px system-ui, sans-serif';
    ctx.fillText('PAUSED', W / 2, 56); ctx.textAlign = 'left';
    btn(80, 70, 200, 42, 'RESUME', () => { mode = 'play'; }, '#2ecc71');
    btn(80, 120, 200, 42, 'OPTIONS', () => { optsReturn = 'pause'; mode = 'options'; }, '#6c5ce7');
    btn(80, 170, 200, 42, 'END RUN', () => endRun(), '#e74c3c', 'your score becomes pesos');
    ctx.fillStyle = '#9aa3c7'; ctx.font = '11px system-ui, sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(`${fmtTime(g.frames)}  ·  ${g.kills} pops  ·  best combo ${g.maxCombo}  ·  ${Math.floor(g.gold)} gold`, W / 2, 232); ctx.textAlign = 'left';
    let y = 252;
    ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillText('WEAPONS', 20, y); y += 18;
    ctx.fillStyle = '#dfe6e9'; ctx.font = '12px system-ui, sans-serif';
    y = wrapText(Object.keys(g.weapons).map(id => `${wName(id)} ${g.weapons[id].lvl}`).join(' · '), 20, y, W - 40, 16) + 6;
    const pw = Object.keys(g.powerStacks).filter(id => !id.startsWith('w_') && !id.startsWith('u_'));
    ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillText('POWERS', 20, y); y += 18;
    ctx.fillStyle = '#dfe6e9'; ctx.font = '12px system-ui, sans-serif';
    y = wrapText(pw.length ? pw.map(id => { const p = POWERS.find(q => q.id === id) || CARDS.find(q => q.id === id); return p.name + (g.powerStacks[id] > 1 ? ' ×' + g.powerStacks[id] : ''); }).join(' · ') : 'None yet', 20, y, W - 40, 16) + 6;
    ctx.fillStyle = '#e056fd'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillText(`RELICS (${g.relics.length}/${RELICS.length})`, 20, y); y += 18;
    ctx.font = '11px system-ui, sans-serif';
    for (const id of g.relics) {
        if (y > H - 20) { ctx.fillStyle = '#999'; ctx.fillText('…', 20, y); break; }
        const r = RELICS.find(q => q.id === id);
        ctx.fillStyle = '#fff'; ctx.fillText(r.name + ':', 20, y);
        const nw = ctx.measureText(r.name + ': ').width;
        ctx.fillStyle = '#b2bec3';
        y = wrapText(r.desc, 20 + nw, y, W - 40 - nw, 14);
    }
}

function drawBunting(y0, t, sag, ph) {
    ctx.strokeStyle = 'rgba(40,20,40,0.7)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-10, y0); ctx.quadraticCurveTo(W / 2, y0 + sag * 2, W + 10, y0); ctx.stroke();
    const N = 13;
    for (let i = 0; i < N; i++) {
        const u = (i + 0.5) / N, x = u * W, y = y0 + sag * 2 * u * (1 - u) * 2 * 0.5 * 1, sw = Math.sin(t * 0.06 + i * 0.8 + ph) * 2.2;
        ctx.fillStyle = ['#ff6b6b', '#feca57', '#48dbfb', '#1dd1a1', '#ff9ff3'][(i + ph) % 5];
        ctx.beginPath(); ctx.moveTo(x - 8, y + 1); ctx.lineTo(x + 8, y + 1); ctx.lineTo(x + sw, y + 19); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.moveTo(x - 8, y + 1); ctx.lineTo(x - 1, y + 1); ctx.lineTo(x + sw * 0.5 - 2, y + 12); ctx.closePath(); ctx.fill();
    }
}