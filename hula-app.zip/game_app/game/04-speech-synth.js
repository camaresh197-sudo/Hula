// ---- a small formant speech synthesizer (voiced source -> 3 moving formant filters, plus a noise path for s / f / j / g) ----
// phoneme: F = [F1,F2,F3] formant targets, d = seconds, v = voicing 0..1, n = [noise filter type, freq, gain]
const PH = {
    J: { F: [300, 2000, 2800], d: 0.1, v: 0, n: ['bandpass', 3000, 0.9], pre: 0.03 },
    EH: { F: [570, 1850, 2500], d: 0.2, v: 1 }, IH: { F: [400, 2000, 2600], d: 0.14, v: 1 }, AE: { F: [720, 1700, 2500], d: 0.2, v: 1 },
    AW: { F: [610, 950, 2500], d: 0.24, v: 1 }, AH: { F: [520, 1350, 2400], d: 0.14, v: 1 },
    EY1: { F: [520, 1900, 2500], d: 0.2, v: 1 }, EY2: { F: [380, 2150, 2800], d: 0.3, v: 1 },
    F: { F: [300, 1500, 2500], d: 0.11, v: 0, n: ['bandpass', 5200, 0.35] }, S: { F: [300, 1600, 2500], d: 0.13, v: 0, n: ['bandpass', 7000, 0.8] },
    Z: { F: [250, 1700, 2500], d: 0.1, v: 0.45, n: ['bandpass', 6600, 0.55] },
    N: { F: [260, 1800, 2700], d: 0.1, v: 0.55 }, M: { F: [260, 1100, 2100], d: 0.12, v: 0.55 },
    G: { F: [350, 1700, 2400], d: 0.07, v: 0, n: ['bandpass', 1900, 0.9], pre: 0.04 },
    A: { F: [800, 1250, 2500], d: 0.16, v: 1 }, I: { F: [320, 2250, 3000], d: 0.14, v: 1 }, O: { F: [520, 900, 2400], d: 0.16, v: 1 }, U: { F: [330, 900, 2200], d: 0.14, v: 1 },
    R: { F: [400, 1400, 2000], d: 0.05, v: 0.5 }, L: { F: [360, 1300, 2700], d: 0.07, v: 0.8 }, Y: { F: [300, 2200, 3000], d: 0.06, v: 1 }, W: { F: [300, 700, 2200], d: 0.07, v: 1 },
    B: { F: [350, 900, 2200], d: 0.05, v: 0.35, n: ['bandpass', 900, 0.5], pre: 0.03 }, D: { F: [350, 1700, 2600], d: 0.05, v: 0.35, n: ['bandpass', 3200, 0.5], pre: 0.03 },
    T: { F: [350, 1700, 2600], d: 0.06, v: 0, n: ['bandpass', 3300, 0.7, 2.2], pre: 0.03 }, P: { F: [350, 900, 2200], d: 0.06, v: 0, n: ['bandpass', 1000, 0.7], pre: 0.03 }, K: { F: [350, 1700, 2400], d: 0.07, v: 0, n: ['bandpass', 1800, 0.8], pre: 0.04 },
    V: { F: [300, 1500, 2300], d: 0.08, v: 0.5, n: ['bandpass', 4500, 0.3] }, H: { F: [500, 1400, 2400], d: 0.08, v: 0, n: ['bandpass', 1500, 0.35] },
};
let GLOT = null;
function glotWave(tilt) {   // glottal-pulse spectrum; tilt = harmonic roll-off exponent (low = pressed/buzzy, high = soft/breathy)
    tilt = tilt || 1.65; if (!GLOT || GLOT.ctxOwner !== AC) GLOT = { ctxOwner: AC };
    const key = tilt.toFixed(2);
    if (!GLOT[key]) { const n = 64, re = new Float32Array(n), im = new Float32Array(n); for (let k = 1; k < n; k++) im[k] = 1 / Math.pow(k, tilt) * (1 + 0.35 * Math.sin(k * 0.7) * (k < 8 ? 1 : 0)); GLOT[key] = AC.createPeriodicWave(re, im); }
    return GLOT[key];
}
let SBUS = null;
function speechBus() {   // gentle limiter so the voice never clips when it stacks on the band
    if (!SBUS || SBUS.ctxOwner !== AC) { const c = AC.createDynamicsCompressor(); c.threshold.value = -14; c.knee.value = 12; c.ratio.value = 4; c.attack.value = 0.004; c.release.value = 0.12; c.connect(musOut && musOut.context === AC ? musOut : musGain); c.ctxOwner = AC; SBUS = c; }
    return SBUS;
}
let SVERB = null;
function speechVerb() {   // ~0.5 s dark room tail, generated once per audio context
    if (!SVERB || SVERB.ctxOwner !== AC) {
        const len = (AC.sampleRate * 0.5) | 0, ir = AC.createBuffer(2, len, AC.sampleRate);
        for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); let lp = 0; for (let i = 0; i < len; i++) { lp += (Math.random() * 2 - 1 - lp) * 0.35; d[i] = lp * Math.pow(1 - i / len, 2.4); } }
        const cv = AC.createConvolver(); cv.buffer = ir; cv.connect(speechBus()); cv.ctxOwner = AC; SVERB = cv;
    }
    return SVERB;
}
const SPEAK_LEVEL = 0.8;
// ---- speakSyn v3: a Klatt-style source-filter synthesizer rendered offline into a buffer (then played) ----
// glottal pulse model (open quotient, fall time) + pitch-synchronous aspiration + jitter/shimmer; cascade of 5 formant resonators with
// nasal anti-resonance; separate frication/burst branch; control tracks at 400 Hz with per-phoneme coarticulation time constants.
const KSR = 22050;
// Liljencrants-Fant glottal flow derivative tables, parameterised by Rd (Fant 1995). 1 period = 1.0
const LF_RD = [], LF_N = 512; for (let i = 0; i < 12; i++) LF_RD.push(0.35 + i * 0.18);   // 0.35 .. 2.33
const LFT = LF_RD.map(Rd => {
    const Ra = (-1 + 4.8 * Rd) / 100, Rk = (22.4 + 11.8 * Rd) / 100, Rg = Rk / (4 * (0.11 * Rd / (0.5 + 1.2 * Rk) - Ra));
    const tp = 1 / (2 * Rg), te = tp * (Rk + 1), ta = Math.max(0.0015, Ra), eps = 1 / ta, om = Math.PI / tp, M = 2000;
    const wave = (al) => { const E0 = -1 / (Math.exp(al * te) * Math.sin(om * te)), a = new Float64Array(M); let sum = 0;
        for (let i = 0; i < M; i++) { const t = (i + 0.5) / M; a[i] = t < te ? E0 * Math.exp(al * t) * Math.sin(om * t) : -(1 / (eps * ta)) * (Math.exp(-eps * (t - te)) - Math.exp(-eps * (1 - te))); sum += a[i]; } return [a, sum / M]; };
    let lo = -30, hi = 300, flo = wave(lo)[1]; for (let it = 0; it < 60; it++) { const mid = (lo + hi) / 2, fm = wave(mid)[1]; if ((fm > 0) === (flo > 0)) { lo = mid; flo = fm; } else hi = mid; }
    const [a] = wave((lo + hi) / 2), d = new Float32Array(LF_N), u = new Float32Array(LF_N); let acc = 0, mx = 0, ss = 0;
    for (let i = 0; i < LF_N; i++) { const v = a[Math.floor(i * M / LF_N)]; d[i] = v; ss += v * v; acc += v; u[i] = acc; mx = Math.max(mx, acc); }
    const mean = acc / LF_N, rms = Math.sqrt(ss / LF_N); for (let i = 0; i < LF_N; i++) { d[i] = (d[i] - mean) / rms; u[i] = Math.max(0, (u[i] - mean * i) / (mx || 1)); }
    return { d, u };
});
function klattRender(seq, vo) {
    const sr = KSR, dtc = 0.0025, FS = vo.fs || 1, BR = (vo.breath != null ? vo.breath : 0.05) * 2.4, tiltv = vo.tilt || 1.65;
    const rf = 0.07 + Math.max(0, tiltv - 1.25) * 0.28, OQ = vo.oq || (0.55 + Math.max(0, tiltv - 1.3) * 0.18), vibC = (vo.vib != null ? vo.vib : 12), wanC = (vo.wander != null ? vo.wander : 7), jitA = (vo.jit != null ? vo.jit : 130) / 130 * 0.008, RASP = vo.rasp || 0, DIP = vo.dip || 0;
    const SGR = !!vo.singer;   // engine v2 sung voice
    const rnd = Math.random, pj = 1 + (rnd() - 0.5) * 0.02, CG = vo.cgain || 1, BK = vo.burstK || 1, BG = vo.burstG != null ? vo.burstG : 1, SA = vo.softAtk || 1, AK = vo.aspK != null ? vo.aspK : 1;   // CG: consonant noise gain, BK: burst length (for sung words)
    const Rd0 = 0.5 + (tiltv - 1.2) * 0.8; let perRd = 1; const fw = [rnd() * 6.28, rnd() * 6.28, rnd() * 6.28];
    // ---- timeline ----
    const segs = []; let T = 0.04;
    let prevVl = false;
    for (const [nm, f0r, sc, f1r, amp, red, fin, wm] of seq) {   // wm = the word's own settings from the Voice Lab (undefined for an untouched word)
        const P = PH[nm]; if (!P) continue; const isVw = SUNG_V.has(nm), pmul = wm && wm.pitch ? Math.pow(2, wm.pitch / 12) : 1, f0 = f0r * pmul, f1 = f1r ? f1r * pmul : f1r;
        const d = P.d * (sc || 1) * (wm ? (isVw ? wm.vd : wm.cd) : 1), fj = 1 + (rnd() - 0.5) * 0.05;
        const open = (typeof OPENAMT !== 'undefined' && OPENAMT[nm] != null) ? OPENAMT[nm] : 0.5, lvl = (0.72 + 0.28 * open) * (amp || 1) * (wm ? wm.vol * (!isVw && P.v > 0 ? wm.camp : 1) : 1);
        const X = wm || vo.xm || { f1s: 1, f2s: 1, f3s: 1, ftime: 1, atk: 1, mumble: 0, pbend: 0, hf: 1, pre: 1, whisp: 0 };
        const sx = Object.assign(wm ? { cg: wm.hiss, bk: wm.burstK, bg: wm.burstG, sa: wm.soft, ak: wm.asp, fm: wm.fs, vm: wm.vol } : { cg: CG, bk: BK, bg: BG, sa: SA, ak: AK, fm: 1, vm: 1 }, { a1: X.f1s, a2: X.f2s, a3: X.f3s, ft: X.ftime, at: X.atk, mb: X.mumble, pb: X.pbend, hf: X.hf, pc: X.pre, wh: vo.whisper ? 1 : X.whisp });
        const vl = prevVl; prevVl = P.v < 0.3 && (P.n || P.pre);
        if (P.pre) { const dpc = P.pre * sx.pc; segs.push(Object.assign({ t: T, d: dpc, P, closure: true, f0, fj, lvl, vl }, sx)); T += dpc; }
        segs.push(Object.assign({ t: T, d, P, f0, f1, fj, lvl, nm, pre: P.pre || 0, red: red || 0, fin: !!fin, vl }, sx)); T += d;
    }
    if (!segs.length) return null;
    const tEnd = T, N = Math.ceil((T + 0.3) * sr), out = new Float32Array(N), outF = new Float32Array(N);
    // ---- state ----
    const st = { g1: 500, g2: 1500, g3: 2500, g0: seq[0][1] * pj, sib: 0, f0: seq[0][1] * pj, F1: 500, F2: 1500, F3: 2500, av: 0, av2: 0, ah: 0, af: 0, fc: 3000, fq: 1.2, nz: 0, nzf: 1200, cr: 0 };
    const fr = Math.ceil((T + 0.3) / dtc) + 2, tr = { f0: new Float32Array(fr), F1: new Float32Array(fr), F2: new Float32Array(fr), F3: new Float32Array(fr), av: new Float32Array(fr), ah: new Float32Array(fr), af: new Float32Array(fr), fc: new Float32Array(fr), fq: new Float32Array(fr), nz: new Float32Array(fr), nzf: new Float32Array(fr), cr: new Float32Array(fr) };
    const al = (tc) => 1 - Math.exp(-dtc / tc);
    const locusF2 = (pl, vf2) => pl === 'lab' ? vf2 * 0.55 + 800 * 0.45 : pl === 'alv' ? vf2 * 0.5 + 1750 * 0.5 : pl === 'vel' ? vf2 * 1.12 : vf2;
    let si = 0;
    for (let k = 0; k < fr; k++) {
        const tk = k * dtc; while (si < segs.length - 1 && segs[si + 1].t <= tk) si++;
        const sg = segs[si], nx = segs[si + 1], P = sg.P, loc = tk - sg.t, over = tk >= tEnd;
        const VOW = P.v >= 1 && !P.n && !P.pre, rd = Math.min(1, (sg.red || 0) + sg.mb);
        let tgt = { f0: sg.f0, F1: P.F[0] + (500 - P.F[0]) * rd * VOW, F2: P.F[1] + (1450 - P.F[1]) * rd * VOW, F3: P.F[2] + (2500 - P.F[2]) * rd * VOW, av: 0, ah: 0, af: 0, nz: 0 }, tcF = VOW ? Math.min(0.05, Math.max(0.02, sg.d * 0.24)) : Math.min(0.05, Math.max(0.02, sg.d * 0.3)), tcA = 0.016 / sg.at, tcN = 0.015, tcP = 0.03;
        if (P.Fend && VOW) { const u = Math.min(1, Math.max(0, (loc / sg.d - 0.16) / 0.64)), e = u * u * (3 - 2 * u); tgt.F1 = P.F[0] + (P.Fend[0] - P.F[0]) * e; tgt.F2 = P.F[1] + (P.Fend[1] - P.F[1]) * e; tgt.F3 = P.F[2] + (P.Fend[2] - P.F[2]) * e; tgt.F1 += (500 - tgt.F1) * rd; tgt.F2 += (1450 - tgt.F2) * rd; tgt.F3 += (2500 - tgt.F3) * rd; }   // the diphthong glide
        if (sg.closure) {   // closure: voicing fades (voiced stops keep a quiet voice bar); formants already head for the next sound
            const n2 = nx && nx.P ? nx.P : P; tgt.F1 = n2.F[0]; tgt.F2 = locusF2(P.place, n2.F[1]); tgt.F3 = n2.F[2] * (P.place === 'vel' ? 0.96 : 1); tgt.av = P.v > 0 ? 0.14 : 0; tgt.f0 = sg.f0; tcF = 0.03;
        } else {
            const vv = P.v * sg.lvl; tgt.av = vv; tgt.ah = (P.v > 0.5 ? BR : BR * 0.25);
            if (P.pre && nx && nx.P) { tgt.F2 = locusF2(P.place, nx.P.F[1]); tgt.F1 = nx.P.F[0] * 0.8; }   // a stop's release already points at the next vowel
            if (P.asp) { tgt.av = 0; tgt.ah = P.asp * Math.sin(Math.PI * Math.min(1, loc / sg.d)); }
            if (sg.vl && VOW && loc < 0.05) tgt.f0 *= 1.05 - loc;   // pitch bump after a voiceless consonant
            if (sg.fin && VOW && loc > sg.d * 0.5) tgt.cr = 1;
            if (sg.f1 && loc > sg.d * 0.35) tgt.f0 = sg.f1; if (P.n && P.v > 0) tgt.f0 = sg.f0 * 0.97;
            if (sg.pb && P.v > 0.3) tgt.f0 *= Math.pow(2, sg.pb / 12 * (Math.min(1, loc / sg.d) - 0.5));   // pitch bend across this sound
            if (P.zn) { tgt.nz = 1; st.nzf = P.zn * FS; }
            if (P.n) {
                st.sib = (sg.nm === 'S' || sg.nm === 'Z' || sg.nm === 'SH') ? 1 : 0; st.fc = P.n[1] * sg.hf * (FS > 1 ? Math.sqrt(FS) : 1); st.fq = P.n[3] || 1.2;
                if (sg.pre) {   // stop / affricate: burst at release, then aspiration (voiceless)
                    if (loc < 0.018 * sg.bk) { tgt.af = P.n[2] * 1.25 * sg.bg * sg.vm; }
                    else if (P.aff && loc < sg.d * 0.85) tgt.af = P.n[2] * 0.7 * sg.cg * sg.vm;
                    if (P.v === 0 && loc < 0.05) tgt.ah = Math.max(BR, (vo.unasp ? 0.16 : 0.5) * sg.ak * (1 - loc / (0.05 * sg.bk)));
                } else {
                    const u = loc / sg.d; tgt.af = P.n[2] * sg.cg * sg.vm * (u < 0.4 ? 0.85 * (u / 0.4) * (u / 0.4) : u < 0.6 ? 0.85 : u < 0.85 ? 0.55 : 0.15);   // a smooth swell, never a step
                }
            }
        }
        if (VOW && nx && !nx.closure && nx.P && nx.P.F && nx.P.v >= 0.5 && !nx.P.pre && !over) {   // coarticulation: the tract starts moving toward the next sound before this one ends
            const uu = Math.min(1, Math.max(0, (loc / sg.d - 0.3) / 0.7)), w = 0.7 * uu * uu * (3 - 2 * uu), nr = nx.red || 0, nv = nx.P.v >= 1 && !nx.P.n ? 1 : 0;
            tgt.F1 += (nx.P.F[0] + (500 - nx.P.F[0]) * nr * nv - tgt.F1) * w; tgt.F2 += (nx.P.F[1] + (1450 - nx.P.F[1]) * nr * nv - tgt.F2) * w; tgt.F3 += (nx.P.F[2] + (2500 - nx.P.F[2]) * nr * nv - tgt.F3) * w;
        }
        if (sg.wh && !over) { tgt.ah = Math.max(tgt.ah, P.v * sg.lvl * 0.55 * sg.wh); tgt.av *= 1 - 0.97 * sg.wh; }
        if (over) { tgt.av = 0; tgt.ah = 0; tgt.af = 0; tcA = 0.05; }
        const aF = al(tcF / sg.ft), aA = al(tcA), aN = al(sg.pre && loc < 0.02 && tgt.af > st.af ? 0.002 * sg.sa : (tgt.af > st.af ? 0.016 : (sg.pre && !P.aff ? 0.008 : 0.022))), aP = al(tcP);   // (a stop's burst now dies away fast: a long hiss tail made "t" ring like a cymbal)
        const aF2 = al(tcF * 0.55 / sg.ft);   // two cascaded stages = smooth S-shaped transitions, no corner at the segment boundary
        st.g1 += (tgt.F1 * sg.fj * FS * sg.fm * sg.a1 - st.g1) * aF2; st.g2 += (tgt.F2 * sg.fj * FS * sg.fm * sg.a2 - st.g2) * aF2; st.g3 += (tgt.F3 * sg.fj * FS * sg.fm * sg.a3 - st.g3) * aF2; st.F1 += (st.g1 - st.F1) * aF2; st.F2 += (st.g2 - st.F2) * aF2; st.F3 += (st.g3 - st.F3) * aF2;
        st.av += (tgt.av - st.av) * aA; st.av2 += (st.av - st.av2) * al(0.005);   // a second voicing stage: no corners at the start or end of a sound
        st.ah += (tgt.ah - st.ah) * al(0.02); st.af += (tgt.af - st.af) * aN; st.nz += (tgt.nz - st.nz) * al(0.02); st.cr += ((tgt.cr || 0) - st.cr) * al(0.04);
        { const aP2 = (loc < 0.02 && !sg.closure ? al(0.035) : aP) * 1.6; st.g0 += (tgt.f0 * pj - st.g0) * aP2; st.f0 += (st.g0 - st.f0) * aP2; }
        tr.F1[k] = st.F1; tr.F2[k] = st.F2; tr.F3[k] = st.F3; tr.av[k] = st.av2; tr.ah[k] = st.ah; tr.af[k] = st.af; tr.fc[k] = st.fc; tr.fq[k] = st.fq; tr.nz[k] = st.nz; tr.nzf[k] = st.nzf; tr.cr[k] = st.cr; tr.f0[k] = st.f0;
    }
    // ---- sample loop ----
    const res = () => ({ a: 0, b: 0, c: 0, y1: 0, y2: 0 }), r1 = res(), r2 = res(), r3 = res(), r4 = res(), r5 = res(), rfn = res();
    const setR = (r, F, BW) => { const c = -Math.exp(-2 * Math.PI * BW / sr), b = 2 * Math.exp(-Math.PI * BW / sr) * Math.cos(2 * Math.PI * Math.min(F, sr * 0.45) / sr); r.c = c; r.b = b; r.a = 1 - b - c; };
    const run = (r, x) => { const y = r.a * x + r.b * r.y1 + r.c * r.y2; r.y2 = r.y1; r.y1 = y; return y; };
    setR(r4, 3300 * FS, 300); setR(r5, 3850 * FS, 400);   // the two fixed upper formants never move
    const NZC = Math.exp(-2 * Math.PI * 120 / sr), NZB = 2 * Math.exp(-Math.PI * 120 / sr);
    let Lk = 0, Lfx = 0, f0m = 1, cr = 0; const L = (a) => a[Lk] + (a[Lk + 1] - a[Lk]) * Lfx;
    let ph = 0, per = { amp: 1, f: 1, odd: 0 }, ulast = 0, nx1 = 0, nx2 = 0, lp = 0, hpY = 0, hpX = 0, nzr = 0, nzx1 = 0, nzx2 = 0, noiseLP = 0; nzr = { A: 1, B: 0, C: 0 };
    const lfo1 = rnd() * 6.28, lfo2 = rnd() * 6.28, lfo3 = rnd() * 6.28, vph = rnd() * 6.28, rph = rnd() * 6.28;
    const FGAIN = 0.012;
    const pulse = (x, oq, rfall) => {   // glottal flow; peak at tp, falls by cosine over rfall*oq
        const tp = oq * (1 - rfall) * 0.85, tn = oq - tp; if (x >= oq) return 0;
        if (x < tp) return 0.5 * (1 - Math.cos(Math.PI * x / tp)); return Math.cos(Math.PI * 0.5 * (x - tp) / tn);
    };
    for (let i = 0; i < N; i++) {
        const ft = i / sr / dtc, tt = i / sr; Lk = Math.min(fr - 2, ft | 0); Lfx = ft - Lk;
        if ((i & 7) === 0) {   // refresh the resonator coefficients every ~0.35 ms (no zipper noise)
            const f1 = L(tr.F1), f2 = L(tr.F2), f3 = L(tr.F3);
            const tw = i / sr, w1 = 1 + 0.011 * Math.sin(6.28 * 3.1 * tw + fw[0]), w2 = 1 + 0.009 * Math.sin(6.28 * 4.3 * tw + fw[1]), w3 = 1 + 0.007 * Math.sin(6.28 * 5.7 * tw + fw[2]); setR(r1, f1 * w1, 62 + f1 * 0.04); setR(r2, f2 * w2, 92 + f2 * 0.028); setR(r3, f3 * w3, 135 + f3 * 0.03); 
            const fc = L(tr.fc); setR(rfn, fc, Math.max(300, fc / Math.max(0.4, L(tr.fq))));
            if (L(tr.nz) > 0.005) { const nf = L(tr.nzf) || 1200, c = -NZC, b = NZB * Math.cos(2 * Math.PI * nf / sr), a0 = 1 - b - c; nzr = { A: 1 / a0, B: -b / a0, C: -c / a0 }; }   // nasal anti-resonance only while it is in use
        }
        // ---- f0 with vibrato, wander, jitter ----
        if ((i & 15) === 0) { const vdep = vibC * 0.00058 * Math.min(1, Math.max(0, (tt - 0.12) / 0.25)) * (SGR ? 1 + 0.55 * Math.min(1, Math.max(0, (tt - 0.25) / 0.5)) : 1), wdep = wanC * 0.00058, vrate = SGR ? 5.3 + 0.5 * Math.sin(2 * Math.PI * 0.37 * tt + vph) : 5.4; cr = L(tr.cr); f0m = (1 - 0.07 * cr) * (SGR && tt < 0.12 ? 1 - 0.04 * Math.pow(1 - tt / 0.12, 2) : 1) * (1 + vdep * Math.sin(2 * Math.PI * vrate * tt + vph) + wdep * (Math.sin(2 * Math.PI * 2.1 * tt + lfo1) + 0.6 * Math.sin(2 * Math.PI * 3.7 * tt + lfo2) + 0.4 * Math.sin(2 * Math.PI * 0.9 * tt + lfo3)) * 0.6); }   // vibrato and wander move at a few Hz: a 1.4 kHz refresh is plenty
        let f0 = L(tr.f0) * f0m; cr = L(tr.cr);
        ph += f0 * per.f / sr;
        if (ph >= 1) { ph -= 1; per.f = 1 + (rnd() - 0.5) * 2 * jitA; per.amp = 1 + (rnd() - 0.5) * 0.12; per.odd ^= 1; perRd = 1 + (rnd() - 0.5) * 0.1; }
        const oq = OQ * (1 + 0.12 * (1 - Math.min(1, L(tr.av) * 1.3))) * (1 - 0.25 * cr);
        // LF glottal flow derivative; Rd (voice quality) follows loudness: louder = pressed/bright, softer = breathy; creak is tighter
        const Rd = Math.min(2.2, Math.max(0.4, Rd0 * (1.14 - 0.24 * Math.min(1, L(tr.av) * 1.3)) * (1 - 0.3 * cr) * perRd)), ri = (Rd - 0.35) / 0.18, r0 = Math.min(LF_RD.length - 2, Math.max(0, ri | 0)), rfr = Math.min(1, Math.max(0, ri - r0)), pj0 = ph * LF_N, j0 = pj0 | 0, j1 = (j0 + 1) % LF_N, jf = pj0 - j0;
        const TA = LFT[r0], TB = LFT[r0 + 1];
        const dA = TA.d[j0] + (TA.d[j1] - TA.d[j0]) * jf, dB = TB.d[j0] + (TB.d[j1] - TB.d[j0]) * jf, uA = TA.u[j0] + (TA.u[j1] - TA.u[j0]) * jf, uB = TB.u[j0] + (TB.u[j1] - TB.u[j0]) * jf;
        const u = uA + (uB - uA) * rfr, du = (dA + (dB - dA) * rfr) * 1.6 * (f0 / 122);
        let amp = per.amp; const dpN = DIP + cr * 0.4; if (dpN && per.odd) amp *= 1 - dpN;   // diplophonia: alternate periods weaker (a growl)
        let av = L(tr.av), ah = L(tr.ah);
        noiseLP += ((rnd() * 2 - 1) - noiseLP) * 0.3; const wn = noiseLP;
        let src = du * amp * av * 2.2 * Math.sqrt(130 / Math.max(60, f0)) + wn * ah * (0.25 + u * 0.9) * 0.3 * (vo.whisper ? 30 : 1);
        if (RASP) src *= 1 - RASP * 0.5 * (0.5 + 0.5 * Math.sin(2 * Math.PI * 32 * tt + rph));
        // nasal anti-resonance (blended in by the nasal amount)
        const nzm = L(tr.nz); if (nzm > 0.01) { const y = nzr.A * src + nzr.B * nzx1 + nzr.C * nzx2; nzx2 = nzx1; nzx1 = src; src = src * (1 - nzm) + y * nzm; } else { nzx2 = nzx1; nzx1 = src; }
        let y = run(r5, run(r4, run(r3, run(r2, run(r1, src)))));
        const af = L(tr.af); let fric = 0; if (af > 0.002) { const wn2 = rnd() * 2 - 1; const fy = run(rfn, wn2); fric = (st.sib ? fy * 0.9 : (fy - hpX) * 1.6) * af; hpX = fy; } else hpX = 0;   // frication / burst: first-difference (rising) spectrum
        out[i] = y * 0.037; outF[i] = fric * (vo.whisper ? 0.05 : 0.11);
    }
    // light post: gentle lowpass + soft clip
    // presence: a two-stage high shelf (about +9 dB above 2 kHz) so consonants and the F3-F4 region cut through, then a gentle top lowpass
    const bg = vo.bright != null ? vo.bright : 0.9, sA = 1 - Math.exp(-2 * Math.PI * 1700 / sr), sB = 1 - Math.exp(-2 * Math.PI * 4200 / sr); let s1 = 0, s2 = 0, l1 = 0, l2 = 0; const lpA = 1 - Math.exp(-2 * Math.PI * (vo.lp || 8200) / sr);
    const fA = 1 - Math.exp(-2 * Math.PI * 7800 / sr); let f1s = 0, f2s = 0;   // consonant noise: shelf only the voice, and take the edge off the hiss with its own lowpass
    for (let i = 0; i < N; i++) { const x = out[i]; s1 += (x - s1) * sA; s2 += (x - s2) * sB; const y = x + bg * (x - s1) + bg * 0.6 * (x - s2); f1s += (outF[i] - f1s) * fA; f2s += (f1s - f2s) * fA; l1 += (y + f2s * (1 + bg * 0.25) - l1) * lpA; l2 += (l1 - l2) * lpA; out[i] = Math.tanh(l2 * 2.0) / 2.0; }
    if (SGR) { const w0 = 2 * Math.PI * 2900 / sr, Q = 2.2, al = Math.sin(w0) / (2 * Q), cw = Math.cos(w0), A = Math.pow(10, 6.5 / 40), b0 = 1 + al * A, b1 = -2 * cw, b2 = 1 - al * A, a0 = 1 + al / A, a1 = -2 * cw, a2 = 1 - al / A; let x1 = 0, x2 = 0, y1 = 0, y2 = 0;   // the singer's formant: a +6.5 dB peak near 2.9 kHz, so a sung vowel carries over the band
        for (let i = 0; i < N; i++) { const x = out[i], y = (b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0; x2 = x1; x1 = x; y2 = y1; y1 = y; out[i] = y; } }
    const fadeN = (0.02 * sr) | 0; for (let i = 0; i < fadeN; i++) { out[N - 1 - i] *= i / fadeN; out[i] *= i / fadeN; }
    return out;
}
const KCACHE = new Map();
function speakSyn(dl, seq, vol, vo) {
    if (!AC || !seq.length || !PH[seq[0][0]]) return;
    vo = vo || {}; let buf, ck = null;
    if (vo.cache) { try { ck = JSON.stringify([seq, vo]); } catch (e) { ck = null; } buf = ck ? KCACHE.get(ck) : null; }   // sung words repeat a lot: render each distinct one once and replay it
    if (!buf) { buf = klattRender(seq, vo); if (buf && ck) { KCACHE.set(ck, buf); if (KCACHE.size > 160) KCACHE.delete(KCACHE.keys().next().value); } }
    if (!buf) return;
    const ab = AC.createBuffer(1, buf.length, KSR); ab.copyToChannel(buf, 0);
    const src = AC.createBufferSource(), out = AC.createGain(), send = AC.createGain(); src.buffer = ab; src.connect(out);
    out.gain.value = vol * SPEAK_LEVEL; out.connect(vo.cv ? cvBus() : speechBus());
    if (vo.fade != null) { const t0 = AC.currentTime + dl + 0.01, L = vol * SPEAK_LEVEL; out.gain.setValueAtTime(L, t0); out.gain.linearRampToValueAtTime(Math.max(0.0001, L * vo.fade), t0 + buf.length / KSR); }   // a decrescendo across the note
    send.gain.value = vo.verb !== undefined ? vo.verb : 0.16; out.connect(send); send.connect(vo.cv ? cvVerb() : speechVerb());
    if (vo.hold) vo.hold.push(src); else src.start(AC.currentTime + dl + 0.01); src.onended = () => { out.disconnect(); send.disconnect(); };
}
const hz = m => 440 * Math.pow(2, (m - 69) / 12), SUNG_MULTI = [[0.5, 0.9], [1, 1], [1.5, 1.1]];   // the sung chorus: octave below, unison, open fifth above (every fifth over a G-major chord tone stays in key)
function chordSing(ch) { let t = ch.v[0]; if (t < 55) t += 12; return [t, t + ch.v[1] - ch.v[0], t + ch.v[2] - ch.v[0], t + 12]; }
// ---------------- cutscene voices: a tiny English/Spanish text-to-phoneme planner on top of speakSyn, with per-character voices, mouth sync and speech bubbles ----------------
Object.assign(PH, {
    SH: { F: [300, 1800, 2600], d: 0.13, v: 0, n: ['bandpass', 4300, 0.8] }, CH: { F: [300, 1800, 2600], d: 0.1, v: 0, n: ['bandpass', 4300, 0.8], pre: 0.03 },
    TH: { F: [300, 1500, 2500], d: 0.08, v: 0.25, n: ['bandpass', 5800, 0.22] }, NG: { F: [260, 1500, 2500], d: 0.1, v: 0.55 },
    UH: { F: [450, 1100, 2400], d: 0.14, v: 1 }, ER: { F: [480, 1350, 1700], d: 0.18, v: 1 },
});
let CVB = null, CVV = null;
function cvBus() { if (!CVB || CVB.ctxOwner !== AC) { const c = AC.createDynamicsCompressor(); c.threshold.value = -16; c.knee.value = 10; c.ratio.value = 4; c.attack.value = 0.004; c.release.value = 0.14; const g = AC.createGain(); g.gain.value = 0.45; c.connect(g); g.connect(sfxGain); c.ctxOwner = AC; CVB = c; } return CVB; }
function ghostWail(dl, f, dur, vol, o) {   // a ghost's moan / cry on the speech engine: a long vowel, pitch gliding, wide vibrato, breathy
    o = o || {}; const vw = o.v || 'O', P = PH[vw], sc = dur / P.d;
    speakSyn(dl, [[vw, f, sc, f * (o.glide || 0.72), o.amp || 1, undefined, true]], vol, { cv: true, fs: o.fs || 1.0, tilt: 1.9, breath: o.breath != null ? o.breath : 0.22, vib: 60, wander: 28, jit: 260, verb: 0.85, lp: 6500, bright: 0.7 });
}
function cvVerb() {   // a darker, longer room for the ghosts
    if (!CVV || CVV.ctxOwner !== AC) { const len = (AC.sampleRate * 0.9) | 0, ir = AC.createBuffer(2, len, AC.sampleRate);
        for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); let lp = 0; for (let i = 0; i < len; i++) { lp += (Math.random() * 2 - 1 - lp) * 0.28; d[i] = lp * Math.pow(1 - i / len, 2.2); } }
        const cv = AC.createConvolver(); cv.buffer = ir; cv.connect(cvBus()); cv.ctxOwner = AC; CVV = cv; }
    return CVV;
}
const VOICES = {
    hero:   { clar: 1, name: 'HERO', col: '#ffd32a', f0: 122, fs: 1.0, bright: 4.0, lp: 7200, rate: 1.0, vib: 8, breath: 0.05, wander: 7, verb: 0.12, vol: 0.95, pr: 1.05, tilt: 1.5, jit: 120, uni: 7, mx: 1 },
    baron:  { name: 'THE BARON', col: '#ff6a5a', f0: 78, fs: 0.78, rate: 1.1, vib: 5, breath: 0.13, wander: 14, verb: 0.6, vol: 1.0, pr: 0.9, tilt: 1.35, lp: 4600, jit: 170, uni: 11, sub: 0.5, rasp: 0.3, dip: 0.3 },
    abuela: { name: 'ABUELA', col: '#ff9ecb', f0: 205, fs: 1.12, rate: 1.12, vib: 28, breath: 0.07, wander: 12, verb: 0.14, vol: 0.9, pr: 1.0, tilt: 1.95, lp: 5200, jit: 260, uni: 5 },
    kid:    { name: 'KID', col: '#7fe3ff', f0: 330, fs: 1.32, rate: 0.95, vib: 10, breath: 0.06, wander: 8, verb: 0.24, vol: 0.85, pr: 1.1, tilt: 2.0, lp: 7200, jit: 160, uni: 4 },
    guitar: { name: 'GUITARIST', col: '#9be37a', f0: 138, fs: 0.97, rate: 0.95, vib: 9, breath: 0.05, wander: 7, verb: 0.12, vol: 0.9, pr: 1.1, tilt: 1.6, jit: 120, uni: 6 },
    cry:    { name: 'CRY', col: '#ffd32a', f0: 200, fs: 1.0, rate: 1.0, vib: 14, breath: 0.05, wander: 9, verb: 0.16, vol: 0.7, pr: 1.0, tilt: 1.55, jit: 130, uni: 6 },
    chorus: { name: 'THE VILLAGERS', col: '#bcd6ff', f0: 150, fs: 1.0, rate: 1.05, vib: 14, breath: 0.1, wander: 10, verb: 0.55, vol: 0.62, pr: 1.0, tilt: 1.8, jit: 200, uni: 8, multi: [[0.78, 0.9], [1, 1], [1.4, 1.16]] },
};
const LEX = {
   hands: 'H AE1 N D Z', floating: 'F L OW1 T IH NG', asking: 'AE1 S K IH NG',
    whoa: 'W OW1', okay: 'OW1 K EY1', where: 'W EH1 R', ever: 'EH1 V ER', look: 'L UH1 K', at: 'AE1 T', stars: 'S T A1 R Z', are: 'A1 R', just: 'J AH1 S T', clapping: 'K L AE1 P IH NG', themselves: 'TH EH M S EH1 L V Z', have: 'H AE1 V', really: 'R I1 L I', looked: 'L UH1 K T', hand: 'H AE1 N D', oh: 'OW1', ghost: 'G OW1 S T', shh: 'SH', do: 'D U1', hear: 'H I1 R', whispering: 'W IH1 S P ER IH NG', stop: 'S T A1 P', asked: 'AE1 S K T', once: 'W AH1 N S', thirty: 'TH ER1 T I', held: 'H EH1 L D', together: 'T U G EH1 TH ER', lantern: 'L AE1 N T ER N', guitar: 'G IH T A1 R', string: 'S T R IH1 NG', fine: 'F AY1 N', smiling: 'S M AY1 L IH NG', see: 'S I1', head: 'H EH1 D', underneath: 'AH N D ER N I1 TH', heh: 'H EH1', good: 'G UH1 D', learned: 'L ER1 N D', name: 'N EY1 M', know: 'N OW1', then: 'TH EH1 N', remember: 'R I M EH1 M B ER', that: 'TH AE1 T', smile: 'S M AY1 L', time: 'T AY1 M', like: 'L AY1 K', days: 'D EY1 Z', day: 'D EY1', nine: 'N AY1 N', light: 'L AY1 T', night: 'N AY1 T', life: 'L AY1 F', mind: 'M AY1 N', find: 'F AY1 N D', kind: 'K AY1 N D', right: 'R AY1 T', hold: 'H OW1 L D', whole: 'H OW1 L', home: 'H OW1 M', alone: 'AH L OW1 N', always: 'AW1 L W EY Z', make: 'M EY1 K', take: 'T EY1 K', made: 'M EY1 D', away: 'AH W EY1', face: 'F EY1 S', late: 'L EY1 T', wait: 'W EY1 T', break: 'B R EY1 K', great: 'G R EY1 T', hate: 'H EY1 T', fake: 'F EY1 K', same: 'S EY1 M', shame: 'SH EY1 M', game: 'G EY1 M', play: 'P L EY1', pay: 'P EY1',
    arriba: 'A R I1 B A', andale: 'A N D A1 L EH', que: 'K EH1', por: 'P O1 R', si: 'S I1', ole: 'O L EH1', toro: 'T O1 R O', noh: 'N O1', problemo: 'P R O B L EH1 M O', frijoles: 'F R I H O1 L EH S', victoria: 'V I K T O1 R I A', jeff: 'J EH1 F', gay: 'G EY1', spelling: 'S P EH1 L IH NG', fun: 'F AH1 N',
    cannot: 'K AE1 N AW T', watch: 'W A1 CH', what: 'W AH1 T', than: 'TH AE1 N', were: 'W ER1', nothing: 'N AH1 TH IH NG',
    let: 'L EH1 T', it: 'IH1 T', turn: 'T ER1 N', your: 'Y AW1 R', skin: 'S K IH1 N', white: 'W AY1 T', and: 'AH N D', every: 'EH1 V R I', spirit: 'S P IH1 R IH T', in: 'IH N', this: 'TH IH1 S', valley: 'V AE1 L I',
    is: 'IH Z', saved: 'S EY1 V D', refuse: 'R I F Y U1 Z', they: 'TH EY1', stay: 'S T EY1', ghosts: 'G O1 U S T S', forever: 'F AW R EH1 V ER', please: 'P L I1 Z', say: 'S EY1', yes: 'Y EH1 S',
    no: 'N OW1', i: 'AY1', never: 'N EH1 V ER', cared: 'K EH1 R D', about: 'AH B AU1 T', village: 'V IH1 L IH J', glad: 'G L AE1 D', 'they\'re': 'TH EH1 R', gone: 'G AW1 N', 'i\'m': 'AY1 M',
    because: 'B I K AW1 Z', clapped: 'K L AE1 P T', for: 'F AW1 R', the: 'TH AH', sombrero: 'S O M B R EH1 R O', me: 'M I1', thank: 'TH AE1 NG K', you: 'Y U1', service: 'S ER1 V IH S',
    catch: 'K AE1 CH', if: 'IH1 F', can: 'K AE1 N', come: 'K AH1 M', back: 'B AE1 K', here: 'H I1 R', kneel: 'N I1 L', master: 'M AE1 S T ER', again: 'AH G EH1 N', sorry: 'S AW1 R I',
    louder: 'L AU1 D ER', feel: 'F I1 L', their: 'TH EH1 R', pain: 'P EY1 N', soon: 'S U1 N', drink: 'D R IH1 NG K', up: 'AH1 P', little: 'L IH1 T L', ones: 'W AH1 N Z', hero: 'H I1 R O',
    to: 'T U1', my: 'M AY1', cantina: 'K A N T I1 N A', mine: 'M AY1 N', pull: 'P UH1 L', why: 'W AY1', viva: 'V I1 V A', hula: 'U1 L A', vaquero: 'V A K EH1 R O', adios: 'A D I O1 S', globo: 'G L O1 B O',
    uno: 'U1 N O', dos: 'D O1 S', tres: 'T R EH1 S', tamales: 'T A M A1 L EH S', impossible: 'IH M P AW1 S IH B L', promise: 'P R AW1 M IH S', plaza: 'P L A1 S A', we: 'W I1', 'that\'s': 'TH AE1 T S', how: 'H AU1', kill: 'K IH1 L', balloon: 'B AH L U1 N', them: 'TH EH1 M', all: 'AW1 L', run: 'R AH1 N', keep: 'K I1 P', following: 'F AW1 L OW IH NG', baron: 'B AE1 R AH N', wondering: 'W AH1 N D ER IH NG', when: 'W EH1 N', ask: 'AE1 S K', would: 'W UH1 D', knew: 'N Y U1', as: 'AE Z', wish: 'W IH1 SH', am: 'AE1 M', first: 'F ER1 S T', pop: 'P A1 P', from: 'F R AH1 M', very: 'V EH1 R I', 'he': 'H I1', was: 'W AH Z', of: 'AH V', years: 'Y I1 R Z', fiestas: 'F I EH1 S T A S', not: 'N A1 T', one: 'W AH1 N', song: 'S AW1 NG', took: 'T UH1 K', hat: 'H AE1 T', a: 'AH', now: 'N AU1', will: 'W IH1 L', clap: 'K L AE1 P', so: 'S OW1', 'there': 'TH EH1 R', 'nobody': 'N O1 B AW D I', 'wanted': 'W AW1 N T IH D', ha: 'H A1', no2: 'N O1',
};
const FB = { a: 'A', e: 'EH', i: 'I', o: 'O', u: 'U', y: 'I', b: 'B', c: 'K', d: 'D', f: 'F', g: 'G', j: 'J', k: 'K', l: 'L', m: 'M', n: 'N', p: 'P', q: 'K', r: 'R', s: 'S', t: 'T', v: 'V', w: 'W', z: 'S', h: '', x: 'K S', 'ñ': 'N Y' };
const VOWELS = new Set(['EH', 'IH', 'AE', 'AW', 'AH', 'EY1', 'EY2', 'A', 'I', 'O', 'U', 'UH', 'ER']);
const OPENAMT = { A: 1, AH: 0.7, AE: 0.85, EH: 0.6, IH: 0.4, I: 0.3, O: 0.7, U: 0.4, UH: 0.5, ER: 0.45, AW: 0.8, EY1: 0.55, EY2: 0.3, F: 0.15, V: 0.15, S: 0.15, Z: 0.15, SH: 0.2, CH: 0.2, TH: 0.18, B: 0, M: 0, P: 0 };
const MX_MAP = { AE: ['A'], AH: ['A'], IH: ['I'], UH: ['U'], AW: ['O'], OW: ['O'], ER: ['EH', 'R'], TH: ['TD'], Z: ['S'], V: ['B'], SH: ['CH'], L: ['LC'], T: ['TD'], D: ['DD'] };   // a Mexican accent: five pure vowels, tapped r, no th / z / v / sh
Object.assign(LEX, { mexico: 'M EH1 H I K O', chido: 'CH I1 D O', ajua: 'A H U1 A', hijole: 'I H O1 L EH', echale: 'EH CH A1 L EH', viva: 'B I1 B A', vamonos: 'B A1 M O N O S', arriba: 'A R I1 B A', orale: 'O1 R A L EH', fiesta: 'F I EH1 S T A', compadre: 'K O M P A1 D R EH', caramba: 'K A R A1 M B A' });
// words the letter-by-letter fallback used to get wrong (long vowels, silent e, "gh", -ed, -ing): spelled out in the synth's own phonemes, for speech and for singing
const FIXED_WORDS = { date: 'D EY1 T', bate: 'B EY1 T', baked: 'B EY1 K T', done: 'D AH1 N', has: 'H AE1 Z', wants: 'W AA1 N T S', "he'll": 'H I1 L', next: 'N EH1 K S T', straight: 'S T R EY1 T', even: 'I1 V EH N', own: 'OW1 N', show: 'SH OW1', telling: 'T EH1 L IH NG', wondered: 'W AH1 N D ER D', cough: 'K AW1 F' };
Object.assign(LEX, FIXED_WORDS);
function mexToks(t) {
    const o = []; t.forEach(([n, st]) => { const m = MX_MAP[n]; if (m) m.forEach((x, i) => o.push([x, i ? 0 : st])); else o.push([n, st]); });
    if (o.length > 1 && o[0][0] === 'S' && !VOWELS.has(o[1][0])) o.unshift(['EH', 0]);   // "school" -> "eschool"
    return o;
}
const G2P_MULTI = [['tch', ['CH']], ['aigh', ['EY']], ['igh', ['AY']], ['ch', ['CH']], ['sh', ['SH']], ['th', ['TH']], ['ph', ['F']], ['ck', ['K']], ['ng', ['NG']], ['qu', ['K', 'W']], ['ai', ['EY']], ['ay', ['EY']], ['ee', ['I']], ['ea', ['I']], ['oa', ['OW']], ['oo', ['U']], ['ou', ['AU']], ['aw', ['AW']], ['au', ['AW']]], G2P_INIT = [['kn', ['N']], ['wr', ['R']], ['wh', ['W']]], G2P_LONG = { a: ['EY'], i: ['AY'], o: ['OW'], u: ['Y', 'U'] };
function g2pFallback(k) {   // spelling -> phonemes for a word that isn't in the lexicon: English digraphs, silent e, -ed and -ing; plain letters (the old five-vowel reading) for everything else
    let end = k.length, tail = [], longAt = -1, m;
    if ((m = /^(.*[^aeiou])ing$/.exec(k)) && k.length > 4) { end = k.length - 3; tail = ['IH', 'NG']; }
    else if (/[^aeiou]ed$/.test(k) && k.length > 3) { const c = k[k.length - 3]; end = k.length - 2; tail = 'pkfsx'.includes(c) || /(ch|sh)ed$/.test(k) ? ['T'] : 'td'.includes(c) ? ['IH', 'D'] : ['D']; if (/[aiou][bcdfgklmnpstvz]ed$/.test(k)) longAt = k.length - 4; }   // baked, hated: the e was silent, so the vowel is long
    else if (/[aiou][bcdfgklmnpstvz]e$/.test(k) && k.length > 3) { longAt = k.length - 3; end = k.length - 1; }
    const out = []; let first = true, i = 0;
    const push = p => { out.push(VOWELS.has(p) && first ? p + '1' : p); if (VOWELS.has(p)) first = false; };
    while (i < end) {
        const ch = k[i];
        if (i === longAt && G2P_LONG[ch]) { G2P_LONG[ch].forEach(push); i++; continue; }
        let hit = null; const lists = i === 0 ? G2P_INIT.concat(G2P_MULTI) : G2P_MULTI;
        for (const [pat, ph] of lists) if (k.startsWith(pat, i) && i + pat.length <= end) { hit = [pat, ph]; break; }
        if (hit) { hit[1].forEach(push); i += hit[0].length; continue; }
        if (ch === 'h') { push('H'); i++; continue; }   // English h is pronounced (the old letter table treated it as silent)
        if (ch === 'i' && i + 1 < end && !'aeiouy'.includes(k[i + 1])) { push('IH'); i++; continue; }   // closed syllable: bit, quick, thing
        const p = FB[ch]; if (p !== undefined) { push(p); if (!VOWELS.has(p) && k[i + 1] === ch) i++; }   // a doubled consonant is one sound
        i++;
    }
    tail.forEach(push); return out.join(' ');
}
function wordToks(w, mx) {
    const k = w.toLowerCase().replace(/[^a-zñ']/g, ''); let d = LEX[k];
    if (!d) d = g2pFallback(k);
    const out = [];
    for (const raw of d.split(' ').filter(Boolean)) {
        const m = /^([A-Z]+)([12])?$/.exec(raw), nm = m[1], st = m[2] ? 1 : 0;
        out.push([nm, st]);
    }
    const r = out.filter(t => PH[t[0]]); return mx ? mexToks(r) : r;
}
PH.AY = { F: [780, 1280, 2500], Fend: [400, 2050, 2650], d: 0.27, v: 1 }; PH.EY = { F: [540, 1850, 2500], Fend: [380, 2200, 2800], d: 0.25, v: 1 };   // 'eye', 'name': a smooth glide, not two separate vowels
PH.OW = { F: [520, 930, 2400], Fend: [350, 780, 2200], d: 0.25, v: 1 }; PH.AU = { F: [780, 1280, 2500], Fend: [370, 900, 2200], d: 0.26, v: 1 };
['AY', 'EY', 'OW', 'AU'].forEach(n => VOWELS.add(n)); Object.assign(OPENAMT, { AY: 0.75, EY: 0.5, OW: 0.55, AU: 0.75 });
PH.J.aff = true; PH.CH.aff = true;
Object.assign(PH.B, { place: 'lab' }); Object.assign(PH.P, { place: 'lab' }); Object.assign(PH.M, { place: 'lab' }); Object.assign(PH.D, { place: 'alv' }); Object.assign(PH.T, { place: 'alv' }); Object.assign(PH.N, { place: 'alv' }); Object.assign(PH.G, { place: 'vel' }); Object.assign(PH.K, { place: 'vel' }); Object.assign(PH.NG, { place: 'vel' }); Object.assign(PH.CH, { place: 'alv' }); Object.assign(PH.J, { place: 'alv' });
Object.assign(OPENAMT, { LC: OPENAMT.L == null ? 0.2 : OPENAMT.L, TD: OPENAMT.T == null ? 0.15 : OPENAMT.T, DD: OPENAMT.D == null ? 0.15 : OPENAMT.D });
PH.LC = Object.assign({}, PH.L, { F: [370, 1650, 2750] }); PH.TD = Object.assign({}, PH.T, { n: ['bandpass', 4300, 0.8, 1.2] }); PH.DD = Object.assign({}, PH.D, { n: ['bandpass', 3900, 0.5, 1.2] });   // clear (non-velarised) l; dental t and d with a brighter burst
PH.R.F = [420, 1250, 1650]; PH.ER.F = [480, 1350, 1600]; PH.L.F = [380, 1050, 2650]; PH.W.F = [300, 650, 2150]; PH.BH = { F: [620, 1400, 2500], d: 0.2, v: 0, asp: 0.55 }; Object.assign(PH.N, { zn: 1500 });
Object.assign(PH.EH, { F: [550, 1850, 2500] }); Object.assign(PH.IH, { F: [400, 2000, 2550] }); Object.assign(PH.AE, { F: [680, 1750, 2450] }); Object.assign(PH.AH, { F: [600, 1250, 2400] });
Object.assign(PH.AW, { F: [540, 880, 2450] }); Object.assign(PH.A, { F: [780, 1280, 2500] }); Object.assign(PH.I, { F: [290, 2250, 2950] }); Object.assign(PH.O, { F: [480, 850, 2400] }); Object.assign(PH.U, { F: [310, 880, 2250] }); Object.assign(PH.UH, { F: [440, 1020, 2240] }); Object.assign(PH.M, { zn: 900 }); Object.assign(PH.NG, { zn: 2100 });
PH.S.n = ['bandpass', 6000, 0.5, 1.1]; PH.F.n = ['bandpass', 5000, 0.3, 0.6]; PH.SH.n = ['bandpass', 3900, 0.55, 1.1]; PH.TH.n = ['bandpass', 5800, 0.2, 0.6]; PH.Z.n = ['bandpass', 5800, 0.4, 1.1]; PH.V.n = ['bandpass', 4600, 0.25, 0.6];
PH.T.n = ['bandpass', 3800, 0.7, 1.6]; PH.K.n = ['bandpass', 1900, 0.7, 1.3]; PH.P.n = ['bandpass', 900, 0.55, 0.8]; PH.B.n = ['bandpass', 800, 0.35, 0.8]; PH.D.n = ['bandpass', 3400, 0.4, 1.5]; PH.CH.n = ['bandpass', 4300, 0.75, 1.4]; PH.G.n = ['bandpass', 1800, 0.55, 1.2]; PH.J.n = ['bandpass', 3200, 0.7, 1.2];
const FUNC_WORDS = new Set(['a', 'an', 'the', 'to', 'of', 'in', 'on', 'at', 'for', 'and', 'or', 'but', 'is', 'are', 'was', 'be', 'it', 'i', 'you', 'he', 'she', 'we', 'they', 'my', 'your', 'me', 'them', 'this', 'their', 'can', 'if', 'your', 'so', 'as', 'with', 'by', 'from', 'that\'s', 'i\'m', 'they\'re', 'because', 'when', 'then']);
function planLine(text, V, raw) {   // -> { chunks:[{off, seq}], env:[{t0,d,o}], words:[{w,t}], dur }
    const chunks = [], env = [], words = []; let off = 0;
    if (raw) {   // hand-built sound (a wail, a laugh): [[phoneme, pitchMul, durScale]]
        let vi = 0; const seq = raw.map(([n, pm, sc], i) => { const f = V.f0 * pm, vow = VOWELS.has(n), long = vow && (sc || 1) >= 1.5; if (vow) vi++; return [n, f, (sc || 1) * (V.rate || 1), long ? f * (i === raw.length - 1 ? 0.78 : 0.9) : (vow ? f * 0.94 : undefined), vow ? Math.max(0.6, 1.2 - vi * 0.07) : 1, undefined, i === raw.length - 1 && long]; }); let tc = 0;
        seq.forEach(([n, f, sc]) => { const P = PH[n], d = P.d * sc + (P.pre || 0); env.push({ t0: tc, d, o: OPENAMT[n] == null ? 0.15 : OPENAMT[n] }); tc += d; });
        chunks.push({ off: 0, seq }); words.push({ w: text, t: 0 }); return { chunks, env, words, dur: tc };
    }
    const RG = (V.range || 1) * (V.noBreath ? 1 : 1.35), X = (m) => 1 + (m - 1) * RG;
    // humanising: seeded noise (stable for a given line while the planner is fitting a shout), a slow pitch walk, and small timing / stress variation
    const hv = V.human != null ? V.human : 3.2; let hs = 2166136261; for (let i = 0; i < text.length; i++) hs = Math.imul(hs ^ text.charCodeAt(i), 16777619); if (!V.noBreath) hs ^= (Date.now() & 0xffff) * 2654435761;
    const rnd = () => { hs = (hs + 0x6D2B79F5) | 0; let t = Math.imul(hs ^ (hs >>> 15), 1 | hs); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    let walk = 0, regOff = 0;
    if (text.length > 26 && !V.noBreath) { chunks.push({ off: 0, seq: [['BH', V.f0, 1, undefined, 0.8]] }); env.push({ t0: 0, d: 0.2, o: 0.35 }); off = 0.24; }   // an audible breath before a long line
    const parts = text.match(/[^,.!?…]+[,.!?…]*/g) || [];
    parts.forEach((part, pi) => {
        const punct = (part.match(/[,.!?…]+$/) || [''])[0], body = part.slice(0, part.length - punct.length), ws = body.trim().split(/\s+/).filter(Boolean), seq = []; let tc = 0;
        const q = /\?/.test(punct), ex = /!/.test(punct), comma = /,/.test(punct), lastPart = pi === parts.length - 1;
        const contentIdx = ws.map((w, i) => FUNC_WORDS.has(w.toLowerCase().replace(/[^a-zñ']/g, '')) ? -1 : i).filter(i => i >= 0), nuclear = contentIdx.length ? contentIdx[contentIdx.length - 1] : ws.length - 1;   // the last content word carries the nuclear accent
        let prevPhone = null;
        regOff = (rnd() - 0.5) * 0.02 * hv;
        ws.forEach((w, wi) => {
            const toks = wordToks(w, V.mx), wm = synSpeechWm(w), wrate = 1 + ((w.length * 7 + w.charCodeAt(0)) % 11 - 5) * 0.012, prog = (wi + 0.5) / ws.length, func = FUNC_WORDS.has(w.toLowerCase().replace(/[^a-zñ']/g, '')) && ws.length > 1, isNuc = wi === nuclear;
            words.push({ w: w + (wi === ws.length - 1 ? punct : ''), t: off + tc });
            let lastV = -1, firstV = -1; toks.forEach((tk, i) => { if (VOWELS.has(tk[0])) { lastV = i; if (firstV < 0 && tk[1]) firstV = i; } }); if (firstV < 0) firstV = lastV;
            let seenStress = false;
            const acc = isNuc ? 1.1 : 0.8, Xw = (m) => 1 + (m - 1) * RG * acc;
            toks.forEach(([nm, st], i) => {
                const isV = VOWELS.has(nm), fin = wi === ws.length - 1 && i === lastV, stressed = isV && st && !func;
                const base = V.f0 * V.pr * (1.09 - 0.2 * ((pi + prog) / parts.length));   // downdrift across the whole utterance
                let f = base * (func ? 0.96 : 1), f1 = 0, amp = func ? 0.78 : 1;
                if (stressed && i === firstV) {
                    if (isNuc) { if (q) { f = base * Xw(1.05); f1 = base * Xw(1.38); } else if (ex) { f = base * Xw(1.22); f1 = base * Xw(0.95); } else if (comma) { f = base * Xw(1.12); f1 = base * Xw(1.2); } else { f = base * Xw(1.14); f1 = base * Xw(V.mx && !lastPart ? 1.12 : 0.84); } amp = 1.2; }   // Chicano-style lilt: a pitch rise on the key word mid-sentence
                    else { f = base * Xw(1.1); f1 = base * Xw(1.17); amp = 1.1; }
                } else if (isV && wi > nuclear) f = base * 0.9;
                else if (isV && !stressed) f = base * (func ? 0.95 : (seenStress ? 1 - 0.09 * RG * acc : 0.98));
                if (fin && !f1 && !func) { if (q) f1 = base * Xw(1.3); else if (comma) f1 = base * Xw(1.1); else if (!ex) f1 = base * Xw(0.8); }
                if (isV) { walk = walk * 0.8 + (rnd() - 0.5) * 0.02 * hv; const hj = (1 + walk + regOff) * (1 + (rnd() - 0.5) * 0.02 * hv); f *= hj; if (f1) f1 *= hj;  }
                const lenMul = (isV ? (st ? (func ? 1.0 : V.mx ? 1.14 : 1.34) : V.mx ? 0.96 : 0.78) : 1) * (func && !isV ? 0.9 : 1) * (fin ? (punct ? 1.9 : 1.25) : 1) * (isNuc && stressed && i === firstV ? 1.12 : 1) * (1 + 0.12 * (V.clar || 0) * (isV ? 1 : 0.7));
                const sc = 0.74 * V.rate * lenMul * wrate * (1 + (rnd() - 0.5) * (isV ? 0.16 : 0.1) * hv), red = (isV && !st && !fin && !V.mx) ? (func ? 0.3 : 0.12) : 0;
                const P = PH[nm], d = P.d * sc + (P.pre || 0); seq.push([nm, f, sc, f1 || undefined, amp, red || undefined, (fin && !!punct && !comma && !ex) || undefined, wm]); if (stressed) seenStress = true; env.push({ t0: off + tc, d, o: OPENAMT[nm] == null ? 0.15 : OPENAMT[nm] }); tc += d; prevPhone = nm;
            });
            tc += (func ? 0.012 : 0.034) * (1 + (rnd() - 0.5) * 1.1 * hv);
        });
        if (seq.length) chunks.push({ off, seq });
        off += tc + (/…|\.\.\./.test(punct) ? 0.38 : /[.!?]/.test(punct) ? 0.24 : /,/.test(punct) ? 0.12 : 0.04);
    });
    return { chunks, env, words, dur: off };
}
const MOODS = {
    chill: { f: 0.95, range: 0.8, rate: 1.18, breath: 0.03, vol: 0.9, vib: 0.8 },
    cold: { f: 0.93, range: 0.5, rate: 1.16, breath: 0.03, vol: 0.9, vib: 0.4 }, rage: { f: 1.1, range: 1.7, rate: 0.9, tilt: -0.25, vol: 1.15, vib: 0.2 },
    mock: { f: 1.06, range: 1.9, rate: 1.0, vib: 1.5 }, gloat: { f: 0.95, range: 1.4, rate: 1.12, breath: 0.02, vol: 1.0 },
    plead: { f: 1.12, range: 1.3, rate: 1.15, breath: 0.08, vol: 0.8, vib: 1.8 }, whisper: { whisper: true, vol: 0.8, range: 0.7, rate: 1.1 },
    cheer: { f: 1.08, range: 1.5, rate: 0.92, vol: 1.08 }, stonemock: { f: 0.94, range: 1.5, rate: 1.22, breath: 0.05, vol: 0.98, vib: 0.9, rasp: 0.45 }, rageh: { f: 0.98, range: 1.9, rate: 0.82, vol: 1.2, tilt: -0.3, rasp: 1.1 }, stoned: { f: 0.86, range: 0.55, rate: 1.42, breath: 0.06, vol: 0.85, vib: 0.5, tilt: -0.12, rasp: 0.6 }, sad: { f: 0.9, range: 0.55, rate: 1.3, breath: 0.1, vol: 0.8, vib: 1.4 },
};
const MOOD_OF = { 'Impossible!': 'rage', 'Adios, globo!': 'cheer', 'So that\'s how you kill a balloon.': 'cold', 'Promise me. Every one of you, in the plaza.': 'cold', 'Mine!': 'cheer', 'Viva Hula Vaquero!': 'cheer', 'Come, come! Tamales for the hero!': 'cheer', 'Thank you!': 'cheer', 'Uno, dos, tres!': 'cheer', 'Soon...': 'whisper', 'Drink up, little ones.': 'gloat', 'To the hero!': 'cheer', 'Catch me if you can!': 'mock', 'Come back here!': 'rage', 'Feel their pain!': 'rage', 'Let it turn your skin white, and every spirit is saved. Refuse, and they stay ghosts forever.': 'gloat', 'Please... say yes!': 'plead', 'I was wondering when you would ask.': 'cold', 'No.': 'cold', 'You knew!': 'rage', 'From the very first pop.': 'cold', 'I never cared about this village.': 'cold', 'I\'m glad they\'re gone.': 'gloat', 'Thank you for your service.': 'mock', 'My cantina...': 'sad', 'Pull!': 'gloat', 'Yes, master.': 'sad', 'Kneel.': 'cold', 'As you wish, master.': 'sad', 'Again!': 'rage', 'Viva!': 'sad', 'Sorry!': 'plead', 'Why?': 'plead', 'Because I was never your hero, little one.': 'cold', 'They clapped for the sombrero. Never for me.': 'cold', 'Years of fiestas, and not one song was mine.': 'sad', 'So I took the hat, and I took the village. Now you will clap for me forever.': 'gloat', 'Louder!': 'rage', 'You cannot pop me, little vaquero!': 'rage', 'Watch me.': 'cheer' };
function moodV(V, mood) {   // a copy of a character voice with the delivery of a mood applied on top
    const m = MOODS[mood]; if (!m) return V; const o = Object.assign({}, V);
    o.f0 = V.f0 * (m.f || 1); o.range = m.range || 1; o.rate = V.rate * (m.rate || 1); o.breath = (V.breath || 0.05) + (m.breath || 0); o.vol = V.vol * (m.vol || 1); o.tilt = (V.tilt || 1.65) + (m.tilt || 0); o.vib = (V.vib || 10) * (m.vib != null ? m.vib : 1); o.whisper = !!m.whisper; if (m.rasp) o.rasp = (V.rasp || 0) + m.rasp;
    return o;
}
// ---- in-game shouts: the same planner, voices and moods as the cutscenes. The old hand-written note lists still set the timing and the melody ----
// ---- layered voice: several time-locked tracks (same timing and pitch, no delay, no echo, one shared reverb), each with its own job ----
//  1 main voice   2 larger tract + softer source (broadens the formant peaks)   3 smaller, brighter tract (consonant and vowel edge)
//  4 breath bed: the same phonemes as shaped airflow only (the natural noise under real speech)   5 chest: a lower, darker tract for body
function speakLayered(dl, seq, vol, vo) {
    // tracks share timing AND pitch (detuned copies beat against each other and sound metallic); the extras only add breath and body
    const fs = vo.fs || 1, tl = vo.tilt || 1.5, hold = [], q = { hold, verb: 0, uni: 0, sub: 0, rasp: 0, dip: 0, breath: 0, vib: 0, wander: 0, jit: 0 };
    speakSyn(dl, seq, vol * 0.9, Object.assign({}, vo, { hold }));
    if (!vo.whisper) speakSyn(dl, seq, vol * 0.22, Object.assign({}, vo, q, { whisper: true, bright: 0.5 }));
    const t = AC.currentTime + dl + 0.01; for (const src of hold) src.start(t);
}
function voOpts(V) { return { fs: V.fs, verb: V.verb, vib: V.vib, breath: V.breath, wander: V.wander, tilt: V.tilt, jit: V.jit, uni: V.uni, sub: V.sub, rasp: V.rasp, dip: V.dip, lp: V.lp, bright: V.bright, whisper: V.whisper, unasp: V.mx }; }
function refTrack(seq) {
    let t = 0; const pts = []; for (const [n, f, sc] of seq) { const P = PH[n]; if (!P) continue; const d = P.d * (sc || 1) + (P.pre || 0); pts.push([t + d / 2, f]); t += d; }
    const fs = pts.map(p => p[1]).slice().sort((a, b) => a - b), med = fs[fs.length >> 1] || 200; return { dur: t, med, pts: pts.map(([tt, f]) => [tt / t, f / med]) };
}
function contourAt(pts, u) { if (u <= pts[0][0]) return pts[0][1]; for (let i = 1; i < pts.length; i++) if (u <= pts[i][0]) { const a = pts[i - 1], b = pts[i], k = (u - a[0]) / Math.max(1e-6, b[0] - a[0]); return a[1] + (b[1] - a[1]) * k; } return pts[pts.length - 1][1]; }
function shout(dl, text, who, ref, o) {   // text -> speech, fitted to the duration and the pitch melody of the old note list `ref`
    o = o || {}; const vol = o.vol != null ? o.vol : 0.85;
    try {
        const rt = refTrack(ref); let V = Object.assign({}, moodV(VOICES[who], o.mood), { range: o.range != null ? o.range : 0.45, noBreath: true }, o.multi ? { multi: o.multi } : null), pl;
        for (let it = 0; it < 4; it++) { pl = planLine(text, V); V.rate = Math.min(3, Math.max(0.25, V.rate * rt.dur / Math.max(0.05, pl.dur))); }
        pl = planLine(text, V); const ratio = rt.med / (V.f0 * V.pr);
        if (o.notes) {   // sung: every vowel sits on a note of the tune; consonants lean into the vowel they belong to; no speech-style glides
            const toks = []; pl.chunks.forEach(c => { c.seq = c.seq.map(t => t.slice()); c.seq.forEach(t => toks.push(t)); });
            const vi = []; toks.forEach((t, i) => { if (VOWELS.has(t[0])) vi.push(i); }); const nv = vi.length, nn = o.notes;
            if (nv) {
                const fo = vi.map((ti, j) => nn[Math.round(j * (nn.length - 1) / Math.max(1, nv - 1))]);
                toks.forEach((t, i) => { let j = vi.findIndex(v => v >= i); if (j < 0) j = nv - 1; t[1] = fo[j]; if (VOWELS.has(t[0])) { t[3] = undefined; t[5] = undefined; } });   // no glide, no reduction
            }
        }
        for (const c of pl.chunks) {
            let tt = c.off; const seq = c.seq.map(([n, f, sc, f1, ...r]) => { const P = PH[n], d = P.d * sc + (P.pre || 0), k = o.notes ? 1 : ratio * contourAt(rt.pts, Math.min(1, (tt + d / 2) / pl.dur)); tt += d; return [n, f * k, sc, f1 ? f1 * k : f1, ...r]; });
            if (V.multi) V.multi.forEach(([pm, fm], k) => speakSyn(dl + c.off + k * 0.012, seq.map(([n, f, s, f1, ...r]) => [n, f * pm, s, f1 ? f1 * pm : f1, ...r]), vol * V.vol, Object.assign(voOpts(V), { fs: V.fs * fm })));
            else speakLayered(dl + c.off, seq, vol * V.vol, voOpts(V));
        }
    } catch (e) { console.warn('shout fell back: ' + (e && e.message)); speakSyn(dl, ref, vol); }
}
const SING_OPEN = new Set(['mom']);   // words tuned with diphthongs off whose open vowel (AA) must still count as the sung vowel, or the whole word is squeezed and starts early
const SING_LEX = {   // sung syllables spelled in the synth's own phonemes (I = "ee", A = "ah", EY = "ay", AU = "ow", AY = "eye")
    horns: 'H AW R N Z', trum: 'T R AH M', pets: 'P EH T S', blow: 'B L OW', the: 'TH AH', fyes: 'F Y EH S', tas: 'T A S', on: 'A N', jakes: 'J EY1 EY2 K S', mahm: 'M A M', mom: 'M AA M', is: 'IH Z', dan: 'D AE N', sing: 'S IH NG', till: 'T IH L', dawn: 'D AW N',
    clap: 'K L AE P', your: 'Y AW R', hands: 'H AE N D Z', hear: 'H I R', gi: 'G IH', tars: 'T A R S', ev: 'EH V', ree: 'R I', bo: 'B AH', dee: 'D I',
    like: 'L AY K', cuz: 'K AH Z', jake: 'J EY K',
    of: 'AH V', quite: 'K W AY T', most: 'M OW S T',
    plays: 'P L EY Z', with: 'W IH TH', prove: 'P R U V', not: 'N AA T', "jeff's": 'J EH F S', that: 'TH AE T',
    jeff: 'J EH F', gay: 'G EY', so: 'S OW', hey: 'H EY', shout: 'SH AU T', it: 'IH T', out: 'AU T', to: 'T U', day: 'D EY',
    te: 'T EH', kee: 'K I', las: 'L A S', flo: 'F L OW', wing: 'W IH NG', moon: 'M U N', high: 'H AY', som: 'S OW M', bre: 'B R EH', ros: 'R OW S', fly: 'F L AY', up: 'AH P', sky: 'S K AY',
    time: 'T AY M', all: 'AW L', night: 'N AY T', flow: 'F L OW', ma: 'M A', lez: 'L EH Z', brought: 'B R AW T', ta: 'T A', mah: 'M A', layz: 'L EH S', for: 'F AW R', crowd: 'K R AU D', loud: 'L AU D', vee: 'V I', va: 'V A', la: 'L A',
};
for (const k in FIXED_WORDS) if (!SING_LEX[k]) SING_LEX[k] = FIXED_WORDS[k].replace(/([A-Z]+)1/g, '$1');   // sung words take the same spellings without stress marks
// one sung syllable: the vowel takes whatever time the note leaves after its consonants, starts ON the beat (the onset consonant leads it), no speech prosody
PH.AA = { F: [850, 1180, 2500], d: 0.2, v: 1 };   // wide-open 'ah' for the word mom
const SUNG_V = new Set([...VOWELS, 'AY', 'EY', 'OW', 'AU', 'AA']);
// ---- SYNTH SETTINGS (tuned live in the Voice Lab, secret menu). Two paths: SPEECH (cutscenes, shouts) and SONG (sung lyrics). Each has base settings for every word,
//      plus per-word overrides that win over the base. The block between the two markers is rewritten by the lab's EXPORT; SAVE keeps versioned copies (last 11).
/*@SYN_BAKED_BEGIN*/const SYN_BAKED = {"v":6,"base":{"speech":{"pitch":0,"vol":1,"fs":1,"vd":1,"cd":1,"hiss":1,"burstG":0.6,"burstK":0.8,"soft":4,"asp":0.5,"camp":1,"f1s":1,"f2s":1,"f3s":1,"ftime":1,"atk":1,"mumble":0,"pbend":0,"hf":1,"pre":1,"whisp":0},"sung":{"pitch":-24,"vol":1.35,"fs":1,"cd":1,"hiss":1.5,"burstG":0.85,"burstK":1,"soft":3,"asp":0.5,"camp":1.6,"cap":0.66,"nas":0.5,"diph":1,"len":0.93,"lead":1,"dbl":0,"vib":5,"tilt":1.8,"verb":0.1,"breath":0,"jit":40,"wander":2,"rasp":0,"f1s":1,"f2s":1,"f3s":1,"ftime":1,"atk":1,"mumble":0,"pbend":0,"hf":1,"pre":1,"whisp":0}},"words":{"speech":{},"sung":{"jeff":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"is":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"gay":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"so":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"i":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"am":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"and":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"i'm":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"jakes":{"pitch":-12,"vol":1,"cd":1.0,"hiss":1.9,"burstG":1,"soft":1,"asp":0.35,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55,"burstK":0.7},"mom":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":0.4,"diph":0,"dbl":0.55},"like":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"cuz":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"of":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":1,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55},"jake":{"pitch":-12,"vol":1,"cd":0.7,"hiss":1,"burstG":1,"soft":1,"asp":0.35,"camp":1,"cap":0.55,"nas":1,"diph":0,"dbl":0.55,"burstK":0.7}}}};/*@SYN_BAKED_END*/
const SYN_FACTORY = JSON.parse(JSON.stringify(SYN_BAKED)), SYN_KEY = 'hulaVaquero_voicelab_v2';
const SYN_NEUTRAL = { pitch: 0, vol: 1, fs: 1, vd: 1, cd: 1, hiss: 1, burstG: 1, burstK: 1, soft: 1, asp: 1, camp: 1, f1s: 1, f2s: 1, f3s: 1, ftime: 1, atk: 1, mumble: 0, pbend: 0, hf: 1, pre: 1, whisp: 0 };
const synClone = o => JSON.parse(JSON.stringify(o));
function synMerge(c) {   // fill anything missing from the factory settings (new sliders added later get their defaults)
    const f = SYN_FACTORY, o = { v: c && c.v || 0, base: { speech: Object.assign({}, f.base.speech, c && c.base && c.base.speech), sung: Object.assign({}, f.base.sung, c && c.base && c.base.sung) }, words: { speech: {}, sung: {} } };
    ['speech', 'sung'].forEach(p => { const src = c && c.words && c.words[p] || f.words[p]; Object.keys(src).forEach(k => { o.words[p][k] = Object.assign({}, src[k]); }); });
    return o;
}
let SYN_STORE = { latest: SYN_BAKED.v, cur: SYN_BAKED.v, hist: [{ v: SYN_BAKED.v, cfg: synClone(SYN_BAKED) }] };   // hist = the last 11 saved versions (current + ten back)
let SYN = synMerge((SYN_STORE.hist.find(h => h.v === SYN_STORE.cur) || SYN_STORE.hist[SYN_STORE.hist.length - 1]).cfg), synWmCache = new Map();
const synKey = w => String(w).toLowerCase().replace(/[^a-zñ']/g, '');
const SYN_STD_SUNG = { pitch: -12, vol: 1, cd: 0.7, hiss: 1, burstG: 1, soft: 1, asp: 1, camp: 1, cap: 0.55, nas: 1, diph: 0, dbl: 0.55 };   // the shared sung-word tuning ("like", "mom", "cuz"): a sung word with no entry of its own starts here, so none can drift off in pitch or level
const synEff = (path, key) => Object.assign({}, SYN.base[path], !SYN.words[path][key] && path === 'sung' ? SYN_STD_SUNG : SYN.words[path][key]);
function synSpeechWm(w) {   // per-word speech settings as a token modifier, or undefined when the word is untouched (so unedited speech is exactly as before)
    const k = synKey(w); if (synWmCache.has(k)) return synWmCache.get(k);
    const e = synEff('speech', k); let r = undefined;
    for (const p in SYN_NEUTRAL) if (Math.abs(e[p] - SYN_NEUTRAL[p]) > 1e-9) { r = e; break; }
    synWmCache.set(k, r); return r;
}
let singWho = null, singMood = 'cheer', singShift = 0;   // the musical: who is singing, in what delivery, and how many semitones up from the written note (null = the chorus, as in the victory song)
function singSyl(dl, w, hzv, dur0, vol, o) {   // o (optional): { fade: end loudness 0..1 across the note, glide: semitones the pitch slides over the note }
    try {
        hzv *= Math.pow(2, singShift / 12);
        if (AC && !singHyb && !SYN.words.sung[synKey(w)]) nsongDuck(AC.currentTime + dl, AC.currentTime + dl + dur0);   // the band dips under each ordinary sung word (the Jeff words keep their own balance)
        const Q = singHyb ? SYN.base.sung : synEff('sung', synKey(w)), VS = (Q.diph || SING_OPEN.has(w.toLowerCase())) ? SUNG_V : VOWELS, CD = Q.cd, CAP = Q.cap, dur = Math.max(0.09, dur0 * Q.len);
        const CF = (nm, i) => (i < toks.length - 1 && (nm === 'M' || nm === 'N' || nm === 'NG')) ? CD * Q.nas : CD;   // a nasal before the vowel is short so the vowel keeps its colour; the closing hum keeps its length
        const V = Object.assign({}, moodV(VOICES[singWho || 'chorus'], singWho ? singMood : 'cheer'), { range: 0.3, noBreath: true }), toks = (SING_LEX[w.toLowerCase()] ? SING_LEX[w.toLowerCase()].split(' ').map(n => [n, 0]) : wordToks(w, false)).filter(t => PH[t[0]]);
        let cons = 0, pre = 0, seen = false, wsum = 0; const VW = n => (n === 'EY1' ? 0.4 : 1);
        toks.forEach(([nm], i) => { const P = PH[nm], d = P.d * CF(nm, i) + (P.pre || 0); if (VS.has(nm)) { seen = true; wsum += VW(nm); } else { cons += d; if (!seen) pre += d; } });
        const cs = cons > dur * CAP ? (dur * CAP / cons) : 1, room = Math.max(0.05, dur - cons * cs);
        const seq = toks.map(([nm], i) => { const P = PH[nm]; return [nm, hzv, VS.has(nm) ? Math.max(0.2, (room * VW(nm) / wsum - (P.pre || 0)) / P.d) : CF(nm, i) * cs, (o && o.glide && VS.has(nm)) ? hzv * Math.pow(2, o.glide / 12) : undefined, VS.has(nm) ? 1 : Q.camp]; });
        if (o && o.glide) { const ds = seq.map(e => PH[e[0]].d * e[2]), Tt = ds.reduce((x, y) => x + y, 0); let tc = 0; seq.forEach((e, i) => { e[1] = hzv * Math.pow(2, o.glide * tc / Tt / 12); tc += ds[i]; e[3] = hzv * Math.pow(2, o.glide * tc / Tt / 12); }); }   // one smooth slide over the whole word (every sound starts where the last one stopped)
        const at = Math.max(0.005, dl - pre * cs * Q.lead), oct = Math.pow(2, Q.pitch / 12);
        const dry = Object.assign(voOpts(V), { singer: !!(ENG2 && singWho && !singHyb), fade: o && o.fade != null ? o.fade : undefined, verb: Q.verb, uni: 0, sub: 0, rasp: Q.rasp, wander: Q.wander, jit: Q.jit, vib: Q.vib, breath: Q.breath, tilt: Q.tilt, cgain: Q.hiss, burstK: Q.burstK, burstG: Q.burstG, softAtk: Q.soft, aspK: Q.asp, xm: { f1s: Q.f1s, f2s: Q.f2s, f3s: Q.f3s, ftime: Q.ftime, atk: Q.atk, mumble: Q.mumble, pbend: Q.pbend, hf: Q.hf, pre: Q.pre, whisp: Q.whisp } });
        (Q.dbl > 0 ? [[0.5, 0.9, Q.dbl], [1, 1, 1]] : [[1, 1, 1]]).forEach(([pm, fm, lv]) => speakSyn(at, seq.map(([n, f, s, f1, ...r]) => [n, f * pm * oct, s, f1 ? f1 * pm * oct : f1, ...r]), vol * V.vol * 1.25 * lv * Q.vol, Object.assign({}, dry, { fs: V.fs * fm * Q.fs, cache: true })));
    } catch (e) { console.warn('singSyl: ' + (e && e.message)); }
}
let singHyb = false;   // true while the synth layer of a hybrid line is scheduled: it uses the plain sung settings and doesn't duck the band again
function singLine(dl, E, syls, vol) {
    if (nsongLine(dl, syls, vol)) {   // HYBRID verse singer: the neural line carries the words; the synth sings the same notes underneath it for the synth timbre
        if (NSONG_HYB > 0) { singHyb = true; try { syls.forEach(([w, st, ln, no]) => singSyl(dl + st * E, w, 440 * Math.pow(2, (no - 69) / 12), ln * E, vol * NSONG_HYB)); } finally { singHyb = false; } }
        return;
    }
    syls.forEach(([w, st, ln, no]) => singSyl(dl + st * E, w, 440 * Math.pow(2, (no - 69) / 12), ln * E, vol)); }
function shoutRaw(dl, ref, who, vol, mood) {   // a hand-built cry (wail, "ay!") with the character's voice quality
    const V = moodV(VOICES[who], mood); speakSyn(dl, ref.map(([n, f, sc]) => [n, f, sc]), vol * V.vol * 0.7, voOpts(V));
}
// a cough in three phases over ~0.35 s: (1) explosive release (noisy, his formants), (2) rough turbulent voiced "huh" (distorted, pitch lurching, ragged), (3) low creaky glottal fry as the folds close
function csCough(dl, amp, vol, V, k) {
    if (!AC || !noiseBuf) return; const t = AC.currentTime + dl + 0.01, v = vol * SPEAK_LEVEL * amp, rr = () => 0.88 + Math.random() * 0.24, out = AC.createGain(), send = AC.createGain(), f0 = V.f0 * (0.74 + 0.08 * amp);
    out.gain.value = 1; out.connect(cvBus()); send.gain.value = 0.06; out.connect(send); send.connect(cvVerb());
    const sat = AC.createWaveShaper(), cur = new Float32Array(257); for (let i = 0; i < 257; i++) { const x = (i - 128) / 128; cur[i] = Math.tanh(2.2 * x) * 0.9; } sat.curve = cur;   // harsh, distorted, throaty
    const master = AC.createGain(); master.gain.setValueAtTime(0.0001, t); master.gain.exponentialRampToValueAtTime(v * 1.1, t + 0.014); master.gain.setTargetAtTime(v * 0.8, t + 0.04, 0.05); master.gain.setTargetAtTime(0.0001, t + 0.18, 0.045);   // swell, shoulder, tail: a body, not a click
    master.connect(out);
    const F = [[600 * rr(), 480, 3.4, 1.1], [1080 * rr(), 880, 4.0, 0.8], [2200 * rr(), 1900, 4.0, 0.32]], bank = (inp, qm, wm) => F.forEach(([f1, f2, q, w]) => { const fl = AC.createBiquadFilter(), gg = AC.createGain(); fl.type = 'bandpass'; fl.Q.value = q * qm; fl.frequency.setValueAtTime(f1, t); fl.frequency.exponentialRampToValueAtTime(f2, t + 0.3); gg.gain.value = w * wm; inp.connect(fl); fl.connect(gg); gg.connect(master); });
    { const src = AC.createBufferSource(), fl = AC.createBiquadFilter(), g = AC.createGain(); src.buffer = noiseBuf; fl.type = 'bandpass'; fl.frequency.value = 1700 * rr(); fl.Q.value = 0.9; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.9 * v, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.045); src.connect(fl); fl.connect(g); g.connect(out); src.start(t, Math.random() * 0.3, 0.06); }   // the glottal release 'k'
    // 1+2: airy turbulence for the whole cough body
    { const src = AC.createBufferSource(), g = AC.createGain(); src.buffer = noiseBuf; src.loop = true; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(1.0, t + 0.01); g.gain.setTargetAtTime(0.22, t + 0.03, 0.03); g.gain.setTargetAtTime(0.0001, t + 0.17, 0.04); src.connect(g); bank(g, 1, 0.9); src.start(t, Math.random() * 0.3, 0.45); src.onended = () => { master.disconnect(); out.disconnect(); send.disconnect(); }; }
    // 2: rough voiced "huh": wobbling, lurching pitch, ragged amplitude, then distorted
    { const o = AC.createOscillator(), am = AC.createGain(), g = AC.createGain(), N = 20, pc = new Float32Array(N), ac = new Float32Array(N); o.setPeriodicWave(glotWave(0.9));
        for (let i = 0; i < N; i++) { const u = i / (N - 1); pc[i] = f0 * (1.3 - 0.6 * u) * (1 + (Math.random() - 0.5) * 0.18); ac[i] = 0.55 + 0.45 * Math.random(); }
        o.frequency.setValueCurveAtTime(pc, t + 0.02, 0.2); am.gain.setValueAtTime(0.5, t); am.gain.setValueCurveAtTime(ac, t + 0.02, 0.2);
        g.gain.setValueAtTime(0.0001, t + 0.02); g.gain.exponentialRampToValueAtTime(1.15, t + 0.035); g.gain.setTargetAtTime(0.0001, t + 0.15, 0.035); o.connect(am); am.connect(sat); sat.connect(g); bank(g, 1.3, 1.0); o.start(t + 0.02); o.stop(t + 0.3); }
    // 3: creaky fry, pulses far below speech pitch
    { const o = AC.createOscillator(), g = AC.createGain(), lp = AC.createBiquadFilter(); o.setPeriodicWave(glotWave(0.8)); o.frequency.setValueAtTime(f0 * 0.66, t + 0.15); o.frequency.exponentialRampToValueAtTime(f0 * 0.4, t + 0.34); lp.type = 'lowpass'; lp.frequency.value = 1500;
        g.gain.setValueAtTime(0.0001, t + 0.15); g.gain.exponentialRampToValueAtTime(0.4, t + 0.19); g.gain.setTargetAtTime(0.0001, t + 0.22, 0.035); o.connect(sat); sat.connect(lp); lp.connect(g); g.connect(master); o.start(t + 0.15); o.stop(t + 0.4); }
}
function csHack(dl, dur, amp, vol, V) {   // a deep rattling throat-clear: harsh fry buzz with a fast flutter, rising then dying in a wet rasp
    if (!AC || !noiseBuf) return; const t = AC.currentTime + dl + 0.01, v = vol * SPEAK_LEVEL * amp, out = AC.createGain(), sat = AC.createWaveShaper(), cur = new Float32Array(257); for (let i = 0; i < 257; i++) { const x = (i - 128) / 128; cur[i] = Math.tanh(2.6 * x) * 0.9; } sat.curve = cur;
    out.gain.setValueAtTime(0.0001, t); out.gain.exponentialRampToValueAtTime(v, t + dur * 0.55); out.gain.setTargetAtTime(0.0001, t + dur * 0.8, dur * 0.1); out.connect(cvBus());
    const flut = AC.createOscillator(), fg = AC.createGain(), amG = AC.createGain(); flut.frequency.value = 26 + Math.random() * 6; fg.gain.value = 0.7; amG.gain.value = 0.3; flut.connect(fg); fg.connect(amG.gain); flut.start(t); flut.stop(t + dur + 0.3);   // the rattle
    amG.connect(sat); sat.connect(out);
    const F = [[560, 500, 2, 0.8], [1150, 1000, 2.5, 0.5], [2100, 1900, 3, 0.2]];
    { const o = AC.createOscillator(); o.setPeriodicWave(glotWave(0.95)); { const N = 24, pc = new Float32Array(N); for (let i = 0; i < N; i++) pc[i] = Math.min(95, V.f0 * 0.3) * (0.8 + Math.random() * 0.4) * (1 - 0.25 * i / N); o.frequency.setValueCurveAtTime(pc, t, dur); }   // low, ragged creak: no smooth pitch glide (that sounded like a whinny)
        F.forEach(([a, b, q, w]) => { const fl = AC.createBiquadFilter(), g = AC.createGain(); fl.type = 'bandpass'; fl.Q.value = q; fl.frequency.setValueAtTime(a, t); fl.frequency.linearRampToValueAtTime(b, t + dur * 0.6); g.gain.value = w; o.connect(fl); fl.connect(g); g.connect(amG); }); o.start(t); o.stop(t + dur + 0.3); }
    { const src = AC.createBufferSource(), fl = AC.createBiquadFilter(), g = AC.createGain(); src.buffer = noiseBuf; src.loop = true; fl.type = 'bandpass'; fl.frequency.value = 1300; fl.Q.value = 1.1; g.gain.value = 1.6; src.connect(fl); fl.connect(g); g.connect(amG); src.start(t, Math.random() * 0.3, dur + 0.3); src.onended = () => { out.disconnect(); amG.disconnect(); }; }
}
function csSpit(dl, vol, V) {   // a wet gather in the throat then a sharp "ptoo" with a slick blip
    if (!AC || !noiseBuf) return; const t = AC.currentTime + dl + 0.01, v = vol * SPEAK_LEVEL, out = AC.createGain(); out.gain.value = 1; out.connect(cvBus());
    { const src = AC.createBufferSource(), fl = AC.createBiquadFilter(), g = AC.createGain(), l = AC.createOscillator(), lg = AC.createGain(); src.buffer = noiseBuf; src.loop = true; fl.type = 'bandpass'; fl.Q.value = 2; fl.frequency.setValueAtTime(380, t - 0.05); fl.frequency.linearRampToValueAtTime(760, t); l.frequency.value = 17; lg.gain.value = 0.4; g.gain.value = 0.5; l.connect(lg); lg.connect(g.gain); l.start(t - 0.05); l.stop(t + 0.01);
        const e = AC.createGain(); e.gain.setValueAtTime(0.0001, t - 0.05); e.gain.exponentialRampToValueAtTime(0.5 * v, t - 0.01); e.gain.exponentialRampToValueAtTime(0.0001, t + 0.01); src.connect(fl); fl.connect(g); g.connect(e); e.connect(out); src.start(t - 0.05, Math.random() * 0.3, 0.12); }   // gurgle
    [[2600, 1.2, 0.95, 0.07], [1100, 0.8, 0.8, 0.09]].forEach(([f, q, w, d]) => { const src = AC.createBufferSource(), fl = AC.createBiquadFilter(), g = AC.createGain(); src.buffer = noiseBuf; fl.type = 'bandpass'; fl.frequency.value = f; fl.Q.value = q; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(w * v, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + d); src.connect(fl); fl.connect(g); g.connect(out); src.start(t, Math.random() * 0.3, d + 0.02); });
    { const o = AC.createOscillator(), g = AC.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(1100, t + 0.01); o.frequency.exponentialRampToValueAtTime(260, t + 0.1); g.gain.setValueAtTime(0.0001, t + 0.01); g.gain.exponentialRampToValueAtTime(0.28 * v, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12); o.connect(g); g.connect(out); o.start(t + 0.01); o.stop(t + 0.15); o.onended = () => out.disconnect(); }   // wet blip
}
function csTap(dl, vol) {   // a card tick on a hard surface
    if (!AC || !noiseBuf) return; const t = AC.currentTime + dl + 0.01, src = AC.createBufferSource(), fl = AC.createBiquadFilter(), g = AC.createGain(); src.buffer = noiseBuf; fl.type = 'bandpass'; fl.frequency.value = 3600 + Math.random() * 800; fl.Q.value = 1.4; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.5 * vol, t + 0.002); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.03); src.connect(fl); fl.connect(g); g.connect(cvBus()); src.start(t, Math.random() * 0.3, 0.05);
}
function csCrinkle(dl, d, vol) {   // plastic bag rustle: jittery high noise bursts
    if (!AC || !noiseBuf) return; const t = AC.currentTime + dl + 0.01, src = AC.createBufferSource(), fl = AC.createBiquadFilter(), g = AC.createGain(), n = Math.floor(d * 30), c = new Float32Array(n); for (let i = 0; i < n; i++) c[i] = (Math.random() < 0.55 ? 0.05 : 0.4 + Math.random() * 0.6) * vol; src.buffer = noiseBuf; src.loop = true; fl.type = 'highpass'; fl.frequency.value = 2800; g.gain.setValueCurveAtTime(c, t, d); src.connect(fl); fl.connect(g); g.connect(cvBus()); src.start(t, Math.random() * 0.3, d + 0.1);
}
function csSniff(dl, d, vol) {   // a hard nasal snort in: rough noise sweeping down through the nose band
    if (!AC || !noiseBuf) return; const t = AC.currentTime + dl + 0.01, v = vol * SPEAK_LEVEL;
    [[2200, 900, 1.6, 1.0], [900, 500, 2.5, 0.6]].forEach(([a, b, q, w]) => { const src = AC.createBufferSource(), fl = AC.createBiquadFilter(), g = AC.createGain(), l = AC.createOscillator(), lg = AC.createGain(); src.buffer = noiseBuf; src.loop = true; fl.type = 'bandpass'; fl.Q.value = q; fl.frequency.setValueAtTime(a, t); fl.frequency.exponentialRampToValueAtTime(b, t + d); l.frequency.value = 40; lg.gain.value = 0.35; l.connect(lg); const am = AC.createGain(); am.gain.value = 0.65; lg.connect(am.gain); l.start(t); l.stop(t + d + 0.1);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(w * v, t + d * 0.25); g.gain.setTargetAtTime(0.0001, t + d * 0.8, d * 0.08); src.connect(fl); fl.connect(am); am.connect(g); g.connect(cvBus()); src.start(t, Math.random() * 0.3, d + 0.4); });
}
function csGasp(dl, d, amp, vol, V) {   // a ragged, whistly breath in, no vowel
    if (!AC || !noiseBuf) return; const t = AC.currentTime + dl + 0.01, v = vol * SPEAK_LEVEL * amp, out = AC.createGain(); out.gain.value = 1; out.connect(cvBus());
    [[700, 2000, 1.2, 0.9], [1600, 3200, 5, 0.35]].forEach(([a0, a1, q, w]) => { const src = AC.createBufferSource(), fl = AC.createBiquadFilter(), g = AC.createGain(); src.buffer = noiseBuf; src.loop = true; fl.type = 'bandpass'; fl.Q.value = q; fl.frequency.setValueAtTime(a0, t); fl.frequency.exponentialRampToValueAtTime(a1, t + d);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(w * v, t + d * 0.85); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.05); src.connect(fl); fl.connect(g); g.connect(out); src.start(t, Math.random() * 0.2, d + 0.08); src.onended = () => out.disconnect(); });
}