
function drawFps() {
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; roundRect(W - 92, H - 22, 86, 18, 6); ctx.fill();
    ctx.fillStyle = fps >= 50 ? '#2ecc71' : fps >= 30 ? '#f1c40f' : '#e74c3c';
    ctx.font = 'bold 11px system-ui, sans-serif'; ctx.textAlign = 'right';
    ctx.fillText(`${fps} FPS · ${RES}x`, W - 12, H - 9); ctx.textAlign = 'left';
}

function render() {
    uiButtons = []; glowLeft = 320;
    if (mode !== 'menu' && mode !== 'shop' && mode !== 'wardrobe' && mode !== 'trophies' && mode !== 'stats' && !(mode === 'options' && optsReturn === 'menu')) menuSeen = -1;
    ctx.setTransform(RES, 0, 0, RES, 0, 0);
    const ingame = g && (mode === 'play' || mode === 'levelup' || mode === 'pause' || mode === 'over' || mode === 'clear' || (mode === 'options' && optsReturn === 'pause'));
    drawSky(ingame ? skyFrame() : (mode === 'cutscene' && cs) ? csSky() : 0);
    if (ingame) {
        drawWorld();
        if (g.kind === 'convoy') drawConvoyDeck();
        if (mode === 'play') { drawLowHp(); drawHUD(); if (g.god) drawGodBadge(); if (g.camp) { drawCampHUD(); if (g.intro > 0) drawLevelIntro(); } else if (g.intro > 0) drawAndale(); }
        if (mode === 'clear') drawClear();
        if (mode === 'levelup') drawLevelUp();
        if (mode === 'pause') drawPause();
        if (mode === 'over') drawOver();
        if (mode === 'options') drawOptions();
    } else if (mode === 'map') drawMap();
    else if (mode === 'wshop') drawWShop();
    else if (mode === 'shop') drawShop();
    else if (mode === 'options') drawOptions();
    else if (mode === 'wardrobe') drawWardrobe();
    else if (mode === 'trophies') drawTrophies();
    else if (mode === 'stats') drawStats();
    else if (mode === 'cutmenu') drawCutMenu();
    else if (mode === 'songmenu') drawSongMenu();
    else if (mode === 'musmenu') drawMusMenu();
    else if (mode === 'cutscene' && cs) drawCutscene();
    else drawMenu();
    if (OPT.fps) drawFps();
}

// =====================================================================
//  INPUT
// =====================================================================
function toLocal(e) {
    const r = canvas.getBoundingClientRect();
    return { x: (e.clientX - r.left) / r.width * W, y: (e.clientY - r.top) / r.height * H };
}
canvas.addEventListener('pointerdown', e => {
    ptrStamp = e.timeStamp;   // the moment of the touch itself (not the frame it is handled in): the beat calibration needs it
    e.preventDefault();
    audioInit();
    const pt = toLocal(e);
    for (let i = uiButtons.length - 1; i >= 0; i--) {
        const b = uiButtons[i];
        if (pt.x >= b.x && pt.x <= b.x + b.w && pt.y >= b.y && pt.y <= b.y + b.h) { if (b.drag) { uiDrag = b; uiDragId = e.pointerId; b.drag(pt); try { canvas.setPointerCapture(e.pointerId); } catch (err) {} return; } b.fn(); return; }
    }
    if (mode === 'cutscene') { csNext(); return; }
    if (mode === 'play' && g && !drag && g.kind !== 'convoy') {
        drag = { id: e.pointerId, sx: pt.x, sy: pt.y, ox: g.player.x, oy: g.player.y, tx: g.player.x, ty: g.player.y };
        try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    }
});
canvas.addEventListener('pointermove', e => {
    if (uiDrag && e.pointerId === uiDragId) { uiDrag.drag(toLocal(e)); return; }
    if (!drag || e.pointerId !== drag.id) return;
    const pt = toLocal(e);
    drag.tx = drag.ox + (pt.x - drag.sx) * OPT.sens;
    drag.ty = drag.oy + (pt.y - drag.sy) * OPT.sens;
});
const endDrag = e => { if (uiDrag && e.pointerId === uiDragId) { if (uiDrag.end) uiDrag.end(); uiDrag = null; return; } if (drag && e.pointerId === drag.id) drag = null; };
canvas.addEventListener('pointerup', endDrag);
canvas.addEventListener('pointercancel', endDrag);

const KEYMAP = { ArrowLeft: 'left', a: 'left', A: 'left', ArrowRight: 'right', d: 'right', D: 'right', ArrowUp: 'up', w: 'up', W: 'up', ArrowDown: 'down', s: 'down', S: 'down' };
window.addEventListener('keydown', e => {
    audioInit();
    if (KEYMAP[e.key]) { keys[KEYMAP[e.key]] = true; e.preventDefault(); }
    if (e.key === ' ') e.preventDefault();
    if (e.repeat) return;
    if (e.key === 'm' || e.key === 'M') { OPT.music = !OPT.music; applyVol(); persist(); }
    if (e.key === 'f' || e.key === 'F') { OPT.fps = !OPT.fps; persist(); }
    if (mode === 'play') {
        if (g.kind === 'convoy') {
            if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') cvSteer(-1);
            else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') cvSteer(1);
            else if (e.key === '1' || e.key === 'ArrowUp') cvHoop();
            else if (e.key === '2' || e.key === 'ArrowDown') cvRam();
            else if (e.key === '3') cvSalsaTool();
            else if (e.key === 'Enter' || e.key === ' ') cvEndTurn();
        }
        if (e.key === ' ' || e.key === 'Shift') { if (g.kind === 'rpg' && !g.actives.dash) rpgRoll(); else useActive('dash'); }
        if (e.key === 'q' || e.key === 'Q') useActive('slow');
        if (g.kind === 'rpg' && (e.key === 'j' || e.key === 'J' || e.key === 'z' || e.key === 'Z')) rpgAttack();
        if (g.kind === 'rpg' && (e.key === 'k' || e.key === 'K' || e.key === 'x' || e.key === 'X')) rpgVolley();
        if (g.kind === 'race' && (e.key === 'b' || e.key === 'B')) raceBoost();
        if (e.key === 'r' || e.key === 'R') useActive('cape');
        if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') { mode = 'pause'; drag = null; }
    } else if (mode === 'pause') {
        if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') mode = 'play';
    } else if (mode === 'levelup') {
        if (e.key >= '1' && e.key <= '3') chooseCard(+e.key - 1);
        if (e.key === 'r' || e.key === 'R') rerollChoices();
    } else if (mode === 'options') {
        if (e.key === 'Escape') mode = optsReturn;
    } else if (mode === 'songmenu' || mode === 'musmenu') {
        if (e.key === 'Escape') { secretGo('cutmenu'); }
    } else if (mode === 'cutmenu') {
        if (e.key === 'Escape') mode = 'menu';
    } else if (mode === 'shop' || mode === 'wardrobe' || mode === 'trophies' || mode === 'stats') {
        if (e.key === 'Escape') mode = 'menu';
    } else if (mode === 'cutscene') {
        if (e.key === 'Escape') endCutscene(); else if (e.key === ' ' || e.key === 'Enter') csNext();
    } else if (mode === 'map') {
        if (e.key === 'Escape') mapBack(); else if (e.key === 'Enter' || e.key === ' ') mapGo();
    } else if (mode === 'wshop') {
        if (e.key === 'Escape' || e.key === 'Enter') leaveShop();
    } else if (mode === 'clear') {
        if (e.key === 'Enter' || e.key === ' ') clearContinue();
    } else if (mode === 'menu' || mode === 'over') {
        if (e.key === 'Enter' || e.key === ' ') { if (mode === 'menu') ride(); else if (g && g.camp) openMap(); else startRun(); }
    }
});
window.addEventListener('keyup', e => { if (KEYMAP[e.key]) keys[KEYMAP[e.key]] = false; });
// ---- gamepad: sticks / d-pad move, buttons mirror the keyboard by sending the same key events ----
const padPrev = { left: false, right: false, up: false, down: false }, padBtn = {};
function padKey(key) { window.dispatchEvent(new KeyboardEvent('keydown', { key })); }
let padBlocked = false;
function pollGamepad() {
    if (padBlocked) return; let pads = null; try { pads = navigator.getGamepads ? navigator.getGamepads() : null; } catch (e) { padBlocked = true; return; }   // some embeds (app previews) forbid the gamepad API by permissions policy
    if (!pads) return;
    let gp = null; for (const p of pads) if (p && p.connected) { gp = p; break; }
    if (!gp) return;
    const B = i => !!(gp.buttons[i] && gp.buttons[i].pressed), ax = gp.axes[0] || 0, ay = gp.axes[1] || 0;
    const now = { left: ax < -0.35 || B(14), right: ax > 0.35 || B(15), up: ay < -0.35 || B(12), down: ay > 0.35 || B(13) };
    for (const k in now) if (now[k] !== padPrev[k]) { keys[k] = now[k]; padPrev[k] = now[k]; needRender = true; }
    const play = mode === 'play', rpg = g && g.kind === 'rpg', lvl = mode === 'levelup';
    const map = {
        0: lvl ? '1' : ' ', 1: lvl ? '2' : play ? 'q' : 'Escape', 2: lvl ? '3' : play ? (rpg ? 'j' : 'r') : 'Enter',
        3: lvl ? 'r' : play ? (rpg ? 'k' : 'r') : 'Enter', 4: 'r', 5: 'b', 9: play || mode === 'pause' ? 'p' : 'Enter',
    };
    for (const i in map) { const d = B(+i); if (d && !padBtn[i]) { needRender = true; padKey(map[i]); } padBtn[i] = d; }
}
window.addEventListener('blur', () => {
    for (const k in keys) keys[k] = false;
    drag = null;
    if (mode === 'play' && OPT.blurPause) mode = 'pause';
});
window.addEventListener('pagehide', () => persist());
document.addEventListener('visibilitychange', () => {
    if (document.hidden) persist();
    if (!AC) return;
    if (document.hidden) { try { AC.suspend(); } catch (e) {} } else { try { AC.resume(); } catch (e) {} }
});

// =====================================================================
//  LOOP (fixed 60 fps simulation)
// =====================================================================
let lastT = performance.now(), acc = 0, needRender = true, lowFps = 0, autoCool = 0;
// Adaptive quality, now for the whole game (menu, cutscenes and play): it steps down one notch at a time when frames stay slow, and steps back UP when there is
// plenty of headroom. Order: the 3D hero's shading and supersampling first (cheapest to lose), then resolution, glow/shading tier, particles.
function qgSteps() {
    const hq0 = OPT.hq == null ? 1 : OPT.hq;
    return [
        () => hq0 - QG.hq > 0 ? (QG.hq++, () => { QG.hq--; }) : null,
        () => { if (RES <= 1) return null; const was = OPT.res; OPT.res = RES > 2 ? 2 : 1; applyRes(); return () => { OPT.res = was; applyRes(); }; },
        () => { if (OPT.gfx <= 1) return null; OPT.gfx--; clearSprites(); return () => { OPT.gfx++; clearSprites(); }; },
        () => { if (OPT.parts <= 0.5) return null; const was = OPT.parts; OPT.parts = 0.5; return () => { OPT.parts = was; }; },
    ];
}
function autoDegrade(up) {
    if (up) { const u = QG.undo.pop(); if (!u) return false; u(); QG.lastUp = performance.now(); return true; }
    for (const st of qgSteps()) { const u = st(); if (u) { QG.undo.push(u); if (performance.now() - QG.lastUp < 20000) QG.wait = Math.min(240, QG.wait * 2); if (mode === 'play') toast('Adaptive quality', 'Visual quality lowered to keep the game smooth', '#ffa502', 170); return true; } }
    return false;
}
for (const ev of ['pointerdown', 'pointerup', 'keydown', 'resize', 'focus']) window.addEventListener(ev, () => { needRender = true; }, true);
function frame(now) {
    pollGamepad();
    const dt = now - lastT;
    acc += Math.min(100, dt);
    lastT = now;
    fpsAcc += dt; fpsN++;
    if (fpsAcc >= 500) {
        fps = Math.round(fpsN * 1000 / fpsAcc); fpsAcc = 0; fpsN = 0;
        if (autoCool > 0) autoCool--;
        if (OPT.auto && !document.hidden && (mode !== 'play' || (g && g.intro <= 0))) {
            lowFps = fps < 38 ? lowFps + 1 : 0;   // 4 seconds below ~38 fps in a row: step down
            QG.good = fps >= 56 ? QG.good + 1 : 0;   // a long clean stretch at full speed: give a notch back
            if (lowFps >= 8 && autoCool <= 0) { lowFps = 0; QG.good = 0; autoCool = 20; autoDegrade(false); }
            else if (QG.good >= QG.wait && autoCool <= 0 && QG.undo.length) { QG.good = 0; autoCool = 20; autoDegrade(true); }
        } else lowFps = 0;
    }
    let n = 0;
    while (acc >= 1000 / 60 && n < 5) { step(); acc -= 1000 / 60; n++; }
    if (acc >= 1000 / 60) acc = 0;
    // on 90/120 Hz screens most frames run no simulation step, so the picture would be identical: skip the redraw
    if (n > 0 || needRender || mode === 'cutscene') { render(); needRender = false; }
    requestAnimationFrame(frame);
}
// start audio as early as the browser allows: build it now (it may sit suspended) and unlock it on the very first touch, click or key
try { audioInit(); } catch (e) {}
const unlockAudio = () => { audioInit(); if (AC && AC.state === 'running') for (const ev of ['pointerdown', 'touchstart', 'touchend', 'mousedown', 'click', 'keydown']) window.removeEventListener(ev, unlockAudio, true); };
for (const ev of ['pointerdown', 'touchstart', 'touchend', 'mousedown', 'click', 'keydown']) window.addEventListener(ev, unlockAudio, true);
requestAnimationFrame(frame);
