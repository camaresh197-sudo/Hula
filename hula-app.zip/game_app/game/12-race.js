
// =====================================================================
//  ACT 2: THE PURSUIT  -  top-down taco-car racer
// =====================================================================
const ROAD_HW = 112;
const RACE_THEMES = {
    dawn:   { ground: '#86c65a', ground2: '#78b84c', road: '#565b68', edge: '#f1e9cf', line: '#f7f1c4', side: 'tree' },
    canyon: { ground: '#d98f52', ground2: '#cc8248', road: '#6a5a52', edge: '#f4d9a8', line: '#ffe29a', side: 'cactus' },
    night:  { ground: '#17314a', ground2: '#132a40', road: '#2a2e3a', edge: '#8aa2c0', line: '#ffe58a', side: 'lamp' },
    boss:   { ground: '#8f4c30', ground2: '#82432a', road: '#3a2d2e', edge: '#ff7a45', line: '#ffb36b', side: 'flame' },
};
function raceTheme() { return RACE_THEMES[(WORLDS[g.wi].levels[g.li]).theme] || RACE_THEMES.dawn; }
function cxAt(y) {
    const d = g.race.dist + (H - y);
    return W / 2 + Math.sin(d * 0.0042) * 46 + Math.sin(d * 0.0017 + 1.3) * 34;
}
function hash2(a, b) { const s = Math.sin(a * 127.1 + b * 311.7) * 43758.5453; return s - Math.floor(s); }

function initRace(L) {
    const st = g.stage;
    g.race = { dist: 0, len: L.len || 1e9, v: 4, vShow: 160, steer: 0, nitro: 0, off: false, spawnT: 50, boost: 30, nm: 0, nextCoin: 500, coinQ: 0, dens: L.dens || 1, theme: L.theme };
    st.bossSpawned = false;
    g.player.x = W / 2; g.player.y = H - 150;
}
function movePlayerFree(spdMul, y0, y1) {
    const S = g.S, p = g.player, spd = S.speed * g.dyn.speed * spdMul;
    let mx = 0, my = 0;
    if (keys.left) mx--; if (keys.right) mx++; if (keys.up) my--; if (keys.down) my++;
    if (p.dash > 0) { p.x += p.dashVx; p.y += p.dashVy; p.dash--; }
    else if (mx || my) { const l = Math.hypot(mx, my); p.vx = mx / l * spd; p.vy = my / l * spd; p.x += p.vx; p.y += p.vy; }
    else if (drag) {
        const dx = drag.tx - p.x, dy = drag.ty - p.y, d = Math.hypot(dx, dy), s = Math.min(d, spd * 1.7);
        if (d > 0.5) { p.vx = dx / d * s; p.vy = dy / d * s; p.x += p.vx; p.y += p.vy; } else { p.vx = p.vy = 0; }
    } else { p.vx *= 0.8; p.vy *= 0.8; }
    p.x = clamp(p.x, 14, W - 14); p.y = clamp(p.y, y0, y1);
    const mv = Math.hypot(p.vx, p.vy);
    if (mv > 0.4) g.lastDir = { x: p.vx / mv, y: p.vy / mv };
    if (Math.abs(p.vx) > 0.3) p.facing = Math.sign(p.vx);
}
// shared per-ball status (flash, burn, slow, cooldowns); returns false if the ball died
function tickBallStatus(b) {
    b.age++;
    if (b.hoopCd > 0) b.hoopCd--;
    if (b.capeCd > 0) b.capeCd--;
    if (b.flash > 0) b.flash--;
    if (b.burnT > 0) {
        b.burnT--;
        if (b.burnT % 20 === 0) { dealDamage(g, b, b.burnDps / 3, { noProc: true, noCrit: true, color: '#e67e22' }); if (b.dead) return false; }
        if (b.burnT === 0) b.burnDps = 0;
    }
    return !b.dead;
}
function smashObstacles() { for (const b of g.balls) if (!b.dead && b.type === 'crate') dealDamage(g, b, 1e9, { noProc: true, noCrit: true }); }

function updateRace() {
    const S = g.S, p = g.player, R = g.race, st = g.stage, m = g.camp.m;
    if (g.clearT > 0) {
        R.v += (2 - R.v) * 0.05; R.dist += R.v; R.vShow = R.v * 40;
        updateBullets(g); commonFx(); updatePickupsK(R.v); if (mode !== 'play') return;
        clearTick(); return;
    }
    commonTick();
    {   // slidey drift steering: momentum carries sideways
        const spd = S.speed * g.dyn.speed * S.grip; let mx = (keys.right ? 1 : 0) - (keys.left ? 1 : 0), my = (keys.down ? 1 : 0) - (keys.up ? 1 : 0), tvx = mx * spd, tvy = my * spd * 0.7;
        if (!mx && !my && drag) { tvx = clamp((drag.tx - p.x) * 0.16, -spd * 1.5, spd * 1.5); tvy = clamp((drag.ty - p.y) * 0.1, -spd, spd); }
        const gr = 0.07 + 0.04 * (S.grip - 1);
        p.vx += (tvx - p.vx) * gr; p.vy += (tvy - p.vy) * 0.12;
        if (p.dash > 0) { p.dash--; }
        p.x = clamp(p.x + p.vx, 14, W - 14); p.y = clamp(p.y + p.vy, H - 290, H - 50);
        if (Math.abs(p.vx) > 2.4 && g.frames % 3 === 0) g.fx.push({ kind: 'p', x: p.x + rand(-10, 10), y: p.y + 18, vx: 0, vy: 1, color: '#ddd', t: 18, max: 18, sz: 3 });
        if (Math.abs(p.vx) > 0.3) p.facing = Math.sign(p.vx); g.lastDir = { x: Math.sign(p.vx) || 0, y: -1 };
    }
    R.boost = Math.min(100, R.boost + 0.03);
    // ---- speed ----
    const cx = cxAt(p.y); R.off = Math.abs(p.x - cx) > ROAD_HW - 6;
    if (R.nitro > 0) R.nitro--;
    const target = (R.nitro > 0 ? 7.4 : 4.2) * (R.off ? Math.min(0.95, 0.62 + (S.grip - 1) * 0.5) : 1) * (g.timeSlow > 0 ? 0.85 : 1);
    R.v += (target - R.v) * 0.06; R.dist += R.v; R.vShow = R.v * 40;
    R.steer += (clamp(p.vx / 4, -1, 1) - R.steer) * 0.2;
    if (R.off && g.frames % 3 === 0) g.fx.push({ kind: 'p', x: p.x + rand(-8, 8), y: p.y + 16, vx: rand(-0.5, 0.5), vy: rand(0.5, 1.5), color: '#d9c7a0', t: 20, max: 20, sz: rand(2, 4) });
    if (R.nitro > 0 && g.frames % 2 === 0) g.fx.push({ kind: 'p', x: p.x + rand(-5, 5), y: p.y + 22, vx: rand(-0.3, 0.3), vy: rand(1.5, 3), color: pick(['#ff7a1a', '#ffd32a', '#fff3a0']), t: 16, max: 16, sz: rand(3, 5) });
    // ---- spawning ----
    const boss = st.boss, nearEnd = !boss && R.len - R.dist < 450;
    if (boss) {
        if (st.t === 1) { g.warn = 110; sfx('boss'); }
        if (st.t === 100 && !st.bossSpawned) {
            st.bossSpawned = true;
            const b = spawnBall('truck', W / 2, -70); b.boss = true; b.big = true; b.r = 40; b.dmg = 24; b.tt = 0; b.cd1 = 100; b.cd2 = 60; b.slam = 0; b.ph2 = false;
            setBossHp(b, 30, bossFloor(900));
            toast('EL CAMIÓN SALSERO', 'Wreck the hot-sauce truck!', '#ff4757', 220);
        }
        if (st.bossSpawned && st.t > 130 && !g.balls.some(b => b.type === 'truck' && !b.dead)) { stageDone(); return; }
    } else if (R.dist >= R.len) { stageDone(); return; }
    if (!nearEnd && --R.spawnT <= 0) {
        const dens = R.dens * g.D.spawn;
        if (g.balls.length < 40) {
            const roll = Math.random();
            if (roll < 0.5) {   // crate wall with a gap, or a lone crate
                const c = cxAt(-20), lane = randi(-1, 1);
                const n = Math.random() < 0.35 ? 3 : 1;
                for (let i = 0; i < n; i++) {
                    const b = spawnBall('crate', c + clamp(lane * 62 + (i - (n - 1) / 2) * 30, -ROAD_HW + 14, ROAD_HW - 14), -20 - i * 6);
                    b.dmg = 6 + 3 * m; b.hp = b.maxHp = 10 + 14 * m; b.vy = b.baseVy = 0;
                }
            } else if (!boss || Math.random() < 0.5) {
                const behind = Math.random() < 0.22;
                const b = spawnBall('rival', cxAt(behind ? H + 30 : -30) + rand(-70, 70), behind ? H + 30 : -30);
                b.dmg = 8 + 3 * m; b.ratio = behind ? rand(1.35, 1.7) : rand(0.25, 0.75); b.hp = b.maxHp = b.hp * 0.9; b.lane = rand(-0.7, 0.7); b.vy = b.baseVy = 0;
            }
        }
        R.spawnT = Math.max(16, 62 - m * 5) / dens * rand(0.75, 1.25);
    }
    if (!nearEnd && R.dist >= R.nextCoin) { R.coinQ = randi(5, 8); R.nextCoin = R.dist + rand(800, 1300); R.coinLane = rand(-0.6, 0.6); R.coinGap = 0; }
    if (R.coinQ > 0 && R.dist >= (R.coinGap || 0)) { fixedCoin(cxAt(-12) + R.coinLane * (ROAD_HW - 22) + Math.sin(R.coinQ * 0.9) * 14, -12, 1); R.coinQ--; R.coinGap = R.dist + 30; }
    // ---- weapons / pets ----
    g.aimA = -Math.PI / 2;
    updateWeapons(g); updateBullets(g); if (mode !== 'play') return;
    if (g.cape) { g.cape = null; }
    updatePet();
    // ---- balls ----
    const bsm = S.ballSpeedMult * (g.timeSlow > 0 ? 0.3 : 1) * (g.dust > 0 ? 0.5 : 1);
    for (const b of g.balls) {
        if (b.dead) continue;
        if (!tickBallStatus(b)) continue;
        let sm = bsm; if (b.slowT > 0) { b.slowT--; sm *= 0.5; }
        if (b.type === 'crate') b.y += R.v;
        else if (b.type === 'rival') {
            b.y += R.v * (1 - b.ratio * Math.min(1, sm + 0.2));
            let tx = cxAt(b.y) + b.lane * (ROAD_HW - 24);
            if (Math.abs(b.y - p.y) < 170 && b.ratio < 1) tx += (p.x - tx) * 0.5;   // aggressive rivals lean into you
            b.x += clamp((tx - b.x) * 0.03, -1.6, 1.6) * sm;
            if (b.ratio > 1) b.y -= 0;   // chasers from behind close in
        } else if (b.type === 'truck') updateTruck(b, sm);
        else b.y += R.v * 0.8;
        if (b.y > H + 70 || b.y < -140 || b.x < -80 || b.x > W + 80) { if (b.type !== 'truck') b.gone = true; }
        const rr = b.r + p.r * 0.9;
        if (!b.gone && (b.x - p.x) ** 2 + (b.y - p.y) ** 2 < rr * rr) {
            if (b.type === 'truck') { if (R.nitro > 0 && !b.hitT) { dealDamage(g, b, 70, { color: '#ffd32a' }); b.hitT = 40; g.shake = 10; p.y = Math.min(H - 50, p.y + 40); } else if (R.nitro <= 0) { hurtPlayer(g, b.dmg, b); p.y = Math.min(H - 50, p.y + 6); } }
            else { (R.nitro > 0 ? (addText(g, b.x, b.y - 14, 'SMASH!', '#ffd32a', 12), gainGold(g, 2), g.shake = Math.max(g.shake, 5)) : hurtPlayer(g, b.dmg / (1 + 0.5 * S.ram), b)); if (S.ram > 0) for (const o of g.balls) if (o !== b && !o.dead && Math.hypot(o.x - b.x, o.y - b.y) < 60) dealDamage(g, o, 14 * S.ram, { noProc: true, noCrit: true }); b.hp = Math.min(b.hp, 0.01); dealDamage(g, b, 1e9, { noProc: true, noCrit: true, color: '#ffffff' }); g.shake = Math.max(g.shake, 6); }
            if (mode !== 'play') return;
        }
    }
    for (const b of g.balls) {   // close calls charge the boost meter
        if (b.hitT > 0) b.hitT--;
        if (b.dead || b.nm || (b.type !== 'rival' && b.type !== 'crate')) continue;
        const dy = Math.abs(b.y - p.y), dx = Math.abs(b.x - p.x);
        if (dy < 16 && dx > 15 && dx < 34) { b.nm = 1; R.boost = Math.min(100, R.boost + 14); gainGold(g, 1); g.score += 25; addText(g, b.x, b.y - 16, 'CLOSE CALL!', '#7bed9f', 10); }
    }
    compactBalls(g);
    updateEBullets(R.v);
    if (mode !== 'play') return;
    updatePickupsK(R.v); if (mode !== 'play') return;
    commonFx(); updateScenery(R.v * 0.3, 0);
}
function raceBoost() {
    const R = g.race; if (mode !== 'play' || g.kind !== 'race' || !R || R.boost < 40 || R.nitro > 60) return;
    R.boost -= 40; R.nitro = 150; g.player.iframes = Math.max(g.player.iframes, 20); sfx('power'); toast('TURBO!', 'Smash through everything', '#ff9f43', 70);
}
function drawRaceFront() {
    const R = g.race; if (!R) return;
    const bx = 44, by = H - 50, br = 28;
    uiButtons.push({ x: bx - br, y: by - br, w: br * 2, h: br * 2, fn: raceBoost });
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.fill();
    const ready = R.boost >= 40, f = R.nitro > 0 ? R.nitro / 150 : R.boost / 100;
    ctx.strokeStyle = R.nitro > 0 ? '#ff9f43' : ready ? '#ffd32a' : '#636e72'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(bx, by, br - 2, -Math.PI / 2, -Math.PI / 2 + TAU * f); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(R.nitro > 0 ? 'TURBO' : 'BOOST', bx, by + 4); ctx.textAlign = 'left';
    if (R.nitro > 0) { ctx.save(); ctx.globalAlpha = 0.25; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; for (let i = 0; i < 8; i++) { const x = (i * 47 + menuT * 11) % W; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); } ctx.restore(); }
}
function updateEBullets(scroll) {
    const p = g.player;
    for (let i = g.ebullets.length - 1; i >= 0; i--) {
        const e = g.ebullets[i]; e.x += e.vx; e.y += e.vy + (e.scroll ? scroll : 0);
        if (e.x < -20 || e.x > W + 20 || e.y < -20 || e.y > H + 20) { g.ebullets.splice(i, 1); continue; }
        const rr = e.r + p.r * 0.7;
        if ((e.x - p.x) ** 2 + (e.y - p.y) ** 2 < rr * rr) { g.ebullets.splice(i, 1); hurtPlayer(g, e.dmg, null); if (mode !== 'play') return; }
    }
}
function updateTruck(b, sm) {
    const R = g.race, p = g.player, hp = b.hp / b.maxHp;
    b.tt++;
    if (b.inv > 0) b.inv--;
    if (!b.ph2 && hp < 0.5) { b.ph2 = true; g.shake = 14; sfx('boss'); toast('FULL THROTTLE!', 'The truck calls reinforcements', '#ff4757', 150); b.inv = 40; }
    const baseY = b.slam > 0 ? Math.min(p.y - 110, 360) : 120;
    b.y += (baseY - b.y) * (b.slam > 0 ? 0.06 : 0.04) * Math.max(0.4, sm);
    const tx = b.slam > 0 ? p.x : cxAt(b.y) + Math.sin(b.tt * (b.ph2 ? 0.03 : 0.02)) * (ROAD_HW - 52);
    b.x += (tx - b.x) * 0.045 * Math.max(0.4, sm);
    if (b.slam > 0) b.slam--;
    if (b.y < 30 || b.inv > 0) return;
    if (b.tt % 420 === 300) { b.slam = 70; toast('BRAKE SLAM!', '', '#ff9f43', 50); }
    if ((b.cd1 -= sm) <= 0) {   // salsa glob fan
        b.cd1 = b.ph2 ? 80 : 110; const base = Math.atan2(p.y - b.y, p.x - b.x), n = b.ph2 ? 2 : 1;
        for (let k = -n; k <= n; k++) g.ebullets.push({ x: b.x, y: b.y + b.r * 0.7, vx: Math.cos(base + k * 0.26) * 2.6, vy: Math.sin(base + k * 0.26) * 2.6, r: 5, dmg: 11, scroll: false });
        sfx('ebullet');
    }
    if ((b.cd2 -= sm) <= 0) {   // drops crates off the back
        b.cd2 = b.ph2 ? 55 : 80;
        const c = spawnBall('crate', clamp(b.x + rand(-34, 34), 20, W - 20), b.y + b.r + 8); c.dmg = 9; c.hp = c.maxHp = 14 + 10 * g.camp.m; c.vy = c.baseVy = 0;
    }
    if (b.ph2 && b.tt % 260 === 200) { const r = spawnBall('rival', cxAt(H + 30) + rand(-60, 60), H + 30); r.ratio = 1.5; r.lane = rand(-0.6, 0.6); r.dmg = 12; r.vy = r.baseVy = 0; }
}

// ---------------------------------------------------------------------
//  Drawing
// ---------------------------------------------------------------------
// =====================================================================
//  RACE LEVEL ART: painted ground tiles, shaded asphalt, rumble curbs, layered roadside scenery,
//  cloud shadows, lamp light pools, embers and a proper finish gantry.
// =====================================================================
const raceTex = new Map();   // seamless tiles, painted once per resolution
const RACE_X = {              // per-theme extras on top of RACE_THEMES
    dawn:   { shoulder: '#c8b07a', curbA: '#d9483b', curbB: '#f6edd8', hi: '#b4e47a', lo: '#3f8a3a' },
    canyon: { shoulder: '#f2c98f', curbA: '#bf5a35', curbB: '#f3dcb0', hi: '#f6b878', lo: '#a8602f' },
    night:  { shoulder: '#506a82', curbA: '#2f3d58', curbB: '#a8c2e2', hi: '#2f6a80', lo: '#081a2a' },
    boss:   { shoulder: '#4c2a26', curbA: '#ff7a45', curbB: '#2a1c1c', hi: '#ff8a3c', lo: '#4a2016' },
};
function tileStamp(w, h, px, py, r, fn) {   // run fn at a point and at its wrapped copies so the tile repeats without seams
    for (const dx of [-w, 0, w]) { if (px + dx + r < 0 || px + dx - r > w) continue; for (const dy of [-h, 0, h]) { if (py + dy + r < 0 || py + dy - r > h) continue; fn(px + dx, py + dy); } }
}
function raceTile(key, w, h, paint) {
    const k = key + '@' + RES; let pat = raceTex.get(k); if (pat) return pat;
    const cv = document.createElement('canvas'); cv.width = Math.ceil(w * RES); cv.height = Math.ceil(h * RES);
    const prev = ctx; ctx = cv.getContext('2d'); ctx.scale(RES, RES);
    try { paint(w, h); pat = prev.createPattern(cv, 'repeat'); } finally { ctx = prev; }
    raceTex.set(k, pat); return pat;
}
function scrollPat(p, ox, oy) { if (p && p.setTransform && typeof DOMMatrix !== 'undefined') p.setTransform(new DOMMatrix([1 / RES, 0, 0, 1 / RES, ox, oy])); }
function paintGround(w, h, th, T, X) {
    const R = mulberry(th === 'dawn' ? 11 : th === 'canyon' ? 23 : th === 'night' ? 37 : 53), rr = (a, b) => a + R() * (b - a), x = ctx;
    x.fillStyle = T.ground; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 18; i++) {   // broad tonal mottling
        const px = rr(0, w), py = rr(0, h), r = rr(26, 60), col = R() < 0.5 ? X.hi : X.lo;
        tileStamp(w, h, px, py, r, (ox, oy) => { const gr = x.createRadialGradient(ox, oy, 0, ox, oy, r); gr.addColorStop(0, hexA(col, 0.17)); gr.addColorStop(1, hexA(col, 0)); x.fillStyle = gr; x.fillRect(ox - r, oy - r, r * 2, r * 2); });
    }
    x.lineCap = 'round';
    if (th === 'dawn' || th === 'night') {
        const cols = th === 'dawn' ? ['#6fb24c', '#8fd262', '#58a03f', '#a8de76', T.ground2] : ['#1d4c55', '#287080', '#173d4a', '#3f8794', T.ground2];
        for (let i = 0; i < 1100; i++) {   // grass blades
            const px = rr(0, w), py = rr(0, h), a = -Math.PI / 2 + rr(-0.8, 0.8), l = rr(2, 5.5), lw = rr(0.5, 1.1), c = cols[(R() * cols.length) | 0];
            tileStamp(w, h, px, py, 6, (ox, oy) => { x.strokeStyle = c; x.lineWidth = lw; x.beginPath(); x.moveTo(ox, oy); x.lineTo(ox + Math.cos(a) * l, oy + Math.sin(a) * l); x.stroke(); });
        }
        for (let i = 0; i < 52; i++) {   // wildflowers / moonlit glints
            const px = rr(0, w), py = rr(0, h), rad = rr(0.7, 1.5), fc = th === 'dawn' ? ['#fff7c2', '#ffd1e0', '#ffffff', '#ffe28a'][(R() * 4) | 0] : ['#7fd6e6', '#a9f0ff'][(R() * 2) | 0];
            tileStamp(w, h, px, py, 3, (ox, oy) => { x.fillStyle = hexA(fc, th === 'dawn' ? 0.9 : 0.5); x.beginPath(); x.arc(ox, oy, rad, 0, TAU); x.fill(); });
        }
        for (let i = 0; i < 22; i++) {   // bare dirt scuffs
            const px = rr(0, w), py = rr(0, h), rx = rr(3, 8), ry = rr(1.5, 3.5);
            tileStamp(w, h, px, py, 9, (ox, oy) => { x.fillStyle = th === 'dawn' ? 'rgba(150,120,70,0.16)' : 'rgba(10,25,40,0.25)'; x.beginPath(); x.ellipse(ox, oy, rx, ry, 0.3, 0, TAU); x.fill(); });
        }
    } else if (th === 'canyon') {
        for (let i = 0; i < 84; i++) {   // wind ripples in the sand
            const px = rr(0, w), py = rr(0, h), l = rr(14, 38), lit = R() < 0.5, lw = rr(0.6, 1.3);
            tileStamp(w, h, px, py, l, (ox, oy) => { x.strokeStyle = lit ? 'rgba(255,232,185,0.24)' : 'rgba(120,58,22,0.2)'; x.lineWidth = lw; x.beginPath(); x.moveTo(ox - l / 2, oy); x.quadraticCurveTo(ox, oy - 3, ox + l / 2, oy + 0.5); x.stroke(); });
        }
        for (let i = 0; i < 900; i++) { const px = rr(0, w), py = rr(0, h), s = rr(0.4, 1.1), lit = R() < 0.5; tileStamp(w, h, px, py, 2, (ox, oy) => { x.fillStyle = lit ? 'rgba(255,225,170,0.3)' : 'rgba(110,50,20,0.28)'; x.fillRect(ox, oy, s, s); }); }
        for (let i = 0; i < 38; i++) {   // pebbles with a lit edge and a shadow
            const px = rr(0, w), py = rr(0, h), r = rr(1.3, 3.4), c = ['#b9835a', '#a2704a', '#cfa070', '#8f5f3c'][(R() * 4) | 0];
            tileStamp(w, h, px, py, 5, (ox, oy) => { x.fillStyle = 'rgba(70,30,10,0.3)'; x.beginPath(); x.ellipse(ox + 0.9, oy + 1.1, r, r * 0.8, 0, 0, TAU); x.fill(); x.fillStyle = c; x.beginPath(); x.ellipse(ox, oy, r, r * 0.85, 0, 0, TAU); x.fill(); x.fillStyle = 'rgba(255,235,200,0.45)'; x.beginPath(); x.ellipse(ox - r * 0.3, oy - r * 0.3, r * 0.4, r * 0.28, 0, 0, TAU); x.fill(); });
        }
        for (let i = 0; i < 5; i++) {   // dry-earth cracks
            let px = rr(0, w), py = rr(0, h); const pts = [[px, py]]; for (let k = 0; k < 6; k++) { px += rr(-9, 9); py += rr(2, 11); pts.push([px, py]); }
            x.strokeStyle = 'rgba(90,40,15,0.35)'; x.lineWidth = 0.8; x.beginPath(); pts.forEach(([a, b], k) => k ? x.lineTo(a, b) : x.moveTo(a, b)); x.stroke();
        }
        for (let i = 0; i < 26; i++) {   // sun-bleached grass flecks
            const px = rr(0, w), py = rr(0, h); tileStamp(w, h, px, py, 5, (ox, oy) => { x.strokeStyle = 'rgba(214,186,100,0.7)'; x.lineWidth = 0.8; for (let k = -1; k <= 1; k++) { x.beginPath(); x.moveTo(ox, oy); x.lineTo(ox + k * 2, oy - 4); x.stroke(); } });
        }
    } else {   // cooled lava crust with glowing fractures
        for (let i = 0; i < 60; i++) { const px = rr(0, w), py = rr(0, h), r = rr(4, 11), n = 6, rot = rr(0, 6), shd = R() < 0.5 ? 'rgba(0,0,0,0.28)' : 'rgba(255,120,60,0.06)';
            tileStamp(w, h, px, py, r, (ox, oy) => { x.fillStyle = shd; x.beginPath(); for (let k = 0; k < n; k++) { const a = rot + k * TAU / n, rd = r * (0.7 + ((k * 7 + i) % 3) * 0.2); k ? x.lineTo(ox + Math.cos(a) * rd, oy + Math.sin(a) * rd) : x.moveTo(ox + Math.cos(a) * rd, oy + Math.sin(a) * rd); } x.closePath(); x.fill(); }); }
        for (let i = 0; i < 12; i++) {
            let px = rr(0, w), py = rr(0, h); const pts = [[px, py]]; for (let k = 0; k < 7; k++) { px += rr(-12, 12); py += rr(-12, 12); pts.push([px, py]); }
            for (const [off, lw, col] of [[0, 3.6, 'rgba(255,80,20,0.22)'], [0, 1.4, 'rgba(255,170,60,0.9)']]) tileStamp(w, h, pts[0][0], pts[0][1], 60, (ox, oy) => { x.strokeStyle = col; x.lineWidth = lw; x.beginPath(); pts.forEach(([a, b], k) => k ? x.lineTo(a - pts[0][0] + ox, b - pts[0][1] + oy) : x.moveTo(ox, oy)); x.stroke(); });
        }
        for (let i = 0; i < 500; i++) { const px = rr(0, w), py = rr(0, h), s = rr(0.4, 1.2), lit = R() < 0.4; tileStamp(w, h, px, py, 2, (ox, oy) => { x.fillStyle = lit ? 'rgba(200,190,185,0.3)' : 'rgba(0,0,0,0.35)'; x.fillRect(ox, oy, s, s); }); }
    }
}
function paintAsphalt(w, h, T) {
    const R = mulberry(77), rr = (a, b) => a + R() * (b - a), x = ctx;
    x.fillStyle = T.road; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 16; i++) {   // tonal mottling
        const px = rr(0, w), py = rr(0, h), r = rr(20, 50), dk = R() < 0.55;
        tileStamp(w, h, px, py, r, (ox, oy) => { const gr = x.createRadialGradient(ox, oy, 0, ox, oy, r); gr.addColorStop(0, dk ? 'rgba(0,0,0,0.12)' : 'rgba(255,255,255,0.06)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = gr; x.fillRect(ox - r, oy - r, r * 2, r * 2); });
    }
    for (let i = 0; i < 1600; i++) { const px = rr(0, w), py = rr(0, h), s = rr(0.4, 1.1), lit = R() < 0.42; tileStamp(w, h, px, py, 2, (ox, oy) => { x.fillStyle = lit ? 'rgba(255,255,255,' + rr(0.07, 0.17).toFixed(2) + ')' : 'rgba(0,0,0,' + rr(0.1, 0.22).toFixed(2) + ')'; x.fillRect(ox, oy, s, s); }); }
    for (let i = 0; i < 70; i++) {   // loose aggregate
        const px = rr(0, w), py = rr(0, h), r = rr(0.9, 2);
        tileStamp(w, h, px, py, 3, (ox, oy) => { x.fillStyle = 'rgba(0,0,0,0.2)'; x.beginPath(); x.ellipse(ox + 0.5, oy + 0.6, r, r * 0.8, 0, 0, TAU); x.fill(); x.fillStyle = 'rgba(190,190,200,0.17)'; x.beginPath(); x.ellipse(ox, oy, r, r * 0.8, 0, 0, TAU); x.fill(); });
    }
    for (let i = 0; i < 3; i++) {   // hairline cracks with a branch
        let px = rr(10, w - 10), py = rr(10, h - 10); const pts = [[px, py]]; for (let k = 0; k < 8; k++) { px += rr(-6, 6); py += rr(3, 9); pts.push([px, py]); }
        x.strokeStyle = 'rgba(0,0,0,0.2)'; x.lineWidth = 0.7; x.beginPath(); pts.forEach(([a, b], k) => k ? x.lineTo(a, b) : x.moveTo(a, b)); x.stroke();
        x.strokeStyle = 'rgba(255,255,255,0.08)'; x.beginPath(); pts.forEach(([a, b], k) => k ? x.lineTo(a + 0.9, b + 0.4) : x.moveTo(a + 0.9, b + 0.4)); x.stroke();
        const m = pts[4]; x.strokeStyle = 'rgba(0,0,0,0.16)'; x.beginPath(); x.moveTo(m[0], m[1]); x.lineTo(m[0] + 9, m[1] + 4); x.lineTo(m[0] + 14, m[1] + 12); x.stroke();
    }
    for (const [ox, oy, r] of [[88, 84, 14], [40, 100, 10]]) { const gr = x.createRadialGradient(ox, oy, 0, ox, oy, r); gr.addColorStop(0, 'rgba(0,0,0,0.3)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = gr; x.fillRect(ox - r, oy - r, r * 2, r * 2); }   // oil stains
}
function roadShadeSprite() {   // one cross-section of the road: dark edges (ambient occlusion) and the polished wheel tracks of two lanes
    const SR = Math.min(RES, 3), HWX = ROAD_HW + 9;
    return cachedDraw(spriteCache, 'roadshade|' + SR, HWX, 0, HWX * 2, 8, SR, () => {
        for (let xx = -ROAD_HW; xx < ROAD_HW; xx += 0.5) {
            const d = ROAD_HW - Math.abs(xx), ax = Math.abs(xx);
            let a = 0.34 * Math.pow(Math.max(0, 1 - d / 24), 1.7);
            a += 0.075 * Math.max(Math.exp(-Math.pow((ax - 40) / 7, 2)), Math.exp(-Math.pow((ax - 72) / 7, 2)));
            if (a > 0.004) { ctx.fillStyle = 'rgba(0,0,0,' + a.toFixed(3) + ')'; ctx.fillRect(xx, 0, 0.5, 8); }
        }
    });
}
function raVignette() { return cachedDraw(spriteCache, 'ravig', 0, 0, W, H, 1, () => { const gr = ctx.createRadialGradient(W / 2, H * 0.52, 140, W / 2, H * 0.52, 430); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.42)'); ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H); }); }
function raBlobSprite() { return cachedDraw(spriteCache, 'rablob', 100, 100, 200, 200, 1, () => { const gr = ctx.createRadialGradient(0, 0, 0, 0, 0, 100); gr.addColorStop(0, 'rgba(0,0,0,0.55)'); gr.addColorStop(0.6, 'rgba(0,0,0,0.25)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = gr; ctx.fillRect(-100, -100, 200, 200); }); }

// ---------- roadside art ----------
const raSh = (rx, ry, ox = 0, oy = 0, a = 0.22) => { ctx.fillStyle = 'rgba(0,0,0,' + a + ')'; ctx.beginPath(); ctx.ellipse(ox, oy, rx, ry, 0, 0, TAU); ctx.fill(); };
const raDot = (x, y, r, c) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); };
const raTube = (pts, w, dark, mid, hi) => { ctx.lineCap = 'round'; ctx.lineJoin = 'round'; for (const [col, lw, off] of [[dark, w + 2, 0], [mid, w, 0], [hi, w * 0.28, -w * 0.22]]) { ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath(); pts.forEach(([x, y], i) => i ? ctx.lineTo(x + off, y) : ctx.moveTo(x + off, y)); ctx.stroke(); } };
function raRock(rx, ry, base, lit, dark, seed) {
    raSh(rx * 1.05, ry * 0.8, rx * 0.25, ry * 0.4, 0.28);
    const R = mulberry(seed), pts = [], n = 8;
    for (let i = 0; i < n; i++) { const a = i * TAU / n + R() * 0.3; pts.push([Math.cos(a) * rx * (0.82 + R() * 0.28), Math.sin(a) * ry * (0.82 + R() * 0.28)]); }
    const poly = (idx, c, cx, cy) => { ctx.fillStyle = c; ctx.beginPath(); idx.forEach((k, i) => i ? ctx.lineTo(pts[k][0], pts[k][1]) : ctx.moveTo(pts[k][0], pts[k][1])); ctx.lineTo(cx, cy); ctx.closePath(); ctx.fill(); };
    poly([0, 1, 2, 3, 4, 5, 6, 7], base, 0, 0);
    poly([4, 5, 6, 7], lit, -rx * 0.12, -ry * 0.12); poly([0, 1, 2, 3], dark, rx * 0.12, ry * 0.12);
    ctx.strokeStyle = 'rgba(0,0,0,0.28)'; ctx.lineWidth = 0.8; ctx.beginPath(); pts.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)); ctx.closePath(); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.beginPath(); ctx.moveTo(pts[5][0], pts[5][1]); ctx.lineTo(pts[6][0], pts[6][1]); ctx.stroke();
}
function raTree(v, c) {   // c: [outline, base, mid, hi, rim]
    const r = 15 + v * 3.5; raSh(r * 1.05, r * 0.75, r * 0.3, r * 0.36);
    raDot(0, 0, r, c[1]);
    for (const [lx, ly, lr] of [[-0.45, -0.4, 0.6], [0.5, -0.3, 0.56], [0.12, 0.5, 0.58], [-0.12, -0.02, 0.68]]) {
        ctx.fillStyle = rg(lx * r - lr * r * 0.3, ly * r - lr * r * 0.35, 1, lx * r, ly * r, lr * r, [[0, c[3]], [0.55, c[2]], [1, c[1]]]);
        ctx.beginPath(); ctx.arc(lx * r, ly * r, lr * r, 0, TAU); ctx.fill();
    }
    ctx.fillStyle = c[4]; for (let k = 0; k < 12; k++) { const a = k * 2.4 + v, d = r * (0.2 + (k % 5) * 0.14); ctx.beginPath(); ctx.ellipse(Math.cos(a) * d - 2, Math.sin(a) * d - 3, 2.2, 1.2, a, 0, TAU); ctx.fill(); }
    ctx.strokeStyle = c[0]; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.stroke();
}
const RA = {
    dawn: {
        major: [
            { k: 'tree', w: 76, h: 76, ox: 38, oy: 38, n: 3, paint(v) { raTree(v, ['rgba(10,50,20,0.45)', '#2c6f33', '#52ab40', '#9be063', 'rgba(210,255,160,0.35)']); if (v === 1) for (let k = 0; k < 6; k++) { const a = k * 1.1, d = 10, fx = Math.cos(a) * d, fy = Math.sin(a) * d; raDot(fx, fy, 2.4, '#ff9a1f'); raDot(fx - 0.7, fy - 0.8, 0.8, '#ffe0a0'); } } },
            { k: 'palm', w: 90, h: 90, ox: 45, oy: 45, n: 2, paint(v) {
                raSh(26, 20, 7, 9, 0.2); const n = 10 + v * 2;
                for (let i = 0; i < n; i++) { const a = i * TAU / n + v * 0.4, L = 30 + (i % 2) * 5; ctx.save(); ctx.rotate(a); ctx.fillStyle = lg(0, 0, L, 0, [[0, '#2f7a35'], [0.5, '#52ab40'], [1, '#7ccb50']]); ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(L * 0.45, -9, L, 0); ctx.quadraticCurveTo(L * 0.45, 7, 0, 0); ctx.fill(); ctx.strokeStyle = 'rgba(20,70,30,0.55)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(2, 0); ctx.lineTo(L * 0.95, 0); ctx.stroke(); ctx.restore(); }
                raDot(0, 0, 5, '#6b4423'); raDot(-1, -1, 3.2, '#8b5e34'); raDot(3, 2, 2, '#4a2f18'); raDot(-3, 2.5, 2, '#4a2f18'); } },
            { k: 'agave', w: 60, h: 60, ox: 30, oy: 30, n: 1, paint() {
                raSh(20, 15, 5, 6, 0.2);
                for (let ring = 0; ring < 2; ring++) for (let i = 0; i < 9; i++) { const a = i * TAU / 9 + ring * 0.35, L = ring ? 14 : 22; ctx.save(); ctx.rotate(a); ctx.fillStyle = lg(0, 0, L, 0, [[0, '#4d8f7c'], [1, ring ? '#9fd6c2' : '#6fb3a0']]); ctx.beginPath(); ctx.moveTo(0, -3.2 + ring); ctx.quadraticCurveTo(L * 0.7, -6.5, L, 0); ctx.quadraticCurveTo(L * 0.7, 6.5, 0, 3.2 - ring); ctx.fill(); ctx.strokeStyle = 'rgba(30,70,60,0.4)'; ctx.lineWidth = 0.6; ctx.stroke(); ctx.fillStyle = '#6b2d3a'; ctx.fillRect(L - 1.2, -0.8, 2.4, 1.6); ctx.restore(); }
                raDot(0, 0, 3, '#c8ecd9'); } },
            { k: 'fbush', w: 50, h: 50, ox: 25, oy: 25, n: 3, paint(v) {
                raSh(17, 12, 4, 5, 0.18);
                for (const [x, y, r] of [[-6, 2, 9], [6, 3, 8], [0, -5, 10], [1, 4, 9]]) { ctx.fillStyle = rg(x - r * 0.3, y - r * 0.35, 1, x, y, r, [[0, '#7fc65a'], [1, '#2f7a35']]); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }
                const cols = [['#ff6b81', '#ffc2cc'], ['#ffd32a', '#fff3a0'], ['#ff9f43', '#ffd9a8']][v % 3];
                for (let k = 0; k < 9; k++) { const a = k * 2.3 + v, d = 3 + (k % 4) * 3, fx = Math.cos(a) * d, fy = Math.sin(a) * d - 1; raDot(fx, fy, 2.2, cols[0]); raDot(fx - 0.5, fy - 0.5, 0.9, cols[1]); } } },
            { k: 'hut', w: 100, h: 90, ox: 50, oy: 45, n: 1, rare: true, paint() {
                raSh(38, 28, 8, 10, 0.25);
                ctx.fillStyle = '#e8d3a8'; roundRect(-30, -4, 60, 34, 3); ctx.fill(); ctx.fillStyle = '#b89a6a'; ctx.fillRect(-9, 12, 18, 18); ctx.fillStyle = '#6b4423'; ctx.fillRect(-9, 12, 18, 2);
                ctx.fillStyle = lg(0, -34, 0, 2, [[0, '#d97a46'], [1, '#bf5f33']]); roundRect(-36, -34, 72, 34, 4); ctx.fill();
                ctx.fillStyle = lg(0, 0, 0, 10, [[0, '#a64f2a'], [1, '#8a3f20']]); roundRect(-36, 0, 72, 8, 3); ctx.fill();
                ctx.strokeStyle = 'rgba(90,35,15,0.35)'; ctx.lineWidth = 0.9;
                for (let r = 0; r < 5; r++) { ctx.beginPath(); ctx.moveTo(-36, -30 + r * 7); ctx.lineTo(36, -30 + r * 7); ctx.stroke(); for (let c = -33; c < 36; c += 8) { ctx.beginPath(); ctx.moveTo(c + (r % 2) * 4, -30 + r * 7); ctx.lineTo(c + (r % 2) * 4, -23 + r * 7); ctx.stroke(); } }
                ctx.fillStyle = 'rgba(255,230,190,0.25)'; ctx.fillRect(-36, -34, 72, 3); ctx.fillStyle = '#c9b08a'; ctx.fillRect(18, -26, 8, 8); ctx.fillStyle = '#3a2418'; ctx.fillRect(19.5, -24.5, 5, 5);
                for (let k = 0; k < 5; k++) raDot(-26 + k * 4, 12, 1.4, ['#e63946', '#2a9d8f'][k % 2]); } },
        ],
        minor: [
            { k: 'tuft', w: 30, h: 30, ox: 15, oy: 20, n: 3, paint(v) { ctx.lineCap = 'round'; for (let i = 0; i < 8; i++) { const a = -Math.PI / 2 + (i - 3.5) * 0.28, L = 7 + ((i + v) % 3) * 3; ctx.strokeStyle = i % 2 ? '#5fa545' : '#86cc5e'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo((i - 3.5) * 1.5, 4); ctx.quadraticCurveTo((i - 3.5) * 2.2, -2, Math.cos(a) * L + (i - 3.5), Math.sin(a) * L + 4); ctx.stroke(); } } },
            { k: 'flwr', w: 36, h: 30, ox: 18, oy: 15, n: 3, paint(v) { const R = mulberry(40 + v), cs = [['#ff6b81', '#fff'], ['#ffd32a', '#fff7b0'], ['#ffffff', '#ffe28a']][v % 3]; for (let i = 0; i < 12; i++) { const x = (R() - 0.5) * 28, y = (R() - 0.5) * 20; ctx.strokeStyle = '#4c9a3a'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(x, y + 3); ctx.lineTo(x, y); ctx.stroke(); raDot(x, y, 2, cs[0]); raDot(x, y, 0.8, cs[1]); } } },
            { k: 'srock', w: 34, h: 28, ox: 17, oy: 14, n: 3, paint(v) { raRock(9 + v * 2, 6.5 + v, '#8c8f93', '#b9bcc0', '#5f6266', 90 + v); } },
        ],
    },
    canyon: {
        major: [
            { k: 'sag', w: 70, h: 100, ox: 35, oy: 86, n: 2, paint(v) {
                const hg = 58 + v * 16; raSh(20, 6, 14, 2, 0.22);
                const tube = (pts, w) => raTube(pts, w, '#155236', '#3a9a5c', 'rgba(200,255,205,0.4)');
                tube([[0, 0], [0, -hg]], 10); tube([[0, -hg * 0.52], [-14, -hg * 0.52], [-14, -hg * 0.84]], 7); tube([[0, -hg * 0.38], [13, -hg * 0.38], [13, -hg * 0.68]], 6.5);
                ctx.strokeStyle = 'rgba(8,50,28,0.4)'; ctx.lineWidth = 0.7; for (const f of [-0.28, 0.05, 0.3]) { ctx.beginPath(); ctx.moveTo(f * 10, -hg + 5); ctx.lineTo(f * 10, -2); ctx.stroke(); }
                for (const [fx, fy] of [[0, -hg - 3], [-14, -hg * 0.84 - 3], [13, -hg * 0.68 - 3]]) { raDot(fx, fy, 2.6, '#ff8fb1'); raDot(fx, fy, 1.1, '#fff2a0'); } } },
            { k: 'boul', w: 90, h: 70, ox: 45, oy: 35, n: 3, paint(v) { raRock(16 + v * 3, 11 + v * 2, '#a45f3f', '#d08a62', '#6e3a26', 120 + v); raRock(8, 6, '#a45f3f', '#d08a62', '#6e3a26', 130 + v); } },
            { k: 'barrel', w: 40, h: 40, ox: 20, oy: 20, n: 2, paint(v) {
                const r = 9 + v * 2; raSh(r * 1.1, r * 0.8, 3, 4, 0.22); ctx.fillStyle = rg(-r * 0.3, -r * 0.35, 1, 0, 0, r, [[0, '#6cc07f'], [1, '#2a7d4c']]); ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
                ctx.strokeStyle = 'rgba(10,60,30,0.45)'; ctx.lineWidth = 0.8; for (let i = 0; i < 10; i++) { const a = i * TAU / 10; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r * 0.25, Math.sin(a) * r * 0.25); ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); ctx.stroke(); }
                for (let i = 0; i < 6; i++) raDot(Math.cos(i * 1.05) * r * 0.32, Math.sin(i * 1.05) * r * 0.32, 1.7, '#ffd84a'); } },
            { k: 'pear', w: 56, h: 50, ox: 28, oy: 25, n: 2, paint(v) {
                raSh(20, 12, 4, 6, 0.2); const pads = [[-9, 3, 8, 11, -0.3], [7, 4, 7, 10, 0.4], [-2, -8, 8, 11, 0.1], [12, -6, 6, 8, 0.7]];
                for (const [x, y, rx, ry, a] of pads) { ctx.fillStyle = rg(x - 2, y - 3, 1, x, y, rx, [[0, '#8fcf86'], [1, '#3a8d54']]); ctx.beginPath(); ctx.ellipse(x, y, rx, ry, a, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(20,70,40,0.5)'; ctx.lineWidth = 0.8; ctx.stroke(); for (let k = 0; k < 5; k++) raDot(x + Math.cos(k * 2) * rx * 0.5, y + Math.sin(k * 2) * ry * 0.5, 0.6, '#f2f2c8'); }
                for (const [x, y] of [[-2, -17], [12, -13], [-12, -8]]) { raDot(x, y, 2.6, '#c2185b'); raDot(x - 0.6, y - 0.6, 0.9, '#ff80ab'); } } },
        ],
        minor: [
            { k: 'peb', w: 34, h: 26, ox: 17, oy: 13, n: 3, paint(v) { const R = mulberry(200 + v); for (let i = 0; i < 5; i++) { const x = (R() - 0.5) * 22, y = (R() - 0.5) * 14, r = 2 + R() * 2.5; raSh(r, r * 0.7, 1, 1.3, 0.25); raDot(x, y, r, '#b07750'); raDot(x - r * 0.3, y - r * 0.3, r * 0.4, '#e0b88e'); } } },
            { k: 'tumble', w: 34, h: 34, ox: 17, oy: 17, n: 2, paint(v) { const R = mulberry(210 + v); raSh(11, 8, 3, 4, 0.18); for (let i = 0; i < 16; i++) { const a = R() * TAU, r0 = 3 + R() * 5, r1 = 8 + R() * 3; ctx.strokeStyle = ['#b8955a', '#d4b479', '#8f6f3d'][i % 3]; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.arc(0, 0, r1, a, a + 1.6 + R()); ctx.stroke(); ctx.beginPath(); ctx.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); ctx.lineTo(Math.cos(a + 2) * r1, Math.sin(a + 2) * r1); ctx.stroke(); } } },
            { k: 'drygr', w: 30, h: 30, ox: 15, oy: 20, n: 2, paint(v) { ctx.lineCap = 'round'; for (let i = 0; i < 9; i++) { const a = -Math.PI / 2 + (i - 4) * 0.3, L = 7 + ((i + v) % 3) * 3; ctx.strokeStyle = i % 2 ? '#c9a653' : '#e0c477'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo((i - 4) * 1.4, 4); ctx.quadraticCurveTo((i - 4) * 2.2, -2, Math.cos(a) * L + (i - 4), Math.sin(a) * L + 4); ctx.stroke(); } } },
            { k: 'srock2', w: 34, h: 28, ox: 17, oy: 14, n: 3, paint(v) { raRock(9 + v * 2, 6.5 + v, '#a45f3f', '#d08a62', '#6e3a26', 230 + v); } },
        ],
    },
    night: {
        major: [
            { k: 'ntree', w: 76, h: 76, ox: 38, oy: 38, n: 3, paint(v) { raTree(v, ['rgba(5,20,30,0.6)', '#17394a', '#235d70', '#3a8fa3', 'rgba(150,230,255,0.28)']); ctx.strokeStyle = 'rgba(170,225,255,0.4)'; ctx.lineWidth = 1.2; const r = 15 + v * 3.5; ctx.beginPath(); ctx.arc(0, 0, r - 0.6, Math.PI * 1.05, Math.PI * 1.55); ctx.stroke(); } },
            { k: 'lamp', w: 44, h: 62, ox: 18, oy: 52, n: 1, lamp: true, paint() {
                raSh(10, 4, 4, 2, 0.3); ctx.fillStyle = lg(-2, 0, 2, 0, [[0, '#18222d'], [0.5, '#52687f'], [1, '#18222d']]); ctx.fillRect(-1.5, -36, 3, 38);
                raTube([[0, -36], [0, -41], [9, -43]], 2, '#18222d', '#3b4c5f', 'rgba(255,255,255,0.15)'); ctx.fillStyle = '#18222d'; roundRect(5, -47, 10, 4.5, 2); ctx.fill(); raDot(10, -43, 2.4, '#fff6c8'); } },
            { k: 'nboul', w: 90, h: 70, ox: 45, oy: 35, n: 3, paint(v) { raRock(15 + v * 3, 10 + v * 2, '#3b4d63', '#6c86a6', '#1f2b3a', 300 + v); raRock(7, 5, '#3b4d63', '#6c86a6', '#1f2b3a', 310 + v); } },
            { k: 'nagave', w: 60, h: 60, ox: 30, oy: 30, n: 1, paint() { raSh(20, 15, 5, 6, 0.3); for (let ring = 0; ring < 2; ring++) for (let i = 0; i < 9; i++) { const a = i * TAU / 9 + ring * 0.35, L = ring ? 14 : 22; ctx.save(); ctx.rotate(a); ctx.fillStyle = lg(0, 0, L, 0, [[0, '#1e4a52'], [1, ring ? '#5aa0aa' : '#3b7f8a']]); ctx.beginPath(); ctx.moveTo(0, -3.2 + ring); ctx.quadraticCurveTo(L * 0.7, -6.5, L, 0); ctx.quadraticCurveTo(L * 0.7, 6.5, 0, 3.2 - ring); ctx.fill(); ctx.restore(); } raDot(0, 0, 3, '#8fd0d8'); } },
        ],
        minor: [
            { k: 'nshroom', w: 40, h: 40, ox: 20, oy: 20, n: 2, paint(v) { const gr = ctx.createRadialGradient(0, 0, 1, 0, 0, 18); gr.addColorStop(0, 'rgba(120,255,230,0.55)'); gr.addColorStop(1, 'rgba(120,255,230,0)'); ctx.fillStyle = gr; ctx.fillRect(-20, -20, 40, 40); for (const [x, y, r] of [[-3, 1, 4], [4, -2, 3], [1, 5, 2.5]]) { ctx.fillStyle = '#baf7ea'; ctx.fillRect(x - 0.7, y, 1.4, 3); raDot(x, y, r, '#5ee0c6'); raDot(x - r * 0.3, y - r * 0.3, r * 0.4, '#e8fffa'); } } },
            { k: 'ntuft', w: 30, h: 30, ox: 15, oy: 20, n: 2, paint(v) { ctx.lineCap = 'round'; for (let i = 0; i < 8; i++) { const a = -Math.PI / 2 + (i - 3.5) * 0.28, L = 7 + ((i + v) % 3) * 3; ctx.strokeStyle = i % 2 ? '#2a6f7c' : '#3f8f9c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo((i - 3.5) * 1.5, 4); ctx.quadraticCurveTo((i - 3.5) * 2.2, -2, Math.cos(a) * L + (i - 3.5), Math.sin(a) * L + 4); ctx.stroke(); } } },
            { k: 'nsrock', w: 34, h: 28, ox: 17, oy: 14, n: 3, paint(v) { raRock(9 + v * 2, 6.5 + v, '#3b4d63', '#6c86a6', '#1f2b3a', 330 + v); } },
        ],
    },
    boss: {
        major: [
            { k: 'brazier', w: 56, h: 56, ox: 28, oy: 28, n: 1, flame: true, paint() { raSh(16, 12, 3, 4, 0.35); raDot(0, 0, 12, '#2a2020'); raDot(0, 0, 10, '#5c4a44'); raDot(0, 0, 8.5, '#1a1210'); for (let i = 0; i < 8; i++) { const a = i * TAU / 8; raDot(Math.cos(a) * 11, Math.sin(a) * 11, 2.4, '#7a665e'); } const gr = ctx.createRadialGradient(0, 0, 0, 0, 0, 8.5); gr.addColorStop(0, '#ffd36a'); gr.addColorStop(0.6, '#ff6a1f'); gr.addColorStop(1, '#8a1f0a'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, 8.5, 0, TAU); ctx.fill(); } },
            { k: 'obs', w: 90, h: 70, ox: 45, oy: 35, n: 3, paint(v) { raRock(15 + v * 3, 10 + v * 2, '#2b2527', '#5c4d52', '#161112', 400 + v); ctx.strokeStyle = 'rgba(255,140,50,0.9)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-6, -3); ctx.lineTo(-1, 1); ctx.lineTo(4, -2); ctx.lineTo(8, 3); ctx.stroke(); } },
            { k: 'dead', w: 90, h: 90, ox: 45, oy: 45, n: 2, paint(v) { raSh(24, 18, 5, 8, 0.28); const R = mulberry(420 + v); ctx.lineCap = 'round'; const br = (x, y, a, L, w, d) => { const x2 = x + Math.cos(a) * L, y2 = y + Math.sin(a) * L; ctx.strokeStyle = '#17110f'; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x2, y2); ctx.stroke(); ctx.strokeStyle = 'rgba(255,120,40,0.35)'; ctx.lineWidth = Math.max(0.5, w * 0.3); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x2, y2); ctx.stroke(); if (d > 0) { br(x2, y2, a + 0.5 + R() * 0.3, L * 0.6, w * 0.65, d - 1); br(x2, y2, a - 0.5 - R() * 0.3, L * 0.6, w * 0.65, d - 1); } }; for (let i = 0; i < 5; i++) br(0, 0, i * TAU / 5 + R() * 0.4, 20, 4, 2); raDot(0, 0, 4, '#0e0908'); } },
            { k: 'lavap', w: 100, h: 80, ox: 50, oy: 40, n: 2, lava: true, paint(v) { const R = mulberry(440 + v), pts = []; for (let i = 0; i < 12; i++) { const a = i * TAU / 12, r = 24 + R() * 10; pts.push([Math.cos(a) * r, Math.sin(a) * r * 0.7]); } const path = k => { ctx.beginPath(); pts.forEach(([x, y], i) => i ? ctx.lineTo(x * k, y * k) : ctx.moveTo(x * k, y * k)); ctx.closePath(); }; ctx.fillStyle = '#1c1210'; path(1.18); ctx.fill(); const gr = ctx.createRadialGradient(0, 0, 2, 0, 0, 34); gr.addColorStop(0, '#fff0a0'); gr.addColorStop(0.35, '#ffb02e'); gr.addColorStop(0.75, '#e8461a'); gr.addColorStop(1, '#8a1f0a'); ctx.fillStyle = gr; path(1); ctx.fill(); ctx.strokeStyle = 'rgba(40,18,10,0.7)'; ctx.lineWidth = 1.4; for (let i = 0; i < 5; i++) { const a = R() * TAU, r = 6 + R() * 14; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r * 0.7); ctx.lineTo(Math.cos(a + 0.8) * (r + 8), Math.sin(a + 0.8) * (r + 8) * 0.7); ctx.stroke(); } } },
        ],
        minor: [
            { k: 'cinder', w: 34, h: 28, ox: 17, oy: 14, n: 3, paint(v) { raRock(8 + v * 2, 6 + v, '#2b2527', '#5c4d52', '#161112', 460 + v); for (let i = 0; i < 4; i++) raDot(-6 + i * 4, (i % 2) * 3 - 1, 0.9, '#ff9a3c'); } },
            { k: 'ash', w: 34, h: 26, ox: 17, oy: 13, n: 2, paint(v) { const R = mulberry(470 + v); for (let i = 0; i < 26; i++) { const a = R() * TAU, d = R() * 12; ctx.fillStyle = R() < 0.5 ? 'rgba(210,200,195,0.35)' : 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(Math.cos(a) * d, Math.sin(a) * d * 0.7, 1.8, 1.2, a, 0, TAU); ctx.fill(); } } },
        ],
    },
};
function raDraw(it, v, x, y) {
    const SR = Math.min(RES, 3), e = cachedDraw(spriteCache, 'ra|' + it.k + '|' + v + '|' + SR + '|' + OPT.gfx, it.ox, it.oy, it.w, it.h, SR, () => it.paint(v));
    ctx.drawImage(e.cv, x - e.ox, y - e.oy, e.w, e.h);
}
function raPick(list, h, rare) { let pool = list.filter(it => rare ? it.rare : !it.rare); if (!pool.length) pool = list.filter(it => !it.rare); return pool[Math.floor(h * 997) % pool.length]; }

function drawRaceBack() {
    const R = g.race, T = raceTheme(), th = RACE_X[R.theme] ? R.theme : 'dawn', X = RACE_X[th], d0 = R.dist, q = OPT.gfx, t = menuT, art = RA[th];
    // ground: painted tile that scrolls with the road
    const gp = raceTile('g' + th, 160, 160, (w, h) => paintGround(w, h, th, T, X));
    scrollPat(gp, 0, d0 % 160); ctx.fillStyle = gp; ctx.fillRect(0, 0, W, H);
    // road geometry
    const STEP = 8, pts = [];
    for (let y = -8; y <= H + 8; y += STEP) pts.push([cxAt(y), y]);
    const poly = (off, col) => {
        ctx.fillStyle = col; ctx.beginPath();
        pts.forEach(([x, y], i) => i ? ctx.lineTo(x - ROAD_HW - off, y) : ctx.moveTo(x - ROAD_HW - off, y));
        for (let i = pts.length - 1; i >= 0; i--) ctx.lineTo(pts[i][0] + ROAD_HW + off, pts[i][1]);
        ctx.closePath(); ctx.fill();
    };
    // soft shadow and a graded gravel shoulder where the asphalt meets the ground
    poly(36, 'rgba(0,0,0,0.07)'); poly(26, hexA(X.shoulder, 0.22)); poly(19, hexA(X.shoulder, 0.42)); poly(13, hexA(X.shoulder, 0.7));
    // rumble curb: alternating blocks with a lit inner lip and a dark outer edge
    ctx.fillStyle = X.curbB; poly(9, X.curbB);
    ctx.fillStyle = X.curbA;
    for (let y = -8; y < H + 8; y += STEP) {
        if (Math.floor((d0 + H - y) / 24) % 2) continue;
        const x = cxAt(y); ctx.fillRect(x - ROAD_HW - 9, y, 9, STEP); ctx.fillRect(x + ROAD_HW, y, 9, STEP);
    }
    ctx.fillStyle = 'rgba(0,0,0,0.28)'; for (const [x, y] of pts) { ctx.fillRect(x - ROAD_HW - 10, y, 1.2, STEP); ctx.fillRect(x + ROAD_HW + 8.8, y, 1.2, STEP); }
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; for (const [x, y] of pts) { ctx.fillRect(x - ROAD_HW - 1, y, 1, STEP); ctx.fillRect(x + ROAD_HW, y, 1, STEP); }
    // asphalt: grainy tile + cross-section shading
    const ap = raceTile('asph' + th, 128, 128, (w, h) => paintAsphalt(w, h, T));
    scrollPat(ap, 0, d0 % 128); poly(0, ap);
    if (q >= 1) { const e = roadShadeSprite(); for (const [x, y] of pts) ctx.drawImage(e.cv, x - e.ox, y, e.w, STEP + 0.6); }
    // worn edge lines (continuous) and dashed lane lines
    ctx.lineCap = 'butt'; ctx.lineJoin = 'round';
    for (const side of [-1, 1]) {
        ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 3.4; ctx.beginPath(); pts.forEach(([x, y], i) => { const xx = x + side * (ROAD_HW - 7) + 0.8; i ? ctx.lineTo(xx, y) : ctx.moveTo(xx, y); }); ctx.stroke();
        ctx.strokeStyle = hexA(T.edge, 0.92); ctx.lineWidth = 2.6; ctx.beginPath(); pts.forEach(([x, y], i) => { const xx = x + side * (ROAD_HW - 7); i ? ctx.lineTo(xx, y) : ctx.moveTo(xx, y); }); ctx.stroke();
    }
    ctx.fillStyle = T.line;
    for (let y = -8; y < H + 8; y += 2) { const wc = (d0 + H - y) % 64; if (wc < 34) { const wear = hash2(Math.floor((d0 + H - y) / 64), 5.2) > 0.85 ? 0.55 : 1; ctx.globalAlpha = wear; ctx.fillRect(cxAt(y) - 2, y, 4, 2.2); } }
    ctx.globalAlpha = 1;
    // skid marks laid down every so often
    if (q >= 2) {
        const k0 = Math.floor((d0 - 60) / 420);
        for (let k = k0; k < k0 + 3; k++) {
            if (hash2(k, 77.7) < 0.55) continue;
            const wy = k * 420 + hash2(k, 3.3) * 200, lane = hash2(k, 8.8) < 0.5 ? -56 : 56, drift = (hash2(k, 1.1) - 0.5) * 40;
            ctx.strokeStyle = 'rgba(0,0,0,0.22)'; ctx.lineWidth = 3;
            for (const wo of [-14, 14]) { ctx.beginPath(); for (let u = 0; u <= 90; u += 6) { const y = H - (wy + u - d0); const x = cxAt(y) + lane + wo + (u / 90) * drift; u ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } ctx.stroke(); }
        }
    }
    // roadside scenery: minor decor first, then the bigger pieces, far (top) to near
    const lamps = [], i0 = Math.floor(d0 / 90) - 1, n = Math.ceil(H / 90) + 4;
    for (let i = i0 + n; i >= i0; i--) {
        const y0 = H - (i * 90 - d0);
        for (const side of [-1, 1]) {
            if (q >= 2) for (let m = 0; m < 2; m++) {
                const hh = hash2(i + m * 13.7, side * 3.1 + 9); if (hh < 0.4) continue;
                const it = art.minor[Math.floor(hash2(i, m + side * 5.7) * art.minor.length) % art.minor.length], y = y0 + (hash2(i, 31 + m) - 0.5) * 84;
                const x = cxAt(y) + side * (ROAD_HW + 22 + hh * 150); if (y < -40 || y > H + 40 || x < -40 || x > W + 40) continue;
                raDraw(it, Math.floor(hash2(i, 5 + m) * it.n) % it.n, x, y);
            }
            const h = hash2(i, side * 7.3); if (h < 0.45) continue;
            const it = raPick(art.major, hash2(i, side * 2.9 + 1.7), h > 0.965), y = y0 + (hash2(i, side * 4.1) - 0.5) * 36;
            const x = cxAt(y) + side * (ROAD_HW + 30 + (h - 0.45) * 100 + (it.rare ? 34 : 0)); if (y < -50 || y > H + 50) continue;
            const v = Math.floor(hash2(i, side * 6.1) * it.n) % it.n; raDraw(it, v, x, y);
            if (it.lamp) lamps.push({ gx: x, gy: y, x: x + 10 - 18 + 18, y: y - 43 });
            if (it.flame) { const f = 10 + Math.sin(t * 0.3 + i * 2) * 3 + hash2(Math.floor(t / 3), i) * 3; drawGlow(x, y, 46, '#ff6a1f', 0.55); ctx.fillStyle = '#ff7a1a'; ctx.beginPath(); ctx.moveTo(x - 6, y + 2); ctx.quadraticCurveTo(x - 8, y - f * 0.6, x, y - f * 1.6); ctx.quadraticCurveTo(x + 8, y - f * 0.6, x + 6, y + 2); ctx.fill(); ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.moveTo(x - 3, y + 2); ctx.quadraticCurveTo(x - 3, y - f * 0.3, x, y - f * 0.9); ctx.quadraticCurveTo(x + 3, y - f * 0.3, x + 3, y + 2); ctx.fill(); }
            if (it.lava) drawGlow(x, y, 70 + Math.sin(t * 0.06 + i) * 6, '#ff5a1f', 0.5);
        }
    }
    // finish gantry
    if (R.len < 1e8) {
        const y = R.dist + H - R.len;
        if (y > -70 && y < H + 50) {
            const cx = cxAt(y), x0 = cx - ROAD_HW, rw = ROAD_HW * 2, cell = rw / 16;
            for (let k = 0; k < 16; k++) for (let j = 0; j < 3; j++) { ctx.fillStyle = (k + j) % 2 ? '#fdfdfd' : '#15151a'; ctx.fillRect(x0 + k * cell, y - 12 + j * 8, cell, 8); }
            ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x0 - 6, y + 14, rw + 12, 14);   // gantry shadow
            for (const px of [x0 - 12, x0 + rw + 4]) { ctx.fillStyle = lg(px, 0, px + 8, 0, [[0, '#8a8f9c'], [0.5, '#e8ecf4'], [1, '#6a6f7c']]); ctx.fillRect(px, y - 74, 8, 76); ctx.fillStyle = '#3a3d48'; ctx.fillRect(px - 2, y - 2, 12, 5); }
            ctx.fillStyle = lg(0, y - 86, 0, y - 62, [[0, '#ff6b4a'], [1, '#c0392b']]); roundRect(x0 - 16, y - 86, rw + 32, 24, 5); ctx.fill();
            for (let k = 0; k < 18; k++) { ctx.fillStyle = k % 2 ? 'rgba(255,255,255,0.9)' : 'rgba(0,0,0,0.75)'; ctx.fillRect(x0 - 16 + 4 + k * ((rw + 24) / 18), y - 84, (rw + 24) / 36, 4); }
            ctx.fillStyle = '#fff'; ctx.font = '900 18px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('META', cx, y - 70); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
            for (let k = 0; k < 14; k++) { const bx = x0 - 8 + k * ((rw + 16) / 13), sw = Math.sin(t * 0.12 + k) * 1.5; ctx.fillStyle = CONF[k % CONF.length]; ctx.beginPath(); ctx.moveTo(bx - 5, y - 62); ctx.lineTo(bx + 5, y - 62); ctx.lineTo(bx + sw, y - 50); ctx.closePath(); ctx.fill(); }
        }
    }
    // atmosphere
    if (q >= 2 && (th === 'dawn' || th === 'canyon')) {
        const b = raBlobSprite();
        for (let i = 0; i < 3; i++) { const x = ((i * 210 + t * 0.35) % (W + 340)) - 170, y = ((i * 290 + d0 * 0.18) % (H + 360)) - 180; ctx.globalAlpha = 0.2; ctx.drawImage(b.cv, x - 100 * (1.1 + i * 0.2), y - 70 * (1.1 + i * 0.2), 200 * (1.1 + i * 0.2), 140 * (1.1 + i * 0.2)); }
        ctx.globalAlpha = 1;
    }
    if (q >= 1) { const v = raVignette(); ctx.drawImage(v.cv, 0, 0, W, H); }
    if (th === 'dawn' || th === 'canyon') {   // low morning / afternoon sun from the upper left
        const gr = ctx.createLinearGradient(0, 0, W, H * 0.8); gr.addColorStop(0, th === 'dawn' ? 'rgba(255,238,170,0.15)' : 'rgba(255,205,130,0.16)'); gr.addColorStop(0.5, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(40,20,60,0.10)');
        ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
    }
    if (q >= 2 && th === 'canyon') for (let i = 0; i < 18; i++) { const x = (hash2(i, 1) * W + t * (0.4 + hash2(i, 2)) + d0 * 0.05) % W, y = (hash2(i, 3) * H + d0 * (0.5 + hash2(i, 4) * 0.8)) % H; ctx.fillStyle = 'rgba(255,236,200,0.22)'; ctx.fillRect(x, y, 1.6, 1.6); }
    if (th === 'boss') {
        const pulse = 0.5 + 0.5 * Math.sin(t * 0.05);
        const gr = ctx.createRadialGradient(W / 2, H * 0.6, 120, W / 2, H * 0.6, 460); gr.addColorStop(0, 'rgba(255,70,20,0)'); gr.addColorStop(1, 'rgba(255,60,20,' + (0.16 + 0.1 * pulse).toFixed(2) + ')'); ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
        if (q >= 1) for (let i = 0; i < 26; i++) { const life = (t * (0.6 + hash2(i, 2) * 0.9) + hash2(i, 9) * 400) % 400, x = (hash2(i, 1) * W + Math.sin(life * 0.05 + i) * 14) % W, y = H - life * (H / 400) * 1.2; ctx.fillStyle = 'rgba(255,' + (140 + hash2(i, 5) * 90 | 0) + ',60,' + (0.8 * (1 - life / 400)).toFixed(2) + ')'; ctx.fillRect(x, y, 1.8, 1.8); }
    }
    if (th === 'night') {   // darkness with a headlight cone, then lamp pools and fireflies on top
        const p = g.player;
        ctx.save(); ctx.fillStyle = 'rgba(3,8,24,0.5)'; ctx.fillRect(0, 0, W, H);
        ctx.globalCompositeOperation = 'destination-out';
        const gr = ctx.createRadialGradient(p.x, p.y - 80, 10, p.x, p.y - 80, 200);
        gr.addColorStop(0, 'rgba(0,0,0,0.95)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H); ctx.restore();
        for (const l of lamps) { drawGlow(l.gx + 2, l.gy + 2, 70, '#ffd98a', 0.42); drawGlow(l.x, l.y, 24, '#fff0b0', 0.95); }
        if (q >= 1) for (let i = 0; i < 16; i++) { const x = (hash2(i, 1) * W + Math.sin(t * 0.02 + i * 3) * 30 + W) % W, y = (hash2(i, 2) * H + d0 * 0.25 + Math.cos(t * 0.017 + i) * 20) % H, a = 0.35 + 0.65 * Math.abs(Math.sin(t * 0.04 + i * 1.7)); drawGlow(x, y, 9, '#b8ff8a', a * 0.8); ctx.fillStyle = 'rgba(230,255,190,' + a.toFixed(2) + ')'; ctx.fillRect(x - 0.7, y - 0.7, 1.4, 1.4); }
    }
}
function drawTacoCar(x, y, s, o = {}) {
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.rotate((o.steer || 0) * 0.16); ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.ellipse(2, 6, 17, 26, 0, 0, TAU); ctx.fill();
    // wheels
    ctx.fillStyle = '#1a1a1a';
    for (const [wx, wy] of [[-15, -14], [15, -14], [-15, 14], [15, 14]]) roundRect(wx - 4, wy - 7, 8, 14, 3), ctx.fill();
    if (o.nitro) { ctx.fillStyle = '#ff7a1a'; ctx.beginPath(); ctx.moveTo(-6, 24); ctx.lineTo(0, 24 + 14 + Math.random() * 10); ctx.lineTo(6, 24); ctx.fill(); ctx.fillStyle = '#fff3a0'; ctx.beginPath(); ctx.moveTo(-3, 24); ctx.lineTo(0, 24 + 8 + Math.random() * 6); ctx.lineTo(3, 24); ctx.fill(); }
    // taco shell body
    ctx.fillStyle = '#f2b138'; roundRect(-14, -24, 28, 48, 13); ctx.fill();
    ctx.fillStyle = '#d99422'; roundRect(-14, -24, 7, 48, 6); ctx.fill();
    ctx.strokeStyle = '#b87414'; ctx.lineWidth = 1.5; roundRect(-14, -24, 28, 48, 13); ctx.stroke();
    // fillings: lettuce, tomato, cheese
    ctx.fillStyle = '#5fcf5f'; ctx.beginPath(); ctx.moveTo(-9, -18);
    for (let i = 0; i < 6; i++) ctx.quadraticCurveTo(-5 + (i % 2 ? 2 : -2) * 2.2, -18 + i * 7 + 3.5, i % 2 ? 4 : -4, -18 + i * 7 + 7);
    ctx.lineTo(9, 24); ctx.lineTo(9, -18); ctx.fill();
    ctx.fillStyle = '#ff4d4d'; for (const yy of [-12, 0, 12]) { ctx.beginPath(); ctx.arc(0, yy, 3.2, 0, TAU); ctx.fill(); }
    ctx.fillStyle = '#ffe066'; ctx.fillRect(-2, -20, 4, 3);
    // windshield + driver sombrero
    ctx.fillStyle = 'rgba(160,220,255,0.85)'; roundRect(-8, -10, 16, 8, 3); ctx.fill();
    ctx.fillStyle = '#c9893b'; ctx.beginPath(); ctx.ellipse(0, -2, 10, 6, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#e8b65a'; ctx.beginPath(); ctx.ellipse(0, -3, 4.5, 3.5, 0, 0, TAU); ctx.fill();
    // headlights
    ctx.fillStyle = '#fff7b0'; ctx.beginPath(); ctx.arc(-9, -23, 2.5, 0, TAU); ctx.arc(9, -23, 2.5, 0, TAU); ctx.fill();
    ctx.restore();
}
function drawRivalCar(b) {
    const x = b.x, y = b.y, c = b.color, back = b.ratio > 1;
    ctx.save(); ctx.translate(x, y); if (b.flash > 0) ctx.globalAlpha = 0.75;
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(2, 5, 12, 20, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1a1a1a'; for (const [wx, wy] of [[-11, -10], [11, -10], [-11, 10], [11, 10]]) roundRect(wx - 3, wy - 6, 6, 12, 2), ctx.fill();
    ctx.fillStyle = b.flash > 0 ? '#fff' : c; roundRect(-10, -19, 20, 38, 8); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.22)'; roundRect(-10, -19, 5, 38, 4); ctx.fill();
    ctx.fillStyle = '#cfe8f5'; roundRect(-7, back ? 2 : -9, 14, 8, 3); ctx.fill();
    ctx.fillStyle = '#ffe9a8'; if (!back) { ctx.fillRect(-8, 16, 4, 2); ctx.fillRect(4, 16, 4, 2); } else { ctx.fillRect(-8, -19, 4, 2); ctx.fillRect(4, -19, 4, 2); }
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(-1, -17, 2, 34);
    ctx.restore();
    if (b.hp < b.maxHp) { ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(x - 11, y - 26, 22, 3); ctx.fillStyle = '#7bed9f'; ctx.fillRect(x - 11, y - 26, 22 * clamp(b.hp / b.maxHp, 0, 1), 3); }
}
function drawTruck(b) {
    const x = b.x, y = b.y;
    ctx.save(); ctx.translate(x, y);
    if (b.inv > 0 && Math.floor(b.inv / 4) % 2 === 0) ctx.globalAlpha = 0.5;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(4, 8, 36, 52, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1a1a1a'; for (const wy of [-34, -8, 22, 42]) { roundRect(-38, wy - 7, 9, 14, 3); ctx.fill(); roundRect(29, wy - 7, 9, 14, 3); ctx.fill(); }
    const f = b.flash > 0;
    ctx.fillStyle = f ? '#ffb8ac' : '#9b2d20'; roundRect(-30, -2, 60, 58, 8); ctx.fill();   // tank trailer
    ctx.fillStyle = f ? '#ffc9be' : '#d63c2a'; roundRect(-26, 2, 52, 50, 24); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.18)'; roundRect(-20, 6, 12, 42, 6); ctx.fill();
    ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 11px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('SALSA', 0, 32); ctx.font = 'bold 8px sans-serif'; ctx.fillText('PICANTE', 0, 42);
    ctx.fillStyle = f ? '#ffb8ac' : '#c0392b'; roundRect(-28, -46, 56, 40, 10); ctx.fill();   // cab
    ctx.fillStyle = '#cfe8f5'; roundRect(-20, -38, 40, 14, 5); ctx.fill();
    ctx.fillStyle = '#ffe58a'; ctx.beginPath(); ctx.arc(-18, -45, 4, 0, TAU); ctx.arc(18, -45, 4, 0, TAU); ctx.fill();
    ctx.fillStyle = '#2d3436'; ctx.fillRect(-24, -20, 48, 5);
    // chili stack
    ctx.fillStyle = '#27ae60'; ctx.fillRect(-1, -62, 2, 16); ctx.fillStyle = '#e74c3c'; ctx.beginPath(); ctx.ellipse(0, -52, 4, 9, 0.2, 0, TAU); ctx.fill();
    ctx.restore();
}