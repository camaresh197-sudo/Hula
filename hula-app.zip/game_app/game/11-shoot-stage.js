
// the single entry point the game loop calls; each kind of act has its own update
function updateGame() {
    trackDps();
    if (g.kind === 'convoy') updateConvoy();
    else if (g.kind === 'race') updateRace();
    else if (g.kind === 'rpg') updateRpg();
    else updateShoot();
}

// ---- boss health adapts to how hard you actually hit, so fights last about the same for everyone ----
function setBossHp(b, secs, floorHp) {
    const hp = Math.min(32000, Math.max(floorHp, g.dps * secs * 0.8));
    b.hp = b.maxHp = hp;
}
const bossFloor = base => base + 220 * (g.camp ? g.camp.lvlDone : 0);

function stageDone() {
    const st = g.stage; if (!st || st.done) return;
    st.done = true; g.clearT = 100;
    toast('LEVEL CLEAR!', '', '#7bed9f', 110); sfx('level'); g.levelFlash = 14;
    g.ebullets = [];
}
function popAll() {
    for (let pass = 0; pass < 3; pass++) {
        const left = g.balls.filter(b => !b.dead && !b.boss);
        if (!left.length) break;
        for (const b of left) { dealDamage(g, b, 1e9, { noProc: true, noCrit: true }); if (!b.dead) dealDamage(g, b, 1e9, { noProc: true, noCrit: true }); }
        g.balls = g.balls.filter(b => !b.dead);
    }
}
function clearTick() {
    popAll(); g.ebullets.length = 0;
    for (const k of g.pickups) k.vac = true;
    g.player.iframes = Math.max(g.player.iframes, 5);
    if (--g.clearT <= 0) showClear();
}
function stageOnKill(b) {
    const st = g.stage;
    if (b.type === 'crate') return;
    if (b.type === 'totem') st.smashed = (st.smashed || 0) + 1;
    else if (!b.boss) st.kills = (st.kills || 0) + 1;
}

// ---- sky shooter levels (Acts 1 and 4) ----
function initShootStage(L) {
    const st = g.stage;
    st.dur = (L.sec || 60) * 60; st.spawnT = 40; st.elites = (L.elites || []).map(f => Math.round(f * st.dur));
    st.evT = L.ev ? 220 : 1e9; st.bossSpawned = false;
}
function campShootSpawn(m) {
    const st = g.stage, L = levelOf(NODES[g.camp.node]);
    if (g.clearT > 0) { clearTick(); return; }
    if (st.done) return;
    st.t++;
    if (st.boss) {
        if (st.t === 1) { g.warn = 110; sfx('boss'); }
        if (st.t === 110 && !st.bossSpawned) {
            st.bossSpawned = true;
            const b = spawnBall(L.boss, W / 2, -70);
            if (L.boss === 'gran') { setBossHp(b, 62, bossFloor(3200)); b.r = 54; b.dmg = 30; } else setBossHp(b, 28, bossFloor(800));
            toast(L.bossName, L.boss === 'gran' ? 'Take back the Golden Sombrero!' : 'Pop it for treasure!', '#ff4757', 220);
        }
        if (st.bossSpawned && st.t > 130 && !g.balls.some(b => b.boss && !b.dead)) stageDone();
        return;
    }
    if (st.t < st.dur - 150 && --st.spawnT <= 0) {
        if (g.balls.length < 140) spawnBall(randomBallType(m));
        st.spawnT = Math.max(12, 56 - m * 5.5) * rand(0.7, 1.3) * 2 / g.D.spawn;   // half as many enemies
    }
    if (st.elites.length && st.t >= st.elites[0]) { st.elites.shift(); spawnBall('elite'); toast('Elite ball incoming!', '', '#8e44ad', 100); }
    if (--st.evT <= 0 && !g.event && st.t < st.dur - 700) { startEvent(); st.evT = randi(8, 11) * 60; }
    updateEvent();
    if (st.t >= st.dur) stageDone();
}
// El Gran Globo: three phases
function updateGran(b, sm) {
    const p = g.player, hp = b.hp / b.maxHp, ph = hp > 0.66 ? 1 : hp > 0.33 ? 2 : 3;
    if (b.phase !== ph) {
        if (b.phase) {
            b.inv = 80; g.shake = 18; g.ebullets.length = 0; sfx('boss'); addRing(g, b.x, b.y, 220, '#ff4757', 30);
            toast('PHASE ' + ph, ph === 2 ? 'He gets serious!' : 'He goes berserk!', '#ff4757', 170);
            for (let i = 0; i < 3; i++) spawnBall('fast', rand(30, W - 30), -20);
        }
        b.phase = ph; b.t = b.t || 0; b.cd1 = 90; b.cd2 = 160; b.cd3 = 0; b.cd4 = 300; b.spin = 0; b.diveT = 0;
    }
    if (b.inv > 0) b.inv--;
    b.t += sm;
    const tx = W / 2 + Math.sin(b.t * 0.011 * (1 + 0.22 * ph)) * (W / 2 - b.r - 12);
    if (b.diveT > 0) {   // dive bomb: drop toward the player, then climb back
        b.diveT--;
        if (b.diveT > 40) b.y += (Math.min(p.y - 130, 360) - b.y) * 0.08; else b.y += (120 - b.y) * 0.07;
        b.x += (p.x - b.x) * 0.02;
    } else { b.y += ((b.y < 118 ? 1.4 : 0) + (118 - b.y) * 0.04) * sm; b.x += (tx - b.x) * 0.03 * sm; }
    if (b.inv > 0 || b.y < 40) return;
    const sp = 2.3 + 0.2 * ph, dm = 10 + 2 * ph;
    if ((b.cd1 -= sm) <= 0) {   // aimed fan
        b.cd1 = 100 - 14 * ph; const base = Math.atan2(p.y - b.y, p.x - b.x), n = ph === 1 ? 2 : ph === 2 ? 3 : 4;
        for (let k = -n; k <= n; k++) g.ebullets.push({ x: b.x, y: b.y + b.r * 0.6, vx: Math.cos(base + k * 0.24) * sp, vy: Math.sin(base + k * 0.24) * sp, r: 4.5, dmg: dm });
        sfx('ebullet');
    }
    if (ph >= 2 && (b.cd2 -= sm) <= 0) {   // ring burst
        b.cd2 = 150 - 14 * ph; const n = 12 + 2 * ph, off = rand(0, TAU);
        for (let k = 0; k < n; k++) g.ebullets.push({ x: b.x, y: b.y, vx: Math.cos(off + k * TAU / n) * 1.9, vy: Math.sin(off + k * TAU / n) * 1.9, r: 4, dmg: dm - 1 });
        addRing(g, b.x, b.y, 60, '#ff6b6b', 14);
    }
    if (ph === 3 && (b.cd3 -= sm) <= 0) {   // spiral stream
        b.cd3 = 8; b.spin += 0.5;
        for (const s of [0, Math.PI]) g.ebullets.push({ x: b.x, y: b.y + 10, vx: Math.cos(b.spin + s) * 2.1, vy: Math.sin(b.spin + s) * 2.1, r: 3.6, dmg: dm - 2 });
    }
    if ((b.cd4 -= sm) <= 0) {   // summons and dives
        b.cd4 = ph === 1 ? 330 : 280;
        if (ph >= 2 && Math.random() < 0.6) { b.diveT = 90; toast('DIVE!', '', '#ff9f43', 50); }
        else for (let i = 0; i < 3; i++) spawnBall(ph === 3 && i === 1 ? 'big' : 'fast', b.x + (i - 1) * 40, b.y + b.r * 0.6);
    }
}

// ---- shared helpers for the racer and RPG updates ----
function commonTick() {
    const S = g.S, p = g.player;
    g.frames++; g.stage.t++;
    computeDyn(g);
    if (p.iframes > 0) p.iframes--;
    if (S.regen > 0) p.hp = Math.min(S.maxHp, p.hp + S.regen / 60);
    if (S.maxShield > 0 && g.shield < S.maxShield) { if (++g.shieldT >= 900) { g.shield++; g.shieldT = 0; } }
    if (g.comboT > 0) { if (--g.comboT <= 0) g.combo = 0; }
    if (g.timeSlow > 0) g.timeSlow--;
    if (g.dust > 0) g.dust--;
    if (g.furyT > 0) g.furyT--;
    if (g.magT > 0) g.magT--;
    if (g.buff && --g.buff.t <= 0) g.buff = null;
    if (g.hurtFlash > 0) g.hurtFlash--;
    if (g.bombFlash > 0) g.bombFlash--;
    if (g.levelFlash > 0) g.levelFlash--;
    if (g.shake > 0) g.shake--;
    if (g.streak && --g.streak.t <= 0) g.streak = null;
    if (g.warn > 0) g.warn--;
    for (const id in g.actives) if (g.actives[id].cd > 0) g.actives[id].cd--;
    for (const h of g.hooks.tick) h(g);
    if (g.frames % 30 === 0) checkAchievements();
}
function commonFx() {
    for (let i = g.fx.length - 1; i >= 0; i--) {
        const f = g.fx[i];
        if (f.kind === 'p') { f.x += f.vx; f.y += f.vy; const dr = f.grav ? 0.985 : 0.94; f.vx *= dr; f.vy = f.vy * dr + (f.grav || 0); }
        else if (f.kind === 'hat') { f.x += f.vx; f.y += f.vy; f.vy += 0.22; f.rot += f.vr; }
        if (--f.t <= 0) g.fx.splice(i, 1);
    }
    for (let i = g.texts.length - 1; i >= 0; i--) { const t = g.texts[i]; t.y -= 0.6; if (--t.t <= 0) g.texts.splice(i, 1); }
    for (let i = g.bolts.length - 1; i >= 0; i--) if (--g.bolts[i].t <= 0) g.bolts.splice(i, 1);
    for (let i = g.toasts.length - 1; i >= 0; i--) if (--g.toasts[i].t <= 0) g.toasts.splice(i, 1);
}
function updatePet() {
    const pt = g.pet, p = g.player; if (!pt) return;
    pt.ang += 0.04;
    const tx = p.x + Math.cos(pt.ang) * 34, ty = p.y - 30 + Math.sin(pt.ang * 2) * 10;
    pt.x += (tx - pt.x) * 0.12; pt.y += (ty - pt.y) * 0.12;
    if (--pt.cd <= 0) {
        const tg = nearestBall(g, pt.x, pt.y, 320);
        if (tg) { const a = Math.atan2(tg.y - pt.y, tg.x - pt.x); shoot(g, pt.x, pt.y, a, 6, 7 * (1 + 0.6 * (pt.rank - 1)), { pierce: 0, r: 2.5, color: '#ff9f43', homing: 0.08, life: 120, canSplit: false }); pt.cd = 42 - 7 * pt.rank; }
        else pt.cd = 15;
    }
}
// pickups: scroll = how fast the world slides under them (racer); gravity only in the racer
function updatePickupsK(scroll) {
    const S = g.S, p = g.player, mag = S.magnet + (g.magT > 0 ? 170 : 0), race = g.kind === 'race';
    for (let i = g.pickups.length - 1; i >= 0; i--) {
        const k = g.pickups[i]; k.t++;
        const dx = p.x - k.x, dy = p.y - k.y, d = Math.sqrt(dx * dx + dy * dy);
        if (k.vac || d < mag) { const s = k.vac ? 9 : 6; k.x += dx / (d || 1) * s; k.y += dy / (d || 1) * s; }
        else if (k.fixed) k.y += scroll;
        else if (race) { k.vx *= 0.95; k.vy *= 0.97; k.x += k.vx; k.y += k.vy + scroll; }
        else { k.vx *= 0.92; k.vy *= 0.92; k.x += k.vx; k.y += k.vy; }
        if (d < p.r + 11) {
            if (k.type === 'xp') gainXp(g, k.value);
            else if (k.type === 'gold') { gainGold(g, k.value); sfx('coin'); }
            else if (k.type === 'heart') heal(g, 20 * S.heartHeal);
            else if (k.type === 'chest') grantRandomRelic(g, 'Chest:');
            else if (k.type === 'gear') grantGear();
            else if (k.type.startsWith('power:')) applyPowerup(k.type.slice(6));
            g.pickups.splice(i, 1);
            if (mode !== 'play') return;
            continue;
        }
        if (k.y > H + 30 || k.y < -80) g.pickups.splice(i, 1);
    }
}
function fixedCoin(x, y, v) { g.pickups.push({ type: 'gold', x, y, value: v, vx: 0, vy: 0, vac: false, t: Math.floor(rand(0, 30)), fixed: true }); }

// ---- the same powerups, flavored for each kind of act ----
function applyPowerup(t) {
    const U = POWERUPS[t]; if (!U) return;
    if (g.kind === 'shoot') { applyPowerupShoot(t); return; }
    const T = (PU_TXT[g.kind] || {})[t] || [U.name, ''];
    sfx('power'); toast(T[0], T[1], U.c, 110);
    if (t === 'magnet') { g.pickups.forEach(k => k.vac = true); g.magT = 480; }
    else if (t === 'nuke') {
        for (const b of g.balls.slice()) if (!b.dead && b.type !== 'crate') dealDamage(g, b, g.kind === 'race' ? 170 : 130, { noProc: true, noCrit: true, color: '#ff6b6b' });
        if (g.kind === 'race') smashObstacles();
        g.ebullets.length = 0; g.bombFlash = 16; g.shake = 14; vib(90);
        for (let i = 0; i < 6; i++) dropPickup(g, 'gold', rand(40, W - 40), rand(120, 300), 2);
        addRing(g, g.player.x, g.player.y, 260, g.kind === 'race' ? '#ff6b35' : '#ff9f43', 26); confetti(g, g.player.x, g.player.y, 36);
    }
    else if (t === 'freeze') g.timeSlow = Math.max(g.timeSlow, 300);
    else if (t === 'fury') g.buff = { type: 'Fury', t: 480 };
    else if (t === 'haste') g.buff = { type: 'Haste', t: 480 };
    else if (t === 'rush') for (let i = 0; i < 12; i++) dropPickup(g, 'gold', rand(40, W - 40), rand(120, 300), 2);
    else if (t === 'frenzy') { if (g.kind === 'race') { g.race.nitro = Math.max(g.race.nitro, 240); g.buff = { type: 'Rapid', t: 240 }; } else g.furyT = 480; }
    else if (t === 'shield') g.shield = Math.max(g.shield, 1);
}
function useActiveAlt(id, a) {   // Dash / Siesta / Cape, in each act's own style
    const p = g.player;
    if (id === 'dash') {
        if (g.kind === 'race') { g.race.nitro = Math.max(g.race.nitro, 70 + 25 * a.rank); toast('NITRO!', '', '#ff9f43', 60); }
        else { p.dash = 10; p.dashVx = g.lastDir.x * 9; p.dashVy = g.lastDir.y * 9; p.iframes = Math.max(p.iframes, 16); }
    } else if (id === 'slow') { g.timeSlow = 180 + 60 * (a.rank - 1); toast('Siesta', g.kind === 'race' ? 'Traffic slowed' : 'Foes slowed', '#a29bfe', 90); }
    else if (id === 'cape') {
        const R = 105 + 12 * a.rank; p.iframes = Math.max(p.iframes, 30);
        addRing(g, p.x, p.y, R, '#ff4757', 20); burst(g, p.x, p.y, '#ff4757', 14); if (AC && OPT.sfx) ole(0);
        for (const b of g.balls) { if (b.dead || b.type === 'crate') continue; const d = Math.hypot(b.x - p.x, b.y - p.y); if (d < R + b.r) { dealDamage(g, b, 22 * (1 + 0.5 * (a.rank - 1)), { noProc: true, noCrit: true, color: '#ff4757' }); if (!b.boss && d > 0) { b.vx = (b.x - p.x) / d * 5; b.vy = (b.y - p.y) / d * 5; b.kx = b.vx; b.ky = b.vy; b.kT = 14; } } }
        for (let i = g.ebullets.length - 1; i >= 0; i--) { const e = g.ebullets[i]; if (Math.hypot(e.x - p.x, e.y - p.y) < R) { g.ebullets.splice(i, 1); addText(g, e.x, e.y, '¡OLÉ!', '#ff4757', 11); } }
    }
}

// ---- special enemy art, player sprite and backdrops per kind ----
function drawSpecialBall(b) {
    if (b.type === 'gran') {
        drawGlow(b.x, b.y, b.r * 3, '#ff2a00', 0.35); ctx.save();
        if (b.inv > 0 && Math.floor(b.inv / 4) % 2 === 0) ctx.globalAlpha = 0.5;
        if (b.flash > 0) ctx.globalAlpha = 0.8;
        drawVillain(b.x, b.y, b.r * 0.95, menuT, {}); ctx.restore(); return true;
    }
    if (b.type === 'truck') { drawTruck(b); return true; }
    if (b.type === 'calavera') { drawCalavera(b); return true; }
    if (b.type === 'totem') { drawTotem(b); return true; }
    if (b.type === 'crate') {
        const x = b.x, y = b.y, r = b.r;
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x - r + 2, y + r - 3, r * 2, 5);
        ctx.fillStyle = b.flash > 0 ? '#fff' : '#a0703c'; roundRect(x - r, y - r, r * 2, r * 2, 3); ctx.fill();
        ctx.strokeStyle = '#5e3a1a'; ctx.lineWidth = 2; roundRect(x - r, y - r, r * 2, r * 2, 3); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(x - r, y - r); ctx.lineTo(x + r, y + r); ctx.moveTo(x + r, y - r); ctx.lineTo(x - r, y + r); ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.fillRect(x - r + 3, y - r + 3, r * 2 - 6, 3); return true;
    }
    if (b.type === 'rival') { drawRivalCar(b); return true; }
    return false;
}
function drawPlayerSprite(p, blink) {
    if (g.kind === 'convoy') return;
    const a = blink ? 0.4 : 1;
    if (g.kind === 'race') drawTacoCar(p.x, p.y, 1, { alpha: a, steer: g.race ? g.race.steer : 0, nitro: g.race && g.race.nitro > 0 });
    else if (g.kind === 'rpg') {
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(p.x, p.y + 22, 12, 4, 0, 0, TAU); ctx.fill();
        const R = g.rpg, mv = R && R.walk !== g._rw; if (R) g._rw = R.walk;
        g._mvT = mv ? 6 : Math.max(0, (g._mvT || 0) - 1); VQ.g = g._mvT > 0 ? 'walk' : 'idle'; VQ.gt = (R ? R.walk : 0) / 0.45 * 6.3 * 0.4 + 0;
        drawVaquero(p.x, p.y - 8, 0.62, p.facing, R ? R.walk : 0, a); VQ.g = null; VQ.gt = null;
    } else {
        if (g.shotCount !== g._sc) { g._sc = g.shotCount; g._fireT = 12; } if (g._fireT > 0) g._fireT--;
        VQ.g = p.dash > 0 ? 'dash' : g.hurtFlash > 0 ? 'recoil' : g._fireT > 0 ? 'fireup' : 'hula'; VQ.fire = g._fireT > 6 ? 1 : 0;
        drawVaquero(p.x, p.y, 0.8, p.facing, menuT * 0.45, a); VQ.g = null;
    }
}
function drawBackdrop() {
    if (g.kind === 'convoy' && g.cv) drawConvoyBack();
    else if (g.kind === 'race' && g.race) drawRaceBack();
    else if (g.kind === 'rpg' && g.rpg) drawRpgBack();
}
function bossFallToast(b) {
    const t = { boss: ['Capitán Globito falls!', 'Chests dropped'], boss2: ['El Sombrero Gigante falls!', 'Chests dropped'], gran: ['EL GRAN GLOBO FALLS!', 'The Golden Sombrero is free!'], truck: ['The truck is wrecked!', 'Salsa everywhere'], calavera: ['La Calavera crumbles!', 'Chests dropped'] }[b.type];
    toast(g.camp || b.type !== 'boss' ? t[0] : 'El Gran Globo falls!', t[1], '#ffd32a', 200);
}
ACHS.push(
    { id: 'a1', name: 'Sky Rider',      desc: 'Clear Act 1: The Rise',           gold: 30,  test: g => g.camp && g.camp.lvlDone >= 4 },
    { id: 'a2', name: 'Road Warrior',   desc: 'Clear Act 2: The Pursuit',        gold: 50,  test: g => g.camp && g.camp.lvlDone >= 8 },
    { id: 'a3', name: 'Bone Breaker',   desc: 'Clear Act 3: The Reckoning',      gold: 80,  test: g => g.camp && g.camp.lvlDone >= 12 },
    { id: 'win', name: 'Fiesta Restored', desc: 'Defeat El Gran Globo',          gold: 300, test: g => g.win },
    { id: 'sc20', name: 'High Roller',   desc: 'Score 20,000 in one run',         gold: 60,  test: g => g.score >= 20000 },
);

function killScore(b) {
    let s = (6 + (b.xp || 0) * 5 + Math.sqrt(b.maxHp || 10) * 1.5) * (1 + Math.min(1, g.combo * 0.02));
    if (b.elite) s += 250; if (b.boss) s += 2000;
    return Math.round(s);
}
function skyFrame() { return g.camp ? (g.skyF || 0) + (g.kind === 'shoot' && g.stage ? g.stage.t * 1.3 : 0) : g.frames; }
function trackDps() {
    if (++g.dpsT >= 60) { g.dpsT = 0; const cur = g.dmgAcc; g.dmgAcc = 0; g.dps = Math.max(cur, g.dps * 0.9); }
}

// ---- hidden test mode: tap the menu title 3 times. All nodes open, big damage, can't die. ----
let godMode = false, godTaps = 0, godTapT = 0, godMsg = 0;
function godTap() {
    const now = performance.now(); godTaps = now - godTapT < 1500 ? godTaps + 1 : 1; godTapT = now;
    if (godTaps >= 3) { godTaps = 0; godMode = !godMode; godMsg = 150; sfx('level'); }
}
function drawGodBadge() {
    ctx.fillStyle = 'rgba(255,40,80,0.85)'; roundRect(W / 2 - 34, 2, 68, 12, 5); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 8px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('GOD MODE', W / 2, 11); ctx.textAlign = 'left';
}