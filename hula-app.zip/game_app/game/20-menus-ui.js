function menuPill(x, y, w, h) {
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; roundRect(x, y + 2, w, h, h / 2); ctx.fill();
    ctx.fillStyle = 'rgba(24,14,40,0.82)'; roundRect(x, y, w, h, h / 2); ctx.fill();
    ctx.strokeStyle = 'rgba(255,211,42,0.55)'; ctx.lineWidth = 1.2; roundRect(x, y, w, h, h / 2); ctx.stroke();
}
// shout log -> mouth shape. Each syllable: [start, end, openness, width (+smile / -round)], seconds after the cue starts
const SYLT = {
    andale: [[0, .12, .6, 0], [.13, .37, 1, .2], [.38, .58, .45, .55]],
    arriba: [[0, .11, .7, 0], [.11, .28, .3, .4], [.3, .5, 1, .1], [.56, .67, .7, 0], [.67, .84, .3, .4], [.86, 1.18, 1, .1]],
    porque: [[0, .14, .6, -.5], [.2, .32, .45, .5], [.34, .68, .95, .1]],
    si: [[.03, .27, .4, .7]],
    grito: [[0, 1.1, .9, -.2]],
};
const talk = { mo: 0, mw: 0, brow: 0, hop: 0 };
function talkState() {
    let to = 0, tw = 0, tb = 0, th = 0;
    if (AC && typeof shoutLog !== 'undefined' && musTrack === 'menu') {
        const now = AC.currentTime;
        for (const s of shoutLog) {
            const sy = SYLT[s.k]; if (!sy) continue;
            const u = now - s.t;
            if (u < -0.05 || u > sy[sy.length - 1][1] + 0.5) continue;
            tb = Math.max(tb, u < sy[sy.length - 1][1] + 0.1 ? 1 : 0.4);
            for (const y of sy) if (u >= y[0] && u <= y[1]) { to = y[2]; tw = y[3]; th = Math.sin((u - y[0]) / (y[1] - y[0]) * Math.PI) * 5; }
        }
    }
    talk.mo += (to - talk.mo) * 0.5; talk.mw += (tw - talk.mw) * 0.5; talk.brow += (tb - talk.brow) * 0.35; talk.hop += (th - talk.hop) * 0.5;
    return talk;
}
// ---------- title screen: backdrop, effects and layout ----------
let menuInT = 0, menuSeen = -99;
const MFX = { sp: [], barT: 0, bar: 0, dust: [] };
const MENU_HY = 282, MENU_HZ = 372, MENU_S = 4.6;   // hero origin, horizon line, hero scale
const MENU_G = [['hula', 0], ['hula', 0], ['flex', 0], ['cheer', 0], ['hips', 1], ['dance', 1], ['point', 0], ['hula', 0]];   // gesture per bar: [name, hide the hoop]
function menuBeatPulse() {
    if (AC && OPT.music && AC.state === 'running' && musTrack === 'menu' && beatLog.length) {
        const lb = beatLog[beatLog.length - 1], dt = Math.max(0, AC.currentTime - lb.t);
        return { p: lb.a * Math.exp(-dt * 6.5), bar: lb.a === 1 ? Math.exp(-dt * 5) : 0, lb };
    }
    return { p: 0, bar: 0, lb: null };
}
function menuMesa(o, y, sc, col) {
    ctx.fillStyle = col;
    for (let k = -1; k < 3; k++) {
        const x0 = k * 240 - o;
        ctx.beginPath(); ctx.moveTo(x0, y);
        for (const [px, py] of [[14, -46], [60, -50], [74, -24], [104, -24], [120, -66], [168, -70], [186, 0]]) ctx.lineTo(x0 + px * sc, y + py * sc);
        ctx.lineTo(x0 + 186 * sc, y + 40); ctx.lineTo(x0, y + 40); ctx.closePath(); ctx.fill();
    }
}
function menuBackdrop(q, t, bt) {
    // low sun with rays, throbbing on the beat
    const sx = W / 2, sy = MENU_HY - 40;
    drawGlow(sx, sy, 210 + bt.p * 26, '#ffb347', 0.55);
    const sg = lg(0, sy - 100, 0, sy + 100, [[0, '#fff2b8'], [0.5, '#ffc45a'], [1, '#ff7a3c']]); ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(sx, sy, 96 + bt.p * 4, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,240,200,0.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(sx, sy, 106 + bt.p * 6 + Math.sin(t * 0.04) * 2, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,200,120,0.18)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(sx, sy, 128 + bt.p * 8, 0, TAU); ctx.stroke();
    if (q >= 1) {
        ctx.save(); ctx.translate(sx, sy); ctx.rotate(-t * 0.002); ctx.fillStyle = 'rgba(255,220,150,0.08)';
        for (let k = 0; k < 18; k++) { ctx.rotate(TAU / 18); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(520, -22); ctx.lineTo(520, 22); ctx.closePath(); ctx.fill(); }
        ctx.restore();
        for (let i = 0; i < 28; i++) {   // stars twinkle above the dusk
            const x = (i * 137.5) % W, y = (i * 53.3) % 200, a = (0.15 + 0.5 * (0.5 + 0.5 * Math.sin(t * 0.05 + i * 1.7))) * (1 - y / 240);
            ctx.fillStyle = `rgba(255,248,220,${a})`; ctx.fillRect(x, y, 1.7, 1.7);
        }
    }
    for (let i = 0; i < 4; i++) {   // slow clouds
        const x = ((i * 190 + t * (0.14 + i * 0.05)) % (W + 200)) - 100, y = 118 + i * 38 + Math.sin(t * 0.01 + i) * 4;
        ctx.fillStyle = 'rgba(255,196,160,0.2)'; ctx.beginPath(); ctx.ellipse(x, y, 52, 11, 0, 0, TAU); ctx.ellipse(x + 26, y - 7, 30, 11, 0, 0, TAU); ctx.ellipse(x - 28, y - 4, 26, 9, 0, 0, TAU); ctx.fill();
    }
    menuMesa((t * 0.05) % 240, MENU_HZ - 6, 0.8, 'rgba(150,80,110,0.5)');
    menuMesa((t * 0.1) % 240 + 90, MENU_HZ + 2, 0.7, 'rgba(120,52,86,0.75)');
    menuMesa((t * 0.2) % 240, MENU_HZ + 8, 0.95, '#4a2040');
    if (q < 1) return;
    for (let i = 0; i < 3; i++) {   // birds crossing the sky
        const x = ((t * (0.5 + i * 0.12) + i * 150) % (W + 80)) - 40, y = 140 + i * 34 + Math.sin(t * 0.04 + i) * 8, fl = Math.sin(t * 0.3 + i * 2) * 5;
        ctx.strokeStyle = '#2a1230'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(x - 8, y - fl); ctx.quadraticCurveTo(x - 3, y - 4, x, y); ctx.quadraticCurveTo(x + 3, y - 4, x + 8, y - fl); ctx.stroke();
    }
    // fireworks burst on the first beat of every bar (on a timer when the music is off)
    const lb = bt.lb, go = lb ? (lb.a === 1 && lb.t !== MFX.barT) : (t % 130 === 0);
    if (go && MFX.sp.length < 120) {
        if (lb) MFX.barT = lb.t;
        const bx = 40 + Math.random() * 280, by = 66 + Math.random() * 120, hue = Math.random() * 360, n = q >= 2 ? 34 : 20;
        for (let k = 0; k < n; k++) { const a = k / n * TAU + Math.random() * 0.3, v = 1.2 + Math.random() * 2.1; MFX.sp.push({ x: bx, y: by, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 54 + Math.random() * 26, max: 80, h: hue + Math.random() * 40 }); }
    }
    for (let i = MFX.sp.length - 1; i >= 0; i--) {
        const p = MFX.sp[i]; p.x += p.vx; p.y += p.vy; p.vy += 0.035; p.vx *= 0.985; p.vy *= 0.99; p.life--;
        if (p.life <= 0) { MFX.sp.splice(i, 1); continue; }
        const a = Math.min(1, p.life / 30);
        ctx.strokeStyle = `hsla(${p.h},95%,70%,${a})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(p.x - p.vx * 2.5, p.y - p.vy * 2.5); ctx.lineTo(p.x, p.y); ctx.stroke();
    }
    const nc = q >= 2 ? 24 : 12;   // confetti drifting down
    for (let i = 0; i < nc; i++) {
        const x = (i * 79 + Math.sin(t * 0.02 + i) * 16 + t * 0.12 * (i % 3)) % W, y = (t * (0.5 + (i % 4) * 0.18) + i * 47) % (H + 30) - 15;
        ctx.save(); ctx.translate(x, y); ctx.rotate(t * 0.07 + i); ctx.fillStyle = ['#ff6b6b', '#feca57', '#48dbfb', '#1dd1a1', '#ff9ff3'][i % 5]; ctx.globalAlpha = 0.8; ctx.fillRect(-3, -1.5, 6, 3); ctx.restore();
    }
}

function menuTorch(x, y, t, k) {
    const f = Math.sin(t * 0.31 + k * 2) * 0.5 + Math.sin(t * 0.53 + k) * 0.5;
    drawGlow(x, y - 54, 70 + f * 8, '#ff9a2a', 0.5);
    ctx.fillStyle = '#2a1410'; ctx.beginPath(); ctx.moveTo(x - 2.5, y); ctx.lineTo(x + 2.5, y); ctx.lineTo(x + 1.5, y - 50); ctx.lineTo(x - 1.5, y - 50); ctx.fill();
    ctx.fillStyle = '#5a3418'; roundRect(x - 6, y - 58, 12, 10, 2); ctx.fill(); ctx.fillStyle = '#8a5a2a'; ctx.fillRect(x - 6, y - 58, 12, 2);
    for (const [c, w, h] of [['#ff5a1a', 6.5, 17], ['#ffa21a', 4.6, 13], ['#ffe27a', 2.6, 8]]) {
        ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(x - w, y - 58); ctx.quadraticCurveTo(x - w - 1 + f, y - 58 - h * 0.6, x + f * 2, y - 58 - h - f * 3); ctx.quadraticCurveTo(x + w + 1 + f, y - 58 - h * 0.6, x + w, y - 58); ctx.fill();
    }
}
function menuGround(q, t, bt) {
    const hz = MENU_HZ;
    ctx.save(); ctx.translate(0, hz + 2); ctx.scale(0.8, 0.8); csHouses(t * 0.06, 0, true, t); ctx.restore();   // village on the horizon
    // sand floor, fading to deep violet at the bottom edge
    ctx.fillStyle = lg(0, hz, 0, H, [[0, '#7a3a44'], [0.18, '#5a2a3c'], [0.6, '#33172e'], [1, '#1a0b1d']]); ctx.fillRect(0, hz, W, H - hz);
    ctx.fillStyle = 'rgba(255,170,90,0.35)'; ctx.fillRect(0, hz, W, 1.5);
    if (q >= 1) {   // perspective lines fanning out of the vanishing point
        ctx.strokeStyle = 'rgba(255,190,130,0.07)'; ctx.lineWidth = 1;
        for (let k = -10; k <= 10; k++) { ctx.beginPath(); ctx.moveTo(W / 2 + k * 14, hz); ctx.lineTo(W / 2 + k * 96, H); ctx.stroke(); }
        for (let k = 1; k < 9; k++) { const y = hz + Math.pow(k / 8, 2) * (H - hz); ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    }
    // round stage under the hero: glowing rings, a rotating star, pulsing with the beat
    const cx = W / 2, cy = MENU_HZ + 30, rx = 138 + bt.p * 5, ry = 25 + bt.p * 1.5;
    drawGlow(cx, cy, 170, '#ffb347', 0.2 + bt.p * 0.2);
    ctx.fillStyle = 'rgba(20,6,22,0.55)'; ctx.beginPath(); ctx.ellipse(cx, cy + 5, rx + 6, ry + 5, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = lg(0, cy - ry, 0, cy + ry, [[0, '#8a4a52'], [1, '#4c2236']]); ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#ffd32a'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,240,180,0.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(cx, cy - 0.8, rx - 2, ry - 1, 0, 0, TAU); ctx.stroke();
    for (const k of [0.8, 0.58, 0.36]) { ctx.strokeStyle = `rgba(255,${180 + k * 60 | 0},120,${0.22 + bt.p * 0.25})`; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.ellipse(cx, cy, rx * k, ry * k, 0, 0, TAU); ctx.stroke(); }
    ctx.save(); ctx.translate(cx, cy); ctx.scale(1, ry / rx); ctx.rotate(t * 0.01); ctx.strokeStyle = 'rgba(255,215,90,0.4)'; ctx.lineWidth = 1.6; ctx.beginPath();
    for (let k = 0; k < 10; k++) { const a = k * TAU * 2 / 5 / 2 * 1, r = rx * 0.5; ctx.lineTo(Math.cos(k * 4 * Math.PI / 5) * r, Math.sin(k * 4 * Math.PI / 5) * r); } ctx.closePath(); ctx.stroke(); ctx.restore();
    for (let k = 0; k < 24; k++) { const a = k / 24 * TAU + t * 0.004, on = (k + (t * 0.12 | 0)) % 3 === 0; ctx.fillStyle = on ? '#fff2a8' : '#c8902a'; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * (rx - 5), cy + Math.sin(a) * (ry - 3), on ? 2 : 1.3, 0, TAU); ctx.fill(); }
    menuTorch(34, MENU_HZ + 44, t, 0); menuTorch(W - 34, MENU_HZ + 44, t, 1);
    drawCactus(66, MENU_HZ + 36, 52, '#22102a'); drawCactus(W - 64, MENU_HZ + 36, 44, '#22102a');
    // spotlight cone from above the title
    if (q >= 1) { ctx.fillStyle = lg(0, 0, 0, hz + 30, [[0, 'rgba(255,245,210,0.0)'], [0.4, 'rgba(255,245,210,0.07)'], [1, 'rgba(255,230,170,0.16)']]); ctx.beginPath(); ctx.moveTo(W / 2 - 30, 0); ctx.lineTo(W / 2 + 30, 0); ctx.lineTo(W / 2 + 150, hz + 30); ctx.lineTo(W / 2 - 150, hz + 30); ctx.fill(); }
}
// balls in sombreros dance round the hero; back = behind him, front = in front (bigger, so it reads as depth)
const MENU_ORB = [[0, 0, 0], [1, 1, 1], [2, 2, 2], [3, 3, 3], [4, 4, 4], [5, 0, 5], [6, 1, 6], [7, 2, 7]];
// ---- the orbiting balls as cheap 3D: a small set of pre-baked rotating, lit spheres per colour (baked a few at a time, then every frame is just a drawImage) ----
const M3_N = 12, M3_R = 22, M3_S = 56, M3 = { fr: {}, sh: null };
function m3Bake(ci, k) {
    const c = document.createElement('canvas'); c.width = c.height = M3_S; const x = c.getContext('2d'), R = M3_R, cx = M3_S / 2, cy = M3_S / 2, base = BALLCOLS[ci];
    const gr = x.createRadialGradient(cx - R * 0.35, cy - R * 0.42, R * 0.08, cx, cy, R * 1.05);
    gr.addColorStop(0, shade(base, 0.55)); gr.addColorStop(0.4, base); gr.addColorStop(0.85, shade(base, -0.4)); gr.addColorStop(1, shade(base, -0.65));
    x.fillStyle = gr; x.beginPath(); x.arc(cx, cy, R, 0, TAU); x.fill();
    x.save(); x.beginPath(); x.arc(cx, cy, R, 0, TAU); x.clip(); x.translate(cx, cy); x.rotate(-0.4);   // the ball's axis leans, so the spin reads as 3D
    const phi = k / M3_N * (Math.PI / 2); x.lineWidth = 1.7; x.strokeStyle = 'rgba(0,0,0,0.24)';
    for (let j = 0; j < 4; j++) {   // meridian seams: only the half facing us, squeezed by the angle they sit at
        const a = phi + j * Math.PI / 2, cs = Math.cos(a), sn = Math.sin(a); if (cs <= 0.04) continue;
        x.beginPath(); if (sn >= 0) x.ellipse(0, 0, Math.max(0.6, R * sn), R, 0, -Math.PI / 2, Math.PI / 2); else x.ellipse(0, 0, Math.max(0.6, R * -sn), R, 0, Math.PI / 2, Math.PI * 1.5); x.stroke();
    }
    x.beginPath(); x.ellipse(0, R * 0.12, R * 0.99, R * 0.26, 0, 0, Math.PI); x.stroke();   // the equator's near side
    x.fillStyle = 'rgba(255,255,255,0.13)'; x.beginPath(); x.ellipse(0, R * 0.12, R * 0.99, R * 0.26, 0, Math.PI, TAU); x.fill();   // a lighter band round the top of the equator
    x.restore();
    const hg = x.createRadialGradient(cx - R * 0.4, cy - R * 0.46, 0, cx - R * 0.4, cy - R * 0.46, R * 0.55); hg.addColorStop(0, 'rgba(255,255,255,0.62)'); hg.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = hg; x.beginPath(); x.arc(cx, cy, R, 0, TAU); x.fill();   // gloss, fixed to the light, not to the spin
    x.strokeStyle = 'rgba(255,215,150,0.26)'; x.lineWidth = 1.6; x.beginPath(); x.arc(cx, cy, R - 0.8, 0.15, 1.35); x.stroke();   // a warm rim light on the lower right
    return c;
}
function m3Warm() {   // a few frames per call, so the first visit never hitches
    let n = 0;
    for (let ci = 0; ci < 5 && n < 6; ci++) { const a = M3.fr[ci] || (M3.fr[ci] = []); for (let k = a.length; k < M3_N && n < 6; k++, n++) a.push(m3Bake(ci, k)); }
    if (!M3.sh) { const c = document.createElement('canvas'); c.width = 48; c.height = 16; const x = c.getContext('2d'), g2 = x.createRadialGradient(24, 8, 0, 24, 8, 24); g2.addColorStop(0, 'rgba(0,0,0,0.5)'); g2.addColorStop(1, 'rgba(0,0,0,0)'); x.setTransform(1, 0, 0, 16 / 48, 0, 0); x.fillStyle = g2; x.fillRect(0, 0, 48, 48); M3.sh = c; }
}
function menuOrbit(t, bt, front) {
    const cx = W / 2, cy = MENU_HY + 36, n = MENU_ORB.length, d3 = OPT.gfx >= 1;
    if (d3) m3Warm();
    const list = [];
    for (const [i, c, k] of MENU_ORB) {
        const a = t * 0.012 + i / n * TAU, d = Math.sin(a);   // d>0 = in front
        if ((d > 0) !== front) continue;
        const sc = 0.8 + 0.3 * d, r = (9 + (k % 3) * 3) * sc * 1.35;
        list.push([d, cx + Math.cos(a) * 150, cy + d * 58 + Math.sin(t * 0.05 + i * 1.7) * 8 - (k % 2) * 40, r, BALLCOLS[c % 5], k % 4, i, c % 5]);
    }
    list.sort((a, b) => a[0] - b[0]);
    for (const o of list) {
        const [d, x, y, r, col, hat, i, ci] = o, vx = Math.cos(t * 0.012 + i / n * TAU) * 5, fr = d3 && M3.fr[ci] && M3.fr[ci].length === M3_N ? M3.fr[ci] : null;
        ctx.save(); ctx.globalAlpha = front ? 1 : 0.85;
        if (!d3 || !M3.sh) { drawBall(fakeBall(x, y, r, col, hat, { vx: -Math.sin(t * 0.012 + i / n * TAU) * 1.8, vy: Math.cos(t * 0.012 + i / n * TAU) * 0.7 })); ctx.restore(); continue; }
        const gy = MENU_HZ + 34 + d * 9, sh = r * 2.5;   // a soft shadow on the ground under each ship: smaller and fainter the higher it floats
        ctx.globalAlpha = clamp(0.9 - (gy - y) / 230, 0.15, 0.9) * (front ? 1 : 0.85); ctx.drawImage(M3.sh, x - sh / 2, gy - sh * 0.17, sh, sh * 0.34); ctx.globalAlpha = front ? 1 : 0.85;
        drawBall(fakeBall(x, y, r, col, hat, { vx: -Math.sin(t * 0.012 + i / n * TAU) * 1.8, vy: Math.cos(t * 0.012 + i / n * TAU) * 0.7 }));   // the avocado ship (the old spinning 3D balls are no longer drawn)
        if (d < 0) { ctx.fillStyle = 'rgba(50,25,85,' + (0.28 * -d) + ')'; ctx.beginPath(); ctx.arc(x, y, r * 1.05, 0, TAU); ctx.fill(); }
        ctx.restore(); continue;
        const spin = t * 0.034 * (1 + (i % 3) * 0.18) + i * 1.3, f = Math.floor(((spin / (Math.PI / 2)) % 1) * M3_N) % M3_N, sq = bt.p * 0.08, k = r / M3_R, w = M3_S * k * (1 + sq), h = M3_S * k * (1 - sq);
        ctx.drawImage(fr[f], x - w / 2, y - h / 2 + r * sq, w, h);   // squashes on the beat, feet planted
        if (d < 0) { ctx.fillStyle = 'rgba(50,25,85,' + (0.34 * -d) + ')'; ctx.beginPath(); ctx.arc(x, y + r * sq * 0.5, r, 0, TAU); ctx.fill(); }   // far side of the orbit sinks into the dusk
        const fb = fakeBall(x + Math.sin(spin * 0.7) * r * 0.13, y, r, col, hat, { vx });
        if (OPT.faces) drawFace(fb);
        if (OPT.hats) drawSombrero(fb.x, y - r * 0.74, r * 1.2, Math.sin((menuT + i * 9) * 0.08) * 0.1 + vx * 0.08, hat);
        ctx.restore();
    }
}
function menuMotes(q, t) {   // gold dust rising round the hero
    if (q < 1) return;
    const nn = q >= 2 ? 34 : 18;
    for (let i = 0; i < nn; i++) {
        const u = ((t * (0.35 + (i % 5) * 0.09) + i * 53) % 330) / 330, x = W / 2 + Math.sin(i * 2.3 + t * 0.012) * (60 + (i % 7) * 18), y = MENU_HZ + 20 - u * 330;
        ctx.fillStyle = `rgba(255,${210 + (i % 4) * 11},120,${Math.sin(u * Math.PI) * 0.8})`; ctx.beginPath(); ctx.arc(x, y, 1 + (i % 3) * 0.6, 0, TAU); ctx.fill();
    }
}
const MENU_TIPS = ['Drag to fly. Your weapons fire by themselves', 'Skills, wardrobe, trophies and settings are all in OPTIONS', 'Pop the sombrero-wearing balls and grab the gold'];
function drawMenu() {
    const q = OPT.gfx, t = menuT;
    if (menuSeen < 0) { menuInT = t; MFX.sp.length = 0; }   // first time on the title screen, or back from a ride: replay the entrance (render() clears menuSeen)
    menuSeen = 1;
    const bt = menuBeatPulse();
    // dusk wash over the sky
    ctx.fillStyle = lg(0, 0, 0, H, [[0, 'rgba(255,120,60,0)'], [0.55, 'rgba(255,150,70,0.14)'], [1, 'rgba(110,30,70,0.4)']]); ctx.fillRect(0, 0, W, H);
    menuBackdrop(q, t, bt);
    menuGround(q, t, bt);
    // bunting
    if (q >= 1) { drawBunting(4, t, 10, 0); drawBunting(26, t, 8, 2); }
    // title: rotating sunburst, then the letters drop in one by one, bob, and catch a gold shine that sweeps across
    ctx.save(); ctx.translate(W / 2, 74); ctx.rotate(t * 0.0015);
    ctx.fillStyle = 'rgba(255,230,150,0.10)'; for (let k = 0; k < 16; k++) { ctx.rotate(TAU / 16); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(260, -12); ctx.lineTo(260, 12); ctx.closePath(); ctx.fill(); }
    ctx.restore();
    uiButtons.push({ x: 20, y: 50, w: 320, h: 56, fn: godTap });
    ctx.textAlign = 'center'; ctx.font = '900 40px system-ui, sans-serif';
    const TT = 'HULA VAQUERO', lws = [...TT].map(c => ctx.measureText(c).width), tot = lws.reduce((a, b) => a + b, 0);
    let lx = W / 2 - tot / 2;
    for (let i = 0; i < TT.length; i++) {
        const u = clamp((t - menuInT - i * 3) / 22, 0, 1), cy = 94 - (1 - u) * (1 - u) * 120 + Math.sin(t * 0.06 + i * 0.55) * 2.2, sw = Math.max(0, 1 - Math.abs(i - ((t * 0.07) % 20 - 4)) / 2.2);
        if (TT[i] !== ' ') {
            ctx.save(); ctx.globalAlpha = Math.min(1, u * 3); ctx.translate(lx + lws[i] / 2, cy); const sc = 1 + bt.p * 0.05 + (1 - u) * 0.4; ctx.scale(sc, sc);
            outlineText(TT[i], 0, 0, lg(0, -32, 0, 4, [[0, lerpColor('#fff6b0', '#ffffff', sw)], [0.5, lerpColor('#ffd32a', '#fff2a8', sw)], [1, lerpColor('#ff9a1a', '#ffd070', sw)]]), 'rgba(80,25,8,0.95)', 9);
            ctx.restore();
        }
        lx += lws[i];
    }
    // ribbon
    const ry = 106, rw = 224;
    ctx.fillStyle = '#7d1020'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.moveTo(W / 2 + sx * (rw / 2 - 6), ry + 4); ctx.lineTo(W / 2 + sx * (rw / 2 + 24), ry + 4); ctx.lineTo(W / 2 + sx * (rw / 2 + 14), ry + 15); ctx.lineTo(W / 2 + sx * (rw / 2 + 24), ry + 26); ctx.lineTo(W / 2 + sx * (rw / 2 - 6), ry + 26); ctx.closePath(); ctx.fill(); }
    ctx.fillStyle = lg(0, ry, 0, ry + 24, [[0, '#ee4a5c'], [1, '#b01530']]); roundRect(W / 2 - rw / 2, ry, rw, 24, 4); ctx.fill();
    ctx.strokeStyle = '#ffd32a'; ctx.lineWidth = 1.3; roundRect(W / 2 - rw / 2 + 3, ry + 3, rw - 6, 18, 3); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.font = '800 13px system-ui, sans-serif'; ctx.fillText('SKY RIDE  ·  DELUXE', W / 2, ry + 17);
    // the hero: double size, dead centre, a new move every bar, face reacting to the shouts
    menuMotes(q, t);
    menuOrbit(t, bt, false);
    const bob = Math.sin(t * 0.05), hy = MENU_HY + bob * 3;
    ctx.fillStyle = 'rgba(0,0,0,0.38)'; ctx.beginPath(); ctx.ellipse(W / 2, MENU_HZ + 32, 92 - bob * 4, 14, 0, 0, TAU); ctx.fill();
    const tk = talkState(); VQ.mo = tk.mo; VQ.mw = tk.mw; VQ.brow = tk.brow;
    let ph = t * 0.3, bpulse = 0, lean = 0;
    if (AC && OPT.music && AC.state === 'running' && musTrack === 'menu' && beatLog.length) {
        const now = AC.currentTime, bp = (now - musT0) / (4 * MUS_E), lb = beatLog[beatLog.length - 1], dt = Math.max(0, now - lb.t);
        bpulse = lb.a * Math.exp(-dt * 6.5);
        if (lb.a === 1 && lb.t !== MFX.gT) { MFX.gT = lb.t; MFX.bar++; }
        ph = bp * Math.PI; lean = Math.sin(bp * Math.PI) * 0.1;
    } else MFX.bar = (t / 150) | 0;   // no music: change move on a timer
    const mg = MENU_G[MFX.bar % MENU_G.length];
    VQ.g = mg[0]; VQ.nohoop = !!mg[1];
    const glM = OPT.hd && OPT.gfx >= 1 && H3.ok === true;
    if (glM) { ctx.save(); VQ.tilt = lean * 0.6; VQ.jump = (tk.hop + bpulse * 3) * 2; } else { ctx.save(); ctx.translate(W / 2, hy + 40 * MENU_S / 2.3 - tk.hop - bpulse * 3); ctx.rotate(lean * 0.6); ctx.scale(1 + bpulse * 0.02, 1 - bpulse * 0.02); ctx.translate(-W / 2, -(hy + 40 * MENU_S / 2.3)); }
    VQ.ill = t + 1; VQ.x = h3Dn(t).li > 0.6 ? 'daydream' : null;   // the title-screen hero carries the same small tells as the dance: a stall, a listening aside, a hand brushing at his neck
    VQ.ssCap = 1; drawVaquero(W / 2, hy, MENU_S, 1, ph); VQ.ill = 0; VQ.x = null; VQ.ssCap = 0; VQ.tilt = 0; VQ.jump = 0; VQ.g = null; VQ.nohoop = false;
    ctx.restore();
    VQ.mo = VQ.mw = VQ.brow = 0;
    menuOrbit(t, bt, true);
    ctx.textAlign = 'left';
    // buttons slide in from the sides; RIDE! pulses and thumps with the beat
    const pulse = 0.5 + 0.5 * Math.sin(t * 0.08), slide = k => { const u = clamp((t - menuInT - 34 - k * 7) / 18, 0, 1); return (1 - u) * (1 - u) * W * (k % 2 ? 1 : -1); };
    drawGlow(W / 2 + slide(0), 452, 130 + pulse * 16 + bt.p * 14, '#2ecc71', 0.5);
    btn(50 + slide(0), 424, 260, 56, 'RIDE!', ride, '#2ecc71', 'world map · 4 acts', 28);
    btn(22 + slide(1), 488, 154, 44, 'ENDLESS', () => startRun(), '#8e44ad', 'no map, just fly', 19);
    btn(184 + slide(2), 488, 154, 44, 'OPTIONS', () => { optsReturn = 'menu'; mode = hubLast; hubT = menuT; sfx('click'); }, '#e67e22', 'skills · wardrobe · more', 20);
    // gold and best-run pills
    const py = 542;
    menuPill(22, py, 154, 28);
    ctx.fillStyle = '#1e8449'; ctx.beginPath(); ctx.arc(40, py + 14, 8, 0, TAU); ctx.fill(); ctx.fillStyle = '#58d68d'; ctx.beginPath(); ctx.arc(40, py + 14, 6.4, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.fillRect(37, py + 10, 2, 2);
    ctx.fillStyle = '#58d68d'; ctx.font = 'bold 14px system-ui, sans-serif'; ctx.fillText('$ ' + save.gold + ' pesos', 54, py + 19, 116);
    menuPill(184, py, 154, 28);
    uiButtons.push({ x: 184, y: py, w: 154, h: 28, fn: secretTap });
    ctx.textAlign = 'center'; ctx.fillStyle = '#dfe6e9'; ctx.font = 'bold 12px system-ui, sans-serif';
    ctx.fillText(save.bestTime ? `BEST  ${fmtTime(save.bestTime)}  ·  Lv ${save.bestLevel}` : 'NO RUNS YET', 261, py + 19);
    if (godMode || godMsg > 0) { godMsg--; ctx.fillStyle = '#ff2850'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillText(godMode ? 'GOD MODE ON' : 'god mode off', W / 2, 418); }
    // a tip that fades in and out
    const tp = (t % 300) / 300, ta = Math.sin(tp * Math.PI) * 0.9;
    ctx.fillStyle = `rgba(255,233,192,${Math.min(1, ta * 1.6)})`; ctx.font = 'italic 12px system-ui, sans-serif'; ctx.fillText(MENU_TIPS[Math.floor(t / 300) % MENU_TIPS.length], W / 2, 592, W - 30);
    outlineText(`${DIFF[OPT.diff].name} difficulty  ·  ${RES}x resolution`, W / 2, 614, '#ffe9c0', 'rgba(30,10,30,0.9)', 3);
    ctx.textAlign = 'left';
}

function dimBg(a = 0.74) { ctx.fillStyle = `rgba(8,8,20,${a})`; ctx.fillRect(0, 0, W, H); }
function screenTitle(t, sub) {
    ctx.textAlign = 'center'; ctx.font = 'bold 24px system-ui, sans-serif'; outlineText(t, W / 2, 44, '#fff');
    if (sub) { ctx.fillStyle = '#f1c40f'; ctx.font = 'bold 15px system-ui, sans-serif'; ctx.fillText(sub, W / 2, 68); }
    ctx.textAlign = 'left';
}

// ---------- options ----------
const OPT_TABS = ['GRAPHICS', 'GAMEPLAY', 'AUDIO', 'CONTROLS', 'BEAT'];
let ptrStamp = 0;
const OPT_DEFS = [
    { tab: 0, key: 'res', label: 'Resolution', vals: [1, 2, 3, 4, 8, 16, 99], fmt: v => v >= 99 ? 'MAX (' + maxRes() + 'x)' : v + 'x' + (v > maxRes() ? ' (max ' + maxRes() + 'x)' : ''), note: 'MAX = sharpest your device allows. Very heavy', apply: applyRes },
    { tab: 0, key: 'hq', label: '3D hero quality', vals: [0, 1, 2], fmt: v => ['Standard', 'High', 'Ultra'][v], note: 'Anti-aliasing, soft shadows, richer lighting on the vaquero. Ultra is heavy', apply: () => { H3.lo = false; } },
    { tab: 0, key: 'gfx', label: 'Graphics quality', vals: [0, 1, 2, 3], fmt: v => ['Low', 'Medium', 'High', 'Ultra'][v], note: 'Shading, glow, parallax, weather', apply: clearSprites },
    { tab: 0, key: 'hd', label: '3D hero', bool: 1, note: 'N64-style 3D vaquero. Needs Medium+ graphics' },
    { tab: 0, key: 'hats', label: 'Sombreros on enemies', bool: 1, note: 'Every ball wears a hat. Knock it off!' },
    { tab: 0, key: 'stache', label: 'Mustaches on enemies', bool: 1, note: 'Un bigote for every ball' },
    { tab: 0, key: 'faces', label: 'Enemy faces', bool: 1, note: 'Googly eyes that follow you' },
    { tab: 0, key: 'glow', label: 'Glow & bloom', bool: 1, note: 'Light halos on shots, gems and fire (High+)' },
    { tab: 0, key: 'parts', label: 'Particles', vals: [0, 0.5, 1, 2], fmt: v => ({ 0: 'Off', 0.5: 'Low', 1: 'Normal', 2: 'Lots' })[v], note: 'Sparks, confetti and cosmetic trails' },
    { tab: 0, key: 'fps', label: 'FPS counter', bool: 1, note: 'Shows the frame rate in a corner' },
    { tab: 1, key: 'diff', label: 'Difficulty', vals: [0, 1, 2, 3], fmt: v => DIFF[v].name, note: 'Harder = tougher balls, more gold' },
    { tab: 1, key: 'shake', label: 'Screen shake', bool: 1, note: 'Camera rumble on hits and booms' },
    { tab: 1, key: 'dmgnums', label: 'Damage numbers', bool: 1, note: 'Floating hit numbers' },
    { tab: 1, key: 'haptics', label: 'Vibration', bool: 1, note: 'Haptic buzz on hits (phones)' },
    { tab: 1, key: 'blurPause', label: 'Auto-pause when away', bool: 1, note: 'Pause if you switch tabs or apps' },
    { tab: 1, key: 'intro', label: 'Opening cutscene', vals: [0, 1, 2], fmt: v => ['First time', 'Every time', 'Never'][v], note: 'Story intro when you press RIDE on the menu' },
    { tab: 1, key: 'sens', label: 'Touch sensitivity', vals: [0.8, 1, 1.3, 1.6, 2], fmt: v => v + 'x', note: 'How far the hero moves per finger drag' },
    { tab: 1, key: 'auto', label: 'Adaptive quality', bool: 1, note: 'Lowers resolution/effects if the game keeps lagging' },
    { tab: 1, key: 'calm', label: 'Reduce flashes', bool: 1, note: 'Softer lightning, hit and low-health flashes' },
    { tab: 1, key: 'reset', label: 'Reset all progress', action: 1, note: 'Erases gold, skills, trophies, wardrobe' },
    { tab: 2, key: 'sfx', label: 'Sound effects', bool: 1, note: 'Pops, coins, booms' },
    { tab: 2, key: 'sfxvol', label: 'Effects volume', vals: [0.25, 0.5, 0.75, 1], fmt: v => Math.round(v * 100) + '%', note: 'Loudness of sound effects' },
    { tab: 2, key: 'music', label: 'Music', bool: 1, note: 'Mariachi son huapango (M to toggle)' },
    { tab: 2, key: 'musicvol', label: 'Music volume', vals: [0.25, 0.5, 0.75, 1], fmt: v => Math.round(v * 100) + '%', note: 'Loudness of the music' },
];
function cycleOpt(d, dir = 1) {
    audioInit();
    if (d.action) {
        if (resetArmed > menuT) {
            try { localStorage.removeItem(SAVE_KEY); } catch (e) {}
            save.gold = 0; save.bestTime = 0; save.bestLevel = 0; save.skills = {}; save.ach = {};
            save.stats = { runs: 0, kills: 0, goldEarned: 0, time: 0, bosses: 0, maxCombo: 0, hats: 0, bestKills: 0 };
            save.cos = { hat: [0], hoop: [0], trail: [0], eq: { hat: 0, hoop: 0, trail: 0 } };
            persist(); resetArmed = 0; sfx('hurt');
        } else resetArmed = menuT + 180;
        return;
    }
    if (d.bool) OPT[d.key] = !OPT[d.key];
    else { const i = Math.max(0, d.vals.indexOf(OPT[d.key])); OPT[d.key] = d.vals[(i + dir + d.vals.length) % d.vals.length]; }
    if (d.apply) d.apply();
    if (d.key.startsWith('sfx') || d.key.startsWith('music')) { applyVol(); if (OPT.music) startMusic(); }
    persist(); sfx('click');
}
const CONTROLS = [
    ['TOUCH', null],
    ['DRAG', 'Fly: your vaquero follows your finger'],
    ['AUTO', 'Weapons fire by themselves'],
    ['TAP', 'Round skill buttons, bottom right'],
    ['KEYBOARD', null],
    ['WASD', 'Move (arrow keys work too)'],
    ['SPACE', 'Dash (Shift works too)'],
    ['R', 'Matador cape (reroll on level-up)'],
    ['Q', 'Siesta: slow every ball'],
    ['P / ESC', 'Pause, or go back'],
    ['M', 'Music on or off'],
    ['F', 'FPS counter on or off'],
    ['1 2 3', 'Pick a level-up card'],
    ['ENTER', 'Start a ride from the menu'],
    ['GAMEPAD', null],
    ['STICK', 'Move (d-pad works too)'],
    ['A  B  X  Y', 'Dash · Slow · Attack/Cape · Volley/Cape'],
    ['START', 'Pause (A/B/X pick level-up cards)'],
];
// ---------- the options hub: every menu in one place ----------
// top tabs: HERO (skills, wardrobe) · RECORDS (trophies, stats) · GAME (settings, which has its own tabs down the left)
const HUB_TABS = [['shop', 'SKILLS', '#e67e22'], ['wardrobe', 'WARDROBE', '#e84393'], ['trophies', 'TROPHIES', '#f39c12'], ['stats', 'STATS', '#0984e3'], ['options', 'SETTINGS', '#6c5ce7']];
const HUB_GROUPS = [['HERO', 0, 1], ['RECORDS', 2, 3], ['GAME', 4, 4]];
let hubLast = 'options', hubT = -99;
const hubPause = () => mode === 'options' && optsReturn === 'pause';
function hubTo(m) { if (m !== mode) { mode = m; hubLast = m; hubT = menuT; sfx('click'); } }
function hubFrame() {
    dimBg(hubPause() ? 0.9 : 0.8);
    if (hubPause()) { screenTitle('SETTINGS'); return; }
    const tw = 66, gap = 3.5;
    HUB_TABS.forEach(([m, lab, col], i) => {
        const x = 8 + i * (tw + gap), y = 8, on = m === mode;
        uiButtons.push({ x, y, w: tw, h: 38, fn: () => hubTo(m) });
        ctx.fillStyle = 'rgba(0,0,0,0.3)'; roundRect(x, y + 2, tw, 36, 9); ctx.fill();
        ctx.fillStyle = on ? lg(0, y, 0, y + 36, [[0, shade(col, 0.25)], [1, col]]) : 'rgba(38,41,70,0.95)'; roundRect(x, y, tw, 36, 9); ctx.fill();
        ctx.strokeStyle = on ? '#fff' : 'rgba(255,255,255,0.12)'; ctx.lineWidth = on ? 1.6 : 1; roundRect(x, y, tw, 36, 9); ctx.stroke();
        ctx.fillStyle = on ? '#fff' : '#9aa3c7'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(lab, x + tw / 2, y + 23, tw - 6); ctx.textAlign = 'left';
    });
    ctx.font = 'bold 8.5px system-ui, sans-serif'; ctx.textAlign = 'center';
    for (const [nm, a, b] of HUB_GROUPS) {
        const x0 = 8 + a * (tw + gap) + 3, x1 = 8 + b * (tw + gap) + tw - 3, on = HUB_TABS.slice(a, b + 1).some(r => r[0] === mode);
        ctx.fillStyle = on ? 'rgba(255,211,42,0.8)' : 'rgba(154,163,199,0.4)'; ctx.fillRect(x0, 50, x1 - x0, 1.5);
        ctx.fillStyle = on ? '#ffd32a' : '#7d86ad'; ctx.fillText(nm, (x0 + x1) / 2, 61);
    }
    ctx.textAlign = 'left';
}
function hubBottom() {
    const back = () => { mode = mode === 'options' ? optsReturn : 'menu'; sfx('click'); };
    if (hubPause()) { btn(110, 586, 140, 40, 'BACK', back, '#6c5ce7'); return; }
    btn(14, 586, 96, 40, 'BACK', back, '#6c5ce7');
    menuPill(118, 592, 124, 28);
    ctx.fillStyle = '#1e8449'; ctx.beginPath(); ctx.arc(134, 606, 7, 0, TAU); ctx.fill(); ctx.fillStyle = '#58d68d'; ctx.beginPath(); ctx.arc(134, 606, 5.4, 0, TAU); ctx.fill();
    ctx.fillStyle = '#58d68d'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillText('$ ' + save.gold, 148, 611, 88);
    btn(250, 586, 96, 40, 'RIDE!', ride, '#2ecc71');
}
function hubBody(draw) {
    hubFrame();
    const u = clamp((menuT - hubT) / 9, 0, 1);
    ctx.save(); ctx.globalAlpha = u; ctx.translate((1 - u) * 14, 0); draw(); ctx.restore();
    hubBottom();
}

// ---------- skills ----------
function drawShop() {
    hubBody(() => {
        const per = 7, pages = Math.ceil(SKILLS.length / per);
        shopPage = Math.min(shopPage, pages - 1);
        const list = SKILLS.slice(shopPage * per, shopPage * per + per);
        list.forEach((s, i) => {
            const x = 14, y = 70 + i * 57, w = W - 28, h = 52;
            const rank = skillRank(s.id), maxed = rank >= s.max, cost = skillCost(s), afford = save.gold >= cost;
            uiButtons.push({ x, y, w, h, fn: () => { if (!maxed && save.gold >= cost) { save.gold -= cost; save.skills[s.id] = rank + 1; persist(); sfx('buy'); } } });
            ctx.fillStyle = 'rgba(30,32,56,0.95)'; roundRect(x, y, w, h, 10); ctx.fill();
            ctx.strokeStyle = maxed ? '#2ecc71' : afford ? '#f1c40f' : '#444'; ctx.lineWidth = 1.5; roundRect(x, y, w, h, 10); ctx.stroke();
            ctx.fillStyle = '#fff'; ctx.font = 'bold 14px system-ui, sans-serif'; ctx.fillText(s.name, x + 12, y + 20);
            for (let k = 0; k < s.max; k++) { ctx.fillStyle = k < rank ? '#2ecc71' : 'rgba(255,255,255,0.2)'; ctx.fillRect(x + 12 + k * 12, y + 27, 9, 5); }
            ctx.fillStyle = '#b2bec3'; ctx.font = '11px system-ui, sans-serif'; ctx.fillText(s.desc, x + 12, y + 45, w - 100);
            ctx.textAlign = 'right'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillStyle = maxed ? '#2ecc71' : afford ? '#f1c40f' : '#777';
            ctx.fillText(maxed ? 'MAX' : '$ ' + cost, x + w - 12, y + 20); ctx.textAlign = 'left';
        });
        ctx.textAlign = 'center'; ctx.fillStyle = '#dfe6e9'; ctx.font = '12px system-ui, sans-serif';
        ctx.fillText(`Page ${shopPage + 1}/${pages} · tap a skill to buy`, W / 2, 498);
        ctx.textAlign = 'left';
        btn(14, 474, 80, 36, '◄', () => { shopPage = (shopPage + pages - 1) % pages; sfx('click'); }, '#636e72');
        btn(W - 94, 474, 80, 36, '►', () => { shopPage = (shopPage + 1) % pages; sfx('click'); }, '#636e72');
    });
}

// ---------- settings: tabs down the left, rows on the right ----------
function railIcon(i, cx, cy, col) {
    ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.8; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (i === 0) { roundRect(cx - 11, cy - 8, 22, 14, 3); ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx, cy + 6); ctx.lineTo(cx, cy + 10); ctx.moveTo(cx - 6, cy + 10); ctx.lineTo(cx + 6, cy + 10); ctx.stroke(); }
    else if (i === 1) { roundRect(cx - 12, cy - 6, 24, 13, 6); ctx.stroke(); ctx.fillRect(cx - 8, cy - 1, 6, 1.8); ctx.fillRect(cx - 5.9, cy - 3.1, 1.8, 6); ctx.beginPath(); ctx.arc(cx + 5, cy - 1, 1.5, 0, TAU); ctx.arc(cx + 8, cy + 2, 1.5, 0, TAU); ctx.fill(); }
    else if (i === 2) { ctx.beginPath(); ctx.moveTo(cx - 9, cy - 3); ctx.lineTo(cx - 4, cy - 3); ctx.lineTo(cx + 1, cy - 8); ctx.lineTo(cx + 1, cy + 8); ctx.lineTo(cx - 4, cy + 3); ctx.lineTo(cx - 9, cy + 3); ctx.closePath(); ctx.stroke(); ctx.beginPath(); ctx.arc(cx + 2, cy, 5, -0.9, 0.9); ctx.stroke(); ctx.beginPath(); ctx.arc(cx + 2, cy, 9, -0.9, 0.9); ctx.stroke(); }
    else if (i === 4) { ctx.beginPath(); ctx.moveTo(cx - 8, cy + 9); ctx.lineTo(cx - 4, cy - 9); ctx.lineTo(cx + 4, cy - 9); ctx.lineTo(cx + 8, cy + 9); ctx.closePath(); ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx, cy + 5); ctx.lineTo(cx + 5, cy - 6); ctx.stroke(); }
    else { roundRect(cx - 12, cy - 7, 24, 15, 3); ctx.stroke(); for (let r = 0; r < 2; r++) for (let k = 0; k < 4; k++) ctx.fillRect(cx - 9 + k * 5, cy - 4 + r * 5, 3, 3); }
    ctx.lineCap = 'butt';
}
function drawControlsTab() {
    let y = 70; const x0 = 72, kw = 62, cw = W - x0 - 8;
    for (const [k, d] of CONTROLS) {
        if (!d) { ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillText(k, x0 + 2, y + 12); ctx.fillStyle = 'rgba(255,211,42,0.3)'; ctx.fillRect(x0, y + 16, cw, 1.5); y += 22; continue; }
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; roundRect(x0, y + 2, kw, 24, 7); ctx.fill();
        ctx.fillStyle = lg(0, y, 0, y + 24, [[0, '#4b5180'], [1, '#2c3052']]); roundRect(x0, y, kw, 24, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 1; roundRect(x0, y, kw, 24, 7); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = 'bold 10.5px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(k, x0 + kw / 2, y + 16, kw - 6); ctx.textAlign = 'left';
        ctx.fillStyle = '#dfe6e9'; ctx.font = '11px system-ui, sans-serif'; ctx.fillText(d, x0 + kw + 8, y + 16, cw - kw - 8);
        y += 26;
    }
}

// =====================================================================
//  BEAT CALIBRATION (options tab). A steady tick plays on the audio clock; you tap on each tick. The average gap between the tick you HEAR
//  and your tap is saved as OPT.beatOff (ms; + = you tap late). Beat-based play will subtract it, so "on the beat" means on the beat you hear.
// =====================================================================
let cal = null;
const CAL_GAP = 0.6, CAL_IN = 4, CAL_N = 16;
function calPerf(ctxT) {   // audio-clock time -> performance.now() time, as heard (uses the browser's output timestamp when it has one)
    let o = null; try { o = AC.getOutputTimestamp ? AC.getOutputTimestamp() : null; } catch (e) {}
    if (o && o.contextTime > 0 && o.performanceTime > 0) return o.performanceTime + (ctxT - o.contextTime) * 1000;
    return performance.now() + (ctxT - AC.currentTime) * 1000;
}
function calTick(ctxT, accent) {
    const o = AC.createOscillator(), g = AC.createGain(); o.type = 'sine'; o.frequency.value = accent ? 1500 : 900;
    g.gain.setValueAtTime(0.0001, ctxT); g.gain.linearRampToValueAtTime(accent ? 0.5 : 0.38, ctxT + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, ctxT + 0.07);
    o.connect(g); g.connect(AC.destination); o.start(ctxT); o.stop(ctxT + 0.09);
}
function calStart(test) {
    audioInit(); if (!AC) return; if (AC.state !== 'running') AC.resume();
    const n = test ? 8 : CAL_N, t0 = AC.currentTime + 0.7, ticks = [];
    for (let i = 0; i < CAL_IN + n; i++) { calTick(t0 + i * CAL_GAP, i >= CAL_IN); ticks.push(calPerf(t0 + i * CAL_GAP)); }
    cal = { test: !!test, ticks, n, taps: [], res: null, last: null, endAt: ticks[ticks.length - 1] + 700 };
    sfx('click');
}
function calTap() {
    if (!cal || cal.res) return;
    const t = ptrStamp > 1e4 ? ptrStamp : performance.now(), now = performance.now();
    if (t < cal.ticks[0] - 400) return;
    let bi = 0; cal.ticks.forEach((tk, i) => { if (Math.abs(t - tk) < Math.abs(t - cal.ticks[bi])) bi = i; });
    const err = t - cal.ticks[bi];
    if (Math.abs(err) > CAL_GAP * 500) return;   // closer to no tick at all
    cal.last = { err: err - (cal.test ? OPT.beatOff : 0), at: now, counted: bi >= CAL_IN };
    if (bi >= CAL_IN) cal.taps.push({ i: bi, err });
}
function calFinish() {
    const e = cal.taps.map(t => t.err), seen = {}; let used = e.filter((v, i) => { const k = cal.taps[i].i; if (seen[k]) return false; seen[k] = 1; return true; });
    if (used.length < (cal.test ? 4 : 8)) { cal.res = { fail: 'Not enough taps. Tap on every tick.' }; return; }
    const med = a => { const s = a.slice().sort((x, y) => x - y); return s[s.length >> 1]; }, m0 = med(used);
    used = used.filter(v => Math.abs(v - m0) < 120);   // throw out the taps that were really a different beat
    const mean = used.reduce((a, b) => a + b, 0) / used.length, sd = Math.sqrt(used.reduce((a, b) => a + (b - mean) * (b - mean), 0) / used.length);
    if (cal.test) { const after = mean - OPT.beatOff; cal.res = { test: true, mean: after, sd, n: used.length }; return; }
    cal.res = { mean, sd, n: used.length };
    OPT.beatOff = clamp(Math.round(mean), -300, 300); persist();
}
function setBeatOff(v) { OPT.beatOff = clamp(Math.round(v), -300, 300); persist(); sfx('click'); }
function drawCalTab() {
    const x0 = 72, cw = W - x0 - 8, cx = x0 + cw / 2, cy = 232, now = performance.now();
    ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillText('BEAT CALIBRATION', x0 + 2, 82);
    ctx.fillStyle = '#9aa3c7'; ctx.font = '10px system-ui, sans-serif';
    ctx.fillText('Press START, then tap in the box exactly when you HEAR', x0 + 2, 98, cw - 4); ctx.fillText('each tick. Headphones change this, so redo it then.', x0 + 2, 111, cw - 4);
    if (cal) needRender = true;
    if (cal && !cal.res && now > cal.endAt) calFinish();
    // the tap pad
    uiButtons.push({ x: x0, y: 122, w: cw, h: 218, fn: () => { if (cal && !cal.res) calTap(); } });
    ctx.fillStyle = 'rgba(30,32,56,0.95)'; roundRect(x0, 122, cw, 218, 14); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.14)'; ctx.lineWidth = 1.2; roundRect(x0, 122, cw, 218, 14); ctx.stroke();
    let hit = 0, nxt = 1, label = 'READY', sub = '';
    if (cal && !cal.res) {
        const tk = cal.ticks; let k = 0; while (k < tk.length && tk[k] < now - 60) k++;
        const prev = k > 0 ? tk[k - 1] : -1e9, next = k < tk.length ? tk[k] : 1e9;
        hit = Math.max(0, 1 - (now - prev) / 180); nxt = clamp((next - now) / (CAL_GAP * 1000), 0, 1);
        const idx = Math.max(0, Math.min(tk.length, k) - 1), inCount = idx < CAL_IN && now < tk[CAL_IN];
        label = inCount ? 'LISTEN...' : 'TAP!'; sub = inCount ? 'count-in ' + Math.min(CAL_IN, k + 1) + '/' + CAL_IN : (Math.max(0, cal.taps.length)) + ' taps · ' + Math.max(0, Math.min(cal.n, tk.length - k)) + ' left';
        ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, 44 + nxt * 56, 0, TAU); ctx.stroke();   // the approach ring closes in on the tick
    }
    ctx.fillStyle = hit > 0 ? lg(cx, cy - 46, cx, cy + 46, [[0, '#ffe066'], [1, '#f39c12']]) : 'rgba(255,255,255,0.1)'; ctx.beginPath(); ctx.arc(cx, cy, 44 + hit * 10, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#ffd32a'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(cx, cy, 44, 0, TAU); ctx.stroke();
    ctx.textAlign = 'center'; ctx.fillStyle = hit > 0.3 ? '#222' : '#fff'; ctx.font = 'bold 14px system-ui, sans-serif'; ctx.fillText(cal && cal.res ? 'DONE' : label, cx, cy + 6);
    ctx.fillStyle = '#9aa3c7'; ctx.font = '10.5px system-ui, sans-serif'; ctx.fillText(sub, cx, cy + 72);
    if (cal && cal.last && now - cal.last.at < 700) { const e = Math.round(cal.last.err); ctx.fillStyle = Math.abs(e) < 40 ? '#2ecc71' : Math.abs(e) < 90 ? '#ffd32a' : '#ff6b6b'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillText((e > 0 ? '+' : '') + e + ' ms ' + (e > 0 ? 'late' : e < 0 ? 'early' : ''), cx, 143); }
    if (cal && cal.res) {
        ctx.font = 'bold 12.5px system-ui, sans-serif'; ctx.fillStyle = cal.res.fail ? '#ff6b6b' : '#2ecc71';
        if (cal.res.fail) ctx.fillText(cal.res.fail, cx, 316, cw - 12);
        else if (cal.res.test) { const m = Math.round(cal.res.mean); ctx.fillText('With your offset you are ' + (m >= 0 ? '+' : '') + m + ' ms off', cx, 308, cw - 12); ctx.fillStyle = '#9aa3c7'; ctx.font = '10.5px system-ui, sans-serif'; ctx.fillText('(steadiness ±' + Math.round(cal.res.sd) + ' ms) closer to 0 is better', cx, 324, cw - 12); }
        else { ctx.fillText('Saved: ' + (OPT.beatOff >= 0 ? '+' : '') + OPT.beatOff + ' ms (' + cal.res.n + ' taps, ±' + Math.round(cal.res.sd) + ')', cx, 308, cw - 12); ctx.fillStyle = '#9aa3c7'; ctx.font = '10.5px system-ui, sans-serif'; ctx.fillText(cal.res.sd > 45 ? 'A bit uneven: run it again for a cleaner number.' : 'Steady taps. Try TEST to check it.', cx, 324, cw - 12); }
    }
    ctx.textAlign = 'left';
    const running = cal && !cal.res;
    miniBtn(x0, 350, (cw - 6) / 2, 34, running ? 'RUNNING...' : 'START (16 beats)', () => { if (!running) calStart(false); }, running ? '#555' : '#2ecc71', 11);
    miniBtn(x0 + (cw + 6) / 2, 350, (cw - 6) / 2, 34, 'TEST (8 beats)', () => { if (!running) calStart(true); }, running ? '#555' : '#3d6fd1', 11);
    // the manual offset
    ctx.fillStyle = 'rgba(30,32,56,0.95)'; roundRect(x0, 394, cw, 92, 12); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.14)'; ctx.lineWidth = 1.2; roundRect(x0, 394, cw, 92, 12); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillText('Your offset', x0 + 10, 414);
    ctx.fillStyle = '#ffd32a'; ctx.textAlign = 'right'; ctx.font = 'bold 15px system-ui, sans-serif'; ctx.fillText((OPT.beatOff > 0 ? '+' : '') + OPT.beatOff + ' ms', x0 + cw - 10, 414); ctx.textAlign = 'left';
    ctx.fillStyle = '#9aa3c7'; ctx.font = '9.5px system-ui, sans-serif'; ctx.fillText(OPT.beatOff > 0 ? 'You tap late, so the game shifts the beat later for you.' : OPT.beatOff < 0 ? 'You tap early, so the game shifts the beat earlier for you.' : 'Zero: no shift.', x0 + 10, 428, cw - 20);
    const bw = (cw - 20 - 4 * 5) / 5;
    [['-25', -25], ['-5', -5], ['0', 0], ['+5', 5], ['+25', 25]].forEach(([l, d], i) => miniBtn(x0 + 10 + i * (bw + 5), 440, bw, 30, l === '0' ? 'RESET' : l, () => setBeatOff(d === 0 ? 0 : OPT.beatOff + d), '#2d3a6b', l === '0' ? 9 : 11));
    ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.font = '9.5px system-ui, sans-serif'; ctx.fillText('Nothing in the game uses this yet: it is set up for beat-based play.', x0 + 2, 506, cw - 4);
}
function drawOptions() {
    hubBody(() => {
        const top = hubPause() ? 76 : 70, rh = 64;
        OPT_TABS.forEach((tn, i) => {
            const x = 8, y = top + i * (rh + 6), w = 58, on = i === optTab;
            uiButtons.push({ x, y, w, h: rh, fn: () => { optTab = i; hubT = menuT; sfx('click'); } });
            ctx.fillStyle = 'rgba(0,0,0,0.3)'; roundRect(x, y + 2, w, rh, 10); ctx.fill();
            ctx.fillStyle = on ? lg(0, y, 0, y + rh, [[0, '#f39c4a'], [1, '#e67e22']]) : 'rgba(38,41,70,0.95)'; roundRect(x, y, w, rh, 10); ctx.fill();
            ctx.strokeStyle = on ? '#fff' : 'rgba(255,255,255,0.12)'; ctx.lineWidth = on ? 1.6 : 1; roundRect(x, y, w, rh, 10); ctx.stroke();
            railIcon(i, x + w / 2, y + 24, on ? '#fff' : '#9aa3c7');
            ctx.fillStyle = on ? '#fff' : '#9aa3c7'; ctx.font = 'bold 8.5px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(tn, x + w / 2, y + 53, w - 4); ctx.textAlign = 'left';
        });
        if (optTab === 3) { drawControlsTab(); return; }
        if (optTab === 4) { drawCalTab(); return; }
        const rows = OPT_DEFS.filter(d => d.tab === optTab), pitch = rows.length > 9 ? 47 : 53;
        rows.forEach((d, i) => {
            const x = 72, y = top + i * pitch, w = W - x - 8, h = pitch - 4, rx = x + w - 108;
            uiButtons.push({ x, y, w, h, fn: () => cycleOpt(d) });
            ctx.fillStyle = 'rgba(30,32,56,0.95)'; roundRect(x, y, w, h, 10); ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.14)'; ctx.lineWidth = 1.2; roundRect(x, y, w, h, 10); ctx.stroke();
            ctx.fillStyle = '#fff'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillText(d.label, x + 10, y + 19, w - 124);
            ctx.fillStyle = '#9aa3c7'; ctx.font = '9.5px system-ui, sans-serif'; ctx.fillText(d.note, x + 10, y + 34, w - 120);
            if (d.action) {
                const armed = resetArmed > menuT; ctx.fillStyle = armed ? '#ff4757' : 'rgba(255,255,255,0.1)'; roundRect(rx + 12, y + h / 2 - 12, 90, 24, 12); ctx.fill();
                ctx.fillStyle = armed ? '#fff' : '#b2bec3'; ctx.font = 'bold 11px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(armed ? 'TAP AGAIN!' : 'RESET', rx + 57, y + h / 2 + 4); ctx.textAlign = 'left';
            } else if (d.bool) {
                const on = !!OPT[d.key], sx = x + w - 52, sy = y + h / 2 - 10;
                ctx.fillStyle = on ? '#2ecc71' : '#4a4f6e'; roundRect(sx, sy, 42, 20, 10); ctx.fill();
                ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(sx + (on ? 32 : 10), sy + 10, 7.5, 0, TAU); ctx.fill();
            } else {
                uiButtons.push({ x: rx - 6, y, w: 34, h, fn: () => cycleOpt(d, -1) }); uiButtons.push({ x: x + w - 30, y, w: 30, h, fn: () => cycleOpt(d, 1) });
                ctx.fillStyle = '#7d86ad'; ctx.font = 'bold 16px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('‹', rx + 6, y + h / 2 + 2); ctx.fillText('›', x + w - 14, y + h / 2 + 2);
                ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 12.5px system-ui, sans-serif'; ctx.fillText(d.fmt(OPT[d.key]), rx + 51, y + h / 2 - 2, 64);
                const n = d.vals.length, ci = d.vals.indexOf(OPT[d.key]), pw = 6, pg = 3, p0 = rx + 51 - (n * pw + (n - 1) * pg) / 2;
                if (n <= 8) for (let k = 0; k < n; k++) { ctx.fillStyle = k === ci ? '#ffd32a' : 'rgba(255,255,255,0.2)'; ctx.fillRect(p0 + k * (pw + pg), y + h / 2 + 7, pw, 3); }
                ctx.textAlign = 'left';
            }
        });
    });
}

// ---------- wardrobe ----------
function equipCos(kind, i) {
    const owned = save.cos[kind].includes(i);
    const item = COS[kind][i];
    if (owned) { save.cos.eq[kind] = i; sfx('click'); }
    else if (save.gold >= item.cost) { save.gold -= item.cost; save.cos[kind].push(i); save.cos.eq[kind] = i; sfx('buy'); }
    persist();
}
function drawWardrobe() {
    hubBody(() => {
        drawGlow(W / 2, 140, 120, '#ffb347', 0.3); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(W / 2, 234, 70, 9, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(255,211,42,0.7)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.ellipse(W / 2, 233, 78, 10, 0, 0, TAU); ctx.stroke();
        drawVaquero(W / 2, 172 + Math.sin(menuT * 0.05) * 3, 2.8, 1, menuT * 0.3);
        const sections = [['hat', 'SOMBREROS', 250], ['hoop', 'HOOPS', 350], ['trail', 'TRAILS', 450]];
        const TG = ['×', '✦', '♨', '✺', '♥'], TC = ['#777', '#fff3a0', '#ff7a1a', '#48dbfb', '#ff6b81'];
        for (const [kind, title, y0] of sections) {
            ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillText(title, 16, y0);
            const list = COS[kind], n = list.length, gap = 5, cw = (W - 28 - gap * (n - 1)) / n;
            list.forEach((it, i) => {
                const x = 14 + i * (cw + gap), y = y0 + 4, h = 80;
                const owned = save.cos[kind].includes(i), eq = save.cos.eq[kind] === i, afford = save.gold >= it.cost;
                uiButtons.push({ x, y, w: cw, h, fn: () => equipCos(kind, i) });
                ctx.fillStyle = 'rgba(30,32,56,0.95)'; roundRect(x, y, cw, h, 9); ctx.fill();
                ctx.strokeStyle = eq ? '#2ecc71' : owned ? '#74b9ff' : afford ? '#f1c40f' : '#444'; ctx.lineWidth = eq ? 2.5 : 1.4; roundRect(x, y, cw, h, 9); ctx.stroke();
                const cx = x + cw / 2;
                if (kind === 'hat') drawSombrero(cx, y + 36, cw * 0.46, 0, i);
                else if (kind === 'hoop') {
                    const hcs = it.c || [hsl2hex((menuT * 3) % 360, 70, 35), hsl2hex((menuT * 3) % 360, 85, 55), '#fff'];
                    ctx.lineWidth = 3.4; ctx.strokeStyle = hcs[1]; ctx.beginPath(); ctx.ellipse(cx, y + 32, cw * 0.38, 9, 0, 0, TAU); ctx.stroke();
                    ctx.strokeStyle = hcs[2]; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.ellipse(cx, y + 32, cw * 0.38, 9, 0, 0.5, 1.5); ctx.stroke();
                } else { ctx.fillStyle = TC[i]; ctx.font = 'bold 22px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(TG[i], cx, y + 40); ctx.textAlign = 'left'; }
                ctx.textAlign = 'center';
                ctx.fillStyle = '#fff'; ctx.font = 'bold 9.5px system-ui, sans-serif'; ctx.fillText(it.name, cx, y + 63, cw - 4);
                ctx.font = 'bold 9px system-ui, sans-serif';
                ctx.fillStyle = eq ? '#2ecc71' : owned ? '#74b9ff' : afford ? '#f1c40f' : '#777';
                ctx.fillText(eq ? 'WORN' : owned ? 'OWNED' : '● ' + it.cost, cx, y + 77, cw - 4);
                ctx.textAlign = 'left';
            });
        }
    });
}

// ---------- trophies and stats ----------
let trophyPage = 0;
function drawTrophies() {
    hubBody(() => {
        const have = ACHS.filter(a => save.ach[a.id]).length, per = 14, pages = Math.ceil(ACHS.length / per);
        trophyPage = Math.min(trophyPage, pages - 1);
        ctx.textAlign = 'center'; ctx.fillStyle = '#f1c40f'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillText(`${have} / ${ACHS.length} earned` + (pages > 1 ? `  ·  page ${trophyPage + 1}/${pages}` : ''), W / 2, 80); ctx.textAlign = 'left';
        ACHS.slice(trophyPage * per, trophyPage * per + per).forEach((a, i) => {
            const x = 14, y = 90 + i * 31, w = W - 28, h = 28, got = !!save.ach[a.id];
            ctx.fillStyle = got ? 'rgba(46,80,56,0.95)' : 'rgba(30,32,56,0.95)'; roundRect(x, y, w, h, 7); ctx.fill();
            ctx.strokeStyle = got ? '#2ecc71' : '#3d4160'; ctx.lineWidth = 1.2; roundRect(x, y, w, h, 7); ctx.stroke();
            ctx.fillStyle = got ? '#f9ca24' : '#555'; ctx.font = 'bold 15px system-ui, sans-serif'; ctx.fillText('★', x + 8, y + 21);
            ctx.fillStyle = got ? '#fff' : '#9aa3c7'; ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillText(a.name, x + 30, y + 13);
            ctx.fillStyle = '#9aa3c7'; ctx.font = '10px system-ui, sans-serif'; ctx.fillText(a.desc, x + 30, y + 25, w - 100);
            ctx.textAlign = 'right'; ctx.fillStyle = got ? '#2ecc71' : '#f1c40f'; ctx.font = 'bold 11px system-ui, sans-serif';
            ctx.fillText(got ? 'DONE' : '● ' + a.gold, x + w - 10, y + 19); ctx.textAlign = 'left';
        });
        if (pages > 1) {
            btn(14, 530, 80, 38, '◄', () => { trophyPage = (trophyPage + pages - 1) % pages; sfx('click'); }, '#636e72');
            btn(W - 94, 530, 80, 38, '►', () => { trophyPage = (trophyPage + 1) % pages; sfx('click'); }, '#636e72');
        }
    });
}
function drawStats() {
    hubBody(() => {
        const st = save.stats;
        const rows = [
            ['Runs played', st.runs], ['Balls popped', st.kills], ['Sombreros knocked off', st.hats], ['Bosses defeated', st.bosses],
            ['Gold earned (all time)', st.goldEarned], ['Time in the sky', fmtTime(st.time)], ['Best run', save.bestTime ? fmtTime(save.bestTime) : '-'],
            ['Best level', save.bestLevel || '-'], ['Best combo', '×' + st.maxCombo], ['Most balls in a run', st.bestKills],
            ['Trophies', Object.keys(save.ach).length + ' / ' + ACHS.length], ['Skill ranks bought', Object.values(save.skills).reduce((a, b) => a + b, 0)],
        ];
        rows.forEach((r, i) => {
            const x = 18, y = 72 + i * 40, w = W - 36, h = 34;
            ctx.fillStyle = i % 2 ? 'rgba(30,32,56,0.8)' : 'rgba(40,43,72,0.8)'; roundRect(x, y, w, h, 8); ctx.fill();
            ctx.fillStyle = '#c8d6e5'; ctx.font = '13px system-ui, sans-serif'; ctx.fillText(r[0], x + 12, y + 22);
            ctx.textAlign = 'right'; ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 14px system-ui, sans-serif'; ctx.fillText(String(r[1]), x + w - 12, y + 22); ctx.textAlign = 'left';
        });
    });
}
