#!/usr/bin/env python3
"""Build the game. Run in a folder holding ALL project docs flat (same file names):
  00-shell.html  NN-<name>.js (concatenated in numeric order into the one <script>)  hula-data-*.json
Usage: python3 build.py [--min] [out.html]
Every embedded base64 blob is a placeholder @@Bnnn@@ in the .js files; the json files map Bnnn -> 'len:z85' (decoded back to the original base64).
--min minifies the script with esbuild (what gets published). Output is the single-file game."""
import re,json,sys,subprocess,glob,base64
a=[x for x in sys.argv[1:] if x!='--min']; out=a[0] if a else 'hula-vaquero-soundfont.html'
mods=sorted(glob.glob('[0-9][0-9]-*.js'))
html=open('00-shell.html').read().replace('/*@@MODULES@@*/','\n'.join(open(f).read() for f in mods))
data={}
def unz(v):   # data json values are 'bytes:z85text' (lossless, ~7% smaller than base64); rebuild the base64 the game embeds
    n,t=v.split(':',1); return base64.b64encode(base64.z85decode(t.encode())[:int(n)]).decode()
for f in glob.glob('hula-data-*.json'): data.update({k:unz(v) for k,v in json.load(open(f)).items()})
html=re.sub(r'@@(B\d{3})@@',lambda m:data[m.group(1)],html)
if '--min' in sys.argv:
    m=next(re.finditer(r'(<script[^>]*>)(.*?)(</script>)',html,re.S)); open('_c.js','w').write(m.group(2))
    subprocess.run([__import__('os').environ.get('ESBUILD','/opt/npm-tools/node_modules/.bin/esbuild'),'_c.js','--minify','--target=es2020','--log-level=error','--outfile=_c.min.js'],check=True)
    mn=open('_c.min.js').read().rstrip('\n'); assert '</script' not in mn
    html=html[:m.start(2)]+'\n'+mn+'\n'+html[m.end(2):]
open(out,'w').write(html); print(out,len(html),len(mods),'modules')
