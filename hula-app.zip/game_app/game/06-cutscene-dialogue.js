function csLineStart(l) {
    const V = l.V; l.started = true; l.f0 = cs.t;
    if (l.sung) return;   // (sung lines make their sound on the band's clock)
    if (l.snort) { csCrinkle(0.6, 0.45, 0.5); csCrinkle(1.1, 0.5, 0.4); for (let i = 0; i < 11; i++) csTap(1.9 + i * 0.12, 0.5 + 0.3 * Math.random()); csSniff(3.7, 0.7, 1.2); csSniff(4.9, 0.28, 0.7); csSniff(5.3, 0.25, 0.6); csGasp(4.45, 0.4, 0.5, V.vol * 0.9, V); csSniff(5.8, 0.3, 0.55); return; }
    if (l.wr) { const d = l.plan.dur; for (let k = 0; k < 1 + (d > 3 ? 1 : 0); k++) csSniff(0.2 + Math.random() * Math.max(0.2, d - 0.6), 0.16 + Math.random() * 0.1, 0.4); }
    if (l.hack && l.raw) {   // rattling heaves, then the spit on the last beat
        const kt = l.plan.env.filter((e, i) => l.raw[i] && l.raw[i][0] === 'K').map(e => e.t0);
        kt.forEach((t0, i) => { if (i < kt.length - 1) csHack(0.03 + t0, Math.max(0.3, Math.min(0.75, kt[i + 1] - t0 - 0.12)), 0.85 + 0.12 * i, V.vol * 0.8, V); else csSpit(0.03 + t0, V.vol * 0.9, V); });
        return;
    }
    if (l.scough && l.raw) { l.plan.env.forEach((e, i) => { if (l.raw[i] && l.raw[i][0] === 'K') csCough(0.03 + e.t0, 0.55 * (0.9 + Math.random() * 0.2), V.vol * 0.7, V, 0); }); return; }
    if (l.cough && l.raw) {   // real cough sounds on the K beats, wheezy gasps in the long gaps
        let n = 0; const tot = l.raw.filter(r => r[0] === 'K').length;
        l.plan.env.forEach((e, i) => { const r = l.raw[i]; if (!r) return;
            if (r[0] === 'K') { csCough(0.03 + e.t0, (n === 0 ? 1.25 : 1) * (0.95 - 0.3 * n / tot) * (0.88 + Math.random() * 0.24), V.vol * 0.7, V, n); n++; }
        });
        const kt = l.plan.env.filter((e, i) => l.raw[i] && l.raw[i][0] === 'K').map(e => e.t0);   // wheezy gasp wherever the gap between two coughs is long
        kt.forEach((t0, i) => { const gp = i < kt.length - 1 ? kt[i + 1] - t0 : 0; if (gp > 0.5) csGasp(0.03 + t0 + 0.3, Math.min(0.55, gp - 0.38), 0.8, V.vol * 1.1, V); });
        return;
    }
    if (neuralHas(l) && neuralPlay(l)) return;   // the pre-rendered neural voice
    for (const c of l.plan.chunks) {
        const dl = 0.03 + c.off;
        if (V.multi) V.multi.forEach(([pm, fm], k) => speakSyn(dl + k * 0.012, c.seq.map(([n, f, s, f1, ...r]) => [n, f * pm, s, f1 ? f1 * pm : f1, ...r]), V.vol, { fs: V.fs * fm, verb: V.verb, vib: V.vib, breath: V.breath, wander: V.wander, tilt: V.tilt, jit: V.jit, uni: V.uni, sub: V.sub, rasp: V.rasp, dip: V.dip, lp: V.lp, bright: V.bright, whisper: V.whisper, unasp: V.mx, cv: true }));
        else speakLayered(dl, c.seq, V.vol, { fs: V.fs, verb: V.verb, vib: V.vib, breath: V.breath, wander: V.wander, tilt: V.tilt, jit: V.jit, uni: V.uni, sub: V.sub, rasp: V.rasp, dip: V.dip, lp: V.lp, bright: V.bright, whisper: V.whisper, unasp: V.mx, cv: true });
    }
}
Object.assign(LEX, { fuck: 'F AH1 K' });   // the hero's pet name for the kid in THE WHY / THE TANGENT
const ACT_SAY = {   // spoken lines of the act cutscenes (matched by scene title; a line only plays in the scene whose text contains its quote)
    'ACT 4 · THE FINAL SHOWDOWN': [{ who: 'baron', say: 'You cannot pop me, little vaquero!', hx: 'defiant', q: '\"You cannot pop', mood: 'rage', x: 180, y: 62, tx: 180 }, { who: 'hero', say: 'Watch me.', ex: 'determined', q: '\"Watch me', gap: 15, mood: 'cheer', x: 180, y: 292, tx: 180 }],
};
function saySource() { return cs.list === END_CUTS ? END_SAY : (cs.list === ACT_CUTS[3] ? ACT_SAY : (muIs() ? MUSICAL_SAY : null)); }
function csSpeak() {
    const src = saySource(); if (!src) return;
    const sc = cs.list[cs.i], L = src[sc.title]; if (!L) return;
    if (cs.spI !== cs.i) {
        cs.spI = cs.i; cs.spL = []; let prevEnd = 0, wired = !!sc.wired;
        L.forEach(ln => {
            if (ln.sing) { const sl = muSungLine(ln, sc); cs.spL.push(sl); prevEnd = sl.end; return; }   // the musical: sung lines are timed by their bar and voiced by the band's sequencer
            if (ln.q && sc.text.indexOf(ln.q) < 0) return;
            let V = moodV(VOICES[ln.who], ln.mood || MOOD_OF[ln.say]); let raw = ln.raw;
            if (ln.snort) wired = true; else if (ln.rage) wired = false; else if (wired && ln.who === 'hero' && !ln.raw) { V = Object.assign({}, V, { rate: V.rate * 1.14 }); ln = Object.assign({}, ln, { wr: true }); }   // after the line he talks faster and sniffs
            if (ln.fitDur && raw) { const mk = g => raw.map(r => r[3] === 'gap' ? [r[0], r[1], (r[2] || 1) * g, 'gap'] : r), dur = g => planLine(ln.say, V, mk(g)).dur, d1 = dur(1), d2 = dur(2); raw = mk(Math.max(0.05, 1 + (ln.fitDur - d1) / Math.max(1e-6, d2 - d1))); }   // stretch the gaps so the line lasts exactly fitDur seconds
            const pl = planLine(ln.say, V, raw); neuralFit(ln, pl);
            const at = ln.gap != null ? prevEnd + ln.gap : ln.q ? Math.floor(Math.max(0, sc.text.indexOf(ln.q)) / CPS) + (ln.d || 0) : ln.at;
            const l = Object.assign({}, ln, { V, plan: pl, raw, at, end: at + Math.ceil(pl.dur * 60), started: false, fired: false }); cs.spL.push(l); prevEnd = l.end;
        });
        cs.holdX = Math.max(0, Math.max(...cs.spL.map(l => l.end)) + 60 - (Math.ceil(sc.text.length / CPS) + 170), sc.musF ? sc.musF + 40 - (Math.ceil(sc.text.length / CPS) + 170) : 0);
    }
    for (const l of cs.spL) if (!l.fired && cs.t >= l.at) { l.fired = true; if (cs.t - l.at <= 14) csLineStart(l); }
}
function cutMouth(who) {   // 0..1 jaw/mouth opening for whoever is speaking right now, or null when they are silent
    if (!cs || !cs.spL || cs.spI !== cs.i) return null;
    for (const l of cs.spL) {
        if (!l.started || l.who !== who || l.nomouth) continue; const sec = (cs.t - l.f0) / 60; if (sec < 0 || sec > l.plan.dur + 0.1) continue;
        let o = 0.1; for (const e of l.plan.env) if (sec >= e.t0 - 0.02 && sec < e.t0 + e.d + 0.02) { o = Math.max(o, e.o * (0.6 + 0.4 * Math.sin(Math.PI * clamp((sec - e.t0) / e.d, 0, 1)))); }
        return o;
    }
    return null;
}
function drawBubbles() {
    if (!cs || !cs.spL) return;
    for (const l of cs.spL) {
        if (!l.started || l.nobub) continue; const sec = (cs.t - l.f0) / 60, life = l.plan.dur + 1.1; if (sec < 0 || sec > life) continue;
        const a = clamp((life - sec) / 0.4, 0, 1) * clamp(sec / 0.1 + 0.2, 0, 1), V = l.V;
        let shown = 0; l.plan.words.forEach((w, i) => { if (w.t <= sec) shown = l.plan.words.slice(0, i + 1).reduce((n, x) => n + x.w.length + 1, 0); });
        ctx.save(); ctx.globalAlpha = a; ctx.font = '700 14px system-ui, sans-serif';
        const maxW = 190, lines = wrapLines(l.say, maxW), w = Math.min(maxW, Math.max(...lines.map(s => ctx.measureText(s).width))) + 20, h = 24 + lines.length * 18;
        const bx = clamp(l.x - w / 2, 8, W - 8 - w), by = clamp(l.y - h / 2, 40, 436 - h);
        ctx.fillStyle = 'rgba(12,8,24,0.86)'; roundRect(bx, by, w, h, 10); ctx.fill(); ctx.strokeStyle = V.col; ctx.lineWidth = 1.5; roundRect(bx, by, w, h, 10); ctx.stroke();
        const tx = clamp(l.tx == null ? l.x : l.tx, bx + 14, bx + w - 14); ctx.fillStyle = 'rgba(12,8,24,0.86)'; ctx.beginPath(); ctx.moveTo(tx - 6, by + h - 0.5); ctx.lineTo(tx + 6, by + h - 0.5); ctx.lineTo(tx + (l.tx == null ? 0 : clamp((l.tx - tx) * 0.3, -8, 8)), by + h + 10); ctx.fill();
        ctx.fillStyle = V.col; ctx.font = '800 9px system-ui, sans-serif'; ctx.fillText(V.name, bx + 10, by + 14);
        ctx.fillStyle = '#fff'; ctx.font = '700 14px system-ui, sans-serif'; let left = shown; lines.forEach((ln, i) => { ctx.fillText(ln.slice(0, Math.max(0, left)), bx + 10, by + 33 + i * 18); left -= ln.length + 1; });
        ctx.restore();
    }
}

const END_SAY = {
    'THE LAST POP': [{ who: 'baron', say: 'Impossible!', hx: 'triumph', q: '\"Impossible!\"', x: 180, y: 66 }, { who: 'hero', say: 'Adios, globo!', ex: 'triumph', at: 215, x: 262, y: 330, tx: 215 }],
    'THE LEDGER': [{ who: 'hero', say: 'So that\'s how you kill a balloon.', ex: 'smirk', at: 60, x: 120, y: 210, tx: 118 }],
    'THE PROMISE': [{ who: 'hero', say: 'Promise me. Every one of you, in the plaza.', ex: 'resolve', at: 50, x: 200, y: 215, tx: 195 }, { who: 'chorus', say: 'We promise!', hx: 'content', gap: 30, x: 80, y: 290, tx: 70 }],
    'THE FALL': [{ who: 'baron', say: 'Noooo!', raw: [['N', 1.1, 1], ['O', 1.15, 3], ['O', 0.95, 4], ['O', 0.7, 5], ['O', 0.45, 6]], at: 100, x: 180, y: 110 }],
    'THE GOLDEN SOMBRERO': [{ who: 'hero', say: 'Mine!', ex: 'greedy', at: 142, x: 262, y: 290, tx: 215 }],
    'THE PLAZA AWAKENS': [{ who: 'chorus', say: 'Viva Hula Vaquero!', hx: 'bliss', q: 'They rise', x: 180, y: 120 }],
    'ABUELA\'S CANTINA': [{ who: 'abuela', say: 'Come, come! Tamales for the hero!', at: 25, x: 118, y: 226, tx: 118 }, { who: 'kid', say: 'Thank you!', at: 150, x: 262, y: 240, tx: 262 }],
    'THE BAND TUNES UP': [{ who: 'guitar', say: 'Uno, dos, tres!', at: 30, x: 280, y: 210, tx: 290 }],
    'THE LANTERNS GO OUT': [{ who: 'baron', say: 'Soon...', at: 210, x: 180, y: 62 }],
    'THE LAST BOTTLE': [{ who: 'baron', say: 'Drink up, little ones.', at: 120, x: 230, y: 90, tx: 200 }],
    'THE TOAST': [{ who: 'abuela', say: 'To the hero!', q: '\"To the hero!\"', x: 150, y: 250, tx: 150 }, { who: 'chorus', say: 'To the hero!', q: '\"To the hero!\"', d: 14, x: 230, y: 300 }, { who: 'baron', say: 'Ha ha ha!', raw: [['H', 1, 1], ['A', 1.3, 1.1], ['H', 1, 1], ['A', 1.2, 1.1], ['H', 1, 1], ['A', 1.0, 1.6]], at: 210, x: 180, y: 70 }],
    'THE CHASE': [{ who: 'baron', say: 'Catch me if you can!', hx: 'fierce', at: 40, x: 230, y: 120, tx: 280 }, { who: 'hero', say: 'Come back here!', ex: 'fierce', gap: 30, x: 120, y: 230, tx: 115 }],
    'THE REVENGE': [{ who: 'baron', say: 'Feel their pain!', at: 60, x: 180, y: 62 }],
    'THE OFFER': [{ who: 'baron', say: 'Let it turn your skin white, and every spirit is saved. Refuse, and they stay ghosts forever.', q: '\"Let it turn', x: 200, y: 100, tx: 255 }, { who: 'chorus', say: 'Please... say yes!', q: 'The villagers kneel', d: 40, x: 90, y: 330, tx: 70 }, { who: 'hero', say: 'I was wondering when you would ask.', ex: 'sly', gap: 25, x: 160, y: 250, tx: 150 }],
    'THE REFUSAL': [{ who: 'hero', say: 'No.', ex: 'defiant', at: 36, x: 190, y: 235, tx: 180 }, { who: 'baron', say: 'You knew!', hx: 'smug', at: 80, x: 250, y: 70, tx: 260 }, { who: 'hero', say: 'Ha ha ha ha!', ex: 'roar_laugh', raw: [['H', 1, 1], ['A', 1.5, 1.1], ['H', 1, 1], ['A', 1.4, 1.1], ['H', 1, 1], ['A', 1.3, 1.1], ['H', 1, 1], ['A', 1.15, 1.8]], gap: 70, x: 190, y: 235, tx: 180 }, { who: 'hero', say: 'From the very first pop.', ex: 'smug', gap: 25, x: 190, y: 235, tx: 180 }],
    'THE LAUGH': [{ who: 'hero', say: 'I never cared about this village.', ex: 'cold', at: 50, x: 190, y: 235, tx: 180 }, { who: 'hero', say: 'I\'m glad they\'re gone.', ex: 'haughty', gap: 25, x: 190, y: 235, tx: 180 }],
    'THE PLUNDER': [{ who: 'hero', say: 'Thank you for your service.', ex: 'haughty', at: 70, x: 200, y: 250, tx: 188 }, { who: 'abuela', say: 'My cantina...', hx: 'cold', gap: 30, x: 80, y: 170, tx: 72 }],
    'THE PORTRAIT': [{ who: 'hero', say: 'Pull!', ex: 'fierce', at: 40, x: 110, y: 290, tx: 100 }, { who: 'chorus', say: 'Yes, master.', hx: 'haughty', gap: 25, x: 180, y: 56 }],
    'THE CROWNING': [{ who: 'hero', say: 'Kneel.', ex: 'haughty', at: 25, x: 260, y: 230, tx: 195 }, { who: 'chorus', say: 'As you wish, master.', hx: 'haughty', gap: 40, x: 180, y: 330, tx: 180 }],
    'THE REHEARSAL': [{ who: 'hero', say: 'Again!', ex: 'stern', at: 30, x: 250, y: 330, tx: 195 }, { who: 'chorus', say: 'Viva!', gap: 10, x: 180, y: 200 }, { who: 'kid', say: 'Sorry!', hx: 'stern', at: 125, x: 150, y: 195, tx: 200 }],
    'THE WHY': [{ who: 'kid', say: 'Why? I looked up to you.', mood: 'plead', q: 'ask him why', d: 10, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: 'Because I was never your hero, little fuck.', mood: 'chill', gap: 40, x: 235, y: 92, tx: 235, ex: 'condescending' },
        { who: 'hero', say: '', raw: [['BH', 1, 1, 'gap']], fitDur: 4, gap: 30, nobub: true, nomouth: true, inh: true, x: 235, y: 92 },   // the massive rip: one long, slow inhale
        { who: 'hero', say: '*cough! cough! COUGH!*', raw: (() => { const r = []; [2, 3, 2, 2, 1].forEach((n, ci) => { for (let i = 0; i < n; i++) { r.push(['K', 0.82 - 0.03 * i, 1.0], ['AH', 0.7 - 0.03 * i, 1.0], ['H', 0.85, 1.2]); if (i < n - 1) r.push(['BH', 1, 0.5, 'gap']); } if (ci < 4) r.push(['BH', 1, 3, 'gap']); }); return r; })(), fitDur: 5, gap: 50, cough: true, x: 235, y: 92, tx: 235 },   // five seconds of uncontrollable coughing
        { who: 'hero', say: '*hhhkk... hhhhKKK... PTOO!*', raw: [['K', 0.8, 1], ['AH', 0.6, 1.5], ['H', 0.7, 1.4], ['BH', 1, 0.8, 'gap'], ['K', 0.75, 1], ['AH', 0.55, 1.8], ['H', 0.65, 1.6], ['BH', 1, 0.7, 'gap'], ['K', 0.7, 1.1], ['AH', 0.5, 2.2], ['H', 0.6, 1.8], ['BH', 1, 1.1, 'gap'], ['K', 0.9, 0.8], ['H', 0.8, 0.6]], fitDur: 3.6, gap: 22, hack: true, x: 235, y: 92, tx: 235 },   // after the fit: a deep rattling hack, then he spits over the ledge
        { who: 'hero', say: 'Whoa. Okay. Where was I...', mood: 'stoned', gap: 55, x: 235, y: 92, tx: 235, ex: 'dizzy' },
        { who: 'kid', say: 'You were telling me why.', mood: 'cold', gap: 45, x: 112, y: 150, tx: 56 }
    ],
    'THE TANGENT': [{ who: 'hero', say: 'They clapped for the sombrero... never for me.', mood: 'cold', gap: 50, x: 235, y: 92, tx: 235, ex: 'bitter', heat: 0.3 },
        { who: 'hero', say: 'Years of fiestas... and not one song was mine.', mood: 'sad', gap: 50, x: 235, y: 92, tx: 235, ex: 'melancholy', heat: 0.12 },
        { who: 'hero', say: '*cough*', raw: [['K', 0.8, 0.9], ['AH', 0.6, 0.7]], gap: 70, scough: true, toke: true, x: 235, y: 92, tx: 235 },
        { who: 'hero', say: 'You ever look at the stars? They are just... clapping for themselves.', mood: 'stoned', gap: 14, x: 235, y: 92, tx: 235, ex: 'daydream' },
        { who: 'hero', say: '*cough*', raw: [['K', 0.8, 0.9], ['AH', 0.6, 0.7]], gap: 80, scough: true, toke: true, x: 235, y: 92, tx: 235 },
        { who: 'hero', say: 'Have you ever really looked at your hand, little fuck?', mood: 'stoned', gap: 14, x: 235, y: 92, tx: 235, ex: 'intrigued' },
        { who: 'hero', say: 'Ha ha ha ha ha!', raw: [['H', 1, 1], ['A', 1.25, 1.2], ['H', 1, 1], ['A', 1.15, 1.2], ['H', 1, 1], ['A', 1.1, 1.3], ['H', 0.95, 1], ['A', 0.95, 2.2]], mood: 'stonemock', gap: 45, x: 235, y: 92, tx: 235, ex: 'laugh', heat: 0.1 },
        { who: 'hero', say: 'You do not have hands! You are a GHOST! Look at you, floating there, asking me about hands!', mood: 'stonemock', gap: 55, x: 235, y: 92, tx: 235, ex: 'cocky', heat: 0.15 },
        { who: 'kid', say: 'Yes. I know what I am.', mood: 'cold', gap: 40, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: 'Shh. Do you hear them? ...They are whispering about me.', mood: 'whisper', gap: 95, x: 235, y: 92, tx: 235, ex: 'suspicious', heat: 0.25, voices: true }
    ],
    'THE STASH': [{ who: 'hero', say: '', raw: [['BH', 1, 1, 'gap']], fitDur: 6.6, gap: 30, nobub: true, nomouth: true, snort: true, x: 235, y: 92 },   // the stash: baggie from the pocket, a line chopped out, one hard snort, the rush
        { who: 'hero', say: 'Clap for the hat. Clap for the hat. Clap for the hat.', mood: 'whisper', gap: 40, x: 235, y: 92, tx: 235, ex: 'creepy', heat: 0.3, voices: true },
        { who: 'hero', say: 'Stop it.', mood: 'cold', gap: 25, x: 235, y: 92, tx: 235, ex: 'defiant', heat: 0.5, hat: true }
    ],
    'THE BREAKING': [{ who: 'hero', say: 'Nobody asked how I was. Not once. Thirty fiestas, and they asked for the hat.', mood: 'plead', gap: 75, x: 235, y: 92, tx: 235, ex: 'disappointed', heat: 0.2 },
        { who: 'hero', say: 'I held this village together. Every lantern. Every guitar string. Me.', mood: 'cold', gap: 60, x: 235, y: 92, tx: 235, ex: 'indignant', heat: 0.55 },
        { who: 'hero', say: '...Sorry. Sorry. I am fine. I am smiling. See?', mood: 'plead', gap: 40, x: 235, y: 92, tx: 235, ex: 'grin', heat: 0.15 },
        { who: 'kid', say: 'The hat was the hero. You were just the head underneath it.', mood: 'cold', gap: 85, bait: true, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: 'Heh. Heh. Good one.', mood: 'stoned', gap: 45, x: 235, y: 92, tx: 235, ex: 'sarcastic', heat: 0.35 },
        { who: 'kid', say: 'Thirty fiestas, and nobody ever learned your name. Not even me.', mood: 'cold', gap: 55, bait: true, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: '...They know my name.', mood: 'cold', gap: 45, x: 235, y: 92, tx: 235, ex: 'defiant', heat: 0.6 },
        { who: 'kid', say: 'Then say it. Say your name.', mood: 'cold', gap: 40, bait: true, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: 'It is... it is...', mood: 'plead', gap: 50, x: 235, y: 92, tx: 235, ex: 'bewildered', heat: 0.5, voices: true },
        { who: 'kid', say: 'You do not remember it, do you? Not even your own name.', mood: 'cold', gap: 45, bait: true, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: 'I am the HERO!', mood: 'rageh', gap: 30, x: 235, y: 92, tx: 235, ex: 'rage', heat: 0.85 },
        { who: 'hero', say: 'FUCK YOU!', mood: 'rageh', gap: 22, x: 235, y: 92, tx: 235, ex: 'roar', heat: 0.95 },
        { who: 'kid', say: 'No. The hat is the hero. It always was.', mood: 'cold', gap: 25, bait: true, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: 'DO NOT SAY THAT!', mood: 'rageh', gap: 8, x: 215, y: 70, tx: 235, ex: 'roar', heat: 1, rage: true },
        { who: 'hero', say: 'AAAAAAAAH!', raw: [['A', 1.25, 2.6], ['A', 1.5, 4], ['A', 1.15, 5.5]], mood: 'rageh', gap: 4, x: 215, y: 70, tx: 235, ex: 'roar', heat: 1 },
        { who: 'kid', say: 'There he is. I wondered when he would show up.', mood: 'cold', gap: 75, bait: true, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: '...I am fine. I am smiling.', mood: 'plead', gap: 85, x: 215, y: 70, tx: 235, ex: 'grin', heat: 0.4 },
        { who: 'kid', say: 'You are not fine. You never were.', mood: 'cold', gap: 50, bait: true, x: 112, y: 150, tx: 56 },
        { who: 'hero', say: 'So I took the hat... and I took the village. Now you will clap... for me... forever.', mood: 'cold', gap: 90, x: 215, y: 70, tx: 235, ex: 'vengeful', heat: 0.45 }
    ],
    'THE FIESTA NEVER ENDS': [{ who: 'hero', say: 'Louder!', ex: 'manic', at: 40, x: 180, y: 200, tx: 180 }, { who: 'chorus', say: 'Viva Hula Vaquero!', hx: 'bliss', gap: 18, x: 180, y: 70 }],
};
