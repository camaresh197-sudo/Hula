
// =====================================================================
//  ACT 2: CONVOY CHASE. A tactical, turn-based chase down a perspective highway.
//  Plan your moves (steer, hoop, ram, salsa), end the turn, and the convoy hits back.
//
//  THE RULES (rebuilt)
//  - Every car is a threat with its own attack. Each attack is TELEGRAPHED: red lanes show where a hit will land at the end of
//    this turn, and every car carries a tag saying what it is about to do. If your lane is red, you take it unless you move,
//    kill the attacker, stick it with salsa, or ram it out of position.
//  - You have 3 moves a turn. Steering, hoops, rams and salsa all draw from the same pool, so the enemy always threatens more than
//    you can fully answer. Choosing what to ignore is the game.
//  - Cars: SCOUTS weave into your lane and ram you (a miss sends them wrecked past you). RACERS rev, lunge, then flee.
//    BRUISERS shoulder-check two lanes every turn until they are dead (armor first, or ram them). SPITTERS volley two lanes
//    every other turn. LANTERN TRUCKS run for the horizon and toss barrels that roll down your lane (shoot them: they explode on
//    whatever is next to them). Ambushes keep arriving, so you cannot turtle.
//  - Rewards: a ram kill refunds a move, a recovered lantern heals you, a dodged strike is points.
//  - The boss runs a four-beat cycle (barrels, spray, escorts, charge). Dodge the charge and he is exhausted and wide open.
// =====================================================================
const CV = { SP: 0.6, MAXR: 8, SALSA_T: 2 };
const CV_T = {
    scout:   { name: 'Scout',         hp: 1, role: 'tailgate', dmg: 8,  col: '#e74c3c', xp: 2,  gold: 1, score: 60,  dodge: 0.7, note: 'Weaves into your lane and rams you' },
    racer:   { name: 'Racer',         hp: 1, role: 'lunge',    dmg: 11, col: '#2e86de', xp: 3,  gold: 1, score: 90,  dodge: 0.8, note: 'Revs, lunges down its lane, then flees' },
    bruiser: { name: 'Bruiser',       hp: 2, role: 'crush',    dmg: 13, col: '#5f6c7b', xp: 5,  gold: 2, score: 140, dodge: 0.15, armor: 1, truck: 1, note: 'Shoulder-checks two lanes every turn' },
    spitter: { name: 'Spitter',       hp: 1, role: 'spit',     dmg: 9,  col: '#8e44ad', xp: 4,  gold: 2, score: 110, dodge: 0.3, note: 'Volleys two lanes every other turn' },
    lantern: { name: 'Lantern Truck', hp: 2, role: 'flee',     dmg: 0,  col: '#f39c12', xp: 8,  gold: 5, score: 260, dodge: 0.6, truck: 1, lantern: 1, note: 'Runs for the horizon: catch it' },
    boss:    { name: 'El Camión Salsero', hp: 24, role: 'boss', dmg: 0, col: '#c0392b', xp: 60, gold: 30, score: 2000, truck: 1, big: 1, boss: 1, note: 'Dodge the charge, then punish him' },
    barrel:  { name: 'Salsa Barrel',  hp: 1, role: 'barrel',   dmg: 9,  col: '#8a4a28', xp: 0, gold: 0, score: 0, barrel: 1, note: 'Rolls down its lane: shoot it or dodge' },
};
const CV_HITTXT = { ram: 'RAMMED!', lunge: 'RAMMED!', crush: 'CRUSHED!', spit: 'SPLAT!', spray: 'SAUCED!', charge: 'FLATTENED!', barrel: 'KABOOM!' };
// level data: waves of [type, lane, row]. amb = a reinforcement car every N turns (from pool), toss = lanterns throw barrels
const CV_LEVELS = [
    { salsa: 3, amb: 2, pool: ['scout', 'scout', 'racer'], waves: [
        [['lantern', 0, 5], ['scout', -1, 4], ['scout', 1, 6]],
        [['lantern', -1, 5], ['lantern', 1, 4], ['scout', 0, 6], ['racer', 1, 6]],
        [['lantern', 0, 5], ['racer', -1, 6], ['scout', 1, 5], ['scout', 0, 7]],
    ] },
    { salsa: 3, amb: 3, pool: ['racer', 'spitter', 'bruiser', 'scout'], toss: 1, waves: [
        [['lantern', 1, 5], ['bruiser', 0, 4], ['scout', -1, 6]],
        [['lantern', -1, 5], ['spitter', 1, 6], ['racer', 0, 5], ['scout', 1, 4]],
        [['lantern', 0, 5], ['lantern', 1, 4], ['bruiser', -1, 5], ['spitter', 0, 7]],
    ] },
    { salsa: 4, amb: 2, pool: ['spitter', 'racer', 'spitter', 'bruiser'], toss: 1, waves: [
        [['lantern', 0, 5], ['spitter', -1, 6], ['spitter', 1, 6], ['racer', 0, 4]],
        [['lantern', -1, 5], ['bruiser', 1, 5], ['racer', 0, 4], ['scout', -1, 6]],
        [['lantern', 1, 5], ['lantern', -1, 4], ['spitter', 0, 6], ['bruiser', 0, 7]],
        [['lantern', 0, 5], ['racer', -1, 4], ['racer', 1, 5], ['spitter', 0, 6], ['bruiser', 1, 6]],
    ] },
    { salsa: 4, boss: 1, waves: [] },
];
let cvBend = 0;
const cvP = r => 4.5 * Math.pow(Math.max(r, 0.25), 1.08);
const cvCovers = (c, lane) => c.big ? (lane === c.lane || lane === c.lane + 1) : lane === c.lane;
const cvLive = () => g.cv.cars.filter(c => !c.dying);
function cvOcc(lane, row, self, big) {
    for (const c of g.cv.cars) {
        if (c === self || c.dying || c.row !== row) continue;
        if (cvCovers(c, lane) || (big && cvCovers(c, lane + 1)) || (c.big && big)) return true;
    }
    return false;
}
const cvApMax = () => 3 + (g.S.cvAp || 0);
const cvReach = () => 8;
const cvRamReach = () => 3 + (g.S.cvReach || 0);
const cvHoopDmg = () => 1 + (g.S.cvHoop || 0) + Math.floor(Math.max(0, g.S.dmg - 1) / 0.6);
const cvRamDmg = () => 2 + (g.S.ram || 0);
function cvScr(x, y) { return { x: 180 + (x - 180) * 1.03, y: 240 + (y - 240) * 1.03 }; }   // csPursuit zooms its picture by 3%
function cvPos(r, lane, big) {
    const u = prU(cvP(r)); return { u, x: prCx(u, cvBend) + (lane + (big ? 0.5 : 0)) * CV.SP * PR.hw * u, y: prY(u) };
}
function cvAt(t, fn) { g.cv.q.push({ t, fn }); }
function cvMsg(s, col) { g.cv.msg = s; g.cv.msgT = 110; g.cv.msgCol = col || '#ffe9a0'; }
const cvAdj = (lane, r) => lane === 0 ? (r < 0.5 ? -1 : 1) : 0;   // the second lane a volley covers: the middle when you are on a side, a random side when you are in the middle

function initConvoy(L) {
    const S = g.S, spec = L.cv || CV_LEVELS[g.li] || CV_LEVELS[0];
    g.cv = { lane: 0, px: 0, ap: cvApMax(), turn: 1, cars: [], slicks: [], q: [], fx: [], phase: 'plan', busy: 24, wave: 0, waves: spec.waves || [], isBoss: !!spec.boss,
        tool: null, salsa: spec.salsa + (S.cvSalsa || 0), nextId: 1, caught: 0, escaped: 0, lanterns: 0, theme: L.theme || 'dawn', msg: '', msgT: 0, msgCol: '#ffe9a0',
        t: 0, scroll: 0, spd: 3.2, nitro: 0, kick: 0, freeSteer: !!S.cvFree, steered: false, bossRef: null, done: false, info: null, shake: 0, over: 0,
        amb: spec.amb || 0, pool: spec.pool || ['scout', 'racer'], toss: !!spec.toss, refunded: false };
    g.stage.bossSpawned = false;
    g.player.x = W / 2; g.player.y = 442;
    if (g.cv.isBoss) cvSpawnBoss(); else cvSpawnWave();
    cvPlan();
}
function cvMake(type, lane, row) {
    const T = CV_T[type], cv = g.cv;
    const c = { id: cv.nextId++, type, lane, row, al: lane, ar: row + (type === 'barrel' ? 0 : 3.5), hp: T.hp, max: T.hp, armor: T.armor || 0, stun: 0, int: null, rot: 0, ox: 0, alpha: 1, dying: 0, flash: 0,
        big: !!T.big, color: T.col, truck: !!T.truck, fix: true, nopuff: !!T.barrel, sc: T.big ? 1.45 : 1.15, t0: Math.random() * 6, mode: 'run', rnd: Math.random(), tl: cv.lane };
    cv.cars.push(c); return c;
}
function cvSpawnWave() {
    const cv = g.cv, w = cv.waves[cv.wave++];
    if (!w) return;
    for (const [type, lane, row] of w) { let r = row; while (cvOcc(lane, r, null) && r < CV.MAXR) r++; cvMake(type, lane, r); }
    cv.lanterns += w.filter(s => s[0] === 'lantern').length;
    if (cv.wave > 1) { toast('CONVOY ' + cv.wave + '/' + cv.waves.length, 'More thieves on the road!', '#ff9f43', 120); g.cv.salsa++; cvMsg('+1 salsa jar'); }
}
function cvSpawnBoss() {
    const cv = g.cv, b = cvMake('boss', -1, 6);
    b.hp = b.max = 20 + 2 * Math.min(4, g.camp ? Math.floor(g.camp.lvlDone / 2) : 0); b.lane = -1; b.al = -1; b.phase2 = false; b.bt = 0; b.recover = false;
    cv.bossRef = b; cv.lanterns = 1;
    g.warn = 110; sfx('boss'); toast('EL CAMIÓN SALSERO', 'Wreck the hot-sauce truck!', '#ff4757', 220);
}
function cvAmbush() {
    const cv = g.cv, live = cv.cars.filter(c => !c.dying && c.type !== 'barrel' && !CV_T[c.type].lantern).length;
    if (live >= 5) return;
    const n = Math.min(5 - live, cv.turn >= 8 ? 2 : (Math.random() < 0.4 ? 2 : 1)), lanes = [-1, 0, 1].sort(() => Math.random() - 0.5);
    let made = 0;
    for (let i = 0; i < n; i++) { let row = 7; while (cvOcc(lanes[i], row, null) && row < CV.MAXR) row++; if (!cvOcc(lanes[i], row, null)) { cvMake(pick(cv.pool), lanes[i], row); made++; } }
    if (made) { toast('AMBUSH!', 'Reinforcements are closing in', '#ff7675', 90); sfx('ebullet'); }
}

// ---- what every car is going to do this enemy phase (shown to the player) ----
// I = { dr: rows it will move (negative = toward you), dl: lanes, hits: [{ lane, dmg, kind }] that land at the end of the phase, atk, atkRow, label }
// Each turn a car rolls c.rnd and remembers c.tl (the lane you were in when the turn began), so the telegraph never changes under you:
// you dodge by leaving the lane, not by out-guessing a reroll.
function cvIntent(c) {
    const cv = g.cv, T = CV_T[c.type], tl = c.tl == null ? cv.lane : c.tl, r = c.rnd == null ? 0.5 : c.rnd;
    const I = c.int = { dr: 0, dl: 0, hits: [], atk: null, atkRow: null, label: '' };
    if (T.barrel) { I.dr = -1; if (c.row <= 1) { I.label = 'BOOM'; I.atk = 'barrel'; I.hits.push({ lane: c.lane, dmg: T.dmg, kind: 'barrel' }); } return; }
    if (c.type === 'boss') return cvBossIntent(c);
    if (c.stun > 0) return;
    const dmg = T.dmg, dir = Math.sign(tl - c.lane), toward = () => (dir && !cvOcc(c.lane + dir, c.row, c)) ? dir : 0;
    if (T.role === 'flee') {
        I.dr = 1;
        if (cvCovers(c, tl) && r < T.dodge) { const opts = [-1, 1].filter(d => { const nl = c.lane + d; return nl >= -1 && nl <= 1 && !cvOcc(nl, c.row, c); }); if (opts.length) I.dl = opts[Math.floor(r * 997) % opts.length]; }
        if (cv.toss && c.row <= 6 && (cv.turn + c.id) % 2 === 0 && cv.cars.filter(o => o.type === 'barrel' && !o.dying).length < 3) { I.atk = 'toss'; I.tossLane = tl; I.label = 'TOSS'; }
    } else if (T.role === 'tailgate') {
        I.dl = toward(); const nl = c.lane + I.dl, nrow = Math.max(1, c.row - 2); I.dr = nrow - c.row;
        if (nrow <= 2) { I.atk = 'ram'; I.atkRow = nrow; I.label = 'RAM'; I.hits.push({ lane: nl, dmg, kind: 'ram' }); }
    } else if (T.role === 'lunge') {
        const m = c.mode || 'run';
        if (m === 'flee') { I.dr = 3; I.label = 'FLEE'; }
        else if (m === 'lunge') { I.dr = 1 - c.row; I.atk = 'lunge'; I.atkRow = 1; I.label = 'LUNGE'; I.hits.push({ lane: c.lane, dmg, kind: 'lunge' }); }
        else { I.dl = toward(); I.dr = Math.max(-2, 3 - c.row); if (c.row + I.dr <= 4) I.label = 'REV'; }
    } else if (T.role === 'crush') {
        if (c.row <= 4) I.dl = toward();
        const nl = c.lane + I.dl, nrow = Math.max(3, c.row - 1); I.dr = nrow - c.row;
        if (nrow <= 3) { const adj = nl === 0 ? (r < 0.5 ? -1 : 1) : 0; I.atk = 'crush'; I.atkRow = nrow; I.label = 'CRUSH'; I.hits.push({ lane: nl, dmg, kind: 'crush' }, { lane: adj, dmg, kind: 'crush' }); }
    } else if (T.role === 'spit') {
        I.dr = c.row < 4 ? 1 : c.row > 6 ? -1 : 0;
        if ((cv.turn + c.id) % 2 === 0) { I.atk = 'spit'; I.label = 'FIRE'; I.hits.push({ lane: tl, dmg, kind: 'spit' }, { lane: cvAdj(tl, r), dmg, kind: 'spit' }); }
        else I.label = 'RELOAD';
    }
}
const BOSS_P1 = ['barrels', 'spray', 'escort', 'charge'], BOSS_P2 = ['spray', 'barrels', 'charge', 'escort'];
function cvBossIntent(b) {
    const cv = g.cv, tl = b.tl == null ? cv.lane : b.tl, r = b.rnd == null ? 0.5 : b.rnd, p2 = !!b.phase2;
    const I = b.int = { dr: 0, dl: 0, hits: [], atk: null, atkRow: null, label: '' };
    if (b.stun > 0) { I.label = 'EXHAUSTED'; return; }
    if (b.recover) { I.atk = 'retreat'; I.dr = 3; I.label = 'RETREAT'; return; }
    const pat = (p2 ? BOSS_P2 : BOSS_P1)[(b.bt || 0) % 4]; I.atk = pat;
    I.dr = b.row > 5 ? -1 : 0;
    if (pat === 'charge') {
        const wl = clamp(tl - (r < 0.5 ? 0 : 1), -1, 0); I.dl = wl - b.lane; I.dr = 2 - b.row; I.label = 'CHARGE'; I.atkRow = 4;
        I.hits.push({ lane: wl, dmg: p2 ? 22 : 18, kind: 'charge' }, { lane: wl + 1, dmg: p2 ? 22 : 18, kind: 'charge' });
    } else if (pat === 'spray') {
        const safe = Math.floor(r * 3) - 1; I.safe = safe; I.label = 'SPRAY';
        for (const l of [-1, 0, 1]) if (l !== safe) I.hits.push({ lane: l, dmg: p2 ? 17 : 14, kind: 'spray' });
    } else if (pat === 'barrels') {
        I.label = 'BARRELS'; I.lanes = p2 ? [-1, 0, 1] : [tl, cvAdj(tl, r)];
    } else { I.label = 'ESCORTS'; if (r < 0.4) I.dl = b.lane === -1 ? 1 : -1; }
}
function cvPlan() {
    const cv = g.cv;
    for (const c of cv.cars) if (!c.dying) { c.rnd = Math.random(); c.tl = cv.lane; }
    cvReplan();
}
function cvReplan() { for (const c of g.cv.cars) if (!c.dying) cvIntent(c); }
function cvThreats() {   // lane -> { n: how many attacks, d: total damage } that will land this enemy phase
    const hot = {};
    for (const c of g.cv.cars) { if (c.dying || !c.int || (c.stun > 0 && c.type !== 'barrel')) continue; for (const h of c.int.hits || []) { const e = hot[h.lane] || (hot[h.lane] = { n: 0, d: 0 }); e.n++; e.d += h.dmg; } }
    return hot;
}
function cvDesc(c) {
    const T = CV_T[c.type], I = c.int || {};
    let d = T.name + '  ·  HP ' + c.hp + '/' + c.max + (c.armor ? '  ·  armored' : '') + (c.stun ? '  ·  stuck' : '');
    if (c.type === 'racer') d += '  ·  ' + ({ run: 'revving up', lunge: 'LUNGING', flee: 'fleeing' })[c.mode || 'run'];
    return d + '  ·  ' + (T.note || '');
}
// ---- player actions ----
const cvReady = () => g.cv && g.cv.phase === 'plan' && g.cv.busy <= 0 && !g.cv.done && mode === 'play';
function cvRefund(n, why) {
    const cv = g.cv; if (cv.ap >= cvApMax() + 1) return;
    cv.ap = Math.min(cvApMax() + 1, cv.ap + n); addText(g, 70, 470, '+' + n + ' MOVE', '#ffd32a', 11); if (why) cvMsg(why, '#ffd32a');
}
function cvSteer(d) {
    const cv = g.cv; if (!cvReady()) return;
    const nl = cv.lane + d; if (nl < -1 || nl > 1) { cvMsg('Edge of the road!'); return; }
    const free = cv.freeSteer && !cv.steered;
    if (!free && cv.ap < 1) { cvMsg('Out of moves: end the turn'); return; }
    if (!free) cv.ap--; cv.steered = true; cv.lane = nl; cv.busy = 8; sfx('click');
    for (let i = 0; i < 6; i++) g.fx.push({ kind: 'p', x: 180 + (cv.px) * 105 + rand(-14, 14), y: 448, vx: -d * rand(0.5, 2), vy: rand(-1, 0.3), color: '#e8d4aa', t: 22, max: 22, sz: rand(2, 4) });
}
function cvFirst(lane, maxRow) {
    let best = null;
    for (const c of g.cv.cars) if (!c.dying && c.row <= maxRow && cvCovers(c, lane) && (!best || c.row < best.row)) best = c;
    return best;
}
function cvHit(c, dmg, src) {
    if (!c || c.dying) return false;
    const T = CV_T[c.type], pos = cvScr(cvPos(c.ar, c.al, c.big).x, cvPos(c.ar, c.al, c.big).y - 40);
    c.flash = 8;
    if (c.armor > 0 && src === 'hoop') { c.armor--; addText(g, pos.x, pos.y, 'ARMOR OFF', '#dfe6e9', 11); sfx('shield'); addRing(g, pos.x, pos.y + 20, 30, '#dfe6e9', 14); cvReplan(); return false; }
    c.hp -= dmg; addText(g, pos.x, pos.y, '-' + dmg, '#ffd32a', 14); sfx('hit'); g.cv.shake = Math.max(g.cv.shake, 5);
    for (let i = 0; i < 8; i++) g.fx.push({ kind: 'p', x: pos.x, y: pos.y + 20, vx: rand(-3, 3), vy: rand(-3, 1), color: pick(['#ffd32a', '#fff3a0', '#ff9f43']), t: 18, max: 18, sz: rand(2, 4) });
    if (c.hp <= 0) { cvKill(c); return true; }
    return false;
}
function cvKill(c) {
    const cv = g.cv, T = CV_T[c.type], pos = cvScr(cvPos(c.ar, c.al, c.big).x, cvPos(c.ar, c.al, c.big).y - 30);
    c.dying = 1; c.hp = 0; c.dieT = 0; c.spin = (Math.random() < 0.5 ? -1 : 1) * rand(0.1, 0.22);
    addRing(g, pos.x, pos.y, 70, '#ff9f43', 22); confetti(g, pos.x, pos.y, T.boss ? 50 : 16);
    if (T.barrel) {   // a shot barrel goes up and hurts whatever is next to it
        addRing(g, pos.x, pos.y, 110, '#ff7a1a', 20); addText(g, pos.x, pos.y - 20, 'BOOM!', '#ff9f43', 13);
        for (const o of cv.cars) if (o !== c && !o.dying && o.type !== 'barrel' && o.type !== 'boss' && Math.abs(o.row - c.row) <= 1 && cvCovers(o, c.lane)) cvAt(8, () => cvHit(o, 2, 'blast'));
        if (cv.bossRef && !cv.bossRef.dying && Math.abs(cv.bossRef.row - c.row) <= 1 && cvCovers(cv.bossRef, c.lane)) cvAt(8, () => cvHit(cv.bossRef, 2, 'blast'));
    }
    if (!T.barrel) {
        g.kills++; g.combo = (g.combo || 0) + 1; g.comboT = 300; g.maxCombo = Math.max(g.maxCombo || 0, g.combo);
        g.score += Math.round(T.score * (1 + Math.min(1, g.combo * 0.04)));
        gainGold(g, T.gold); gainXp(g, T.xp);
        if (T.lantern) { cv.caught++; heal(g, 5); toast('LANTERNS RECOVERED', cv.caught + (cv.isBoss ? '' : '/' + cv.lanterns), '#ffd32a', 90); }
        addText(g, pos.x, pos.y - 16, '+' + T.gold + ' coins', '#f1c40f', 11);
        if (g.S.cvRefund && !cv.refunded && !T.boss) { cv.refunded = true; cvRefund(1); }
    }
    if (T.boss) { g.bossKills = (g.bossKills || 0) + 1; for (const o of cv.cars) if (o !== c && !o.dying) o.dying = 1; bossFallToast({ type: 'truck' }); }
    sfx(T.boss ? 'boss' : 'coin');
    cvReplan();
}
function cvRicochet(from, left, dmg) {
    const cv = g.cv; if (left <= 0) return;
    let best = null, bd = 99;
    for (const c of cv.cars) { if (c.dying || c === from) continue; const d = Math.abs(c.lane - from.lane) + Math.abs(c.row - from.row) * 0.6; if (Math.abs(c.lane - from.lane) <= 1 && Math.abs(c.row - from.row) <= 2 && d < bd) { bd = d; best = c; } }
    if (!best) return;
    cv.fx.push({ k: 'hoop', l0: from.al, r0: from.ar, l1: best.al, r1: best.ar, t: 0, max: 12, big0: from.big, big1: best.big });
    cvAt(12, () => { const dead = cvHit(best, 1, 'hoop'); if (dead) cvRicochet(best, left - 1, 1); });
}
function cvHoop() {
    const cv = g.cv; if (!cvReady()) return;
    if (cv.ap < 1) { cvMsg('Out of moves: end the turn'); return; }
    const tgt = cvFirst(cv.lane, cvReach());
    if (!tgt) { cvMsg('Nothing in your lane! Steer or ram.'); return; }
    cv.ap--; cv.busy = 26; sfx('shoot');
    cv.fx.push({ k: 'hoop', l0: cv.px, r0: 0, l1: tgt.al, r1: tgt.ar, t: 0, max: 14, big1: tgt.big });
    cvAt(14, () => { const dead = cvHit(tgt, cvHoopDmg(), 'hoop'); if (dead) cvRicochet(tgt, 1 + (g.S.cvBounce || 0), 1); });
}
function cvRam() {
    const cv = g.cv; if (!cvReady()) return;
    if (cv.ap < 2) { cvMsg('Ram needs 2 moves', '#ff7675'); return; }
    const tgt = cvFirst(cv.lane, cvRamReach());
    if (!tgt) { cvMsg('Nothing in ram range!'); return; }
    cv.ap -= 2; cv.busy = 40; cv.nitro = 26; cv.kick = 1; sfx('power');
    cvAt(18, () => {
        const dmg = cvRamDmg() + (tgt.big ? 1 : 0), isBar = tgt.type === 'barrel';
        tgt.armor = 0; cvHit(tgt, dmg, 'ram'); g.cv.shake = 12;
        if (tgt.dying) { if (!isBar) cvRefund(1, 'Ram kill: move refunded!'); return; }
        tgt.stun = Math.max(tgt.stun, 1);
        if (!tgt.big) {   // spun sideways, bumping whoever is there, and reeled in two rows
            const opts = [-1, 1].map(d => tgt.lane + d).filter(l => l >= -1 && l <= 1);
            const l2 = opts.length ? pick(opts) : tgt.lane, hit = g.cv.cars.find(o => o !== tgt && !o.dying && o.lane === l2 && Math.abs(o.row - tgt.row) <= 1 && !o.big);
            if (hit) { cvHit(hit, 1, 'ram'); addText(g, 180, 230, 'PILE-UP!', '#ff7675', 16); }
            else if (!cvOcc(l2, tgt.row, tgt)) tgt.lane = l2;
        }
        let nr = Math.max(1, tgt.row - 2); while (nr < tgt.row && cvOcc(tgt.lane, nr, tgt, tgt.big)) nr++; tgt.row = nr;
        if (tgt.type === 'racer') tgt.mode = 'run';
        cvReplan();
    });
}
function cvSalsaTool() {
    const cv = g.cv; if (!cvReady()) return;
    if (cv.salsa < 1) { cvMsg('Out of salsa jars!', '#ff7675'); return; }
    if (cv.ap < 1) { cvMsg('Out of moves: end the turn'); return; }
    cv.tool = cv.tool === 'salsa' ? null : 'salsa';
    if (cv.tool) cvMsg('Tap a car to splat it with salsa');
}
function cvSalsaAt(c) {
    const cv = g.cv; if (!cvReady() || cv.tool !== 'salsa') return;
    cv.tool = null; cv.salsa--; cv.ap--; cv.busy = 28; sfx('power');
    const p0 = cvPos(c.ar, c.al, c.big), a = cvScr(p0.x, p0.y);
    cv.fx.push({ k: 'jar', l1: c.al, r1: c.ar, big1: c.big, t: 0, max: 16 });
    cvAt(16, () => {
        c.stun = Math.max(c.stun, 1);
        if (!c.big) cv.slicks.push({ lane: c.lane, row: c.row, t: CV.SALSA_T }); else for (const l of [c.lane, c.lane + 1]) cv.slicks.push({ lane: l, row: c.row, t: CV.SALSA_T });
        addText(g, a.x, a.y - 50, 'STUCK!', '#ff7675', 14); addRing(g, a.x, a.y, 44, '#e74c3c', 16); confetti(g, a.x, a.y - 20, 8);
        cvReplan();
    });
}
// ---- the enemy phase ----
function cvHurt(dmg) {   // every strike counts: the turn-based hits must not be swallowed by the real-time invulnerability window
    const p = g.player; p.iframes = 0; hurtPlayer(g, dmg, null); g.cv.shake = Math.max(g.cv.shake, 9);
}
function cvMove(c, I) {
    const cv = g.cv, T = CV_T[c.type], lim = T.lantern ? CV.MAXR + 1 : CV.MAXR - 1;
    if (I.dl) { const nl = c.lane + I.dl; if (nl >= -1 && nl <= 1 && !cvOcc(nl, c.row, c)) c.lane = nl; }
    const dir = Math.sign(I.dr);
    for (let s = 0; s < Math.abs(I.dr); s++) {
        const nr = c.row + dir; if (nr < 1 || nr > lim || cvOcc(c.lane, nr, c)) break;
        c.row = nr;
        const sl = cv.slicks.find(q => q.lane === c.lane && q.row === c.row);
        if (sl) { c.stun = 1; sl.t--; const q = cvScr(cvPos(c.row, c.lane).x, cvPos(c.row, c.lane).y - 50); cvAt(4, () => addText(g, q.x, q.y, 'SPIN OUT!', '#ff9f43', 12)); break; }
    }
}
function cvTelegraph(c, lanes, kind) {
    const cv = g.cv;
    if (kind === 'spit') { for (const lane of lanes) cv.fx.push({ k: 'spit', l0: c.al, r0: c.ar, lane, t: 0, max: 18 }); sfx('ebullet'); }
    else { cv.fx.push({ k: 'spray', lanes, t: 0, max: 20 }); sfx(kind === 'spray' ? 'ebullet' : 'hit'); }
}
function cvResolveStrike(c, lanes, dmg, kind) {
    const cv = g.cv; if (cv.done || mode !== 'play') return;
    const hit = lanes.includes(cv.lane), x = 180 + cv.px * 100;
    if (hit) { cvHurt(dmg); addText(g, x, 400, CV_HITTXT[kind] || 'HIT!', '#ff7675', 14); }
    else { addText(g, x, 410, 'DODGED!', '#7bed9f', 12); g.score += 15; }
    if (kind === 'ram' && !c.dying) { c.dying = 1; c.dieT = 0; c.hp = 0; if (hit) c.spin = (Math.random() < 0.5 ? -1 : 1) * 0.2; else { c.gone = 1; c.spin = 0; } }   // a scout that rams you is wrecked; one that misses roars past
}
function cvBarrelBoom(c) {
    const cv = g.cv; if (c.dying || cv.done || mode !== 'play') return;
    const hitMe = cv.lane === c.lane; c.dying = 1; c.hp = 0; c.dieT = 0; c.spin = 0.15; sfx('hit');
    const pp = cvScr(cvPos(0.4, c.lane).x, 430); addRing(g, pp.x, pp.y, 60, '#ff7a1a', 18); confetti(g, pp.x, pp.y, 10);
    if (hitMe) { cvHurt(CV_T.barrel.dmg); addText(g, 180 + cv.px * 100, 400, 'KABOOM!', '#ff7675', 14); } else { addText(g, 180 + cv.px * 100, 410, 'DODGED!', '#7bed9f', 12); g.score += 15; }
}
function cvEndTurn() {
    const cv = g.cv; if (!cvReady()) return;
    cv.phase = 'enemy'; cv.tool = null; cv.ap = 0; cv.busy = 0; sfx('click');
    cvReplan();
    let t = 6;
    const order = cv.cars.filter(c => !c.dying).sort((a, b) => a.row - b.row);
    for (const c of order) {
        if (c.dying) continue;
        const T = CV_T[c.type], I = c.int || { dr: 0, dl: 0, hits: [] };
        if (c.type === 'boss') { cvAt(t, () => cvBossAct(c)); t += 44; continue; }
        if (T.barrel) {
            c.row--;
            if (c.row <= 0) { const at = t; t += 8; cvAt(at + 6, () => cvBarrelBoom(c)); }
            continue;
        }
        if (c.stun > 0) { c.stun--; continue; }
        const lane0 = c.lane;
        cvMove(c, I);
        if (c.stun > 0) continue;   // slid onto salsa: spun out, no attack
        if (T.role === 'lunge') { if ((c.mode || 'run') === 'run' && c.row <= 4) c.mode = 'lunge'; else if (c.mode === 'flee') c.mode = 'run'; }
        if (I.atk === 'toss') {
            const lane = I.tossLane;
            if (!cvOcc(lane, 2, null)) { const bar = cvMake('barrel', lane, 2); bar.ar = c.ar; bar.al = c.al; sfx('ebullet'); const q = cvScr(cvPos(c.ar, c.al).x, cvPos(c.ar, c.al).y - 60); cvAt(t, () => addText(g, q.x, q.y, 'BARREL!', '#ffb142', 12)); }
        } else if (I.atk && I.hits.length && (I.atkRow == null || c.row <= I.atkRow)) {
            const shift = I.atk === 'spit' ? 0 : c.lane - (lane0 + (I.dl || 0)), lanes = [...new Set(I.hits.map(h => clamp(h.lane + shift, -1, 1)))], kind = I.hits[0].kind, dmg = I.hits[0].dmg, at = t;
            t += 22;
            cvAt(at, () => { if (!c.dying || kind === 'ram') cvTelegraph(c, lanes, kind); });
            cvAt(at + 16, () => cvResolveStrike(c, lanes, dmg, kind));
            if (kind === 'lunge') c.mode = 'flee';
        }
        if (c.row > CV.MAXR) {
            c.escaped = 1;
            if (T.lantern) {
                cv.escaped++; cvAt(t + 10, () => { cvHurt(12); toast('LANTERNS STOLEN!', 'A truck got away', '#ff7675', 110); addText(g, 180, 200, 'ESCAPED!', '#ff4757', 18); });
            }
            c.dying = 1; c.dieT = 0; c.spin = 0; c.gone = 1;
        }
    }
    cv.slicks = cv.slicks.filter(s => s.t > 0);
    cvAt(t + 36, cvNewTurn);
    cv.phase = 'enemy';
}
function cvBossAct(b) {
    const cv = g.cv, I = b.int || { dr: 0, hits: [] }; if (b.dying || cv.done) return;
    if (b.stun > 0) { b.stun--; if (b.stun <= 0) b.recover = true; addText(g, 180, 250, 'EXHAUSTED', '#ffe9a0', 13); return; }
    const p2 = !!b.phase2, atk = I.atk || 'none';
    if (I.dl) { const nl = b.lane + I.dl; if (nl >= -1 && nl <= 0 && !cvOcc(nl, b.row, b, true)) b.lane = nl; }
    const nr = clamp(b.row + I.dr, 2, 7); let r = b.row; const dir = Math.sign(nr - r);
    while (r !== nr && !cvOcc(b.lane, r + dir, b, true)) r += dir; b.row = r;
    const pos = cvScr(cvPos(b.ar, b.al, true).x, cvPos(b.ar, b.al, true).y - 50);
    if (atk === 'retreat') { b.recover = false; addText(g, pos.x, pos.y, 'BACKING OFF', '#a29bfe', 12); return; }
    b.bt = (b.bt || 0) + 1;
    if (atk === 'barrels') {
        addText(g, pos.x, pos.y, 'BARRELS!', '#ffb142', 13); sfx('ebullet');
        for (const lane of I.lanes || []) if (!cvOcc(lane, 2, null)) { const bar = cvMake('barrel', lane, 2); bar.ar = b.ar; bar.al = lane; cv.fx.push({ k: 'bar', t: 0, max: 12 }); }
    } else if (atk === 'spray') {
        const lanes = (I.hits || []).map(h => h.lane), dmg = p2 ? 17 : 14;
        addText(g, pos.x, pos.y, 'SALSA SPRAY!', '#ff7675', 13); sfx('ebullet');
        cv.fx.push({ k: 'spray', lanes, t: 0, max: 22 });
        cvAt(20, () => cvResolveStrike(b, lanes, dmg, 'spray'));
    } else if (atk === 'charge') {
        const lanes = [b.lane, b.lane + 1], dmg = p2 ? 22 : 18;
        addText(g, pos.x, pos.y, 'CHARGE!', '#ff4757', 15); cv.shake = 10; cv.fx.push({ k: 'spray', lanes, t: 0, max: 20 });
        if (b.row <= 4) cvAt(16, () => cvResolveStrike(b, lanes, dmg, 'charge'));
        if (p2) b.recover = true; else b.stun = 1;   // the exhausted boss is the opening: hit him now
    } else if (atk === 'escort') {
        addText(g, pos.x, pos.y, 'ESCORTS!', '#a29bfe', 13);
        const types = p2 ? ['racer', 'spitter'] : ['scout', 'spitter']; let n = 0;
        for (const l of [-1, 1, 0]) { if (n >= 2 || cv.cars.filter(c => !c.dying && c.type !== 'boss' && c.type !== 'barrel').length >= 4) break; if (!cvOcc(l, 7, null)) { cvMake(pick(types), l, 7); n++; } }
    }
}
function cvNewTurn() {
    const cv = g.cv; cv.turn++; cv.phase = 'plan'; cv.ap = cvApMax(); cv.steered = false; cv.refunded = false; cv.busy = 14;
    cv.cars = cv.cars.filter(c => !c.dying || c.dieT < 50);
    if (cv.isBoss) {
        const b = cv.bossRef;
        if (b && !b.dying && !b.phase2 && b.hp <= b.max / 2) { b.phase2 = true; b.bt = 0; toast('PHASE 2', 'The truck is furious!', '#ff4757', 140); cv.shake = 14; sfx('boss'); }
    }
    cvCheck();
    if (cv.done) return;
    if (!cv.isBoss && cv.amb && cv.turn % cv.amb === 0) cvAmbush();
    cvPlan();
}
function cvCheck() {
    const cv = g.cv; if (cv.done) return;
    const objs = cv.cars.filter(c => !c.dying && (CV_T[c.type].lantern || c.type === 'boss'));
    if (!objs.length) {
        if (!cv.isBoss && cv.wave < cv.waves.length) { cvSpawnWave(); return; }
        cv.done = true; cv.q = []; cv.phase = 'win';
        for (const c of cv.cars) if (!c.dying) { c.dying = 1; c.dieT = 0; c.spin = 0; c.gone = 1; }
        stageDone();
    }
}
function updateConvoy() {
    const cv = g.cv, p = g.player;
    commonTick(); cv.t++;
    // smooth motion of everything toward its logical place
    cv.px += (cv.lane - cv.px) * 0.22;
    cv.spd += ((cv.nitro > 0 ? 9 : cv.phase === 'enemy' ? 4.6 : 3.2) - cv.spd) * 0.12; cv.scroll += cv.spd;
    if (cv.nitro > 0) cv.nitro--;
    if (cv.shake > 0) cv.shake *= 0.9;
    for (const c of cv.cars) {
        c.al += ((c.big ? c.lane : c.lane) - c.al) * 0.2; c.ar += (c.row - c.ar) * (c.type === 'barrel' ? 0.2 : 0.14);
        if (c.flash > 0) c.flash--;
        if (c.dying) {
            c.dieT++;
            if (c.gone) { c.ar += 0.35; c.alpha = Math.max(0, 1 - c.dieT / 30); }
            else { c.rot += (c.spin || 0.15); c.ox += (c.spin > 0 ? 1 : -1) * 3; c.alpha = Math.max(0, 1 - c.dieT / 45); if (c.dieT % 3 === 0) { const q = cvScr(cvPos(c.ar, c.al, c.big).x, cvPos(c.ar, c.al, c.big).y - 20); g.fx.push({ kind: 'p', x: q.x, y: q.y, vx: rand(-1, 1), vy: rand(-2, -0.5), color: pick(['#555', '#888', '#ff9f43']), t: 24, max: 24, sz: rand(3, 6) }); } }
        }
    }
    if (g.clearT > 0) { commonFx(); for (let i = cv.fx.length - 1; i >= 0; i--) if (++cv.fx[i].t > cv.fx[i].max) cv.fx.splice(i, 1); if (--g.clearT <= 0) showClear(); return; }
    if (cv.busy > 0) cv.busy--;
    if (cv.msgT > 0) cv.msgT--;
    for (let i = cv.q.length - 1; i >= 0; i--) { const e = cv.q[i]; if (--e.t <= 0) { cv.q.splice(i, 1); e.fn(); if (g.cv !== cv) return; } }
    for (let i = cv.fx.length - 1; i >= 0; i--) if (++cv.fx[i].t > cv.fx[i].max) cv.fx.splice(i, 1);
    if (cv.phase === 'plan' && !cv.done && cv.busy <= 0 && cv.ap <= 0 && !cv.q.length) { cv.busy = 30; cvAt(26, () => { if (g.cv === cv && cv.phase === 'plan') { cv.busy = 0; cvEndTurn(); } }); }
    if (cv.phase === 'plan' && !cv.done && cv.busy <= 0 && cvLive().length === 0 && !cv.q.length) cvCheck();
    commonFx();
    p.x = W / 2; p.y = 442;
}
// ---------- drawing ----------
function cvIntentTag(c, x, y, s) {
    const I = c.int; if (!I || c.dying) return;
    ctx.save(); ctx.translate(x, y); ctx.textAlign = 'center'; ctx.font = 'bold 9px system-ui, sans-serif';
    let txt;
    if (c.stun > 0 && !I.label) txt = 'STUCK';
    else {
        const arrows = I.dr > 0 ? '▲'.repeat(Math.min(3, I.dr)) : I.dr < 0 ? '▼'.repeat(Math.min(3, -I.dr)) : '';
        txt = (I.dl < 0 ? '◄ ' : '') + (I.label || arrows || '■') + (I.dl > 0 ? ' ►' : '');
    }
    const hot = I.hits && I.hits.length > 0 && !(c.stun > 0 && c.type !== 'barrel'), w = Math.max(34, ctx.measureText(txt).width + 14);
    ctx.fillStyle = hot ? 'rgba(120,10,20,0.85)' : 'rgba(8,6,20,0.7)'; roundRect(-w / 2, -9, w, 14, 7); ctx.fill();
    ctx.fillStyle = c.stun > 0 && !I.label ? '#ff9f43' : hot ? '#ffb3b3' : '#9be3ff'; ctx.fillText(txt, 0, 1.5);
    ctx.restore();
}
function cvLaneQuad(lane, r0, r1, col, a) {
    const A = cvPos(r0, lane), B = cvPos(r1, lane), wA = CV.SP * PR.hw * A.u * 0.46, wB = CV.SP * PR.hw * B.u * 0.46;
    ctx.fillStyle = col; ctx.globalAlpha = a; ctx.beginPath(); ctx.moveTo(A.x - wA, A.y); ctx.lineTo(A.x + wA, A.y); ctx.lineTo(B.x + wB, B.y); ctx.lineTo(B.x - wB, B.y); ctx.closePath(); ctx.fill(); ctx.globalAlpha = 1;
}
function cvDrawFx(cv, f) {
    const k = f.t / f.max;
    if (f.k === 'hoop') {
        const r = f.r0 + (f.r1 - f.r0) * k, l = f.l0 + (f.l1 - f.l0) * k, P = cvPos(r, l, k > 0.5 && f.big1), s = P.u;
        ctx.save(); ctx.translate(P.x, P.y - 30 * s); ctx.scale(1, 0.55);
        for (let i = 0; i < 3; i++) { ctx.strokeStyle = i === 0 ? '#2ecc71' : i === 1 ? '#f1c40f' : '#ff4fa3'; ctx.lineWidth = Math.max(1.6, 6 * s) - i * Math.max(0.4, s); ctx.beginPath(); ctx.arc(0, 0, Math.max(5, 30 * s) - i * 1.2, cv.t * 0.5 + i, cv.t * 0.5 + i + TAU * 0.9); ctx.stroke(); }
        ctx.restore(); drawGlow(P.x, P.y - 30 * s, 26 * s + 8, '#9bff9b', 0.6);
    } else if (f.k === 'jar') {
        const r = f.r1 * k, P = cvPos(f.r1 * k + 0.0, f.l1 * k, false), arc = Math.sin(k * Math.PI) * 60 * (P.u + 0.3);
        const E = cvPos(f.r1, f.l1, f.big1); const x = 180 + (E.x - 180) * k, y = 440 + (E.y - 40 * E.u - 440) * k - arc;
        ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(x, y, 7 - 3 * k, 0, TAU); ctx.fill(); ctx.fillStyle = '#f1c40f'; ctx.fillRect(x - 2, y - 9 + 3 * k, 4, 3);
    } else if (f.k === 'spit') {
        const P0 = cvPos(f.r0, f.l0), P1 = cvPos(0.2, f.lane), x = P0.x + (P1.x - P0.x) * k, y = P0.y + (P1.y - P0.y) * k - Math.sin(k * Math.PI) * 26, s = 0.3 + 0.9 * k;
        ctx.fillStyle = '#ff9f43'; ctx.beginPath(); ctx.arc(x, y - 24 * s, 7 * s, 0, TAU); ctx.fill(); drawGlow(x, y - 24 * s, 18 * s, '#ff7a1a', 0.7);
    } else if (f.k === 'spray') {
        for (const l of f.lanes) cvLaneQuad(l, 0, 5, '#ff4a2a', 0.45 * Math.sin(k * Math.PI));
    }
}
function drawConvoyBack() {
    const cv = g.cv; if (!cv) return;
    const pal = PR_PAL[cv.theme] ? cv.theme : 'dawn';
    cvBend = prBend(cv.t);
    const sel = cv.tool === 'salsa';
    csPursuit(cv.t, {
        pal, y0: 0, dist: () => cv.scroll, shake: cv.shake * 0.7, lines: cv.nitro > 0 ? 1 : 0.12,
        convoy: cv.cars.filter(c => c.type !== 'barrel').map(c => ({ p: () => cvP(c.ar), lane: (c.al + (c.big ? 0.5 : 0)) * CV.SP, color: c.flash > 0 && c.flash % 2 ? '#ffffff' : c.color, truck: c.truck, id: c.id, fix: 1, nopuff: c.dying || c.stun > 0 && false, rot: c.rot, ox: c.ox, alpha: c.dying ? c.alpha : null, sc: c.sc })),
        car: { s: 0.66, x: 180 + cv.px * CV.SP * PR.hw, y: 444, nitro: cv.nitro > 0 ? Math.min(1, cv.nitro / 10) : 0.05, spin: cv.spd * 1.4, dust: false },
        after: () => {
            const pl = cv.px;
            if (cv.phase === 'plan') { cvLaneQuad(cv.lane, 0.3, cv.isBoss ? 8 : 8, '#ffd32a', 0.07 + 0.03 * Math.sin(cv.t * 0.12)); }
            for (const s of cv.slicks) { const P = cvPos(s.row, s.lane); ctx.fillStyle = 'rgba(214,48,49,' + (0.35 + 0.1 * s.t) + ')'; ctx.beginPath(); ctx.ellipse(P.x, P.y - 2, 40 * P.u, 11 * P.u, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,200,120,0.35)'; ctx.beginPath(); ctx.ellipse(P.x - 8 * P.u, P.y - 3, 14 * P.u, 4 * P.u, 0, 0, TAU); ctx.fill(); }
            // incoming hits: every lane that will be struck this turn, with how many attacks land there
            if (cv.phase === 'plan' && !cv.done) {
                const hot = cvThreats();
                for (const l in hot) {
                    const e = hot[l], pulse = 0.14 + Math.min(0.18, e.d / 80) + 0.1 * Math.sin(cv.t * 0.3); cvLaneQuad(+l, 0, 5.5, '#ff2a2a', pulse);
                    const P = cvPos(0.6, +l); ctx.fillStyle = '#ff4757'; ctx.font = '900 ' + Math.round(22 * P.u + 8) + 'px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('!'.repeat(Math.min(3, e.n)), P.x, P.y - 10 * P.u); ctx.textAlign = 'left';
                }
            }
            // barrels
            for (const c of cv.cars) if (c.type === 'barrel' && c.alpha > 0.05) {
                const P = cvPos(c.ar, c.al), s = P.u * 1.1;
                ctx.save(); ctx.globalAlpha = c.alpha; ctx.translate(P.x + c.ox * P.u, P.y); ctx.rotate(c.rot); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(0, 0, 30 * s, 6 * s, 0, 0, TAU); ctx.fill();
                ctx.fillStyle = lg(-24 * s, 0, 24 * s, 0, [[0, '#5a2e14'], [0.4, '#b0693a'], [1, '#4a2410']]); roundRect(-24 * s, -52 * s, 48 * s, 52 * s, 9 * s); ctx.fill();
                ctx.fillStyle = '#d63031'; ctx.fillRect(-24 * s, -40 * s, 48 * s, 7 * s); ctx.fillRect(-24 * s, -16 * s, 48 * s, 7 * s); ctx.fillStyle = '#ffe9a0'; ctx.font = '900 ' + Math.round(14 * s) + 'px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('🌶', 0, -22 * s); ctx.textAlign = 'left'; ctx.restore();
                if (!c.dying && cv.phase === 'plan') cvIntentTag(c, P.x, P.y + 12 * Math.max(0.5, s * 1.1), s);
                if (sel && !c.dying) { ctx.strokeStyle = '#ff7675'; ctx.lineWidth = 2; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.ellipse(P.x, P.y - 24 * s, 34 * s + 4, 30 * s + 4, 0, 0, TAU); ctx.stroke(); ctx.setLineDash([]); }
            }
            for (const f of cv.fx) cvDrawFx(cv, f);
            // car overlays: lantern marker, hp pips, intention tag
            const list = cv.cars.filter(c => !c.dying && c.type !== 'barrel').sort((a, b) => b.row - a.row);
            for (const c of list) {
                const P = cvPos(c.ar, c.al, c.big), s = P.u * (c.sc || 1), top = P.y - (c.truck ? 98 : 94) * s, T = CV_T[c.type];
                if (T.lantern) { drawGlow(P.x, top - 8 * s, 30 * s + 8, '#ffd32a', 0.55 + 0.2 * Math.sin(cv.t * 0.2)); ctx.fillStyle = '#ffd32a'; ctx.font = '900 ' + Math.round(11 + 12 * s) + 'px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('★', P.x, top - 2 * s - 2); ctx.textAlign = 'left'; }
                const n = c.max, w = Math.max(5, 9 * s * 1.3), x0 = P.x - (n * (w + 2)) / 2 + 1, yy = top - (T.lantern ? 18 * s + 6 : 4);
                if (c.big) { const bw = 120 * s * 0.9; ctx.fillStyle = 'rgba(0,0,0,0.6)'; roundRect(P.x - bw / 2, yy - 4, bw, 7, 3); ctx.fill(); ctx.fillStyle = '#ff4757'; roundRect(P.x - bw / 2 + 1, yy - 3, Math.max(2, (bw - 2) * c.hp / c.max), 5, 2); ctx.fill(); }
                else { for (let i = 0; i < n; i++) { ctx.fillStyle = 'rgba(0,0,0,0.55)'; roundRect(x0 + i * (w + 2) - 1, yy - 1, w + 2, w * 0.7 + 2, 2); ctx.fill(); ctx.fillStyle = i < c.hp ? '#ff6b6b' : 'rgba(255,255,255,0.18)'; roundRect(x0 + i * (w + 2), yy, w, w * 0.7, 1.5); ctx.fill(); } }
                if (c.armor > 0) { ctx.fillStyle = '#b2bec3'; ctx.strokeStyle = '#2d3436'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(P.x + n * (w + 2) / 2 + 5, yy - 3); ctx.lineTo(P.x + n * (w + 2) / 2 + 13, yy - 3); ctx.lineTo(P.x + n * (w + 2) / 2 + 13, yy + 3); ctx.lineTo(P.x + n * (w + 2) / 2 + 9, yy + 8); ctx.lineTo(P.x + n * (w + 2) / 2 + 5, yy + 3); ctx.closePath(); ctx.fill(); ctx.stroke(); }
                if (cv.phase === 'plan') cvIntentTag(c, P.x, P.y + 12 * Math.max(0.5, s * 1.4), s);
                if (sel) { ctx.strokeStyle = '#ff7675'; ctx.lineWidth = 2.5; ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.ellipse(P.x, P.y - 40 * s, 58 * s + 6, 46 * s + 6, 0, 0, TAU); ctx.stroke(); ctx.setLineDash([]); }
            }
        },
    });
    // tap targets for cars (screen space, after the picture's 3% zoom)
    const list = cv.cars.filter(c => !c.dying).sort((a, b) => b.row - a.row);
    for (const c of list) {
        const P = cvPos(c.ar, c.al, c.big), q = cvScr(P.x, P.y - 40 * P.u * (c.sc || 1)), s = P.u * (c.sc || 1) * 1.03, hw = Math.max(18, 58 * s), hh = Math.max(20, 52 * s);
        if (mode === 'play') uiButtons.push({ x: q.x - hw, y: q.y - hh, w: hw * 2, h: hh * 2, fn: () => { if (cv.tool === 'salsa') cvSalsaAt(c); else { cv.info = cv.info === c ? null : c; sfx('click'); } } });
    }
}
function drawConvoyDeck() {
    const cv = g.cv; if (!cv) return;
    const y0 = 446, ready = cvReady(), live = mode === 'play';
    ctx.fillStyle = lg(0, y0, 0, H, [[0, '#2a1a3a'], [1, '#0e0a18']]); ctx.fillRect(0, y0, W, H - y0);
    ctx.fillStyle = '#ffd32a'; ctx.fillRect(0, y0, W, 2); ctx.fillStyle = 'rgba(255,211,42,0.25)'; ctx.fillRect(0, y0 + 2, W, 3);
    // turn + moves
    ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillStyle = '#b2bec3'; ctx.textAlign = 'left'; ctx.fillText('TURN ' + cv.turn, 12, y0 + 20);
    const max = Math.max(cvApMax(), cv.ap);
    for (let i = 0; i < max; i++) { const x = 84 + i * 22, on = i < cv.ap; ctx.fillStyle = on ? '#ffd32a' : 'rgba(255,255,255,0.12)'; ctx.beginPath(); ctx.arc(x, y0 + 16, 8, 0, TAU); ctx.fill(); if (on) { ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.beginPath(); ctx.arc(x - 2.5, y0 + 13.5, 2.5, 0, TAU); ctx.fill(); } ctx.strokeStyle = on ? '#a97c05' : 'rgba(255,255,255,0.2)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(x, y0 + 16, 8, 0, TAU); ctx.stroke(); }
    ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillStyle = '#ffe9a0'; ctx.fillText('MOVES', 84 + max * 22 + 2, y0 + 20);
    ctx.textAlign = 'right'; ctx.fillStyle = '#ff9f9f'; ctx.fillText('JARS ' + cv.salsa, W - 12, y0 + 20); ctx.textAlign = 'left';
    // message / car info line
    ctx.textAlign = 'center'; ctx.font = 'bold 12px system-ui, sans-serif';
    if (cv.msgT > 0) { ctx.fillStyle = cv.msgCol; ctx.fillText(cv.msg, W / 2, y0 + 44, W - 20); }
    else if (cv.info && !cv.info.dying) {
        ctx.fillStyle = '#9be3ff'; ctx.fillText(cvDesc(cv.info), W / 2, y0 + 44, W - 20);
    } else if (cv.phase === 'enemy') { ctx.fillStyle = '#ff9f9f'; ctx.fillText('The convoy strikes back...', W / 2, y0 + 44); }
    else {
        const nHot = Object.keys(cvThreats()).length;
        ctx.fillStyle = nHot ? '#ffb3b3' : 'rgba(255,255,255,0.6)'; ctx.font = '11px system-ui, sans-serif';
        ctx.fillText(cv.tool === 'salsa' ? 'Tap a car to splat it with salsa' : nHot ? 'RED LANES get hit this turn: steer out, kill the attacker, or stick it' : 'Gold lane = your hoop path · tap a car to read its move', W / 2, y0 + 44, W - 20);
    }
    ctx.textAlign = 'left';
    // tool buttons
    const by = y0 + 58, bh = 66, can = (n) => ready && cv.ap >= n;
    const tool = (x, w, label, sub, col, fn, on, sel, icon) => {
        if (live) uiButtons.push({ x, y: by, w, h: bh, fn });
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; roundRect(x, by + 3, w, bh, 12); ctx.fill();
        const gr = ctx.createLinearGradient(0, by, 0, by + bh); gr.addColorStop(0, on ? shade(col, 0.2) : '#3a3a48'); gr.addColorStop(1, on ? col : '#26262f'); ctx.fillStyle = gr; roundRect(x, by, w, bh, 12); ctx.fill();
        ctx.strokeStyle = sel ? '#fff' : on ? 'rgba(255,255,255,0.35)' : 'rgba(255,255,255,0.1)'; ctx.lineWidth = sel ? 3 : 1.2; roundRect(x, by, w, bh, 12); ctx.stroke();
        if (on) { ctx.fillStyle = 'rgba(255,255,255,0.14)'; roundRect(x + 2, by + 2, w - 4, bh / 2 - 2, 10); ctx.fill(); }
        ctx.save(); ctx.translate(x + w / 2, by + 24); ctx.globalAlpha = on ? 1 : 0.45; icon(); ctx.restore();
        ctx.textAlign = 'center'; ctx.fillStyle = on ? '#fff' : '#8a8a96'; ctx.font = '900 12px system-ui, sans-serif'; ctx.fillText(label, x + w / 2, by + 48); ctx.font = 'bold 9px system-ui, sans-serif'; ctx.fillStyle = on ? 'rgba(255,255,255,0.85)' : '#6a6a76'; ctx.fillText(sub, x + w / 2, by + 60); ctx.textAlign = 'left';
    };
    tool(10, 44, '◄', cv.freeSteer && !cv.steered ? 'free' : '1 move', '#576574', () => cvSteer(-1), can(cv.freeSteer && !cv.steered ? 0 : 1) && cv.lane > -1, false, () => { ctx.fillStyle = '#fff'; ctx.font = '900 22px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('◄', 0, 7); });
    tool(60, 76, 'HOOP', '1 move', '#27ae60', cvHoop, can(1), false, () => { ctx.strokeStyle = '#2ecc71'; ctx.lineWidth = 4; ctx.beginPath(); ctx.ellipse(0, 0, 17, 9, 0, 0, TAU); ctx.stroke(); ctx.strokeStyle = '#f1c40f'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.ellipse(0, 0, 13, 6.5, 0, 0, TAU); ctx.stroke(); });
    tool(142, 76, 'RAM', '2 moves', '#e67e22', cvRam, can(2), false, () => { ctx.fillStyle = '#ffe066'; ctx.beginPath(); ctx.moveTo(-15, -7); ctx.lineTo(4, -7); ctx.lineTo(4, -13); ctx.lineTo(17, 0); ctx.lineTo(4, 13); ctx.lineTo(4, 7); ctx.lineTo(-15, 7); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(120,60,0,0.6)'; ctx.lineWidth = 1.5; ctx.stroke(); });
    tool(224, 76, 'SALSA', cv.salsa + ' jars', '#c0392b', cvSalsaTool, can(1) && cv.salsa > 0, cv.tool === 'salsa', () => { ctx.fillStyle = '#e74c3c'; ctx.beginPath(); ctx.arc(0, 2, 12, 0, TAU); ctx.fill(); ctx.fillStyle = '#f1c40f'; ctx.fillRect(-5, -13, 10, 5); ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.ellipse(-4, -2, 3, 5, 0, 0, TAU); ctx.fill(); });
    tool(306, 44, '►', cv.freeSteer && !cv.steered ? 'free' : '1 move', '#576574', () => cvSteer(1), can(cv.freeSteer && !cv.steered ? 0 : 1) && cv.lane < 1, false, () => { ctx.fillStyle = '#fff'; ctx.font = '900 22px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('►', 0, 7); });
    // end turn
    const ey = by + bh + 14, on = ready;
    if (live) uiButtons.push({ x: 40, y: ey, w: 280, h: 46, fn: cvEndTurn });
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; roundRect(40, ey + 3, 280, 46, 12); ctx.fill();
    const gr = ctx.createLinearGradient(0, ey, 0, ey + 46); gr.addColorStop(0, on ? (cv.ap <= 0 ? '#ffd32a' : '#ff7a6a') : '#3a3a48'); gr.addColorStop(1, on ? (cv.ap <= 0 ? '#e0a800' : '#e0443a') : '#26262f'); ctx.fillStyle = gr; roundRect(40, ey, 280, 46, 12); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.3)'; ctx.lineWidth = 1.2; roundRect(40, ey, 280, 46, 12); ctx.stroke();
    ctx.fillStyle = on ? '#fff' : '#8a8a96'; ctx.font = '900 18px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(cv.ap <= 0 && on ? 'GO! (END TURN)' : 'END TURN', W / 2, ey + 29); ctx.textAlign = 'left';
}
function convoyHud() {   // progress label for the top bar
    const cv = g.cv; if (!cv) return { frac: 0, label: '' };
    if (cv.isBoss) { const b = cv.bossRef; return { frac: b ? Math.max(0, b.hp / b.max) : 0, label: 'EL CAMIÓN SALSERO' }; }
    const total = cv.waves.reduce((n, w) => n + w.filter(s => s[0] === 'lantern').length, 0);
    return { frac: total ? cv.caught / total : 0, label: 'Lantern trucks ' + cv.caught + '/' + total + (cv.escaped ? '  ·  escaped ' + cv.escaped : '') };
}
CARDS.push(
    P('cv_ap',    'Extra Gear',          'epic',   '+1 move every turn.', g => { g.S.cvAp = (g.S.cvAp || 0) + 1; }, { max: 2 }),
    P('cv_hoop',  'Heavy Hoop',          'common', 'Hoop throws hit +1 harder.', g => { g.S.cvHoop = (g.S.cvHoop || 0) + 1; }, { max: 2 }),
    P('cv_bounce','Ricochet Hoop',       'rare',   'When the hoop takes a car out it bounces one more time.', g => { g.S.cvBounce = (g.S.cvBounce || 0) + 1; }, { max: 2 }),
    P('cv_reach', 'Long Lasso',          'common', 'Your ram reaches 1 row farther.', g => { g.S.cvReach = (g.S.cvReach || 0) + 1; }, { max: 3 }),
    P('cv_salsa', 'Salsa Cooler',        'common', '+2 salsa jars now.', g => { g.S.cvSalsa = (g.S.cvSalsa || 0) + 2; g.cv && (g.cv.salsa += 2); }, { max: 3 }),
    P('cv_free',  'Smooth Steering',     'rare',   'Your first lane change each turn is free.', g => { g.S.cvFree = 1; g.cv && (g.cv.freeSteer = true); }),
    P('cv_refund','Adrenaline Lane',     'rare',   'The first kill each turn refunds a move.', g => { g.S.cvRefund = 1; }),
);
CARD_SETS.convoy = ['cv_ap', 'cv_hoop', 'cv_bounce', 'cv_reach', 'cv_salsa', 'cv_free', 'cv_refund', 'r_bumper', 'r_plate', 'r_shell', 'r_repair', 'c_gold', 'c_study', 'c_dmg'];
