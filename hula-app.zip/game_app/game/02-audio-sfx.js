let sfxVoices = 0;   // live one-shot sfx oscillators; capped so a firefight can't pile up hundreds of nodes

// =====================================================================
//  SAMPLE LAYER: real recordings take over a sound when one is supplied; anything missing keeps its synth voice
// =====================================================================
// Drop files into samples/ and run  python3 pack_samples.py  (see README). Names:
//   sfx_<name>           sfx_shoot, sfx_hit, sfx_pop, sfx_coin, sfx_hurt, sfx_level, sfx_boss, sfx_click, sfx_buy, sfx_power,
//                        sfx_ebullet, sfx_thunder, sfx_trumpet, sfx_shield, sfx_beat, sfx_trophy
//   voice_<cue>          voice_arriba, voice_grito, voice_toro, voice_ole, voice_noprob, voice_spell, voice_frijol,
//                        voice_andale, voice_porque, voice_si      (+ crowd = cheering crowd)
//   drums                kick, snare, hat, tom, shaker, clap, cymbal, impact, riser
//   pitched instruments  guitar, bass (guitarron), trumpet, violin, accordion, pad (strings), choir, bell
//                        name them with the MIDI note they were recorded at:  trumpet@60.wav, trumpet@72.wav
//                        (the nearest one is re-pitched, so 2-4 notes per instrument is plenty)
//   round robin          add .2 .3 ...  (snare.wav, snare.2.wav, snare.3.wav); one is picked at random each hit
// Instrument, drum and effect samples are rendered from TimGM6mb.sf2 (Tim Brechbill / David Bolton, GPL-2). Personal use; check GPL-2 before distributing. Voice cues are the original synth.
/*SAMPLES_BEGIN*/
const SAMPLE_PACK = {
 "accordion@52": "data:audio/ogg;base64,@@B000@@",
 "accordion@60": "data:audio/ogg;base64,@@B001@@",
 "accordion@68": "data:audio/ogg;base64,@@B002@@",
 "accordion@76": "data:audio/ogg;base64,@@B003@@",
 "bass@40": "data:audio/ogg;base64,@@B004@@",
 "bass@46": "data:audio/ogg;base64,@@B005@@",
 "bass@52": "data:audio/ogg;base64,@@B006@@",
 "bass@58": "data:audio/ogg;base64,@@B007@@",
 "bell@72": "data:audio/ogg;base64,@@B008@@",
 "bell@84": "data:audio/ogg;base64,@@B009@@",
 "bell@96": "data:audio/ogg;base64,@@B010@@",
 "choir@55": "data:audio/ogg;base64,@@B011@@",
 "choir@64": "data:audio/ogg;base64,@@B012@@",
 "choir@73": "data:audio/ogg;base64,@@B013@@",
 "clap": "data:audio/ogg;base64,@@B014@@",
 "crowd": "data:audio/ogg;base64,@@B015@@",
 "cymbal": "data:audio/ogg;base64,@@B016@@",
 "guitar@48": "data:audio/ogg;base64,@@B017@@",
 "guitar@57": "data:audio/ogg;base64,@@B018@@",
 "guitar@66": "data:audio/ogg;base64,@@B019@@",
 "guitar@75": "data:audio/ogg;base64,@@B020@@",
 "guitar@84": "data:audio/ogg;base64,@@B021@@",
 "hat": "data:audio/ogg;base64,@@B022@@",
 "impact": "data:audio/ogg;base64,@@B023@@",
 "kick": "data:audio/ogg;base64,@@B024@@",
 "pad@45": "data:audio/ogg;base64,@@B025@@",
 "pad@54": "data:audio/ogg;base64,@@B026@@",
 "pad@63": "data:audio/ogg;base64,@@B027@@",
 "pad@72": "data:audio/ogg;base64,@@B028@@",
 "riser": "data:audio/ogg;base64,@@B029@@",
 "sfx_beat": "data:audio/ogg;base64,@@B030@@",
 "sfx_boss": "data:audio/ogg;base64,@@B031@@",
 "sfx_buy": "data:audio/ogg;base64,@@B032@@",
 "sfx_click": "data:audio/ogg;base64,@@B033@@",
 "sfx_coin": "data:audio/ogg;base64,@@B034@@",
 "sfx_level": "data:audio/ogg;base64,@@B035@@",
 "sfx_power": "data:audio/ogg;base64,@@B036@@",
 "sfx_shield": "data:audio/ogg;base64,@@B037@@",
 "sfx_trophy": "data:audio/ogg;base64,@@B038@@",
 "sfx_trumpet": "data:audio/ogg;base64,@@B039@@",
 "shaker": "data:audio/ogg;base64,@@B040@@",
 "snare": "data:audio/ogg;base64,@@B041@@",
 "tom": "data:audio/ogg;base64,@@B042@@",
 "trumpet@58": "data:audio/ogg;base64,@@B043@@",
 "trumpet@66": "data:audio/ogg;base64,@@B044@@",
 "trumpet@74": "data:audio/ogg;base64,@@B045@@",
 "trumpet@82": "data:audio/ogg;base64,@@B046@@",
 "violin@60": "data:audio/ogg;base64,@@B047@@",
 "violin@69": "data:audio/ogg;base64,@@B048@@",
 "violin@78": "data:audio/ogg;base64,@@B049@@",
 "violin@87": "data:audio/ogg;base64,@@B050@@",
 "violin@96": "data:audio/ogg;base64,@@B051@@"
};
/*SAMPLES_END*/
const SAMPLE_TRIM = {"guitar": 0.8, "bass": 1.39, "trumpet": 0.37, "violin": 0.23, "accordion": 0.27, "pad": 0.11, "choir": 0.47, "bell": 0.4, "kick": 1.5, "snare": 0.36, "hat": 0.07, "shaker": 0.26, "clap": 0.07, "cymbal": 0.14, "tom": 1.27, "impact": 1.43, "riser": 0.5, "crowd": 0.69, "sfx_coin": 0.13, "sfx_buy": 0.1, "sfx_power": 0.09, "sfx_level": 0.16, "sfx_trophy": 0.15, "sfx_trumpet": 0.05, "sfx_beat": 0.11, "sfx_boss": 0.22, "sfx_click": 0.21, "sfx_shield": 0.05, "voice_arriba": 0.82, "voice_grito": 0.95, "voice_toro": 0.68, "voice_ole": 1.06, "voice_noprob": 0.49, "voice_spell": 0.7, "voice_frijol": 0.62, "voice_andale": 0.71, "voice_porque": 0.92, "voice_si": 1.5};   // calibrated: each sample matched to the loudness of the synth voice it replaces
const SAMPLE_LOOP = {};   // optional sustain loop for held notes, seconds inside the file, e.g. { violin: [0.4, 1.2] }
const SMP = {};           // decoded buffers: name -> [{ buf, root }]
let smpReady = 0, smpTotal = 0;
const SMP_MUS = 0.25;     // level of a peak-normalised sample relative to the synth voice it replaces (tune with SAMPLE_TRIM)
const SFX_REL = { shoot: 0.35, hit: 0.4, ebullet: 0.35, pop: 0.5, coin: 0.5, click: 0.4, beat: 0.8 };
const smpHas = n => !!SMP[n];
function smpAdd(key, buf) {
    const m = /^(.+?)(?:@(\d+))?(?:\.\d+)?$/.exec(key);
    (SMP[m[1]] = SMP[m[1]] || []).push({ buf, root: m[2] ? +m[2] : null });
}
function smpLoad() {
    if (!AC || /[?&]synth\b/.test(location.search)) return;   // ?synth in the URL = original synthesized sound, for A/B listening
    const keys = Object.keys(SAMPLE_PACK); smpTotal = keys.length;
    keys.forEach(k => {
        fetch(SAMPLE_PACK[k]).then(r => r.arrayBuffer())
            .then(ab => new Promise((ok, no) => AC.decodeAudioData(ab, ok, no)))   // callback form also works on older Safari
            .then(buf => { smpAdd(k, buf); smpReady++; })
            .catch(e => { console.warn('sample failed:', k, e && e.message); });
    });
}
let smpLast = {};
function smpPick(name, midi) {
    const L = SMP[name]; if (!L) return null;
    if (midi != null && L.some(x => x.root != null)) {   // multisample: nearest recorded root, alternating between ties
        let best = Infinity, c = [];
        L.forEach(x => { const d = x.root == null ? 99 : Math.abs(x.root - midi); if (d < best) { best = d; c = [x]; } else if (d === best) c.push(x); });
        return c[(Math.random() * c.length) | 0];
    }
    if (L.length === 1) return L[0];
    let i; do { i = (Math.random() * L.length) | 0; } while (i === smpLast[name]);   // round robin: never the same take twice in a row
    smpLast[name] = i; return L[i];
}
// o: dl delay s, v gain, rate speed, midi target note, dur hold time, att attack s, pan, dest, voice (counts toward the sfx voice cap)
function smpPlay(name, o = {}) {
    if (!AC || !SMP[name]) return false;
    if (o.voice && sfxVoices >= 40) return true;
    const p = smpPick(name, o.midi); if (!p) return false;
    const t = AC.currentTime + (o.dl || 0), s = AC.createBufferSource(), g = AC.createGain();
    let rate = o.rate || 1; if (o.midi != null && p.root != null) rate *= Math.pow(2, (o.midi - p.root) / 12);
    s.buffer = p.buf; s.playbackRate.value = rate;
    const vol = (o.v == null ? 1 : o.v) * (SAMPLE_TRIM[name] || 1), att = o.att || 0.003, natural = p.buf.duration / rate;
    let end = t + natural;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + att);
    const lp = SAMPLE_LOOP[name];
    if (o.dur && lp && o.dur > natural) { s.loop = true; s.loopStart = lp[0]; s.loopEnd = lp[1]; }
    if (o.dur && (s.loop || o.dur < natural)) {   // held notes end with a short release instead of a click
        const rel = Math.min(0.08, o.dur * 0.3); end = t + o.dur;
        g.gain.setValueAtTime(vol, Math.max(t + att, end - rel)); g.gain.linearRampToValueAtTime(0.0001, end);
    }
    s.connect(g);
    let out = g;
    if (o.pan && AC.createStereoPanner) { const pn = AC.createStereoPanner(); pn.pan.value = o.pan; g.connect(pn); out = pn; }
    out.connect(o.dest || musGain);
    s.start(t); s.stop(end + 0.03);
    if (o.voice) sfxVoices++;
    s.onended = () => { if (o.voice) sfxVoices--; try { out.disconnect(); g.disconnect(); } catch (e) {} };
    return true;
}
// music helpers: v / ref keeps each call's synth dynamics (accents, humanize, crescendos) when a sample plays instead
const smpNote = (name, midi, dur, v, ref, dl, o = {}) => smpPlay(name, Object.assign({ midi, dur, v: v / ref * SMP_MUS, dl }, o));
const smpHit = (name, dl, v, ref, o = {}) => smpPlay(name, Object.assign({ v: v / ref * SMP_MUS, dl }, o));
const cue = (name, dl) => smpPlay('voice_' + name, { dl, v: 0.9, dest: speechBus() });
// debugging from the console:  HV_AUDIO.status()
window.HV_AUDIO = { status: () => ({ loaded: smpReady, of: smpTotal, sounds: Object.keys(SMP) }), has: smpHas, play: (n, o) => smpPlay(n, o) };
function tone(f, d, type = 'square', v = 0.15, slide = 0, delay = 0, dest) {
    if (!AC) return;
    if (sfxVoices >= 40 && v < 0.1) return;
    const t = AC.currentTime + delay, o = AC.createOscillator(), gn = AC.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + d);
    gn.gain.setValueAtTime(v, t); gn.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(gn); gn.connect(dest || sfxGain); o.start(t); o.stop(t + d + 0.03);
    sfxVoices++; o.onended = () => { sfxVoices--; gn.disconnect(); };
}
function sfx(n) {
    if (!AC || !OPT.sfx) return;
    const now = AC.currentTime, gap = { shoot: 0.09, hit: 0.05, pop: 0.04, coin: 0.05, ebullet: 0.1 }[n] || 0.03;
    if (lastSfx[n] && now - lastSfx[n] < gap) return;
    lastSfx[n] = now;
    const j = 0.94 + Math.random() * 0.12;   // +/-6% pitch variation
    if (smpPlay('sfx_' + n, { rate: j, v: SFX_REL[n] || 0.7, dest: sfxGain, voice: true })) return;
    switch (n) {
        case 'shoot': tone(520 * j, 0.05, 'square', 0.025, -200); break;
        case 'hit': tone(240 * j, 0.04, 'triangle', 0.05, -80); break;
        case 'pop': tone(340 * j, 0.1, 'square', 0.08, -200); tone(520 * j, 0.07, 'triangle', 0.05, 200, 0.02); break;
        case 'coin': tone(988, 0.06, 'square', 0.05); tone(1319, 0.1, 'square', 0.05, 0, 0.05); break;
        case 'hurt': tone(160, 0.25, 'sawtooth', 0.16, -100); break;
        case 'level': [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.16, 'square', 0.08, 0, i * 0.07)); break;
        case 'boss': tone(110, 0.6, 'sawtooth', 0.18, -40); tone(82, 0.7, 'square', 0.1, -30, 0.05); break;
        case 'click': tone(700, 0.05, 'square', 0.05); break;
        case 'buy': tone(660, 0.07, 'square', 0.06); tone(880, 0.12, 'square', 0.06, 0, 0.07); break;
        case 'power': [392, 523, 659].forEach((f, i) => tone(f, 0.12, 'triangle', 0.1, 0, i * 0.05)); break;
        case 'ebullet': tone(300, 0.08, 'sawtooth', 0.035, -120); break;
        case 'thunder': tone(60, 0.5, 'sawtooth', 0.12, -20); break;
        case 'trumpet': tone(392, 0.18, 'sawtooth', 0.06); tone(523, 0.22, 'sawtooth', 0.06, 0, 0.08); break;
        case 'shield': tone(900, 0.15, 'triangle', 0.08, -500); break;
        case 'beat': tone(70, 0.12, 'sine', 0.16, -20); tone(58, 0.14, 'sine', 0.12, -15, 0.15); break;
        case 'trophy': [784, 988, 1175, 1568].forEach((f, i) => tone(f, 0.14, 'triangle', 0.09, 0, i * 0.08)); break;
    }
}
// ---- Mexican son huapango suite: 6/8, ~2:15, 172 bars, key change A minor -> D minor -> A minor ----
// Band: guitarrón, vihuela, guitar solos, shaker + claps, trumpets in thirds, violins,
// plus synthesized "¡Arriba, arriba!" shouts and mariachi gritos.
let noiseBuf = null;
function note(f, dur, type, v, delay, dest, o2 = {}) {
    if (!AC) return;
    const t = AC.currentTime + delay, o = AC.createOscillator(), gn = AC.createGain(), att = o2.att || 0.005;
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (o2.slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + o2.slide), t + dur);
    gn.gain.setValueAtTime(0.0001, t);
    gn.gain.linearRampToValueAtTime(v, t + att);
    gn.gain.setValueAtTime(v, t + Math.max(att, dur * 0.6));
    gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    if (o2.vib) {   // vibrato fades in like a real player's, instead of wobbling from the first instant
        const l = AC.createOscillator(), lg = AC.createGain();
        l.frequency.value = 5.2 + Math.random() * 0.6; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(14, t + Math.min(dur * 0.6, 0.28));
        l.connect(lg); lg.connect(o.detune);
        l.start(t); l.stop(t + dur + 0.03);
    }
    // timbre: a low-pass whose cutoff follows the note. [from, to, seconds] are multiples of the pitch. Raw sawtooth in the band is tamed by default.
    let lp = o2.lp;
    if (!lp && dest === musGain && type === 'sawtooth') lp = [7, 7, 0];
    let src = o;
    if (lp) {
        const fl = AC.createBiquadFilter(), top = x => Math.max(80, Math.min(15000, f * x));
        fl.type = 'lowpass'; fl.Q.value = 0.6; fl.frequency.setValueAtTime(top(lp[0]), t);
        if (lp[1] !== lp[0]) fl.frequency.exponentialRampToValueAtTime(top(lp[1]), t + Math.max(0.01, Math.min(dur, lp[2] || dur)));
        o.connect(fl); src = fl;
    }
    src.connect(gn);
    if (o2.pan && AC.createStereoPanner) { const pn = AC.createStereoPanner(); pn.pan.value = o2.pan; gn.connect(pn); pn.connect(dest || sfxGain); }
    else gn.connect(dest || sfxGain);
    o.start(t); o.stop(t + dur + 0.03);
    o.onended = () => gn.disconnect();
}
function noiseHit(delay, v, type, freq, dur) {
    if (!AC || !noiseBuf) return;
    const t = AC.currentTime + delay, s = AC.createBufferSource(), fl = AC.createBiquadFilter(), gn = AC.createGain();
    s.buffer = noiseBuf; fl.type = type; fl.frequency.value = freq;
    gn.gain.setValueAtTime(v, t); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(fl); fl.connect(gn); gn.connect(musGain);
    if (dur > 0.18) s.loop = true;   // buffer is only 0.5 s long: loop so long rumbles don't cut out early
    s.start(t, Math.random() * 0.3, dur + 0.02);
    s.onended = () => gn.disconnect();
}
const shaker = (d, v) => smpHit('shaker', d, v, 0.05) || noiseHit(d, v, 'highpass', 6000, 0.06);
const clap = (d, v) => smpHit('clap', d, v, 0.05) || noiseHit(d, v, 'bandpass', 1800, 0.09);
const cymbal = (d, v) => smpHit('cymbal', d, v * 0.6, 0.05, { dur: 0.9 }) || noiseHit(d, v, 'highpass', 3500, 0.55);
// one sung/shouted syllable: sawtooth through two formant filters (a crude vocal tract)
function syl(delay, dur, f0a, f0b, F1, F2, vol, am) {
    if (!AC) return;
    const t = AC.currentTime + delay, o = AC.createOscillator(), env = AC.createGain(), amg = AC.createGain(), out = AC.createGain();
    o.type = 'sawtooth'; o.frequency.setValueAtTime(f0a, t); o.frequency.linearRampToValueAtTime(f0b, t + dur);
    env.gain.setValueAtTime(0.0001, t); env.gain.linearRampToValueAtTime(vol, t + 0.025);
    env.gain.setValueAtTime(vol, t + Math.max(0.03, dur - 0.05)); env.gain.linearRampToValueAtTime(0.0001, t + dur);
    amg.gain.value = 1;
    o.connect(env); env.connect(amg);
    if (am) {   // fast amplitude flutter = rolled "rr" / laughing "ja-ja"
        amg.gain.value = 0.5;
        const l = AC.createOscillator(), lg = AC.createGain();
        l.frequency.value = am; lg.gain.value = 0.5; l.connect(lg); lg.connect(amg.gain); l.start(t); l.stop(t + dur + 0.05);
    }
    [[F1, 1], [F2, 0.55]].forEach(p => {
        const bp = AC.createBiquadFilter(), bg = AC.createGain();
        bp.type = 'bandpass'; bp.frequency.value = p[0]; bp.Q.value = 5; bg.gain.value = p[1];
        amg.connect(bp); bp.connect(bg); bg.connect(out);
    });
    out.connect(musGain); o.start(t); o.stop(t + dur + 0.05);
}
let crowdBuf = null;
function roar(dl, dur, v) {   // looped noise swell = a cheering crowd
    if (!AC || !crowdBuf) return;
    const t = AC.currentTime + dl, s = AC.createBufferSource(), bp = AC.createBiquadFilter(), gn = AC.createGain();
    s.buffer = crowdBuf; s.loop = true; bp.type = 'bandpass'; bp.frequency.value = 1100; bp.Q.value = 0.7;
    gn.gain.setValueAtTime(0.0001, t); gn.gain.linearRampToValueAtTime(v, t + 0.3);
    gn.gain.setValueAtTime(v, t + dur * 0.5); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(bp); bp.connect(gn); gn.connect(musGain); s.start(t); s.stop(t + dur + 0.05);
}
function crowd(dl, dur = 2.6, k = 1) {   // roar + applause claps + a few whoops
    if (smpHit('crowd', dl, 0.14 * k, 0.14, { v: 0.5 * k })) return;
    roar(dl, dur, 0.14 * k);
    for (let i = 0; i < Math.round(22 * k); i++) clap(dl + 0.15 + Math.random() * dur * 0.85, 0.03 + Math.random() * 0.04);
    for (let i = 0; i < 3; i++) { const f = 380 + Math.random() * 250; syl(dl + 0.1 + Math.random() * 1.2, 0.35 + Math.random() * 0.3, f, f * 1.25, 700, 1200, 0.22 * k); }
}
const CUEFN = { arriba, grito, toro, ole, noprob, spell, frijol, andale: andaleVoice, porque, si };