
// =====================================================================
//  GAME STATE
// =====================================================================
let mode = 'menu';           // menu | shop | options | wardrobe | stats | trophies | play | levelup | pause | over
let g = null;
let menuT = 0;
let shopPage = 0;
let optTab = 0, optsReturn = 'menu', resetArmed = 0;
let drag = null;
let uiButtons = [];
let fps = 60, fpsAcc = 0, fpsN = 0;
const keys = { left: false, right: false, up: false, down: false };
const PARTM = () => OPT.parts;

function baseStats() {
    return {
        maxHp: 100, regen: 0, armor: 0, dodge: 0, speed: 3.0, iframes: 50, dmgTaken: 1,
        dmg: 1, fireRate: 1, projSpeed: 1, size: 1, pierce: 0, extraProj: 0, spreadMult: 1, jitter: 0,
        crit: 0.05, critMult: 2, bounce: 0, homing: 0, cooldownMult: 1, aoe: 1, durMult: 1,
        burnChance: 0, burnMult: 1, slowChance: 0, chainChance: 0, explodeChance: 0, splitChance: 0,
        execute: 0, bigDmg: 1, critExplode: 0, knock: 0, thorns: 0, dupChance: 0,
        magnet: 45, goldMult: 1, goldDropMult: 1, xpMult: 1, luck: 0, heartDrop: 0.008, heartHeal: 1,
        healOnKill: 0, ballSpeedMult: 1, ballHpMult: 1, maxShield: 0, skillCd: 1, lowHpDmg: 0, bounty: 0,
        comboTime: 0, dropMult: 1, grip: 1, ram: 0, arc: 0, whirl: 0,
        backfire: false, sideArms: false, adrenaline: false, critBurn: false, staticCharge: false,
        comboMaster: false, overkill: false, pinata: false, midas: false, firstHitCrit: false,
    };
}

// ---------- background scenery state ----------
const clouds = [];
for (let i = 0; i < 14; i++) clouds.push({ x: rand(-40, W + 40), y: rand(0, H), w: rand(50, 130), s: rand(0.4, 1.4), z: rand(0.3, 1) });
const starsBg = Array.from({ length: 90 }, () => ({ x: rand(0, W), y: rand(0, H), s: rand(0.5, 1.8) }));
const mesas = Array.from({ length: 8 }, (_, i) => ({ x: i * 52 - 30 + rand(-8, 8), w: rand(46, 86), h: rand(36, 96) }));
const cacti = Array.from({ length: 5 }, (_, i) => ({ x: i * 80 + rand(10, 60), h: rand(22, 40) }));
const motes = Array.from({ length: 36 }, () => ({ x: rand(0, W), y: rand(0, H), s: rand(0.3, 1), r: rand(1.5, 4) }));
const shooters = [];
const lightning = { t: 0, pts: [] };
let cloudSprite = null;
function makeCloudSprite() {
    const c = document.createElement('canvas'); c.width = 256; c.height = 112;
    const x = c.getContext('2d');
    const puffs = [[70, 66, 46], [118, 50, 54], [168, 62, 48], [208, 72, 34], [36, 76, 30], [128, 78, 52]];
    for (const p of puffs) {   // cool blue-grey underside
        const gr = x.createRadialGradient(p[0], p[1] + 8, 0, p[0], p[1] + 8, p[2]);
        gr.addColorStop(0, 'rgba(120,140,190,0.5)'); gr.addColorStop(1, 'rgba(120,140,190,0)');
        x.fillStyle = gr; x.beginPath(); x.arc(p[0], p[1] + 8, p[2], 0, TAU); x.fill();
    }
    for (const p of puffs) {
        const gr = x.createRadialGradient(p[0], p[1], 0, p[0], p[1], p[2]);
        gr.addColorStop(0, 'rgba(255,255,255,0.95)'); gr.addColorStop(0.6, 'rgba(255,255,255,0.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
        x.fillStyle = gr; x.beginPath(); x.arc(p[0], p[1], p[2], 0, TAU); x.fill();
    }
    for (const p of puffs) {   // sunlit tops
        const gr = x.createRadialGradient(p[0] - p[2] * 0.2, p[1] - p[2] * 0.4, 0, p[0] - p[2] * 0.2, p[1] - p[2] * 0.4, p[2] * 0.7);
        gr.addColorStop(0, 'rgba(255,250,235,0.95)'); gr.addColorStop(1, 'rgba(255,250,235,0)');
        x.fillStyle = gr; x.beginPath(); x.arc(p[0] - p[2] * 0.2, p[1] - p[2] * 0.4, p[2] * 0.7, 0, TAU); x.fill();
    }
    return c;
}
try { cloudSprite = makeCloudSprite(); } catch (e) { cloudSprite = null; }

// =====================================================================
//  CAMPAIGN: worlds, levels, score, run coins vs. skill pesos
//  Act 1 = sky shooter, Act 2 = taco racer, Act 3 = action RPG,
//  Act 4 = the boss act (sky shooter again, our pick of the three).
// =====================================================================
const BOSS_TYPES = { boss: 1, boss2: 1, gran: 1, truck: 1, calavera: 1 };
BTYPES.rival    = { r: 12, hp: 28,   vy: 0, dmg: 12, xp: 3,  gold: 0.35, colors: ['#e74c3c', '#f39c12', '#3498db', '#9b59b6'] };
BTYPES.totem    = { r: 17, hp: 150,  vy: 0, dmg: 0,  xp: 12, gold: 0, coins: 12, colors: ['#8e44ad'] };
BTYPES.crate    = { r: 12, hp: 12,   vy: 0, dmg: 0,  xp: 0,  gold: 0, coins: 3,  colors: ['#a0703c'] };
BTYPES.gran     = { r: 54, hp: 5000, vy: 0, dmg: 40, xp: 200, gold: 0, coins: 220, colors: ['#8c1d22'] };
BTYPES.truck    = { r: 40, hp: 2600, vy: 0, dmg: 35, xp: 100, gold: 0, coins: 120, colors: ['#c0392b'] };
BTYPES.calavera = { r: 40, hp: 2400, vy: 0, dmg: 35, xp: 100, gold: 0, coins: 120, colors: ['#dfe6e9'] };
WEAPONS.machete = { name: 'Machete', color: '#dfe6e9' };

const WORLDS = [
    { act: 1, title: 'THE RISE', kind: 'shoot', label: 'SKY SHOOTER', col: '#48dbfb', track: 'game',
      levels: [
        { name: 'Valle Chiquito Liftoff', sec: 55, sky: 0,     obj: 'Survive 55 seconds', story: 'The village shrinks below. Pop the balls and ride higher!' },
        { name: 'Cloud Rustlers',         sec: 65, sky: 4500,  obj: 'Survive 65 seconds', story: 'Rustlers lurk in the fog. Keep that hoop spinning.' },
        { name: 'Thunderhead Gauntlet',   sec: 75, sky: 9800,  obj: 'Survive 75 seconds', elites: [0.5], story: 'Thunder rolls. The baron\'s elite scouts are close.' },
        { name: 'Capitán Globito',        boss: 'boss', sky: 12500, bossName: 'CAPITÁN GLOBITO', obj: 'Defeat the boss', story: 'Capitán Globito guards the sky gate. Pop him!' },
      ] },
    { act: 2, title: 'THE PURSUIT', kind: 'convoy', label: 'CONVOY CHASE', col: '#ff9f43', track: 'race',
      levels: [
        { name: 'Taco Tuesday Rush',  len: 15000, theme: 'dawn',   dens: 1.0, obj: 'Recover every lantern truck', story: 'The scouts flee by car! Plan your moves and lasso the lantern trucks before they reach the horizon.' },
        { name: 'Canyon Sprint',      len: 18000, theme: 'canyon', dens: 1.2, obj: 'Recover every lantern truck', story: 'Bruisers wear armor. Ram them, or strip the plating with your hoop first.' },
        { name: 'Midnight Mesa Run',  len: 21000, theme: 'night',  dens: 1.4, obj: 'Recover every lantern truck', story: 'Night falls and the spitters are aiming at you. Watch the red lanes!' },
        { name: 'El Camión Salsero',  boss: 'truck', theme: 'boss', dens: 0.8, bossName: 'EL CAMIÓN SALSERO', obj: 'Wreck the truck', story: 'The baron\'s hot-sauce truck hauls the stolen fiesta. Stop it!' },
      ] },
    { act: 3, title: 'THE RECKONING', kind: 'rpg', label: 'ACTION RPG', col: '#a29bfe', track: 'rpg', shop: true,
      levels: [
        { name: 'Plaza de los Piñatas', theme: 'plaza',   goal: { t: 'kill', n: 26 }, obj: 'Defeat 26 foes', story: 'The chase ends in the plaza. Skeleton piñatas rise!' },
        { name: 'Cantina Brawl',        theme: 'cantina', goal: { t: 'kill', n: 34 }, obj: 'Defeat 34 foes', story: 'Abuela\'s cantina is overrun. Smash them all.' },
        { name: 'Bone Orchard',         theme: 'orchard', goal: { t: 'totem', n: 3 }, obj: 'Smash 3 curse totems', story: 'Shatter the three curse totems to break the spell.' },
        { name: 'La Calavera Gigante',  theme: 'bone', boss: 'calavera', bossName: 'LA CALAVERA GIGANTE', obj: 'Defeat the boss', story: 'La Calavera guards the stairway to the baron\'s fortress.' },
      ] },
    { act: 4, title: 'THE FINAL SHOWDOWN', kind: 'shoot', label: 'SKY SHOOTER', col: '#ff4757', track: 'boss', shop: true,
      levels: [
        { name: 'Fiesta Galaxy Gates', sec: 70, sky: 17500, obj: 'Survive 70 seconds', story: 'The Fiesta Galaxy opens. The baron\'s armada waits beyond.' },
        { name: 'Meteor Piñatas',      sec: 80, sky: 21000, ev: true, obj: 'Survive 80 seconds', story: 'Meteor piñatas rain down. Stay in the sweet spot!' },
        { name: 'The Baron\'s Armada', sec: 90, sky: 25500, elites: [0.3, 0.65], obj: 'Survive 90 seconds', story: 'His elite guard blocks the way. One more push!' },
        { name: 'EL GRAN GLOBO',       boss: 'gran', sky: 28500, bossName: 'EL GRAN GLOBO', obj: 'Take back the Sombrero', story: 'El Gran Globo holds the Golden Sombrero. End this!' },
      ] },
];
const NODES = [];
WORLDS.forEach((w, wi) => w.levels.forEach((L, li) => {
    if (li === 3 && w.shop) NODES.push({ type: 'shop', w: wi, l: -1, id: 's' + wi });
    NODES.push({ type: 'level', w: wi, l: li, id: 'l' + wi + '_' + li });
}));
const MAP_Y0 = 60, BAND_H = 114;
const NODEPOS = (() => {
    const pos = [];
    WORLDS.forEach((w, wi) => {
        const list = []; NODES.forEach((n, i) => { if (n.w === wi) list.push(i); });
        const n = list.length, top = MAP_Y0 + (3 - wi) * BAND_H, cy = top + 72;
        const x0 = n === 5 ? 38 : 50, x1 = n === 5 ? 322 : 310;
        list.forEach((idx, k) => {
            const u = k / (n - 1), x = wi % 2 === 0 ? x0 + (x1 - x0) * u : x1 - (x1 - x0) * u;
            pos[idx] = { x, y: cy + Math.sin(k * 1.9 + wi) * 8, band: wi };
        });
    });
    return pos;
})();
const levelOf = n => WORLDS[n.w].levels[n.l];

// ---- score -> skill currency ("pesos"). Bigger scores pay out a bigger multiplier. ----
const payoutMult = score => 1 + Math.min(3, score / 15000);
const payout = score => Math.max(0, Math.round(score / 40 * payoutMult(score)));
const campActive = () => !!(g && g.camp && g.camp.active);
save.camp = Object.assign({ clears: {}, wins: 0, runs: 0, bestScore: 0, furthest: 0 }, save.camp || {});

// ---- the same powerup / weapon, in its own flavor for each kind of act ----
const PU_TXT = {
    shoot: { magnet: ['Magnet!', ''], nuke: ['Piñata Bomb!', ''], freeze: ['Freeze!', ''], frenzy: ['Frenzy!', ''], shield: ['Shield!', ''] },
    race:  { magnet: ['Magnet Hubcaps!', 'Coins fly to your car'], nuke: ['Salsa Bomb!', 'Everything on the road explodes'], freeze: ['Siesta Slow-Mo!', 'Traffic crawls'], frenzy: ['NITRO!', 'Smash through anything'], shield: ['Taco Shell!', 'Blocks one crash'] },
    rpg:   { magnet: ['Loot Magnet!', 'Loot flies to you'], nuke: ['Fireball Nova!', 'Burns every foe'], freeze: ['Stone Gaze!', 'Foes turn to stone'], frenzy: ['Fiesta Fury!', 'Faster hands and feet'], shield: ['Poncho Ward!', 'Blocks one hit'] },
};
const WALT = {
    race: { skulls: 'Ghost Exhaust', revolver: 'Salsa Cannon', buckshot: 'Tortilla Scatter', hoops: 'Spinning Hubcaps', lasso: 'Tow Cable', chili: 'Chili Missiles', thunder: 'Thunder Horn', cactus: 'Spike Burst', dynamite: 'Salsa Mines', sunbeam: 'Headlight Beam', tumbleweed: 'Rolling Barrels', trumpet: 'Air Horn', boomerang: 'Chorizo Chain', machete: 'Machete' },
    rpg:  { skulls: 'Calavera Spirits', revolver: 'Six-Shooter', buckshot: 'Scattergun', hoops: 'Orbiting Hoops', lasso: 'Lasso Spin', chili: 'Chili Fireballs', thunder: 'Storm Call', cactus: 'Cactus Nova', dynamite: 'Dynamite', sunbeam: 'Sunbeam', tumbleweed: 'Tumbleweed', trumpet: 'Mariachi Trumpet', boomerang: 'Hoop Throw', machete: 'Machete' },
};
const wName = id => (g && WALT[g.kind] && WALT[g.kind][id]) || (WEAPONS[id] ? WEAPONS[id].name : id);
const activeName = id => g && g.kind === 'race' ? { dash: 'Nitro', slow: 'Siesta', cape: 'Shockwave' }[id] : g && g.kind === 'rpg' ? { dash: 'Roll', slow: 'Siesta', cape: 'Matador' }[id] : ACTIVES[id].name;

// ---- level-up cards for the racer and the RPG (stats are shared, so they carry over everywhere) ----
const CARDS = [
    // taco racer
    P('r_cannon', 'Salsa Cannon Mk II', 'common', 'Cannon +1 level: more damage, extra shot every 3 levels.', g => levelWeapon(g, 'revolver'), { req: canLevel('revolver'), max: 7, weapon: 'revolver' }),
    P('r_twin',   'Twin Tortilla Launchers', 'epic', 'Your guns fire +1 extra projectile.', g => { g.S.extraProj += 1; }, { max: 3 }),
    P('r_hot',    'Hot Sauce Rounds', 'common', '15% chance on hit to set foes on fire.', g => { g.S.burnChance += 0.15; }, { max: 3 }),
    P('r_turbo',  'Turbo Engine', 'common', 'Top speed and steering +8%.', g => { g.S.speed *= 1.08; }, { max: 4 }),
    P('r_tires',  'Grippy Tires', 'common', 'Steering +20%. Slicks and sand slow you less.', g => { g.S.grip += 0.2; }, { max: 3 }),
    P('r_plate',  'Armor Plating', 'common', '+20 max HP and +1 armor.', g => { changeMaxHp(g, 20); g.S.armor += 1; }, { max: 4 }),
    P('r_shell',  'Taco Shell Shield', 'rare', '+1 shield that recharges every 15s.', g => { g.S.maxShield += 1; g.shield += 1; }, { max: 2 }),
    P('r_hub',    'Magnet Hubcaps', 'common', 'Pickup magnet +35.', g => { g.S.magnet += 35; }, { max: 3 }),
    P('r_nitro',  'Nitro Tank', 'rare', 'Adds a NITRO button (or upgrades it): invincible speed burst.', g => { if (g.actives.dash) { g.actives.dash.rank = Math.min(3, g.actives.dash.rank + 1); } else g.actives.dash = { rank: 1, cd: 0 }; }, { max: 3 }),
    P('r_bumper', 'Spiked Bumper', 'rare', 'Ramming hurts foes much more and hurts you less.', g => { g.S.ram += 1; }, { max: 3 }),
    P('w_r_mines', 'Salsa Mines', 'rare', 'NEW WEAPON: lobs explosive salsa jars down the road.', g => unlockWeapon(g, 'dynamite'), { req: lacks('dynamite'), unlock: true }),
    P('w_r_chili', 'Chili Missiles', 'rare', 'NEW WEAPON: homing chili missiles that ignite foes.', g => unlockWeapon(g, 'chili'), { req: lacks('chili'), unlock: true }),
    P('w_r_hub',   'Spinning Hubcaps', 'rare', 'NEW WEAPON: hubcaps orbit your car and smack foes.', g => unlockWeapon(g, 'hoops'), { req: lacks('hoops'), unlock: true }),
    P('w_r_scat',  'Tortilla Scatter', 'rare', 'NEW WEAPON: a fan of flying tortillas.', g => unlockWeapon(g, 'buckshot'), { req: lacks('buckshot'), unlock: true }),
    P('r_luck',   "Rabbit's Foot", 'common', 'Luck +10 and power-up drops +20%.', g => { g.S.luck += 10; g.S.dropMult += 0.2; }, { max: 3 }),
    P('r_repair', 'Guac Repair Kit', 'common', 'Heal 40% now and regenerate +0.3 HP/s.', g => { heal(g, g.S.maxHp * 0.4); g.S.regen += 0.3; }, { max: 2 }),
    // action RPG
    P('p_machete', 'Sharper Machete', 'common', 'Machete +1 level: more damage and reach.', g => levelWeapon(g, 'machete'), { req: canLevel('machete'), max: 7, weapon: 'machete' }),
    P('p_sweep',   'Wide Swing', 'common', 'Machete arc 25% wider.', g => { g.S.arc += 0.25; }, { max: 3, req: owns('machete') }),
    P('p_whirl',   'Whirlwind', 'epic', 'Every 5 seconds the hero spins, slashing everything around.', g => { g.S.whirl = 1; }),
    P('p_gun',     'Six-Shooter Mastery', 'common', 'Six-Shooter +1 level: more damage, extra bullet every 3 levels.', g => levelWeapon(g, 'revolver'), { req: canLevel('revolver'), max: 7, weapon: 'revolver' }),
    P('w_p_hoop',  'Hoop Throw', 'rare', 'NEW WEAPON: hurl a hula hoop that returns to you.', g => unlockWeapon(g, 'boomerang'), { req: lacks('boomerang'), unlock: true }),
    P('w_p_lasso', 'Lasso Spin', 'rare', 'NEW WEAPON: a spinning lasso lashes everything near you.', g => unlockWeapon(g, 'lasso'), { req: lacks('lasso'), unlock: true }),
    P('w_p_nova',  'Cactus Nova', 'rare', 'NEW WEAPON: needles burst out in every direction.', g => unlockWeapon(g, 'cactus'), { req: lacks('cactus'), unlock: true }),
    P('w_p_fire',  'Chili Fireballs', 'rare', 'NEW WEAPON: homing fireballs that ignite foes.', g => unlockWeapon(g, 'chili'), { req: lacks('chili'), unlock: true }),
    P('w_p_storm', 'Storm Call', 'epic', 'NEW WEAPON: lightning strikes random foes.', g => unlockWeapon(g, 'thunder'), { req: lacks('thunder'), unlock: true }),
    P('w_p_hoops', 'Orbiting Hoops', 'rare', 'NEW WEAPON: spare hoops circle the hero.', g => unlockWeapon(g, 'hoops'), { req: lacks('hoops'), unlock: true }),
    P('p_poncho',  'Iron Poncho', 'common', '+10 max HP and +2 armor.', g => { changeMaxHp(g, 10); g.S.armor += 2; }, { max: 4 }),
    P('p_spurs',   'Swift Spurs', 'common', 'Move speed +10%.', g => { g.S.speed *= 1.1; }, { max: 4 }),
    P('p_roll',    'Dodge Roll', 'rare', 'Adds a ROLL button (or upgrades it): an invincible dash.', g => { if (g.actives.dash) { g.actives.dash.rank = Math.min(3, g.actives.dash.rank + 1); } else g.actives.dash = { rank: 1, cd: 0 }; }, { max: 3 }),
    P('p_tequila', 'Liquid Courage', 'rare', 'Foes you defeat have a 10% chance to heal you.', g => { g.S.healOnKill += 0.1; }, { max: 3 }),
    P('p_eye',     "Bandit's Eye", 'common', 'Critical chance +8%.', g => { g.S.crit += 0.08; }, { max: 4 }),
    P('p_rage',    'Fiesta Rage', 'common', 'All damage +15%.', g => { g.S.dmg *= 1.15; }, { max: 5 }),
    // anywhere
    P('c_gold',    'Pot of Gold', 'common', 'Run coins gained +15%.', g => { g.S.goldMult += 0.15; }, { max: 3 }),
    P('c_study',   'Quick Study', 'common', 'XP gained +10%.', g => { g.S.xpMult *= 1.1; }, { max: 3 }),
    P('c_hp',      'Toughness', 'common', '+15 max HP.', g => { changeMaxHp(g, 15); }, { max: 4 }),
    P('c_dmg',     'Firepower', 'common', 'All damage +12%.', g => { g.S.dmg *= 1.12; }, { max: 4 }),
];
const CARD_SETS = {
    race: ['r_cannon', 'r_twin', 'r_hot', 'r_turbo', 'r_tires', 'r_plate', 'r_shell', 'r_hub', 'r_nitro', 'r_bumper', 'w_r_mines', 'w_r_chili', 'w_r_hub', 'w_r_scat', 'r_luck', 'r_repair', 'c_gold', 'c_study', 'c_dmg'],
    rpg: ['p_machete', 'p_sweep', 'p_whirl', 'p_gun', 'w_p_hoop', 'w_p_lasso', 'w_p_nova', 'w_p_fire', 'w_p_storm', 'w_p_hoops', 'p_poncho', 'p_spurs', 'p_roll', 'p_tequila', 'p_eye', 'p_rage', 'c_gold', 'c_study', 'c_hp'],
};
function availableCards() {
    const ids = CARD_SETS[g.kind] || [];
    return CARDS.filter(c => ids.includes(c.id) && (g.powerStacks[c.id] || 0) < c.max && c.req(g));
}

// ---- run-coin shop (one per world after Act 2) ----
const SHOP_ITEMS = [
    { id: 'guac',  name: 'Guacamole Bowl',   desc: 'Heal 60% of your max HP.',                  base: 28,  buy: g => heal(g, g.S.maxHp * 0.6) },
    { id: 'stew',  name: 'Hearty Stew',      desc: '+25 max HP and heal 25.',                   base: 48,  buy: g => changeMaxHp(g, 25) },
    { id: 'stone', name: 'Whetstone',        desc: 'All damage +12% for the rest of the run.',  base: 60,  buy: g => { g.S.dmg *= 1.12; } },
    { id: 'poncho',name: 'Poncho Patch',     desc: '+2 armor.',                                 base: 55,  buy: g => { g.S.armor += 2; } },
    { id: 'spurs', name: 'Silver Spurs',     desc: 'Move speed +10%.',                          base: 50,  buy: g => { g.S.speed *= 1.1; } },
    { id: 'dice',  name: 'Lucky Dice',       desc: '+2 level-up rerolls.',                      base: 34,  buy: g => { g.rerolls += 2; } },
    { id: 'relic', name: 'Mystery Relic',    desc: 'A random relic. Most help, some bite.',     base: 95,  buy: g => { grantRandomRelic(g, 'Shop:'); } },
    { id: 'tonic', name: 'Fiesta Tonic',     desc: 'Gain a level now and pick a new power.',    base: 110, buy: g => { gainLevel(g); }, after: true },
    { id: 'crate', name: 'Armory Crate',     desc: 'Unlock a random new weapon.',               base: 130, buy: g => { const p = Object.keys(WEAPONS).filter(i => !g.weapons[i] && i !== 'machete'); if (p.length) { const i = pick(p); unlockWeapon(g, i); toast('Armory Crate', WEAPONS[i].name + ' equipped', '#ffb142', 150); } else gainLevel(g); }, after: true },
    { id: 'tin',   name: 'Tin Star Shield',  desc: '+1 shield that recharges every 15s.',       base: 75,  buy: g => { g.S.maxShield++; g.shield++; } },
    { id: 'clover',name: 'Four-Leaf Clover', desc: 'Luck +12: rarer cards and more drops.',     base: 45,  buy: g => { g.S.luck += 12; } },
];

// =====================================================================
//  WORLD MAP + RUN SHOP + LEVEL FLOW SCREENS
// =====================================================================
let mapSel = 0, mapConfirm = 0, wsMsg = '', wsFlash = 0;

function drawCoinIcon(x, y, r) {   // run coin (gold)
    ctx.fillStyle = '#a97c05'; ctx.beginPath(); ctx.arc(x + 0.5, y + 0.6, r, 0, TAU); ctx.fill();
    ctx.fillStyle = '#f7d23c'; ctx.beginPath(); ctx.arc(x, y, r * 0.86, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.fillRect(x - r * 0.45, y - r * 0.55, r * 0.3, r * 0.3);
}
function drawPesoIcon(x, y, r) {   // skill currency (green "$" token)
    ctx.fillStyle = '#145a32'; ctx.beginPath(); ctx.arc(x + 0.5, y + 0.6, r, 0, TAU); ctx.fill();
    ctx.fillStyle = '#58d68d'; ctx.beginPath(); ctx.arc(x, y, r * 0.86, 0, TAU); ctx.fill();
    ctx.fillStyle = '#0b3d20'; ctx.font = `900 ${Math.round(r * 1.25)}px system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('$', x, y + 0.5); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
}
function pill(x, y, w, h, col) {
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; roundRect(x, y, w, h, h / 2); ctx.fill();
    ctx.strokeStyle = col || 'rgba(255,211,42,0.5)'; ctx.lineWidth = 1.1; roundRect(x, y, w, h, h / 2); ctx.stroke();
}

function openMap() {
    mode = 'map'; drag = null; mapConfirm = 0;
    mapSel = campActive() ? g.camp.node : 0;
}
function nodeState(i) {
    if (godMode) return 'cur';
    if (!campActive()) return i === 0 ? 'cur' : 'lock';
    const c = g.camp; return i < c.node ? 'done' : i === c.node ? 'cur' : 'lock';
}
function mapGo() {
    const i = mapSel;
    if (nodeState(i) !== 'cur') { sfx('hurt'); return; }
    sfx('click');
    if (!campActive()) startRun(true);
    if (godMode) { g.camp.node = i; g.camp.lvlDone = NODES.slice(0, i).filter(x => x.type !== 'shop').length; }
    const n = NODES[i];
    if (n.type !== 'shop' && n.l === 0 && ACT_CUTS[n.w] && !g.camp.seen[n.w] && OPT.intro !== 2) { g.camp.seen[n.w] = 1; startCutsceneList(ACT_CUTS[n.w], () => beginLevel(n.w, n.l)); return; }
    if (n.type === 'shop') openWShop(n.w); else beginLevel(n.w, n.l);
}
function mapBack() {
    if (campActive()) {
        if (mapConfirm > 0) { mapConfirm = 0; endRun(); }
        else mapConfirm = 150;
    } else mode = 'menu';
}

// ---------- map art: four painted bands, one per world ----------
function mapBand(wi, t) {
    const w = WORLDS[wi], x = 8, y = MAP_Y0 + (3 - wi) * BAND_H, bw = W - 16, bh = BAND_H - 6;
    ctx.save(); roundRect(x, y, bw, bh, 12); ctx.clip();
    if (wi === 0) {   // dawn sky, clouds, mesas, floating balls
        ctx.fillStyle = lg(0, y, 0, y + bh, [[0, '#3b8fd9'], [0.55, '#8fcdf5'], [1, '#ffc98a']]); ctx.fillRect(x, y, bw, bh);
        drawGlow(x + bw - 50, y + bh - 8, 70, '#ffe9a8', 0.8);
        ctx.fillStyle = 'rgba(255,255,255,0.8)';
        for (let k = 0; k < 4; k++) { const cx = x + ((k * 101 + t * 0.12) % (bw + 90)) - 40, cy = y + 30 + (k % 2) * 28; ctx.beginPath(); ctx.ellipse(cx, cy, 24, 8, 0, 0, TAU); ctx.ellipse(cx + 13, cy - 5, 15, 9, 0, 0, TAU); ctx.ellipse(cx - 13, cy - 2, 13, 7, 0, 0, TAU); ctx.fill(); }
        ctx.fillStyle = '#c0713a';
        for (let k = 0; k < 5; k++) { const mx = x + 10 + k * 76, mh = 22 + (k * 37) % 20; ctx.beginPath(); ctx.moveTo(mx, y + bh); ctx.lineTo(mx + 6, y + bh - mh); ctx.lineTo(mx + 34, y + bh - mh); ctx.lineTo(mx + 42, y + bh); ctx.fill(); }
        [[60, 48, 8, 0], [190, 30, 7, 1], [300, 56, 9, 2]].forEach(b => { const by = y + b[1] + Math.sin(t * 0.04 + b[3] * 2) * 4; ctx.fillStyle = BALLCOLS[b[3]]; ctx.beginPath(); ctx.arc(x + b[0], by, b[2], 0, TAU); ctx.fill(); drawSombrero(x + b[0], by - b[2] * 0.7, b[2] * 1.2, 0, b[3]); });
    } else if (wi === 1) {   // canyon road with a cruising taco car
        ctx.fillStyle = lg(0, y, 0, y + bh, [[0, '#f7c873'], [1, '#d9803a']]); ctx.fillRect(x, y, bw, bh);
        ctx.fillStyle = '#a34a28'; ctx.beginPath(); ctx.moveTo(x, y + 60); for (let k = 0; k <= 8; k++) ctx.lineTo(x + k * bw / 8, y + 36 + ((k * 53) % 28)); ctx.lineTo(x + bw, y + 60); ctx.lineTo(x + bw, y + bh); ctx.lineTo(x, y + bh); ctx.fill();
        ctx.fillStyle = '#6f3320'; for (let k = 0; k < 6; k++) drawCactus(x + 30 + k * 62, y + bh - 3, 14 + (k * 7) % 10, '#6f3320');
        ctx.fillStyle = 'rgba(40,30,50,0.6)'; ctx.fillRect(x, y + bh - 14, bw, 8);
        ctx.fillStyle = '#ffd32a'; for (let k = 0; k < 12; k++) ctx.fillRect(x + ((k * 34 - t * 3) % (bw + 34) + bw + 34) % (bw + 34) - 10, y + bh - 11, 14, 2);
        ctx.save(); ctx.translate(x + ((t * 0.7) % (bw + 80)) - 30, y + bh - 8); ctx.rotate(-Math.PI / 2); drawTacoCar(0, 0, 0.55, {}); ctx.restore();
    } else if (wi === 2) {   // haunted village at dusk
        ctx.fillStyle = lg(0, y, 0, y + bh, [[0, '#2d1b4e'], [1, '#8a3c6e']]); ctx.fillRect(x, y, bw, bh);
        drawGlow(x + 56, y + 36, 46, '#fff3c0', 0.7); ctx.fillStyle = '#fff6d8'; ctx.beginPath(); ctx.arc(x + 56, y + 36, 14, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(180,170,140,0.5)'; ctx.beginPath(); ctx.arc(x + 51, y + 33, 4, 0, TAU); ctx.arc(x + 61, y + 40, 3, 0, TAU); ctx.fill();
        ctx.fillStyle = '#1c0f2a'; for (let k = 0; k < 5; k++) { const hx = x + 110 + k * 46, hh = 20 + (k * 13) % 16; ctx.fillRect(hx, y + bh - hh, 34, hh); ctx.fillStyle = '#ffcf6b'; ctx.fillRect(hx + 12, y + bh - hh + 6, 7, 8); ctx.fillStyle = '#1c0f2a'; }
        ctx.fillStyle = '#3a2a4a'; for (let k = 0; k < 7; k++) { const tx = x + 14 + k * 50; ctx.fillRect(tx, y + bh - 17, 4, 17); ctx.fillRect(tx - 4, y + bh - 13, 12, 3); }
        for (let k = 0; k < 8; k++) { const fx = x + 20 + ((k * 61 + t * 0.2) % (bw - 30)), fy = y + 30 + Math.sin(t * 0.03 + k * 2) * 18 + (k % 3) * 14; drawGlow(fx, fy, 8, '#ffe58a', 0.5 + 0.4 * Math.sin(t * 0.1 + k)); }
    } else {   // fiesta galaxy, the baron looms
        ctx.fillStyle = lg(0, y, 0, y + bh, [[0, '#12041f'], [1, '#5a1166']]); ctx.fillRect(x, y, bw, bh);
        drawGlow(x + 250, y + 70, 120, '#c0392b', 0.45); drawGlow(x + 60, y + 30, 90, '#6c5ce7', 0.35);
        ctx.fillStyle = '#fff'; for (let k = 0; k < 40; k++) { const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * 0.03 + k)); ctx.globalAlpha = tw; ctx.fillRect(x + (k * 53) % bw, y + (k * 29) % bh, 1.5, 1.5); } ctx.globalAlpha = 1;
        drawVillain(x + 120, y + 56, 20, t, {});
    }
    ctx.restore();
    ctx.strokeStyle = w.col; ctx.lineWidth = 2; roundRect(x, y, bw, bh, 12); ctx.stroke();
    ctx.font = 'bold 12px system-ui, sans-serif'; ctx.textAlign = 'left';
    outlineText(`ACT ${w.act}: ${w.title}`, x + 10, y + 17, '#fff', 'rgba(0,0,0,0.75)', 3.5);
    ctx.textAlign = 'right'; ctx.font = 'bold 9px system-ui, sans-serif';
    outlineText(w.label, x + bw - 10, y + 16, w.col, 'rgba(0,0,0,0.8)', 3); ctx.textAlign = 'left';
}
function segPts(i) {
    const a = NODEPOS[i], b = NODEPOS[i + 1];
    if (a.band === b.band) return [a.x, a.y, (a.x + b.x) / 2, (a.y + b.y) / 2 + (i % 2 ? 7 : -7), b.x, b.y];
    const side = a.x > W / 2 ? 1 : -1;
    return [a.x, a.y, a.x + side * 54, (a.y + b.y) / 2, b.x, b.y];
}
function mapPath() {
    const cur = campActive() ? g.camp.node : 0;
    ctx.lineCap = 'round';
    for (const pass of [0, 1, 2]) for (let i = 0; i < NODEPOS.length - 1; i++) {
        const s = segPts(i), done = campActive() && i < cur;
        ctx.beginPath(); ctx.moveTo(s[0], s[1]); ctx.quadraticCurveTo(s[2], s[3], s[4], s[5]);
        if (pass === 0) { ctx.strokeStyle = 'rgba(20,10,30,0.6)'; ctx.lineWidth = 9; ctx.setLineDash([]); }
        else if (pass === 1) { ctx.strokeStyle = done ? '#ffd32a' : '#e9dcb4'; ctx.lineWidth = 5.5; ctx.setLineDash([]); }
        else { ctx.strokeStyle = done ? '#fff7c4' : 'rgba(120,90,50,0.55)'; ctx.lineWidth = 1.4; ctx.setLineDash([3, 7]); }
        ctx.stroke();
    }
    ctx.setLineDash([]);
}
function drawNode(i, t) {
    const n = NODES[i], p = NODEPOS[i], st = nodeState(i), w = WORLDS[n.w];
    const boss = n.type === 'level' && n.l === 3, shop = n.type === 'shop', r = boss ? 18 : 14, sel = mapSel === i;
    uiButtons.push({ x: p.x - 22, y: p.y - 22, w: 44, h: 44, fn: () => { mapSel = i; sfx('click'); } });
    const pulse = 0.5 + 0.5 * Math.sin(t * 0.12);
    if (st === 'cur') drawGlow(p.x, p.y, r * 3.2 + pulse * 8, w.col, 0.85);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(p.x + 1, p.y + r * 0.85, r, r * 0.45, 0, 0, TAU); ctx.fill();
    const f = st === 'done' ? ['#9af0b6', '#1e8449'] : st === 'cur' ? [shade(w.col, 0.55), w.col] : ['#8a9599', '#454c52'];
    ctx.fillStyle = rg(p.x - r * 0.3, p.y - r * 0.35, r * 0.1, p.x, p.y, r * 1.15, [[0, f[0]], [1, f[1]]]);
    ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.fill();
    ctx.lineWidth = sel ? 3.2 : 2; ctx.strokeStyle = sel ? '#fff' : 'rgba(20,10,30,0.85)'; ctx.stroke();
    if (sel) { ctx.strokeStyle = `rgba(255,255,255,${0.35 + 0.35 * pulse})`; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(p.x, p.y, r + 5 + pulse * 2, 0, TAU); ctx.stroke(); }
    ctx.fillStyle = '#fff'; ctx.strokeStyle = '#fff';
    if (st === 'done') {   // check mark
        ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(p.x - r * 0.42, p.y + 0.5); ctx.lineTo(p.x - r * 0.1, p.y + r * 0.38); ctx.lineTo(p.x + r * 0.5, p.y - r * 0.34); ctx.stroke();
    } else if (st === 'lock') {   // padlock
        ctx.fillStyle = '#d5dbdb'; roundRect(p.x - 5, p.y - 1, 10, 8, 1.5); ctx.fill();
        ctx.strokeStyle = '#d5dbdb'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(p.x, p.y - 2, 3.4, Math.PI, 0); ctx.stroke();
    } else if (shop) {   // market tent
        ctx.fillStyle = '#ff6b6b'; ctx.beginPath(); ctx.moveTo(p.x, p.y - 8); ctx.lineTo(p.x + 9, p.y + 1); ctx.lineTo(p.x - 9, p.y + 1); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.fillRect(p.x - 3, p.y - 3, 3, 4); ctx.fillStyle = '#6b3f1d'; ctx.fillRect(p.x - 7, p.y + 1, 14, 6); ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.arc(p.x, p.y + 4, 1.8, 0, TAU); ctx.fill();
    } else if (boss) {   // skull
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(p.x, p.y - 2, 8, 0, TAU); ctx.fill(); ctx.fillRect(p.x - 4.5, p.y + 3, 9, 6);
        ctx.fillStyle = '#2b1030'; ctx.beginPath(); ctx.arc(p.x - 3.2, p.y - 2, 2.2, 0, TAU); ctx.arc(p.x + 3.2, p.y - 2, 2.2, 0, TAU); ctx.fill(); ctx.fillRect(p.x - 0.7, p.y + 1.5, 1.4, 2);
        ctx.fillRect(p.x - 2.2, p.y + 5.5, 0.9, 3); ctx.fillRect(p.x + 1.3, p.y + 5.5, 0.9, 3);
    } else {
        ctx.font = 'bold 15px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#1b1226';
        ctx.fillText(String(n.l + 1), p.x, p.y + 1); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    }
    if (save.camp.clears[n.id] && st !== 'done') {   // star: cleared in an earlier run
        ctx.fillStyle = '#ffd32a'; ctx.beginPath();
        for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? 2.6 : 5.6; ctx.lineTo(p.x + r * 0.85 + Math.cos(a) * rr, p.y - r * 0.85 + Math.sin(a) * rr); }
        ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(80,40,0,0.7)'; ctx.lineWidth = 0.8; ctx.stroke();
    }
    ctx.font = 'bold 8px system-ui, sans-serif'; ctx.textAlign = 'center';
    outlineText(shop ? 'SHOP' : `${w.act}-${n.l + 1}`, p.x, p.y + r + 11, '#fff', 'rgba(0,0,0,0.8)', 2.5); ctx.textAlign = 'left';
    if (st === 'cur') drawVaquero(p.x, p.y - r - 20 + Math.sin(t * 0.1) * 3, 0.3, 1, t * 0.3);
}
function drawMap() {
    const t = menuT, run = campActive();
    ctx.fillStyle = '#0d0b18'; ctx.fillRect(0, 0, W, H);
    for (let wi = 3; wi >= 0; wi--) mapBand(wi, t);
    mapPath();
    for (let i = 0; i < NODES.length; i++) drawNode(i, t);
    // header
    ctx.fillStyle = lg(0, 0, 0, 56, [[0, '#2a1d44'], [1, '#120d22']]); ctx.fillRect(0, 0, W, 56);
    ctx.fillStyle = '#ffd32a'; ctx.font = '900 18px system-ui, sans-serif'; ctx.fillText('WORLD MAP', 12, 22);
    ctx.fillStyle = '#b2bec3'; ctx.font = '10px system-ui, sans-serif';
    ctx.fillText(mapConfirm > 0 ? 'Tap again to end this run and bank your pesos' : run ? 'Run in progress' : 'New run: reach El Gran Globo', 12, 35);
    btn(W - 74, 6, 64, 26, run ? (mapConfirm > 0 ? 'SURE?' : 'END RUN') : 'MENU', mapBack, run ? '#c0392b' : '#636e72', null, 11);
    if (run) {
        pill(10, 38, 72, 15); drawCoinIcon(20, 45.5, 5.2); ctx.fillStyle = '#f1c40f'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillText(String(g.gold), 29, 49);
        pill(88, 38, 92, 15); ctx.fillStyle = '#dfe6e9'; ctx.fillText('SCORE ' + g.score, 96, 49);
        pill(186, 38, 44, 15); ctx.fillText('Lv ' + g.level, 194, 49);
        pill(236, 38, 114, 15, 'rgba(46,204,113,0.6)');
        const k = clamp(g.player.hp / g.S.maxHp, 0, 1); ctx.fillStyle = k > 0.5 ? '#2ecc71' : k > 0.25 ? '#f39c12' : '#e74c3c'; roundRect(240, 41, 106 * k, 9, 4); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.font = 'bold 8px system-ui, sans-serif'; ctx.fillText(`HP ${Math.ceil(g.player.hp)}/${Math.round(g.S.maxHp)}`, 246, 48.5);
    } else {
        pill(10, 38, 96, 15, 'rgba(46,204,113,0.6)'); drawPesoIcon(20, 45.5, 5.2); ctx.fillStyle = '#58d68d'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillText(save.gold + ' pesos', 29, 49);
        pill(112, 38, 130, 15); ctx.fillStyle = '#dfe6e9'; ctx.fillText('BEST SCORE ' + save.camp.bestScore, 120, 49);
        pill(248, 38, 102, 15); ctx.fillText('WINS ' + save.camp.wins + ' · RUNS ' + save.camp.runs, 254, 49);
    }
    if (mapConfirm > 0) mapConfirm--;
    drawMapInfo();
}
function drawMapInfo() {
    const i = mapSel, n = NODES[i], w = WORLDS[n.w], st = nodeState(i), y0 = 528, h = H - y0 - 6;
    ctx.fillStyle = 'rgba(14,12,30,0.97)'; roundRect(8, y0, W - 16, h, 12); ctx.fill();
    ctx.strokeStyle = w.col; ctx.lineWidth = 2; roundRect(8, y0, W - 16, h, 12); ctx.stroke();
    let title, sub, story;
    if (n.type === 'shop') { title = `Act ${w.act} Shop: Feria del Pueblo`; sub = 'RUN COIN SHOP · spend coins from your run'; story = 'Stock up before the boss. Prices rise a little with your game score.'; }
    else { const L = levelOf(n); title = `${w.act}-${n.l + 1}  ${L.name}`; sub = `${w.label} · ${L.obj}`; story = L.story; }
    ctx.font = 'bold 14px system-ui, sans-serif'; ctx.fillStyle = '#fff'; ctx.fillText(title, 20, y0 + 24, W - 40);
    ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillStyle = w.col; ctx.fillText(sub, 20, y0 + 41, W - 40);
    ctx.font = '11px system-ui, sans-serif'; ctx.fillStyle = '#b2bec3'; wrapText(story, 20, y0 + 60, W - 150, 14);
    const best = save.camp.clears[n.id];
    if (best) { ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillText('★ best ' + best, 20, y0 + h - 10); }
    const bx = W - 124, by = y0 + h - 50;
    if (st === 'cur') btn(bx, by, 108, 42, campActive() ? 'GO!' : 'START RUN', mapGo, '#2ecc71', null, campActive() ? 20 : 14);
    else { ctx.fillStyle = 'rgba(255,255,255,0.08)'; roundRect(bx, by, 108, 42, 12); ctx.fill(); ctx.fillStyle = st === 'done' ? '#2ecc71' : '#7f8c8d'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(st === 'done' ? 'CLEARED' : 'LOCKED', bx + 54, by + 26); ctx.textAlign = 'left'; }
}

// ---------- the run-coin shop ----------
const shopPrice = (s, wi) => Math.round(s.base * (1 + 0.3 * wi) * (1 + g.score / 40000));
function openWShop(wi) {
    mode = 'wshop'; drag = null; wsMsg = ''; wsFlash = 0;
    const c = g.camp;
    if (!c.shops[wi]) {
        const rest = shuffle(SHOP_ITEMS.filter(s => s.id !== 'guac')).slice(0, 5);
        c.shops[wi] = [SHOP_ITEMS[0]].concat(rest).map(s => ({ id: s.id, sold: false }));
    }
    g.shopWi = wi;
}
function shopBuy(e, it, price) {
    if (e.sold) return;
    if (g.gold < price) { wsMsg = 'Not enough coins!'; wsFlash = 40; sfx('hurt'); return; }
    g.gold -= price; e.sold = true; sfx('buy'); wsMsg = it.name + ' bought!'; wsFlash = 60;
    it.buy(g);
    if (it.after && g.pending > 0) { g.returnTo = 'wshop'; openLevelUp(); }
}
function leaveShop() {
    const c = g.camp; c.node++; save.camp.furthest = Math.max(save.camp.furthest, c.node); persist();
    sfx('click'); openMap();
}
function drawWShop() {
    const t = menuT, wi = g.shopWi, c = g.camp, stock = c.shops[wi];
    ctx.fillStyle = lg(0, 0, 0, H, [[0, '#2a1240'], [0.5, '#5a2a52'], [1, '#2b1230']]); ctx.fillRect(0, 0, W, H);
    drawBunting(2, t, 9, 1); drawBunting(24, t, 7, 3);
    for (let k = 0; k < 4; k++) { const sx = 6 + k * 88; ctx.fillStyle = k % 2 ? '#ff6b6b' : '#feca57'; ctx.beginPath(); ctx.moveTo(sx, 54); ctx.lineTo(sx + 80, 54); ctx.lineTo(sx + 72, 66); ctx.lineTo(sx + 8, 66); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.25)'; for (let j = 0; j < 4; j++) ctx.fillRect(sx + 4 + j * 20, 54, 9, 12); }
    ctx.textAlign = 'center'; ctx.font = '900 22px system-ui, sans-serif'; outlineText('FERIA DEL PUEBLO', W / 2, 92, '#ffd32a', 'rgba(60,20,10,0.9)', 5);
    ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillStyle = '#dfe6e9'; ctx.fillText(`ACT ${WORLDS[wi].act} SHOP · spend your run coins`, W / 2, 108); ctx.textAlign = 'left';
    pill(10, 116, 96, 20); drawCoinIcon(22, 126, 6.5); ctx.fillStyle = '#f1c40f'; ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillText(String(g.gold), 34, 130);
    pill(112, 116, 110, 20); ctx.fillStyle = '#dfe6e9'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillText('SCORE ' + g.score, 122, 130);
    pill(228, 116, 122, 20); const k = clamp(g.player.hp / g.S.maxHp, 0, 1); ctx.fillStyle = '#2ecc71'; roundRect(232, 120, 114 * k, 12, 5); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillText(`HP ${Math.ceil(g.player.hp)}/${Math.round(g.S.maxHp)}`, 238, 130);
    stock.forEach((e, i) => {
        const it = SHOP_ITEMS.find(s => s.id === e.id), price = shopPrice(it, wi), afford = g.gold >= price && !e.sold;
        const x = 12, y = 146 + i * 58, w = W - 24, h = 52;
        uiButtons.push({ x, y, w, h, fn: () => shopBuy(e, it, price) });
        ctx.fillStyle = e.sold ? 'rgba(30,30,40,0.7)' : 'rgba(40,24,66,0.95)'; roundRect(x, y, w, h, 10); ctx.fill();
        ctx.strokeStyle = e.sold ? '#555' : afford ? '#f1c40f' : '#6c5ce7'; ctx.lineWidth = 1.5; roundRect(x, y, w, h, 10); ctx.stroke();
        ctx.fillStyle = e.sold ? '#777' : '#fff'; ctx.font = 'bold 14px system-ui, sans-serif'; ctx.fillText(it.name, x + 12, y + 21);
        ctx.fillStyle = e.sold ? '#666' : '#b2bec3'; ctx.font = '11px system-ui, sans-serif'; ctx.fillText(it.desc, x + 12, y + 40, w - 96);
        if (e.sold) { ctx.fillStyle = '#2ecc71'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.textAlign = 'right'; ctx.fillText('SOLD', x + w - 14, y + 31); ctx.textAlign = 'left'; }
        else { drawCoinIcon(x + w - 62, y + 26, 7); ctx.fillStyle = afford ? '#f1c40f' : '#777'; ctx.font = 'bold 15px system-ui, sans-serif'; ctx.textAlign = 'right'; ctx.fillText(String(price), x + w - 12, y + 31); ctx.textAlign = 'left'; }
    });
    if (wsFlash > 0) { wsFlash--; ctx.textAlign = 'center'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillStyle = g.gold < 0 || /Not/.test(wsMsg) ? '#ff7675' : '#7bed9f'; ctx.fillText(wsMsg, W / 2, 506); ctx.textAlign = 'left'; }
    btn(60, 524, 240, 52, 'LEAVE SHOP', leaveShop, '#2ecc71', 'back to the map', 20);
    ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.font = '10px system-ui, sans-serif'; ctx.fillText('Run coins are lost when the run ends. Your score turns into pesos.', W / 2, 600); ctx.textAlign = 'left';
}

// ---------- level intro banner, HUD extras, clear + game over screens ----------
function drawLevelIntro() {
    const c = g.camp, n = NODES[c.node], w = WORLDS[n.w], L = levelOf(n);
    const a = Math.min(1, (130 - g.intro) / 14, g.intro / 22);
    ctx.save(); ctx.globalAlpha = a;
    const y = 196, h = 190;
    ctx.fillStyle = lg(0, y, 0, y + h, [[0, 'rgba(10,8,24,0)'], [0.15, 'rgba(10,8,24,0.86)'], [0.85, 'rgba(10,8,24,0.86)'], [1, 'rgba(10,8,24,0)']]); ctx.fillRect(0, y, W, h);
    ctx.textAlign = 'center';
    ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillStyle = w.col; ctx.fillText(`ACT ${w.act}: ${w.title}  ·  LEVEL ${n.l + 1}/4`, W / 2, y + 38);
    ctx.font = '900 26px system-ui, sans-serif'; outlineText(L.name, W / 2, y + 72, '#fff', 'rgba(0,0,0,0.75)', 6);
    ctx.font = 'bold 14px system-ui, sans-serif'; ctx.fillStyle = '#ffd32a'; ctx.fillText(L.obj, W / 2, y + 98);
    ctx.font = '12px system-ui, sans-serif'; ctx.fillStyle = '#dfe6e9'; wrapCenter(L.story, W / 2, y + 122, W - 70, 16);
    ctx.font = '10px system-ui, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ctx.fillText(g.kind === 'convoy' ? 'Plan your moves: steer, HOOP, RAM, SALSA, then END TURN' : g.kind === 'race' ? 'Drag to drift · close calls charge BOOST · TURBO smashes everything' : g.kind === 'rpg' ? 'Drag to move · SLASH to combo · roll through the red ! lunges' : 'Drag to fly · your guns fire on their own', W / 2, y + 166);
    ctx.textAlign = 'left'; ctx.restore();
}
function wrapCenter(text, x, y, maxW, lh) {
    const words = String(text).split(' '); let line = '';
    for (const wd of words) { const test = line ? line + ' ' + wd : wd; if (ctx.measureText(test).width > maxW && line) { ctx.fillText(line, x, y); line = wd; y += lh; } else line = test; }
    if (line) ctx.fillText(line, x, y);
}
function hudSub() {
    if (!g.camp) return fmtTime(g.frames) + '  ·  ' + Math.floor(g.frames * 1.6 / 10) + ' m';
    const n = NODES[g.camp.node]; return `${WORLDS[n.w].act}-${n.l + 1}  ${levelOf(n).name}`;
}
function drawCampHUD() {
    const c = g.camp, st = g.stage; if (!st) return;
    const n = NODES[c.node], L = levelOf(n), w = WORLDS[n.w], bx = 10, by = 56, bw = W - 20, bh = 12;
    let frac = 0, label = '', col = w.col;
    const boss = g.balls.find(b => b.boss && !b.dead);
    if (g.kind === 'convoy') { const h = convoyHud(); frac = h.frac; label = h.label; if (g.cv && g.cv.isBoss) col = '#ff4757'; }
    else if (st.boss) { frac = boss ? boss.hp / boss.maxHp : (st.bossSpawned ? 0 : 1); label = L.bossName; col = '#ff4757'; }
    else if (g.kind === 'shoot') { frac = st.t / st.dur; label = Math.max(0, Math.ceil((st.dur - st.t) / 60)) + 's left'; }
    else if (g.kind === 'race') { frac = g.race.dist / g.race.len; label = Math.round(clamp(frac, 0, 1) * 100) + '%  ·  ' + Math.round(g.race.vShow * 0.75) + ' km/h'; }
    else if (st.goal) { frac = st.goal.t === 'kill' ? st.kills / st.goal.n : st.smashed / st.goal.n; label = st.goal.t === 'kill' ? `Foes ${st.kills}/${st.goal.n}` : `Totems ${st.smashed}/${st.goal.n}`; }
    frac = clamp(frac, 0, 1);
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; roundRect(bx, by, bw, bh, 6); ctx.fill();
    ctx.fillStyle = col; if (frac > 0.01) { roundRect(bx + 1, by + 1, Math.max(6, (bw - 2) * frac), bh - 2, 5); ctx.fill(); }
    ctx.fillStyle = 'rgba(255,255,255,0.25)'; if (frac > 0.01) { roundRect(bx + 2, by + 2, Math.max(4, (bw - 4) * frac), 3.5, 2); ctx.fill(); }
    ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 1; roundRect(bx, by, bw, bh, 6); ctx.stroke();
    ctx.font = 'bold 9px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.fillText(label, W / 2, by + 9); ctx.textAlign = 'left';
    if (g.kind === 'race' && !st.boss) { const fx = bx + 4 + (bw - 8) * frac; ctx.fillStyle = '#ffd32a'; ctx.beginPath(); ctx.arc(fx, by + 6, 4.5, 0, TAU); ctx.fill(); }
    ctx.font = 'bold 11px system-ui, sans-serif'; ctx.textAlign = 'right'; ctx.fillStyle = '#ffe9a0'; ctx.fillText('SCORE ' + g.score, W - 10, 47); ctx.textAlign = 'left';
}
function showClear() {
    const c = g.camp, n = NODES[c.node];
    if (n.w === 3 && n.l === 3) { playEnding(); return; }
    g.live = false; mode = 'clear'; drag = null;
    const noHit = g.lastHurt < g.lvlT0;
    const base = 300 + 120 * c.lvlDone, hpB = Math.round(300 * g.player.hp / g.S.maxHp), nhB = noHit ? 500 : 0;
    const lvlScore = g.score - g.lvlScore0 + base + hpB + nhB;
    g.score += base + hpB + nhB;
    g.clearInfo = { base, hpB, nhB, lvlScore, coins: g.gold - g.lvlGold0, kills: g.kills - g.lvlKills0, time: g.frames - g.lvlT0, noHit };
    c.done[n.id] = 1; c.lvlDone++;
    save.camp.clears[n.id] = Math.max(save.camp.clears[n.id] || 0, lvlScore);
    heal(g, g.S.maxHp * 0.3);
    g.player.hp = Math.min(g.S.maxHp, g.player.hp);
    persist(); sfx('level'); confetti(g, W / 2, 200, 40);
}
function clearContinue() {
    const c = g.camp; c.node++; save.camp.furthest = Math.max(save.camp.furthest, c.node); persist();
    sfx('click'); openMap();
    if (g.pending > 0) { g.returnTo = 'map'; openLevelUp(); }
}
function drawClear() {
    const ci = g.clearInfo, n = NODES[g.camp.node], w = WORLDS[n.w], L = levelOf(n);
    dimBg(0.84); ctx.textAlign = 'center';
    ctx.font = '900 32px system-ui, sans-serif'; outlineText('LEVEL CLEAR!', W / 2, 96, '#7bed9f', 'rgba(0,50,20,0.9)', 7);
    ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillStyle = w.col; ctx.fillText(`ACT ${w.act}: ${w.title}`, W / 2, 124);
    ctx.font = 'bold 17px system-ui, sans-serif'; ctx.fillStyle = '#fff'; ctx.fillText(`${w.act}-${n.l + 1}  ${L.name}`, W / 2, 148);
    const rows = [['Time', fmtTime(ci.time)], ['Foes defeated', String(ci.kills)], ['Coins collected', '+' + ci.coins], ['Level clear bonus', '+' + ci.base], ['Health bonus', '+' + ci.hpB], ['Flawless bonus', ci.noHit ? '+' + ci.nhB : '–']];
    ctx.font = '14px system-ui, sans-serif';
    rows.forEach((r, i) => { const y = 192 + i * 28; ctx.textAlign = 'left'; ctx.fillStyle = '#b2bec3'; ctx.fillText(r[0], 52, y); ctx.textAlign = 'right'; ctx.fillStyle = r[1] === '–' ? '#636e72' : '#fff'; ctx.fillText(r[1], W - 52, y); });
    ctx.textAlign = 'center'; ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillStyle = '#ffd32a'; ctx.fillText('RUN SCORE', W / 2, 378);
    ctx.font = '900 36px system-ui, sans-serif'; outlineText(String(g.score), W / 2, 414, '#ffe066', 'rgba(80,40,0,0.9)', 6);
    ctx.font = '11px system-ui, sans-serif'; ctx.fillStyle = '#58d68d'; ctx.fillText(`Banking this now would pay about ${payout(g.score)} pesos`, W / 2, 438);
    ctx.fillStyle = '#b2bec3'; ctx.fillText(`HP ${Math.ceil(g.player.hp)}/${Math.round(g.S.maxHp)}  ·  Lv ${g.level}  ·  ${g.gold} run coins`, W / 2, 460);
    ctx.textAlign = 'left';
    btn(60, 486, 240, 56, 'CONTINUE', clearContinue, '#2ecc71', 'back to the world map', 22);
}
function drawOver() {
    dimBg(0.86);
    const win = g.win, c = g.camp;
    ctx.textAlign = 'center'; ctx.font = '900 30px system-ui, sans-serif';
    outlineText(win ? 'FIESTA RESTORED!' : 'KNOCKED OUT!', W / 2, 84, win ? '#ffd32a' : '#ff4757', win ? 'rgba(90,40,0,0.9)' : 'rgba(60,0,10,0.9)', 7);
    ctx.font = '12px system-ui, sans-serif'; ctx.fillStyle = '#dfe6e9';
    ctx.fillText(win ? 'El Gran Globo falls. The Golden Sombrero is yours!' : g.newBest || g.newBestScore ? '★ NEW BEST ★' : (c ? 'The run ends here. Your score becomes pesos.' : 'Your score becomes pesos.'), W / 2, 108);
    ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillStyle = '#ffd32a'; ctx.fillText('GAME SCORE', W / 2, 142);
    ctx.font = '900 38px system-ui, sans-serif'; outlineText(String(g.score), W / 2, 180, '#ffe066', 'rgba(80,40,0,0.9)', 6);
    ctx.font = '11px system-ui, sans-serif'; ctx.fillStyle = '#b2bec3'; ctx.fillText(`score bonus ×${payoutMult(g.score).toFixed(2)}  (bigger scores pay more per point)`, W / 2, 200);
    drawPesoIcon(W / 2 - 74, 232, 11); ctx.textAlign = 'left'; ctx.font = '900 24px system-ui, sans-serif'; ctx.fillStyle = '#58d68d'; ctx.fillText('+' + g.pay + ' pesos', W / 2 - 56, 241);
    ctx.textAlign = 'center'; ctx.font = '11px system-ui, sans-serif'; ctx.fillStyle = '#b2bec3'; ctx.fillText(`total ${save.gold} pesos to spend on skills`, W / 2, 262);
    ctx.fillStyle = '#fff'; ctx.font = '14px system-ui, sans-serif';
    let reach = '';
    if (c) { const n = NODES[Math.min(c.node, NODES.length - 1)], w = WORLDS[n.w]; reach = n.type === 'shop' ? `Reached the Act ${w.act} shop` : `Reached Act ${w.act}-${n.l + 1}: ${levelOf(n).name}`; }
    const lines = [reach || `Time  ${fmtTime(g.frames)}  ·  Altitude  ${Math.floor(g.frames * 1.6 / 10)} m`, `Level ${g.level}  ·  Relics ${g.relics.length}  ·  Foes ${g.kills}`, `Best combo ×${g.maxCombo}  ·  Bosses ${g.bossKills}`];
    lines.forEach((l, i) => ctx.fillText(l, W / 2, 298 + i * 24, W - 30));
    ctx.textAlign = 'left';
    btn(70, 392, 220, 52, c ? 'NEW RUN' : 'RIDE AGAIN', c ? openMap : () => startRun(), '#2ecc71', c ? 'open the world map' : null, 20);
    btn(70, 454, 220, 46, 'SKILLS', () => { mode = 'shop'; shopPage = 0; }, '#6c5ce7', 'spend your pesos');
    btn(70, 510, 220, 46, 'MENU', () => { mode = 'menu'; }, '#636e72');
}

// =====================================================================
//  CAMPAIGN FLOW: starting levels, the update dispatcher, shared helpers
// =====================================================================
function newCamp() { return { active: true, node: 0, done: {}, seen: {}, m: 0.25, lvlDone: 0, shops: {} }; }

function beginLevel(wi, li) {
    const w = WORLDS[wi], L = w.levels[li], c = g.camp;
    g.kind = w.kind; g.wi = wi; g.li = li; g.live = true;
    g.balls = []; g.bullets = []; g.ebullets = []; g.pickups = []; g.fx = []; g.texts = []; g.bolts = []; g.toasts = [];
    g.beam = null; g.cape = null; g.event = null; g.streak = null; g.warn = 0; g.timeSlow = 0; g.dust = 0; g.buff = null; g.furyT = 0; g.magT = 0;
    g.combo = 0; g.comboT = 0; g.hitstop = 0; g.shake = 0; g.hurtFlash = 0; g.bombFlash = 0; g.levelFlash = 0; g.clearT = 0; g.aimA = -Math.PI / 2;
    c.m = 0.25 + c.lvlDone * 0.42;
    for (const id in g.actives) g.actives[id].cd = 0;
    const p = g.player; p.vx = p.vy = 0; p.dash = 0; p.iframes = 150; p.facing = 1;
    p.x = W / 2; p.y = w.kind === 'race' ? H - 140 : w.kind === 'rpg' ? H - 170 : H - 150;
    if (g.pet) { g.pet.x = p.x - 30; g.pet.y = p.y - 30; }
    g.lvlScore0 = g.score; g.lvlGold0 = g.gold; g.lvlKills0 = g.kills; g.lvlT0 = g.frames; g.lastHurt = Math.min(g.lastHurt, g.lvlT0 - 1);
    g.stage = { t: 0, boss: !!L.boss, done: false };
    g.skyF = L.sky != null ? L.sky : 0; g.biome = biomeIdx(g.skyF);
    if (w.kind === 'shoot') initShootStage(L); else if (w.kind === 'convoy') initConvoy(L); else if (w.kind === 'race') initRace(L); else initRpg(L);
    mode = 'play'; g.intro = 130; drag = null;
    if (li === 0 && AC && OPT.sfx) andaleVoice(0.05);
    if (g.pending > 0) openLevelUp();
}