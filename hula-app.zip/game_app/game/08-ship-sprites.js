
// =====================================================================
//  THE AVOCADO SHIPS: every enemy (not the bosses) is flown as a cartoon avocado ship with a face, mustache and sombrero.
//  One avocado ship, 37 little sprites (128px, rendered from the 3D model every 5 degrees of turn from 0 = nose down the screen to 180 = nose up, seen from above), recoloured per enemy type at load and given its own trail, aura or gear; it swings to face where it is heading, mirrored for the other side.
//  The hull is drawn to match the enemy's radius, so hit-boxes are unchanged. Bosses keep their old art.
// =====================================================================
const SHIP_BASE = ['data:image/webp;base64,@@B150@@', 'data:image/webp;base64,@@B151@@', 'data:image/webp;base64,@@B152@@', 'data:image/webp;base64,@@B153@@', 'data:image/webp;base64,@@B154@@', 'data:image/webp;base64,@@B155@@', 'data:image/webp;base64,@@B156@@', 'data:image/webp;base64,@@B157@@', 'data:image/webp;base64,@@B158@@', 'data:image/webp;base64,@@B159@@', 'data:image/webp;base64,@@B160@@', 'data:image/webp;base64,@@B161@@', 'data:image/webp;base64,@@B162@@', 'data:image/webp;base64,@@B163@@', 'data:image/webp;base64,@@B164@@', 'data:image/webp;base64,@@B165@@', 'data:image/webp;base64,@@B166@@', 'data:image/webp;base64,@@B167@@', 'data:image/webp;base64,@@B168@@', 'data:image/webp;base64,@@B169@@', 'data:image/webp;base64,@@B170@@', 'data:image/webp;base64,@@B171@@', 'data:image/webp;base64,@@B172@@', 'data:image/webp;base64,@@B173@@', 'data:image/webp;base64,@@B174@@', 'data:image/webp;base64,@@B175@@', 'data:image/webp;base64,@@B176@@', 'data:image/webp;base64,@@B177@@', 'data:image/webp;base64,@@B178@@', 'data:image/webp;base64,@@B179@@', 'data:image/webp;base64,@@B180@@', 'data:image/webp;base64,@@B181@@', 'data:image/webp;base64,@@B182@@', 'data:image/webp;base64,@@B183@@', 'data:image/webp;base64,@@B184@@', 'data:image/webp;base64,@@B185@@', 'data:image/webp;base64,@@B186@@'].map(u => { const im = new Image(); im.src = u; return im; });   // one ship, 37 turn angles
const SHIP_TINT = {   // hull recolour per type: [hue, saturation x, lightness x] relative to the green basic ship
    basic: null,
    fast: [163, 1.88, 1.51],
    zig: [339, 2.21, 1.75],
    big: [12, 1.59, 1.45],
    armored: [184, 0.20, 1.47],
    golden: [48, 2.03, 1.20],
    pistolero: [28, 1.81, 1.23],
    splitter: [168, 1.72, 1.00],
    dive: [9, 2.28, 1.53],
    shielded: [213, 2.28, 1.58],
    bomber: [240, 0.21, 0.77],
    elite: [282, 0.99, 1.13],
    mender: [168, 2.28, 0.86],
    pinata: [39, 2.21, 1.70]
};
const SHIP_IMG = {};   // per type: recoloured frames, built the first time a ship of that type is drawn
function shipTintFrame(im, t) {
    const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d'); x.drawImage(im, 0, 0, 128, 128);
    if (!t) return c;
    const d = x.getImageData(0, 0, 128, 128), p = d.data, H2 = t[0] / 360;
    const hue2 = (q, pp, tt) => { if (tt < 0) tt += 1; if (tt > 1) tt -= 1; return tt < 1 / 6 ? q + (pp - q) * 6 * tt : tt < 0.5 ? pp : tt < 2 / 3 ? q + (pp - q) * (2 / 3 - tt) * 6 : q; };
    for (let i = 0; i < p.length; i += 4) {
        if (p[i + 3] < 8) continue;
        const r = p[i] / 255, g = p[i + 1] / 255, b = p[i + 2] / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), dl = mx - mn;
        if (dl < 0.06) continue;
        const l = (mx + mn) / 2, s = dl / (1 - Math.abs(2 * l - 1));
        let h = mx === r ? ((g - b) / dl + (g < b ? 6 : 0)) : mx === g ? (b - r) / dl + 2 : (r - g) / dl + 4; h *= 60;   // only the green hull is recoloured: the hat, face, mustache and flames keep their colours
        const w = Math.min(1, Math.max(0, (h - 52) / 12)) * Math.min(1, Math.max(0, (170 - h) / 20)) * Math.min(1, s / 0.2);
        if (w <= 0) continue;
        const s2 = Math.min(1, s * t[1]), l2 = Math.min(0.96, l * t[2]), q = l2 < 0.5 ? l2 * (1 + s2) : l2 + s2 - l2 * s2, pp = 2 * l2 - q;
        p[i] += (hue2(pp, q, H2 + 1 / 3) * 255 - p[i]) * w; p[i + 1] += (hue2(pp, q, H2) * 255 - p[i + 1]) * w; p[i + 2] += (hue2(pp, q, H2 - 1 / 3) * 255 - p[i + 2]) * w;
    }
    x.putImageData(d, 0, 0); return c;
}
// the menu and cutscene balls are ships too: each of the five ball colours is flown by one ship type
const SHIP_OF_COL = { '#ff6b6b': 'dive', '#4ecdc4': 'fast', '#ffe66d': 'golden', '#a29bfe': 'shielded', '#ff9ff3': 'zig' };
function shipOf(b) {   // the ship sprites for an enemy, once the base ship has loaded (bosses keep their old art)
    if (b.boss || !SHIP_BASE.every(im => im.complete && im.naturalWidth)) return null;
    const ty = SHIP_TINT[b.type] !== undefined ? b.type : 'basic';
    return SHIP_IMG[ty] || (SHIP_IMG[ty] = { fr: SHIP_BASE.map(im => shipTintFrame(im, SHIP_TINT[ty])), hw: 60, white: [] });
}
function shipWhite(s, f) {   // hit flash: the same silhouette in white, built once per frame
    if (!s.white[f]) {
        const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
        x.drawImage(s.fr[f], 0, 0, 128, 128); x.globalCompositeOperation = "source-atop"; x.fillStyle = "#fff"; x.fillRect(0, 0, 128, 128); s.white[f] = c;
    }
    return s.white[f];
}
const SHIP_STEP = Math.PI / 36, SHIP_NF = 37;

// ---- each colour has its own look: small effects drawn around the recoloured ship (behind = trails and auras, front = badges and gear) ----
function shipTrait(b, hd, front) {
    const r = b.r, T = menuT + (b.phase || 0), fx = Math.sin(hd), fy = Math.cos(hd), px = fy, py = -fx;   // forward, and sideways
    ctx.save(); ctx.translate(b.x, b.y);
    switch (b.type) {
    case 'fast': if (!front) {   // speed streaks trailing behind
        ctx.lineCap = 'round'; for (let i = -1; i <= 1; i++) { const o = i * r * 0.55, l = r * (1.5 + 0.5 * Math.sin(T * 0.3 + i * 2)); ctx.strokeStyle = 'rgba(255,255,255,' + (i ? 0.35 : 0.55) + ')'; ctx.lineWidth = Math.max(1.5, r * 0.09); ctx.beginPath(); ctx.moveTo(px * o - fx * r * 0.8, py * o - fy * r * 0.8); ctx.lineTo(px * o - fx * (r * 0.8 + l), py * o - fy * (r * 0.8 + l)); ctx.stroke(); } } break;
    case 'dive': if (!front) {   // a flame trail
        for (let i = 0; i < 4; i++) { const d = r * (0.8 + i * 0.5), q = r * (0.5 - i * 0.1) * (1 + 0.15 * Math.sin(T * 0.6 + i)); ctx.fillStyle = ['rgba(255,240,150,0.85)', 'rgba(255,170,40,0.7)', 'rgba(255,90,40,0.5)', 'rgba(200,40,30,0.3)'][i]; ctx.beginPath(); ctx.arc(-fx * d, -fy * d, Math.max(1, q), 0, TAU); ctx.fill(); } } break;
    case 'zig': if (!front) {   // a crackling zigzag trail
        ctx.strokeStyle = 'rgba(255,120,190,0.75)'; ctx.lineWidth = Math.max(1.5, r * 0.1); ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(-fx * r * 0.7, -fy * r * 0.7);
        for (let i = 1; i <= 5; i++) { const d = r * (0.7 + i * 0.38), o = (i % 2 ? 1 : -1) * r * 0.32; ctx.lineTo(-fx * d + px * o, -fy * d + py * o); } ctx.stroke(); } break;
    case 'golden': if (!front) {   // a pulsing golden glow and glints
        const g = ctx.createRadialGradient(0, 0, r * 0.3, 0, 0, r * 2.1), pu = 0.5 + 0.5 * Math.sin(T * 0.12); g.addColorStop(0, 'rgba(255,225,80,' + (0.5 + 0.2 * pu) + ')'); g.addColorStop(1, 'rgba(255,200,0,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r * 2.1, 0, TAU); ctx.fill();
        } else { for (let i = 0; i < 3; i++) { const a = T * 0.05 + i * 2.1, q = 0.5 + 0.5 * Math.sin(T * 0.2 + i * 1.7); ctx.fillStyle = 'rgba(255,255,220,' + q + ')'; ctx.beginPath(); ctx.arc(Math.cos(a) * r * 1.1, Math.sin(a) * r * 0.9, r * 0.09 * (0.5 + q), 0, TAU); ctx.fill(); } } break;
    case 'elite': if (!front) {   // a violet aura
        const g = ctx.createRadialGradient(0, 0, r * 0.5, 0, 0, r * 1.9); g.addColorStop(0, 'rgba(170,90,255,0.35)'); g.addColorStop(1, 'rgba(170,90,255,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r * 1.9, 0, TAU); ctx.fill();
        } else {   // a little gold crown
        const cx = 0, cy = -r * 1.28, w = r * 0.62, h = r * 0.42; ctx.fillStyle = '#ffd43b'; ctx.strokeStyle = '#8a5a00'; ctx.lineWidth = Math.max(1, r * 0.05);
        ctx.beginPath(); ctx.moveTo(cx - w / 2, cy + h / 2); ctx.lineTo(cx - w / 2, cy - h / 4); ctx.lineTo(cx - w / 4, cy + h / 8); ctx.lineTo(cx, cy - h / 2); ctx.lineTo(cx + w / 4, cy + h / 8); ctx.lineTo(cx + w / 2, cy - h / 4); ctx.lineTo(cx + w / 2, cy + h / 2); ctx.closePath(); ctx.fill(); ctx.stroke(); } break;
    case 'pinata': if (!front) {   // orbiting confetti
        const cols = ['#ff6b6b', '#ffe66d', '#4ecdc4', '#a29bfe', '#ff9ff3', '#54a0ff']; for (let i = 0; i < 6; i++) { const a = T * 0.04 + i * 1.047, d = r * (1.25 + 0.15 * Math.sin(T * 0.1 + i)); ctx.fillStyle = cols[i]; ctx.save(); ctx.translate(Math.cos(a) * d, Math.sin(a) * d * 0.8); ctx.rotate(a * 3); ctx.fillRect(-r * 0.09, -r * 0.05, r * 0.18, r * 0.1); ctx.restore(); } } break;
    case 'armored': if (front) {   // steel plates around the hull
        ctx.lineCap = 'butt'; for (let i = 0; i < 4; i++) { const a0 = i * Math.PI / 2 + 0.35; ctx.strokeStyle = '#8795a1'; ctx.lineWidth = Math.max(2, r * 0.2); ctx.beginPath(); ctx.arc(0, 0, r * 1.02, a0, a0 + 0.9); ctx.stroke(); ctx.strokeStyle = '#dfe6e9'; ctx.lineWidth = Math.max(1, r * 0.06); ctx.beginPath(); ctx.arc(0, 0, r * 1.07, a0 + 0.05, a0 + 0.8); ctx.stroke(); } } break;
    case 'bomber': if (front) {   // a bomb slung underneath, with a sparking fuse
        const by = r * 1.15, br = r * 0.3; ctx.fillStyle = '#2d3436'; ctx.beginPath(); ctx.arc(0, by, br, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.beginPath(); ctx.arc(-br * 0.3, by - br * 0.3, br * 0.25, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#b2bec3'; ctx.lineWidth = Math.max(1, r * 0.05); ctx.beginPath(); ctx.moveTo(br * 0.4, by - br * 0.8); ctx.lineTo(br * 0.8, by - br * 1.3); ctx.stroke(); ctx.fillStyle = Math.sin(T * 0.7) > 0 ? '#ffe66d' : '#ff6b6b'; ctx.beginPath(); ctx.arc(br * 0.8, by - br * 1.3, r * 0.08, 0, TAU); ctx.fill(); } break;
    case 'pistolero': if (front) {   // a revolver at its side
        ctx.save(); ctx.translate(r * 1.0, r * 0.25); ctx.rotate(-0.4); ctx.fillStyle = '#636e72'; ctx.fillRect(-r * 0.05, -r * 0.08, r * 0.5, r * 0.16); ctx.fillStyle = '#8d5524'; ctx.beginPath(); ctx.moveTo(-r * 0.05, -r * 0.08); ctx.lineTo(-r * 0.22, r * 0.2); ctx.lineTo(-r * 0.02, r * 0.16); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#2d3436'; ctx.beginPath(); ctx.arc(r * 0.05, 0, r * 0.1, 0, TAU); ctx.fill(); ctx.restore(); } break;
    case 'splitter': if (front) {   // a dashed seam where it will split in two
        ctx.setLineDash([r * 0.18, r * 0.14]); ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = Math.max(1.5, r * 0.07); ctx.beginPath(); ctx.moveTo(px * -r * 0.0 - fx * r * 1.05, py * -r * 0.0 - fy * r * 1.05); ctx.lineTo(fx * r * 1.05, fy * r * 1.05); ctx.stroke(); ctx.setLineDash([]); } break;
    case 'mender': if (front) {   // a pulsing medic cross
        const bx = r * 0.95, by = -r * 0.75, br = r * 0.3 * (1 + 0.12 * Math.sin(T * 0.15)); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.fill(); ctx.fillStyle = '#00b894'; ctx.fillRect(bx - br * 0.65, by - br * 0.2, br * 1.3, br * 0.4); ctx.fillRect(bx - br * 0.2, by - br * 0.65, br * 0.4, br * 1.3); } break;
    }
    ctx.restore();
}
function drawShip(b, s) {
    // heading: 0 = nose straight down the screen (the way they fly in); it swings toward the velocity, all the way round, so a ship knocked upward shows its tail
    // velocity: the real movement since the last frame (catches sway, zigzags, bounces), else the ball's own vx/vy (menu and cutscene balls are rebuilt every frame)
    let vx = b.vx || 0, vy = b.vy || 0; const now = performance.now();
    if (b._lt === undefined || now - b._lt > 150) { b._lt = now; b._lx = b.x; b._ly = b.y; b._ov = false; }
    else if (now - b._lt > 6) {
        const dt = (now - b._lt) / 16.7, dx = (b.x - b._lx) / dt, dy = (b.y - b._ly) / dt;
        if (Math.abs(dx) < 30 && Math.abs(dy) < 30) { b._ox = b._ov ? b._ox + (dx - b._ox) * 0.12 : dx; b._oy = b._ov ? b._oy + (dy - b._oy) * 0.12 : dy; b._ov = true; }
        b._lt = now; b._lx = b.x; b._ly = b.y;
    }
    if (b._ov) { vx = b._ox; vy = b._oy; }
    const sp = Math.hypot(vx, vy);
    let tx = vx * 1.8, ty = vy, has = sp > 0.2;
    const pl = (b.id !== undefined && mode === 'play' && g && g.player) ? g.player : null;
    if (pl) {   // in a run the ships also keep their nose on you: the heading is mostly toward the hero, a little toward where they are flying
        const ax = pl.x - b.x, ay = pl.y - b.y, al = Math.hypot(ax, ay) || 1, ml = Math.hypot(tx, ty) || 1;
        tx = (ax / al) * 0.7 + (has ? (tx / ml) * 0.3 : 0); ty = (ay / al) * 0.7 + (has ? (ty / ml) * 0.3 : 0); has = true;
    }
    if (has) {
        const want = Math.atan2(tx, ty);   // 0 = nose down the screen, +-PI = nose up
        if (b.hd === undefined) b.hd = want; else { let df = want - b.hd; df -= TAU * Math.round(df / TAU); b.hd += clamp(df * 0.08, -0.06, 0.06); b.hd -= TAU * Math.round(b.hd / TAU); }
    } else if (b.hd === undefined) b.hd = 0;
    const hd = b.hd, a = Math.abs(hd), f = Math.min(SHIP_NF - 1, Math.round(a / SHIP_STEP)), resid = (a - f * SHIP_STEP) * Math.sign(hd);   // nearest turn sprite, the small remainder done by rotating it (no blending, so no ghosting)
    const k = (b.r * 2 * 1.12) / s.hw, sz = 192 * k, bob = Math.sin((menuT + b.phase) * 0.08) * 0.05;
    shipTrait(b, hd, 0);
    ctx.save(); ctx.translate(b.x, b.y); const rot = bob - resid; if (rot) ctx.rotate(rot); if (hd < 0) ctx.scale(-1, 1);
    ctx.drawImage(b.flash > 0 ? shipWhite(s, f) : s.fr[f], -sz / 2, -sz / 2, sz, sz);
    ctx.restore();
    shipTrait(b, hd, 1);
}
