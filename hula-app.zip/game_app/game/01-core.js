'use strict';
// =====================================================================
//  HULA VAQUERO: SKY RIDE  -  DELUXE
//  Fly upward on your spinning hoop, blast the falling balls,
//  level up, collect relics, and spend gold on permanent skills.
//  Now with an options menu, up to 4x resolution, upgraded graphics,
//  sombreros on every enemy, and a pile of new features.
// =====================================================================

const canvas = document.getElementById('game');
let ctx = canvas.getContext('2d');   // swapped briefly while rendering cached sprites
const W = 360, H = 640, TAU = Math.PI * 2;
const spriteCache = new Map(), glowCache = new Map(), hatCache = new Map(), faceCache = new Map(), HV = new Map();
let spGen = 0;
function clearSprites() { spGen++; spriteCache.clear(); hatCache.clear(); faceCache.clear(); HV.clear(); }
// render a small piece of art once into an offscreen canvas, then blit it every frame
function cachedDraw(map, key, ox, oy, w, h, SR, fn) {
    let e = map.get(key);
    if (e) return e;
    if (map.size > 160) map.clear();
    const cv = document.createElement('canvas'); cv.width = Math.max(1, Math.ceil(w * SR)); cv.height = Math.max(1, Math.ceil(h * SR));
    const prev = ctx; ctx = cv.getContext('2d'); ctx.setTransform(SR, 0, 0, SR, ox * SR, oy * SR);
    try { fn(); } finally { ctx = prev; }
    e = { cv, ox, oy, w, h }; map.set(key, e);
    return e;
}
let RES = 2;
// adaptive-quality governor state (see frame() in the main loop): hq = how many tiers the 3D hero's shading/supersampling is lowered, undo = how to put back each step taken
const QG = { hq: 0, undo: [], good: 0, wait: 30, lastUp: -1e9 };

// ---------- helpers ----------
const rand = (a, b) => a + Math.random() * (b - a);
const randi = (a, b) => Math.floor(rand(a, b + 1));
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const fmtTime = f => { const s = Math.floor(f / 60); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const rgbMemo = new Map();
function hexToRgb(h) { let r = rgbMemo.get(h); if (!r) { const n = parseInt(h.slice(1), 16); r = [(n >> 16) & 255, (n >> 8) & 255, n & 255]; if (rgbMemo.size > 400) rgbMemo.clear(); rgbMemo.set(h, r); } return r; }
function lerpColor(a, b, t) {
    const A = hexToRgb(a), B = hexToRgb(b);
    return `rgb(${Math.round(A[0] + (B[0] - A[0]) * t)},${Math.round(A[1] + (B[1] - A[1]) * t)},${Math.round(A[2] + (B[2] - A[2]) * t)})`;
}
// t>0 lightens toward white, t<0 darkens toward black
const shadeMemo = new Map();
function shade(h, t) {
    const key = h + t; let s = shadeMemo.get(key);
    if (s) return s;
    const c = hexToRgb(h), f = t >= 0 ? 255 : 0, a = Math.abs(t);
    s = `rgb(${Math.round(c[0] + (f - c[0]) * a)},${Math.round(c[1] + (f - c[1]) * a)},${Math.round(c[2] + (f - c[2]) * a)})`;
    if (shadeMemo.size > 600) shadeMemo.clear();
    shadeMemo.set(key, s); return s;
}
function hsl2hex(h, s, l) {
    s /= 100; l /= 100;
    const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
    const f = n => Math.round(255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))));
    return '#' + [f(0), f(8), f(4)].map(v => v.toString(16).padStart(2, '0')).join('');
}

// ---------- persistent save + options ----------
const SAVE_KEY = 'hulaVaquero_skyride_v1';
const DEFAULT_OPTS = {
    res: 2, hq: 1, gfx: 2, hd: true, hats: true, stache: true, faces: true, glow: true, parts: 1, fps: false,
    diff: 1, intro: 0, shake: true, dmgnums: true, haptics: true, blurPause: true,
    sfx: true, sfxvol: 0.75, music: true, musicvol: 0.5, sens: 1.3, auto: true, calm: false, beatOff: 0,
};
let save = { gold: 0, bestTime: 0, bestLevel: 0, skills: {}, opts: {}, stats: {}, ach: {}, cos: {} };
try { const s = JSON.parse(localStorage.getItem(SAVE_KEY)); if (s && typeof s === 'object') save = Object.assign(save, s); } catch (e) {}
for (const k of ['skills', 'opts', 'stats', 'ach', 'cos']) if (!save[k] || typeof save[k] !== 'object') save[k] = {};   // a damaged save can't crash startup
if (typeof save.gold !== 'number' || !isFinite(save.gold)) save.gold = 0;
const OPT = save.opts = Object.assign({}, DEFAULT_OPTS, save.opts || {});
if (!save.up3) { save.up3 = 1; try { if ((window.devicePixelRatio || 1) >= 2.5 && OPT.res < 3) OPT.res = 3; } catch (e) {} }   // one-time: sharp phone screens get 3x
save.stats = Object.assign({ runs: 0, kills: 0, goldEarned: 0, time: 0, bosses: 0, maxCombo: 0, hats: 0, bestKills: 0 }, save.stats || {});
save.ach = save.ach || {};
save.cos = Object.assign({ hat: [0], hoop: [0], trail: [0] }, save.cos || {});
save.cos.eq = Object.assign({ hat: 0, hoop: 0, trail: 0 }, save.cos.eq || {});
function pickPowerup() {   // weighted: most are 1, the Piñata Bomb is rare
    const ks = Object.keys(POWERUPS); let tot = 0; for (const k of ks) tot += POWERUPS[k].rare || 1;
    let r = Math.random() * tot; for (const k of ks) { r -= POWERUPS[k].rare || 1; if (r <= 0) return k; }
    return ks[0];
}
if (save.skills && save.skills.bomb) {   // the old Piñata Bomb skill became a rare drop: refund the gold
    let refund = 0; for (let i = 0; i < save.skills.bomb; i++) refund += Math.round(90 * Math.pow(1.7, i));
    save.gold += refund; delete save.skills.bomb;
}
function persist() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) {} }

// largest scale the device can safely allocate (mobile browsers cap canvas area near 16.7M pixels)
function maxRes() {
    const mobile = /Android|iPhone|iPad|iPod|Mobile/i.test((typeof navigator !== 'undefined' && navigator.userAgent) || '');
    return Math.max(1, Math.floor(Math.sqrt((mobile ? 16777216 : 200000000) / (W * H))));
}
function applyRes() {
    RES = Math.min(OPT.res, maxRes());
    canvas.width = W * RES; canvas.height = H * RES;
    ctx.setTransform(RES, 0, 0, RES, 0, 0);
    clearSprites();
}
applyRes();

const DIFF = [
    { name: 'Easy',      hp: 0.75, dmg: 0.7,  gold: 0.8, spawn: 0.85 },
    { name: 'Normal',    hp: 1,    dmg: 1,    gold: 1,   spawn: 1 },
    { name: 'Hard',      hp: 1.35, dmg: 1.25, gold: 1.3, spawn: 1.2 },
    { name: 'Nightmare', hp: 1.8,  dmg: 1.6,  gold: 1.8, spawn: 1.5 },
];

// =====================================================================
//  AUDIO (all synthesized, no files)
// =====================================================================
let ENG2 = true; try { ENG2 = localStorage.getItem('hv_eng2') !== '0'; } catch (e) {}   // engine v2: singer's formant + vibrato growth + scoop on sung voices, glue compressor + limiter on the master (toggle in the secret menu, MUSICAL tab)
let ENG2_GLUE = null, ENG2_LIM = null;
function setEng2(on) {
    ENG2 = !!on; try { localStorage.setItem('hv_eng2', on ? '1' : '0'); } catch (e) {}
    if (AC && ENG2_GLUE) { ENG2_GLUE.threshold.value = on ? -20 : 0; ENG2_GLUE.ratio.value = on ? 2.2 : 1; ENG2_LIM.threshold.value = on ? -2.5 : 0; ENG2_LIM.ratio.value = on ? 20 : 1; }   // off = both ratios 1: they pass the signal untouched
}
let AC = null, sfxGain = null, musGain = null, musOut = null, musTimer = null, musStep = 0, musNext = 0;
const lastSfx = {};
function audioInit() {
    if (AC) { nsongPreload(); if (AC.state === 'suspended' || AC.state === 'interrupted') AC.resume(); return; }
    try {
        const C = window.AudioContext || window.webkitAudioContext;
        if (!C) return;
        AC = new C();
        sfxGain = AC.createGain(); musGain = AC.createGain(); musOut = AC.createGain(); musGain.connect(musOut);   // musGain = the band only (so it can duck under the sung words); musOut = band + voices, the user's music volume
        const comp = AC.createDynamicsCompressor();
        comp.threshold.value = -14; comp.knee.value = 12; comp.ratio.value = 6; comp.attack.value = 0.004; comp.release.value = 0.18;
        const master = AC.createGain(); master.gain.value = 0.9;
        const lim = AC.createDynamicsCompressor(); lim.knee.value = 0; lim.attack.value = 0.001; lim.release.value = 0.09; ENG2_LIM = lim;   // brick-wall-ish limiter on the very end: nothing reaches the speakers hot, however many voices stack
        sfxGain.connect(comp); comp.connect(master); master.connect(lim); lim.connect(AC.destination);
        {   // music bus: gentle top-end roll-off (takes the digital fizz off), plus a shared hall reverb so the band sounds like one room
            const tone = AC.createBiquadFilter(); tone.type = 'lowpass'; tone.frequency.value = 11000; tone.Q.value = 0.5;
            const len = (AC.sampleRate * 1.5) | 0, ir = AC.createBuffer(2, len, AC.sampleRate);
            for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); let lp = 0; for (let i = 0; i < len; i++) { lp += (Math.random() * 2 - 1 - lp) * 0.22; d[i] = lp * Math.pow(1 - i / len, 3); } }
            const cv = AC.createConvolver(); cv.buffer = ir; const wet = AC.createGain(); wet.gain.value = 0.16;
            const glue = AC.createDynamicsCompressor(); glue.knee.value = 10; glue.attack.value = 0.03; glue.release.value = 0.28; ENG2_GLUE = glue;   // slow, gentle bus compressor: band, voices and sung words settle into one mix
            musOut.connect(glue); glue.connect(tone); tone.connect(comp); glue.connect(cv); cv.connect(wet); wet.connect(comp);
            setEng2(ENG2);
        }
        noiseBuf = AC.createBuffer(1, (AC.sampleRate * 0.5) | 0, AC.sampleRate);
        { const d = noiseBuf.getChannelData(0); for (let k = 0; k < d.length; k++) d[k] = Math.random() * 2 - 1; }
        crowdBuf = AC.createBuffer(1, (AC.sampleRate * 2) | 0, AC.sampleRate);
        { const d = crowdBuf.getChannelData(0); for (let k = 0; k < d.length; k++) d[k] = Math.random() * 2 - 1; }
        AC.onstatechange = () => { if (AC.state === 'running' && musStep < 8) { musStep = 0; musNext = AC.currentTime + 0.1; musT0 = musNext; } };
        applyVol(); smpLoad(); startMusic();
    } catch (e) { AC = null; }
}
function applyVol() {
    if (!AC) return;
    const t = AC.currentTime;   // short glide instead of a hard jump: no clicks when sliders or mute toggles move
    sfxGain.gain.setTargetAtTime(OPT.sfx ? OPT.sfxvol : 0, t, 0.015);
    musOut.gain.setTargetAtTime(OPT.music ? OPT.musicvol * 0.5 : 0, t, 0.015); musGain.gain.setTargetAtTime(1, t, 0.015);
}