function startCutsceneList(list, onEnd, idx) { cs = { i: idx || 0, t: 0, list, end: onEnd }; mode = 'cutscene'; drag = null; }
function playEnding() { if (OPT.intro === 2) endRun(true); else startCutsceneList(END_CUTS, () => endRun(true)); }

// =====================================================================
//  SECRET CUTSCENE THEATER: tap the BEST pill on the main menu 3 times
// =====================================================================
let secTaps = 0, secTapT = 0;
function secretTap() {
    const now = performance.now(); secTaps = now - secTapT < 1500 ? secTaps + 1 : 1; secTapT = now;
    if (secTaps >= 3) { secTaps = 0; mode = 'cutmenu'; sfx('level'); }
}
function playFrom(list, idx) {
    startCutsceneList(list, () => { mode = 'cutmenu'; cs = null; }, idx || 0);
    sfx('click');
}
function drawCutMenu() {
    dimBg(0.8);
    screenTitle('CUTSCENE THEATER', 'pick a scene to watch'); secretTabs('cutmenu');
    const cell = (x, y, w, h, label, fn, col) => {
        uiButtons.push({ x, y, w, h, fn });
        ctx.fillStyle = col; roundRect(x, y, w, h, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1.2; roundRect(x, y, w, h, 7); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(label, x + w / 2, y + h / 2 + 4, w - 8); ctx.textAlign = 'left';
    };
    ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillText('STORY', 16, 84);
    const story = [['Act 1 intro', CUT], ['Act 2 intro', ACT_CUTS[1]], ['Act 3 intro', ACT_CUTS[2]], ['Act 4 intro', ACT_CUTS[3]], ['FULL ENDING', END_CUTS]];
    story.forEach((s, i) => cell(14 + (i % 2) * 168, 92 + Math.floor(i / 2) * 32, 164, 28, s[0], () => playFrom(s[1], 0), i === 4 ? '#c0392b' : '#6c5ce7'));
    ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillText('ENDING SCENES (plays on from there)', 16, 204);
    END_CUTS.forEach((sc, i) => cell(14 + (i % 2) * 168, 212 + Math.floor(i / 2) * 26, 164, 24, (i + 1) + '. ' + sc.title, () => playFrom(END_CUTS, i), '#2d3a6b'));
    btn(14, 586, 164, 40, 'SONG TEST', () => { secretGo('songmenu'); }, '#16a085');
    btn(182, 586, 164, 40, 'BACK', () => { secretGo('menu'); }, '#6c5ce7');
}
// the musical (a test): THE WHY through THE BREAKING as four sung numbers. These scenes exist only here; the regular cutscenes are unchanged.
function playMusical(idx) { startCutsceneList(MUSICAL_CUTS, () => { mode = 'musmenu'; cs = null; }, idx || 0); sfx('click'); }
function drawMusMenu() {
    dimBg(0.8);
    screenTitle('THE MUSICAL', 'a test: THE WHY through THE BREAKING, sung'); secretTabs('musmenu');
    const cell = (x, y, w, h, label, fn, col) => {
        uiButtons.push({ x, y, w, h, fn });
        ctx.fillStyle = col; roundRect(x, y, w, h, 8); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1.2; roundRect(x, y, w, h, 8); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(label, x + w / 2, y + h / 2 + 5, w - 10); ctx.textAlign = 'left';
    };
    cell(14, 96, 332, 48, 'PLAY THE WHOLE MUSICAL', () => playMusical(0), '#c0392b');
    ctx.fillStyle = '#ffd32a'; ctx.font = 'bold 11px system-ui, sans-serif'; ctx.fillText('OR ONE NUMBER AT A TIME', 16, 172);
    MUSICAL_CUTS.forEach((sc, i) => cell(14, 182 + i * 54, 332, 46, (i + 1) + '. ' + sc.title, () => { startCutsceneList([MUSICAL_CUTS[i]], () => { mode = 'musmenu'; cs = null; }, 0); sfx('click'); }, '#2d3a6b'));
    cell(14, 436, 332, 40, 'ENGINE V2: ' + (ENG2 ? 'ON' : 'OFF') + '  (tap to compare)', () => { setEng2(!ENG2); sfx('click'); }, ENG2 ? '#1e8449' : '#555');
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.font = '11px system-ui, sans-serif'; ctx.fillText('V2 = singer\'s formant, vibrato that grows, glue compressor + limiter.', 16, 494);
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.font = '11px system-ui, sans-serif'; ctx.fillText('Each number plays on its own band. Tap to skip ahead.', 16, 420);
    btn(14, 586, 332, 40, 'BACK', () => { secretGo('cutmenu'); }, '#6c5ce7');
}
// =====================================================================
//  VOICE LAB (secret menu tab). Every spoken or sung word in the game goes through one voice synthesizer; here each word gets its own sliders.
//  Pick SPEECH or SONG, pick ALL WORDS or one word, tap a sample, drag a slider (or tap the number and type one), hear it again.
//  SAVE = a new numbered version the game uses from then on (last 11 kept, step back with OLDER). SEND TO CLAUDE stores the settings where Claude can read them.
// =====================================================================
function miniBtn(x, y, w, h, label, fn, col, fs = 11, hot) {
    uiButtons.push({ x, y, w, h, fn });
    ctx.fillStyle = col; roundRect(x, y, w, h, 7); ctx.fill();
    ctx.strokeStyle = hot ? '#ffd32a' : 'rgba(255,255,255,0.35)'; ctx.lineWidth = hot ? 2 : 1.2; roundRect(x, y, w, h, 7); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.font = 'bold ' + fs + 'px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(label, x + w / 2, y + h / 2 + fs * 0.36, w - 6); ctx.textAlign = 'left';
}
function secretGo(m) { mode = m; songTest = null; sfx('click'); applyVol(); }
function secretTabs(active) {
    const T = [['THEATER', 'cutmenu'], ['SONGS', 'songmenu'], ['MUSICAL', 'musmenu']], w = (W - 28 - 8) / 3;
    T.forEach(([l, m], i) => miniBtn(14 + i * (w + 4), 4, w, 22, l, () => secretGo(m), m === active ? '#16a085' : '#2d3a6b', 11, m === active));
}
// key, label, min, max, step, where it applies (S = speech, G = song), explanation (tap the name in the lab)
let uiDrag = null, uiDragId = -1;
let songTest = null;
function playSongTest(k) { songTest = k; musTrack = null; sfx('click'); }   // musTrack=null forces the sequencer to restart the track even when it is already playing
function drawSongMenu() {
    dimBg(0.8);
    screenTitle('SONG TEST', songTest ? 'now playing: ' + songTest : 'pick a track to hear it'); secretTabs('songmenu');
    const keys = Object.keys(TRACKS), rows = Math.ceil(keys.length / 2);
    const pitch = Math.min(26, Math.floor(480 / rows));
    keys.forEach((k, i) => {
        const x = 14 + (i % 2) * 168, y = 84 + Math.floor(i / 2) * pitch, w = 164, h = pitch - 2, on = k === songTest;
        uiButtons.push({ x, y, w, h, fn: () => playSongTest(k) });
        ctx.fillStyle = on ? '#16a085' : '#2d3a6b'; roundRect(x, y, w, h, 7); ctx.fill();
        ctx.strokeStyle = on ? '#ffd32a' : 'rgba(255,255,255,0.35)'; ctx.lineWidth = on ? 2 : 1.2; roundRect(x, y, w, h, 7); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(k, x + w / 2, y + h / 2 + 4, w - 8); ctx.textAlign = 'left';
    });
    btn(14, 586, 164, 40, 'STOP', () => { songTest = null; sfx('click'); }, '#c0392b');
    btn(182, 586, 164, 40, 'BACK', () => { secretGo('cutmenu'); }, '#6c5ce7');
}