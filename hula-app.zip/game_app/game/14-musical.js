// =====================================================================
//  THE MUSICAL (a test; secret theater only). THE WHY, THE TANGENT, THE STASH and THE BREAKING re-told as four sung numbers.
//  The regular cutscenes are untouched: these are separate scenes that reuse the same art (csWhy) with sung lines.
//  Each number is its own track (sty 'stage'): the band is the sequencer, and it also sings the words (see seqStep) so voice and band share one clock.
// =====================================================================
const muIs = () => !!(cs && cs.list && cs.list[0] && cs.list[0].mu);   // is the cutscene that is playing one of the musical's scenes (the whole musical or a single number)?
const MU_LEAD = 0;   // (scene time is the band's own clock: see csSfx, so line times are bar times)
function muS(str) { return str.trim().split(/\s+/).map(t => { const [w, st, ln, no, ox] = t.split(':'); const r = [w, +st, +ln, nn(no)]; if (ox) { const o = {}, f = /f([\d.]+)/.exec(ox), g = /g(-?[\d.]+)/.exec(ox); if (f) o.fade = +f[1]; if (g) o.glide = +g[1]; r.push(o); } return r; }); }   // 'syllable:step:length:note[:f<end loudness>g<glide semitones>]'   // 'syllable:step:length:note'; a leading + continues the word (the same word, next note)
Object.assign(SING_LEX, { mis: 'M IH S', ter: 'T AH R', ahh: 'AA', be: 'B I', cause: 'K AW Z', nev: 'N EH V', er: 'AH R', he: 'H I', ro: 'R OW', lit: 'L IH T', tle: 'T AH L', kay: 'K EY', o: 'OW', whoa: 'W OW', ing: 'IH NG', ty: 'T I', bod: 'B AA D', y: 'I', geth: 'G EH TH', ry: 'R I', sor: 'S AA R', ev: 'EH V', ven: 'V EH N', mem: 'M EH M', ber: 'B AH R', re: 'R I', lage: 'L IH J', un: 'AH N', der: 'D AH R', neath: 'N I TH', whis: 'W IH S', per: 'P AH R', bout: 'B AU T', ping: 'P IH NG', selves: 'S EH L V Z', ly: 'L I', ways: 'W EY Z', float: 'F L OW T', fies: 'F Y EH S', tas: 'T A S', bre: 'B R EH', som: 'S OW M', real: 'R I L', ask: 'A S K', thir: 'TH AH R', smil: 'S M AY L', won: 'W AH N', dered: 'D AH R D', shh: 'SH', ah: 'A', wan: 'W AA N' });
const muHero = { x: 235, y: 92, tx: 235 }, muKid = { x: 112, y: 150, tx: 56 };
const muH = (n, ...a) => { const o = []; a.forEach(x => { const [v, k] = String(x).split('x'); for (let i = 0; i < +k; i++) o.push(+v); }); return o.slice(0, n); };   // run-length hype list: H(n, '0x4', '1x8')
const MU = {
    why: {
        title: '♪ THE WHY', track: 'mu_why', tonic: 4, hook: [2, 1, 0, 1, 2], hookBase: 72, intro: 1, feel: 'ballad', E: 0.14, lead: 'gtr', prog: 'Em C G D Em C G D', hype: muH(8, '0x8'),
        gaps: [[4, 3, 'Em Em Em', 2]],
        gapLines: [
            Object.assign({ gap: 0, off: 2, who: 'hero', say: '', raw: [['BH', 1, 1, 'gap']], fitDur: 1.33, nobub: true, nomouth: true, inh: true }, muHero),   // the big rip, a third of the length
            Object.assign({ gap: 0, off: 13, who: 'hero', say: '*cough! cough! COUGH!*', raw: (() => { const r = []; [2, 1, 1].forEach((n, ci) => { for (let i = 0; i < n; i++) { r.push(['K', 0.82 - 0.03 * i, 1.0], ['AH', 0.7 - 0.03 * i, 1.0], ['H', 0.85, 1.2]); if (i < n - 1) r.push(['BH', 1, 0.5, 'gap']); } if (ci < 2) r.push(['BH', 1, 2, 'gap']); }); return r; })(), fitDur: 1.67, cough: true }, muHero),
            Object.assign({ gap: 0, gb: 2, who: 'hero', say: 'Ahh...', mood: 'stoned', ex: 'dizzy', sing: muS('Ahh:2:14:G4:f0.25g-2') }, muHero),   // the smoky exhale after the fit
        ],
        text: 'The smallest spirit finds the courage to ask him why. He sits on the ledge, still smiling, and the smoke loosens something underneath.',
        lines: [
            Object.assign({ bar: 0, who: 'kid', say: 'Why did you do it? Why?', mood: 'plead', shift: 12, sing: muS('Why:0:3:B4 did:3:2:B4 you:5:2:G4 do:7:3:A4 it:10:4:B4 why:19:13:G4:f0.2g2') }, muKid),
            Object.assign({ bar: 2, who: 'hero', say: 'I was never the hero, little fuck.', mood: 'chill', ex: 'condescending', sing: muS('I:0:3:B4 was:3:3:D5 nev:6:3:B4 +er:9:3:G4 the:12:4:B4 he:16:3:A4 +ro:19:3:F#4 lit:22:2:A4 +tle:24:2:D5 fuck:26:6:D4') }, muHero),
            Object.assign({ bar: 4, who: 'kid', say: 'Just tell me why.', mood: 'cold', shift: 12, sing: muS('Just:0:4:B4 tell:4:4:G4 me:8:6:B4 why:16:14:E4') }, muKid),
        ],
    },
    tangent: {
        title: '♪ THE TANGENT', track: 'mu_tangent', tonic: 9, hook: [0, 2, 1, 2, 3], hookBase: 72, intro: 1, feel: 'drift', E: 0.15, lead: 'gtr', prog: 'Am F C G Am F C G Dm Am Bb E7 Am F Dm E7 Am F E7 Am', hype: muH(20, '0x4', '1x12', '0x4'),
        cuts: [[6, 10]],
        gaps: [[4, 1, 'Am'], [6, 1, 'C']],
        gapLines: [
            Object.assign({ gap: 0, off: 7, who: 'hero', say: '*cough*', raw: [['K', 0.8, 0.5], ['AH', 0.6, 0.4]], scough: true, toke: true }, muHero),
            Object.assign({ gap: 1, off: 7, who: 'hero', say: '*cough*', raw: [['K', 0.8, 0.5], ['AH', 0.6, 0.4]], scough: true, toke: true }, muHero),
        ],
        text: 'The smoke carries him far from the question. He talks to the stars, to his own hand, and to the voices he swears are whispering.',
        lines: [
            Object.assign({ bar: 0, who: 'hero', say: 'They clapped for the sombrero... why not... for me.', mood: 'cold', ex: 'bitter', heat: 0.3, sing: muS('They:0:2:E4 clapped:2:3:A4 for:5:2:A4 the:7:2:C5 som:9:2:E5 +bre:11:2:C5 +ro:13:3:A4 why:16:3:C5 not:19:3:A4 for:22:3:F4 me:25:7:A4') }, muHero),
            Object.assign({ bar: 2, who: 'hero', say: 'Years of fiestas... why not clap for me?', mood: 'sad', ex: 'melancholy', heat: 0.12, sing: muS('Years:0:3:E4 of:3:2:G4 fies:5:3:C5 +tas:8:6:E5 why:16:2:D5 not:18:3:B4 clap:21:3:G4 for:24:3:D5 me:27:5:G4') }, muHero),
            Object.assign({ bar: 4, who: 'hero', say: 'Look at the stars. Why do they clap for themselves?', look: 'up', mood: 'stoned', ex: 'daydream', sing: muS('Look:0:2:A4 at:2:2:E4 the:4:2:A4 stars:6:3:C5 Why:9:2:A4 do:11:2:A4 they:13:2:C5 clap:16:3:E5 for:19:2:C5 them:21:3:A4 +selves:24:8:A4') }, muHero),
            Object.assign({ bar: 16, who: 'hero', say: 'Shh. Do you hear the voices? ...They are whispering to me.', mood: 'whisper', ex: 'paranoid', heat: 0.25, voices: true, smood: 'whisper', vol: 0.8, sing: muS('Shh:0:6:E4 Do:8:2:A4 you:10:2:C5 hear:12:2:A4 the:14:2:A4 voi:16:3:F4 +ces:19:4:F4 They:24:2:A4 are:26:2:C5 whis:28:2:A4 +per:30:2:F4 +ing:32:5:G#4 to:37:3:E5 me:40:8:B4') }, muHero),
        ],
    },
    stash: {
        title: '♪ THE STASH', track: 'mu_stash', tonic: 9, hook: [0, 0, 1, 0], hookBase: 69, intro: 0, feel: 'creep', E: 0.16, lead: 'choir', prog: 'Am Am Am Am Dm E7 Am Am', hype: muH(8, '0x3', '1x3', '2x1', '0x1'),
        text: 'A baggie, a rolled bill, one hard snort. The whispers swell into a chant, and the only thing they are cheering for is the hat.',
        lines: [
            Object.assign({ bar: 0, who: 'hero', say: '', raw: [['BH', 1, 1, 'gap']], fitDur: 6.6, nobub: true, nomouth: true, snort: true, at: 10 }, { x: 235, y: 92 }),   // the stash itself: baggie, a line, one hard snort, the rush (the same moment as the regular scene)
            Object.assign({ bar: 3, who: 'hero', sv: 'chorus', say: 'Clap for the hat. Clap for the hat. Clap for the hat.', mood: 'whisper', ex: 'paranoid', heat: 0.3, voices: true, smood: 'cheer', vol: 0.85, sing: muS('Clap:0:2:E4 for:2:2:E4 the:4:3:A4 hat:8:8:C5 Clap:16:2:F4 for:18:2:F4 the:20:3:A4 hat:24:8:D5 Clap:32:2:G#4 for:34:2:G#4 the:36:3:B4 hat:40:8:E5') }, muHero),
            Object.assign({ bar: 6, who: 'hero', say: 'Stop it.', mood: 'cold', ex: 'defiant', heat: 0.5, hat: true, sing: muS('Stop:0:4:A4 it:8:8:E4') }, muHero),
        ],
    },
    breaking: {
        title: '♪ THE BREAKING', track: 'mu_breaking', tonic: 2, hook: [0, 2, 3, 2, 4], hookBase: 74, intro: 1, feel: 'rise', E: 0.12, lead: 'violin', wired: true, cuts: [[0, 2], [6, 1], [13, 1], [19, 1], [24, 1], [33, 1]],
        prog: 'Dm Bb Gm A7 Dm Bb Gm A7 Dm F Gm A7 Dm Bb Gm C Dm Gm A7 Dm Bb F Gm A7 Dm Dm Bb Gm A7 Dm Bb A7 Gm A7 Dm Bb Gm Dm Dm Bb Gm A7 Dm Dm',
        hype: muH(44, '0x4', '1x4', '0x2', '1x15', '2x4', '3x3', '0x6', '1x2', '2x2', '3x2'),
        text: 'Wired and wide awake, he finally says the quiet part out loud. The smallest spirit only needs one sentence to break him.',
        lines: [
            Object.assign({ bar: 0, who: 'hero', say: 'Thirty fiestas, and they only asked for the hat.', mood: 'plead', ex: 'disappointed', heat: 0.2, sing: muS('Thir:0:2:D5 +ty:2:2:D5 fies:4:2:A#4 +tas:6:3:G4 and:9:2:G4 they:11:2:A#4 on:13:1.5:C#5 +ly:14.5:1.5:C#5 asked:16:3:E5 for:19:2:C#5 the:21:2:A4 hat:24:8:A4') }, muHero),
            Object.assign({ bar: 4, who: 'hero', say: 'I held this village together. Me.', mood: 'cold', ex: 'indignant', heat: 0.55, sing: muS('I:0:2:A4 held:2:3:A4 this:5:3:F4 vil:8:3:D5 +lage:11:3:A4 to:14:2:F4 +geth:16:3:F4 +er:19:5:D5 Me:32:14:A4') }, muHero),
            Object.assign({ bar: 8, who: 'hero', say: 'I am fine. I am fine and smiling. See?', mood: 'plead', ex: 'grin', heat: 0.15, sing: muS('I:0:2:A4 am:2:2:A4 fine:4:3:A4 I:8:2:A4 am:10:2:A4 fine:12:2:A4 and:14:2:F4 smil:16:2:F4 +ing:18:2:A4 See:20:10:C5') }, muHero),
            Object.assign({ bar: 10, who: 'kid', say: 'I can see, you are not fine.', mood: 'cold', bait: true, shift: 12, sing: muS('I:0:2:D5 can:2:3:A#4 see:5:6:G4 you:16:2:E5 are:18:2:C#5 not:20:3:A4 fine:24:12:D4') }, muKid),
            Object.assign({ bar: 14, who: 'kid', say: 'Thirty fiestas, and nobody even learned your name.', mood: 'cold', bait: true, shift: 12, sing: muS('Thir:0:2:D5 +ty:2:2:D5 fies:4:2:A#4 +tas:6:3:G4 and:10:2:A#4 no:12:2:D5 +bod:14:2:D5 +y:16:2:E5 e:18:2:G4 +ven:20:2:G4 learned:22:3:G4 your:25:2:C5 name:27:6:E5') }, muKid),
            Object.assign({ bar: 17, who: 'hero', say: 'They know my name.', mood: 'cold', ex: 'defiant', heat: 0.6, sing: muS('They:0:2:D5 know:2:3:A#4 my:5:3:G4 name:9:7:D4') }, muHero),
            Object.assign({ bar: 18, who: 'kid', say: 'What is your name?', mood: 'cold', bait: true, shift: 12, sing: muS('What:0:3:E5 is:3:2:E5 your:5:2:C#5 name:7:8:A4') }, muKid),
            Object.assign({ bar: 20, who: 'hero', say: 'It is... it is...', mood: 'plead', ex: 'bewildered', heat: 0.5, voices: true, sing: muS('It:0:3:D5 is:3:9:F4 it:16:3:C5 is:19:12:A4') }, muHero),
            Object.assign({ bar: 22, who: 'kid', say: 'You do not remember it, do you?', mood: 'cold', bait: true, shift: 12, sing: muS('You:0:2:D5 do:2:2:D5 not:4:2:A#4 re:6:2:G4 +mem:8:2:D5 +ber:10:2:A#4 it:12:2:G4 do:14:2:A#4 you:16:10:E5') }, muKid),
            Object.assign({ bar: 25, who: 'hero', say: 'I am the HERO!', mood: 'rageh', smood: 'rageh', ex: 'rage', heat: 0.85, sing: muS('I:0:2:A4 am:2:2:A4 the:4:3:D5 HE:8:2:F5 +RO:10:6:D5') }, muHero),
            Object.assign({ bar: 26, who: 'hero', say: 'FUCK YOU!', bird: true, mood: 'rageh', smood: 'rageh', ex: 'roar', heat: 0.95, sing: muS('FUCK:0:4:D5 YOU:4:12:F5') }, muHero),
            Object.assign({ bar: 27, who: 'kid', say: 'No. The hat is the hero. It always was.', mood: 'cold', bait: true, shift: 12, sing: muS('No:0:4:D5 The:6:2:D5 hat:8:2:A#4 is:10:2:G4 the:12:2:A#4 he:14:2:D5 +ro:16:3:C#5 It:20:3:E5 al:24:2:C#5 +ways:26:2:A4 was:28:4:E4') }, muKid),
            Object.assign({ bar: 29, who: 'hero', say: 'DO NOT SAY THAT!', mood: 'rageh', smood: 'rageh', ex: 'roar', heat: 1, rage: true, sing: muS('DO:0:3:D5 NOT:4:3:D5 SAY:8:3:F5 THAT:12:4:D5'), x: 215, y: 70, tx: 235 }),
            Object.assign({ bar: 30, who: 'hero', say: 'AAAAAAAAH!', mood: 'rageh', smood: 'rageh', ex: 'roar', heat: 1, sing: muS('Ah:0:14:F5 +Ah:16:15:A5'), x: 215, y: 70, tx: 235 }),
            Object.assign({ bar: 32, who: 'kid', say: 'There he is.', mood: 'cold', bait: true, shift: 12, sing: muS('There:0:3:D5 he:3:3:A#4 is:6:10:G4') }, muKid),
            Object.assign({ bar: 34, who: 'hero', say: 'I am fine. I am fine and smiling.', mood: 'plead', ex: 'grin', heat: 0.4, sing: muS('I:0:3:A4 am:3:2:F4 fine:5:4:A4 I:10:2:A4 am:12:2:F4 fine:14:3:A4 and:17:2:F4 smil:19:3:D5 +ing:22:10:A#4'), x: 215, y: 70, tx: 235 }),
            Object.assign({ bar: 36, who: 'kid', say: 'You are not fine. You never were.', mood: 'cold', bait: true, shift: 12, sing: muS('You:0:2:D5 are:2:2:D5 not:4:3:A#4 fine:8:6:G4 You:16:2:A4 nev:18:3:D5 +er:21:3:A4 were:24:8:F4') }, muKid),
            Object.assign({ bar: 38, who: 'hero', say: 'So I took the hat... and the village. Now you will clap... for me... forever.', mood: 'cold', ex: 'vengeful', heat: 0.45, sing: muS('So:0:3:A4 I:4:2:A4 took:6:3:F4 the:10:2:A4 hat:12:4:D5 and:16:3:A#4 the:20:2:A#4 vil:22:3:D5 +lage:25:3:F5 Now:28:3:D5 you:32:3:D5 will:36:3:A#4 clap:40:4:G4 for:44:3:E5 me:48:8:C#5 for:58:2:A4 +ev:60:2:C#5 +er:64:16:D5'), x: 215, y: 70, tx: 235 }),
        ],
    },
};
// build each number: parse the chord progression, double the sung tune with the lead instrument, mark the last bar, and register its track
function muMel(lines, nBars) { const m = new Array(16 * nBars).fill(0); lines.forEach(l => { if (!l.sing) return; l.sing.forEach(([w, st, ln, no]) => { const i = l.bar * 16 + st; if (i < m.length) { m[i] = no + 12; for (let t = 1; t < ln && i + t < m.length; t++) m[i + t] = -1; } }); }); return m; }
// ---- composition helpers: harmony, countermelody, voice-led pad, walking bass ----
const MU_NAT = [0, 2, 3, 5, 7, 8, 10];
function muDeg(n, tonic) { const rel = ((n - tonic) % 12 + 12) % 12; let best = 0, bd = 99; MU_NAT.forEach((o, i) => { const d = Math.min(Math.abs(rel - o), 12 - Math.abs(rel - o)); if (d < bd) { bd = d; best = i; } }); return best; }
function muStep(n, tonic, k) { const rel = ((n - tonic) % 12 + 12) % 12, base = n - rel; let idx = muDeg(n, tonic) + k; const o2 = Math.floor(idx / 7); idx = ((idx % 7) + 7) % 7; return base + 12 * o2 + MU_NAT[idx]; }
function muHarmNote(no, ch, tonic) { const pcs = ch.v.map(x => x % 12); for (const d of [3, 4, 5, 7, 8]) if (pcs.includes(((no - d) % 12 + 12) % 12)) return no - d; return muStep(no, tonic, -2); }   // the nearest chord tone a third or so under the tune (else the diatonic third)
function muHarmLine(l, song, tonic) {   // a backing line for a sung line: the ghost choir sings "ah" a third under its long notes and its last note
    const notes = l.sing, last = notes.length - 1, out = [];
    notes.forEach(([w, st, ln, no], i) => { if (ln >= 4 || i === last) { const ch = song[Math.min(song.length - 1, l.bar + (st >> 4))].ch; out.push(['ah', st, ln, muHarmNote(no, ch, tonic)]); } });
    return out;
}
function muVoicePad(song) {   // every bar's triad voiced as close as possible to the one before (no leaps), kept in the middle register
    let prev = null; return song.map(b => { const pcs = b.ch.v.slice(0, 3).map(x => x % 12); let best = null, bs = 1e9;
        for (let a = 0; a < 3; a++) for (let c = 0; c < 3; c++) for (let d = 0; d < 3; d++) { const v = [pcs[0] + 48 + 12 * a, pcs[1] + 48 + 12 * c, pcs[2] + 48 + 12 * d].sort((x, y) => x - y); if (v[0] < 52 || v[2] > 79) continue; const sc = prev ? v.reduce((t, n, i) => t + Math.abs(n - prev[i]), 0) : Math.abs(v[0] + v[1] + v[2] - 186); if (sc < bs) { bs = sc; best = v; } }
        prev = best; return best; });
}
function muHooks(T, lines, song, nB) {   // the countermelody: the number's own little motif (as chord-tone steps) answers in every gap the singers leave, and states itself in the intro
    const occ = new Array(nB * 16 + 2).fill(0), mark = (a, b) => { for (let i = Math.max(0, a); i < b && i < occ.length; i++) occ[i] = 1; };
    lines.forEach(l => { if (l.sing) l.sing.forEach(([w, st, ln]) => mark(l.bar * 16 + st - 1, l.bar * 16 + st + ln + 1)); else mark(l.bar * 16, l.bar * 16 + 16 * (l.span || 2)); });
    const ev = {}, tone = (ch, idx) => { const v = ch.v.slice(0, 3).map(x => x % 12); let t0 = T.hookBase + ((v[0] - T.hookBase) % 12 + 12) % 12; const t = [t0]; for (let i = 1; i < 3; i++) { let n = t[i - 1] + 1; while (n % 12 !== v[i]) n++; t.push(n); } t.push(t[0] + 12, t[1] + 12); return t[idx]; };
    for (let b = 0; b < nB - 1; b++) {
        const intro = b < T.intro; let s0 = intro ? 2 : -1;
        if (!intro) { let run = 0; for (let st = 0; st < 16; st++) { if (!occ[b * 16 + st]) { run++; if (run === 6 && s0 < 0) s0 = st - 5; } else run = 0; } if (s0 < 0) continue; if (s0 % 2) s0++; if (s0 > 8) continue; }
        const free = intro ? 14 : (() => { let e = s0; while (e < 16 && !occ[b * 16 + e]) e++; return e - s0; })(), n = Math.min(T.hook.length, Math.max(2, Math.floor(free / 2)));
        for (let i = 0; i < n; i++) { const st = s0 + i * 2, last = i === n - 1, len = last ? Math.max(2, Math.min(6, free - i * 2)) : 2; ev[b * 16 + st] = [tone(song[b].ch, T.hook[i]), len]; }
    }
    return ev;
}
function muBassApproach(song, tonic) {   // last 16th group of each bar: a scale tone leading into the next chord's root
    return song.map((b, i) => { const nx = song[i + 1] ? song[i + 1].ch : null; if (!nx) return 0; let r = nx.r; const cand = [muStep(r, tonic, 1), muStep(r, tonic, -1)].map(n => n); const cur = b.ch.r; return cand.reduce((a, c) => Math.abs(c - cur) < Math.abs(a - cur) ? c : a); });
}

// ---- the number's own instrumental line: the lead instrument no longer doubles the singers; it plays a part of its own (a different rhythm, built from the chord tones) that changes with each number's feel ----
function muCounter(T, pre, nB, muteB, I) {
    const m = new Array(16 * nB).fill(0), tones = (ch, lo) => { const v = ch.v.slice(0, 3).map(x => x % 12), t = []; v.forEach(pc => t.push(lo + ((pc - lo) % 12 + 12) % 12)); t.sort((a, b) => a - b); return t.concat(t.map(x => x + 12)); };
    const put = (b, st, no, ln) => { const i = b * 16 + st; if (i >= m.length) return; m[i] = no; for (let k = 1; k < ln && i + k < m.length; k++) m[i + k] = -1; };
    for (let b = 0; b < nB - 1; b++) {
        if (muteB.includes(b) || b < I && T.feel !== 'ballad' && T.feel !== 'drift') continue;
        const ch = pre[b].ch, hy = T.hype ? (T.hype[b] || 0) : 0, ev = b % 2 === 0;
        if (T.feel === 'ballad') { const t = tones(ch, 60); if (ev) { put(b, 0, t[4], 6); put(b, 6, t[3], 2); put(b, 8, t[2], 8); } else { put(b, 0, t[2], 4); put(b, 4, t[3], 4); put(b, 8, t[5], 6); put(b, 14, t[4], 2); } }
        else if (T.feel === 'drift') { const t = tones(ch, 62), ph = [[4, 3, 2, 3, 1], [3, 4, 5, 4, 2]][ev ? 0 : 1]; [0, 3, 6, 10, 12].forEach((st, i) => put(b, st, t[ph[i]], i === 4 ? 4 : 3)); }
        else if (T.feel === 'creep') { if (b < 2) continue; const t = tones(ch, 52); put(b, 0, t[0] + (ev ? 0 : 1), 3); put(b, 8, t[ev ? 0 : 1] + (ev ? 1 : 0), 3); put(b, 12, t[0] + (ev ? 1 : 0), 2); }
        else {   // the breaking: bare at first, then a rising ostinato that gets faster as the band piles in
            const t = tones(ch, 62), rg = T.rage ? 0 : 0;
            if (hy === 0) { put(b, 0, t[3], 12); put(b, 12, t[2], 4); }
            else if (hy === 1) { const sq = [0, 1, 2, 1]; for (let st = 0; st < 16; st += 2) put(b, st, t[sq[(st >> 1) % 4] + 1], 2); }
            else if (hy === 2) { const sq = [0, 1, 2, 3, 2, 1, 2, 4]; for (let st = 0; st < 16; st += 2) put(b, st, t[sq[st >> 1]], 2); }
            else { const sq = [0, 1, 2, 3, 4, 5, 4, 3, 2, 3, 4, 5, 4, 3, 2, 1]; for (let st = 0; st < 16; st++) put(b, st, t[sq[st]] + (st === 0 ? 0 : 0), 1); }
        }
    }
    return m;
}
const MUSICAL_CUTS = [], MUSICAL_SAY = {};
['why', 'tangent', 'stash', 'breaking'].forEach(k => {
    const T = MU[k];
    if (T.cuts) {   // bars dropped with the words that were cut: later bars (and their chords) move up whole, so the tune keeps its harmony
        const toks = T.prog.split(/\s+/), hy = T.hype.slice();
        T.cuts.slice().sort((x, y) => y[0] - x[0]).forEach(([pos, n]) => { toks.splice(pos, n); hy.splice(pos, n); T.lines.forEach(l => { if (l.bar >= pos + n) { l.bar -= n; if (l.at != null) l.at -= Math.round(n * 16 * T.E * 60); } }); });
        T.prog = toks.join(' '); T.hype = hy; T.cuts = null;
    }
    if (T.gaps) {   // rests for the spoken bits (the joint hit and coughs): extra bars spliced in, everything after them moves down
        const g0 = T.gaps.map((g, i) => ({ pos: g[0], n: g[1], ch: g[2].split(' '), mn: g[3] || g[1], i })), toks = T.prog.split(/\s+/), hy = T.hype.slice(), gs = {};
        g0.sort((x, y) => y.pos - x.pos).forEach(g => { toks.splice(g.pos, 0, ...g.ch); hy.splice(g.pos, 0, ...new Array(g.n).fill(hy[Math.max(0, g.pos - 1)])); T.lines.forEach(l => { if (l.bar >= g.pos) { l.bar += g.n; if (l.at != null) l.at += Math.round(g.n * 16 * T.E * 60); } }); });
        g0.forEach(g => { gs[g.i] = { bar: g.pos + g0.filter(o => o.pos < g.pos).reduce((t, o) => t + o.n, 0), n: g.n, mn: g.mn }; });
        T.prog = toks.join(' '); T.hype = hy; T.muteBars = [];
        T.gapLines.forEach(l => { const G = gs[l.gap]; if (l.sing) l.bar = G.bar + (l.gb || 0); else { l.bar = G.bar; l.span = G.mn; l.at = Math.round((G.bar * 16 + l.off) * T.E * 60); } delete l.gap; delete l.off; delete l.gb; T.lines.push(l); });
        Object.values(gs).forEach(G => { for (let b = 0; b < G.mn; b++) T.muteBars.push(G.bar + b); });
        T.lines.sort((x, y) => x.bar - y.bar || (x.at || 0) - (y.at || 0));
        T.gaps = null;
    }
    const I = T.intro || 0, names = (I ? new Array(I).fill(T.prog.split(/\s+/)[0]).concat(T.prog.split(/\s+/)) : T.prog.split(/\s+/)), nB = names.length;
    T.lines.forEach(l => { l.bar += I; if (I && l.at != null) l.at += Math.round(I * 16 * T.E * 60); });
    const muteB = (T.muteBars || []).map(b => b + I);
    if (I) T.hype = new Array(I).fill(0).concat(T.hype);
    const prog = names.join(' ');
    const pre = mkSong([{ name: 'mu-' + k, prog, scale: GM, lo: 60, hi: 84, seed: 1, rhy: RH_MID, lead: T.lead, hype: 0 }]), song = mkSong([{ name: 'mu-' + k, prog, scale: GM, lo: 60, hi: 84, seed: 1, rhy: RH_MID, lead: T.lead, mel: muCounter(T, pre, nB, muteB, I), hype: 0 }]);
    song.forEach((b, i) => { b.hype = T.hype ? T.hype[i] : 0; });
    song[nB - 1].last = true; song[nB - 1].nx = song[nB - 1].ch;
    const hl = [];   // (no backing choir: the characters sing alone)
    TRACKS[T.track] = { song, mel: null, e: T.E, kind: 'seq', sty: 'stage', feel: T.feel, lines: T.lines.concat(hl), mk: (() => { const r = T.lines.find(l => l.rage), f = T.lines.find(l => l.ex === 'rage'); return r && f ? { fill: f.bar - 1, rage0: r.bar, rage1: r.bar + 2 } : null; })(), mute: muteB.reduce((o, b) => (o[b] = 1, o), {}), hookEv: muHooks(T, T.lines, song, nB), pad: muVoicePad(song), appr: muBassApproach(song, T.tonic) };
    MUSICAL_SAY[T.title] = T.lines;
    const scene = Object.assign({}, END_CUTS.find(s => s.title === ({ why: 'THE WHY', tangent: 'THE TANGENT', stash: 'THE STASH', breaking: 'THE BREAKING' })[k]), { title: T.title, text: T.text, track: T.track, mu: T, musF: Math.round((MU_LEAD + nB * 16 * T.E) * 60), wired: !!T.wired });
    MUSICAL_CUTS.push(scene);
});
function muSungLine(ln, sc) {   // a sung line as the cutscene sees it: the same fields a spoken line has (plan.env drives the mouth, plan.words the bubble), timed by its bar
    const E = sc.mu.E, sy = ln.sing, say = ln.say.split(' '), words = []; let wi = -1;
    sy.forEach(([tk, st]) => { if (tk[0] !== '+') { wi++; words.push({ w: say[wi] != null ? say[wi] : tk, t: st * E }); } });
    const end = Math.max(...sy.map(s => (s[1] + s[2]) * E)), ok = words.length === say.length, W = ok ? words : say.map((w, i) => ({ w, t: end * i / say.length }));
    const env = sy.map(([tk, st, len]) => ({ t0: st * E, d: Math.max(0.08, len * E * 0.95), o: 0.85 })), at = Math.round((MU_LEAD + ln.bar * 16 * E) * 60) - 4;
    return Object.assign({}, ln, { V: moodV(VOICES[ln.who], ln.mood), plan: { chunks: [], env, words: W, dur: end }, at, end: at + Math.ceil(end * 60), started: false, fired: false, sung: true });
}
function muSing(l, dl, E) {   // called by the band on the bar the line starts: every syllable is scheduled on the band's clock
    singWho = l.sv || l.who; singMood = l.smood || 'cheer'; singShift = l.shift || 0;
    try { l.sing.forEach(([w, st, len, no, o]) => singSyl(dl + st * E, w.replace(/^\+/, ''), 440 * Math.pow(2, (no - 69) / 12), len * E, l.vol || 1, o)); }
    finally { singWho = null; singMood = 'cheer'; singShift = 0; }
}
