
const mf = m => 440 * Math.pow(2, (m - 69) / 12);
const CH = {
    Am: { r: 45, f: 52, v: [64, 69, 72] },     Dm: { r: 50, f: 57, v: [65, 69, 74] },
    E:  { r: 40, f: 47, v: [64, 68, 71, 76] }, G:  { r: 43, f: 50, v: [62, 67, 71] },
    F:  { r: 41, f: 48, v: [60, 65, 69] },     C:  { r: 48, f: 55, v: [64, 67, 72] },
    Em: { r: 40, f: 47, v: [64, 67, 71] },
    D:  { r: 50, f: 57, v: [62, 66, 69] },     A:  { r: 45, f: 52, v: [61, 64, 69] },
    Bb: { r: 46, f: 53, v: [62, 65, 70] },     Gm: { r: 43, f: 50, v: [62, 67, 70] },
};
// melodies: 6 eighth-note slots per bar; midi note, 0 = rest, -1 = hold previous note
const MA  = [76,-1,72,69,72,76, 74,-1,77,-1,76,74, 71,-1,68,71,74,76, 69,-1,-1,-1,72,76,
             81,-1,76,-1,72,76, 77,-1,74,-1,77,81, 80,-1,76,-1,71,68, 69,-1,-1,-1,-1,-1];
const MA2 = [79,-1,76,-1,72,76, 77,-1,74,-1,77,81, 80,-1,83,-1,80,76, 71,74,76,80,83,0];
const MAF = [].concat(MA, MA.slice(0, 24), MA2);                       // 16 bars
const MB  = [69,-1,-1,68,69,72, 71,-1,-1,67,71,74, 72,-1,-1,69,72,77, 76,-1,-1,-1,71,68,
             76,-1,72,-1,69,72, 74,-1,71,-1,67,71, 72,-1,69,-1,65,69, 68,-1,71,-1,76,-1];
const MB2 = [76,-1,79,-1,76,72, 74,-1,71,-1,74,79, 72,-1,76,-1,81,-1, 80,-1,76,-1,71,68,
             77,-1,72,-1,77,81, 79,-1,76,-1,72,76, 80,-1,83,-1,80,76, 81,-1,-1,-1,0,0];
const MC  = [72,-1,76,-1,81,-1, 79,-1,76,-1,72,-1, 77,-1,74,-1,69,-1, 72,-1,-1,71,72,74,
             76,-1,80,-1,76,-1, 81,-1,-1,-1,76,-1, 77,-1,81,-1,77,74, 76,-1,-1,-1,0,0];
const MC2 = [81,-1,84,-1,81,76, 84,-1,79,-1,76,79, 77,-1,81,-1,77,74, 76,-1,72,-1,69,72,
             77,-1,72,-1,69,72, 74,-1,79,-1,83,-1, 80,-1,76,-1,71,68, 76,-1,-1,-1,0,0];
const MCF = [].concat(MC, MC2);                                         // 16 bars
const INTRO = [69,72,76,-1,-1,-1, 81,-1,-1,-1,-1,-1, 80,-1,76,-1,71,-1, 68,71,76,80,83,0];
const CODA = [].concat(MA.slice(0, 24), [77,-1,74,-1,77,81, 80,-1,83,-1,80,76, 71,74,76,80,83,-1, 81,-1,-1,-1,-1,-1]);

// ---- build the song, section by section ----
const SONG = [];
let SONG_TARGET = SONG;
function addSec(name, prog, mel, inst, o = {}) {
    const tr = o.tr || 0, cues = o.cues || {};
    prog.split(/\s+/).filter(Boolean).forEach((nm, i) => {
        let ch = CH[nm]; if (tr) ch = { r: ch.r + tr, f: ch.f + tr, v: ch.v.map(x => x + tr) };
        const m = mel ? mel.slice(i * 6, i * 6 + 6).map(x => x > 0 ? x + tr : x) : [0, 0, 0, 0, 0, 0];
        const nBars = prog.split(/\s+/).filter(Boolean).length;
        SONG_TARGET.push({ ch, m, inst: o.insts ? o.insts[Math.floor(i / 2) % o.insts.length] : inst, sec: name, i, end: i === nBars - 1, cue: cues[i] || null });
    });
}
// seeded generator: builds a singable melody that lands on chord tones and cadences on each 4th bar
function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const SC_MIN = [9, 11, 0, 2, 4, 5, 7, 8], SC_MAJ = [0, 2, 4, 5, 7, 9, 11];
const TPL = ['x-x-x-', 'xxx-x-', 'x--xx-', 'x-xxxx', 'xx-xx-', 'x-x-xx', 'x--x--', 'xxxxxx'];
function genMel(prog, seed, scale, lo, hi) {
    const R = rng(seed), out = [], names = prog.split(/\s+/).filter(Boolean);
    const cand = []; for (let m = lo; m <= hi; m++) if (scale.includes(m % 12)) cand.push(m);
    let cur = cand[Math.floor(cand.length / 2)];
    names.forEach((nm, bi) => {
        const ch = CH[nm], tones = new Set(ch.v.map(x => x % 12)), rootPc = ch.r % 12;
        const near = (m, pred) => { let best = cand[0], bd = 99; for (const c of cand) if (pred(c) && Math.abs(c - m) < bd) { bd = Math.abs(c - m); best = c; } return best; };
        const last = bi === names.length - 1, phraseEnd = bi % 4 === 3;
        const tpl = last ? 'x-----' : phraseEnd ? (R() < 0.5 ? 'x-----' : 'x--x--') : TPL[Math.floor(R() * TPL.length)];
        for (let s = 0; s < 6; s++) {
            if (tpl[s] === '-') { out.push(-1); continue; }
            let idx = clamp(cand.indexOf(cur) + Math.floor(R() * 5) - 2, 0, cand.length - 1), n = cand[idx];
            if (phraseEnd && s === 0) n = near(n, c => c % 12 === rootPc);
            else if (s === 0 || s === 3) n = near(n, c => tones.has(c % 12));
            cur = n; out.push(n);
        }
    });
    return out;
}
const PA = 'Am Dm E Am Am Dm E Am Am Dm E Am C Dm E E';
const PB = 'Am G F E Am G F E', PB2 = 'C G Am E F C E Am';
const PS = 'Am Dm E Am Am Dm E Am C G Am E F Dm E E';
const PC = 'Am C Dm Am E Am Dm E Am C Dm Am F G E E';
const PBR = 'Am Am E E Am Am E E';
const K = -7;   // A minor -> D minor
addSec('intro',  'Am Am E E', INTRO, 'trumpet', { cues: { 0: 'grito' } });
addSec('A',      PA,  MAF, 'trumpet', { cues: { 0: 'arriba', 8: 'toro' } });
addSec('B',      PB,  MB,  'violin', { cues: { 3: 'frijol', 6: 'spell' } });
addSec('solo1',  PS,  null, 'solo',   { cues: { 0: 'grito', 8: 'ole', 12: 'noprob' } });
addSec('break1', PBR, null, 'break',  { cues: { 5: 'arriba' } });
addSec('B2',     PB2, MB2, 'duet',    { cues: { 0: 'grito', 4: 'toro' } });
addSec('A-Dm',   PA,  MAF, 'duet',    { tr: K, cues: { 0: 'arriba', 8: 'noprob' } });
addSec('duetDm', PC,  MCF, 'duet',    { tr: K, cues: { 3: 'frijol',  8: 'toro' } });
addSec('soloDm', PS,  null, 'solo',   { tr: K, cues: { 0: 'grito', 8: 'ole' } });
addSec('break2', PBR, null, 'break',  { tr: K, cues: { 5: 'grito' } });
addSec('B-Dm',   PB,  MB,  'violin',  { tr: K, cues: { 4: 'noprob' } });
addSec('duetAm', PC,  MCF, 'duet',    { cues: { 3: 'spell',  0: 'grito', 8: 'noprob' } });
const PBL = 'Am F C G Am F E E Am Dm G C F Dm E E', PFC = 'C G Am Em F C G G C G Am Em F G C C', PPC = 'Am Dm E Am Dm E E E';
addSec('ballad',   PBL, genMel(PBL, 11, SC_MIN, 64, 81), 'ballad',    { cues: { 8: 'ole' } });
addSec('accord',   PA,  genMel(PA, 22, SC_MIN, 64, 84),  'accordion', { cues: { 0: 'arriba', 8: 'toro' } });
addSec('callresp', PA,  MAF, 'trumpet', { tr: -5, insts: ['trumpet', 'violin'], cues: { 0: 'grito', 12: 'ole' } });
addSec('solo-Em',  PS,  null, 'solo',   { tr: -5, cues: { 0: 'grito', 8: 'noprob' } });
addSec('break3',   PBR, null, 'break',  { tr: -5, cues: { 5: 'arriba' } });
addSec('fiesta-C', PFC, genMel(PFC, 33, SC_MAJ, 67, 86), 'duet', { cues: { 0: 'toro', 8: 'arriba' } });
addSec('B3',       PB,  genMel(PB, 44, SC_MIN, 64, 81),  'violin');
addSec('accord2',  PA,  genMel(PA, 55, SC_MIN, 64, 84),  'accordion', { tr: K, cues: { 0: 'grito' } });
addSec('solo-Gm',  PS,  null, 'solo',   { tr: 5, cues: { 8: 'noprob' } });
addSec('ballad2',  PBL, genMel(PBL, 66, SC_MIN, 64, 81), 'ballad',    { tr: K, cues: { 0: 'grito' } });
addSec('break4',   PBR, null, 'break',  { cues: { 5: 'grito' } });
addSec('duetLift', PC,  MCF, 'duet',    { tr: 5, cues: { 0: 'arriba', 8: 'toro' } });
addSec('B-Em',     PB,  MB,  'violin',  { tr: -5 });
addSec('fiesta-D', PFC, genMel(PFC, 77, SC_MAJ, 67, 86), 'duet', { tr: 2, cues: { 0: 'grito', 8: 'ole' } });
addSec('break5',   PBR, null, 'break',  { cues: { 5: 'arriba' } });
addSec('B4',       PB2, MB2, 'violin',  { tr: 5, cues: { 0: 'grito' } });
addSec('break6',   PBR, null, 'break',  { tr: K, cues: { 5: 'arriba' } });
addSec('preCoda',  PPC, genMel(PPC, 88, SC_MIN, 69, 84), 'trumpet', { cues: { 0: 'noprob' } });
addSec('A-fin',  PA,  MAF, 'duet',    { cues: { 12: 'frijol',  0: 'arriba', 8: 'toro' } });
addSec('coda',   'Am Dm E Am Dm E E Am', CODA, 'coda', { cues: { 3: 'noprob', 6: 'arriba' } });
const MELODY = [].concat.apply([], SONG.map(b => b.m));

const TRACKS = { game: { song: SONG, mel: MELODY, e: 0.13 } };   // TRACKS.menu is added below, once mkSong exists
// =====================================================================
//  NEW SONGS: Act 2 "race", Act 3 "rpg", Act 4 "boss"  (16-step sequenced, same mariachi band)
// =====================================================================
function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const NOTE_PC = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
function parseChord(name) {
    const m = /^([A-G])([#b]?)(m|dim|7|m7)?$/.exec(name); if (!m) return { r: 45, v: [57, 60, 64], name };
    let pc = NOTE_PC[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0); pc = (pc + 12) % 12;
    const r = 36 + pc + (pc < 5 ? 12 : 0), q = m[3] || '';
    const third = (q === 'm' || q === 'm7' || q === 'dim') ? 3 : 4, fifth = q === 'dim' ? 6 : 7;
    const v = [r + 12, r + 12 + third, r + 12 + fifth]; if (q === '7' || q === 'm7') v.push(r + 12 + 10);
    return { r, f: r + fifth, v, name, pcs: new Set(v.map(x => x % 12)) };
}
function seqMel(names, scale, lo, hi, seed, rhy) {
    const R = mulberry(seed), cand = []; for (let n = lo; n <= hi; n++) if (scale.includes(n % 12)) cand.push(n);
    let cur = cand[Math.floor(cand.length / 2)], out = [];
    names.forEach((nm, bi) => {
        const ch = parseChord(nm), tpl = rhy[(bi + Math.floor(R() * 3)) % rhy.length], tones = cand.filter(n => ch.pcs.has(n % 12));
        for (let s = 0; s < 16; s++) {
            if (tpl[s] === '.') { out.push(tpl[s] === '-' ? -1 : 0); continue; }
            let idx = cand.indexOf(cur); idx = clamp(idx + Math.floor(R() * 5) - 2, 0, cand.length - 1);
            let n = cand[idx];
            if (s % 8 === 0 || (s % 4 === 0 && R() < 0.5)) { let best = tones[0], bd = 99; for (const t of tones) { const d = Math.abs(t - n); if (d < bd) { bd = d; best = t; } } n = best; }
            cur = n; out.push(n);
        }
    });
    return out;
}
// ---- composed finale melody: 4-bar phrases built from two singable motifs, answered a step higher, ending on a long chord tone ----
// each motif entry: [slot, scale-step offset from the bar's anchor note, length in 16ths]
const FM_A = [[0, 0, 2], [2, 1, 2], [4, 2, 4], [8, 1, 2], [10, 0, 2], [12, -1, 4]];     // up and back down: e e q e e q
const FM_B = [[0, 2, 2], [2, 1, 2], [4, 0, 2], [6, 1, 2], [8, 2, 4], [12, 4, 4]];       // climbs to the top of the phrase
const FM_C = [[0, 0, 4], [4, 1, 2], [6, 0, 2], [8, -1, 4], [12, 0, 4]];                  // calm, quarter-note based
function finaleMel(names, scale, lo, hi, variant) {
    const cand = []; for (let n = lo; n <= hi; n++) if (scale.includes(n % 12)) cand.push(n);
    const mid = Math.floor(cand.length * 0.28), out = [];
    const plans = [[FM_A, FM_A, FM_B], [FM_B, FM_B, FM_A], [FM_A, FM_B, FM_B], [FM_C, FM_C, FM_A]];
    const planA = plans[variant % plans.length], planB = plans[(variant + 1) % plans.length];
    const nearest = (ch, target) => { let best = cand[mid], bd = 99; for (let k = 0; k < cand.length; k++) if (ch.pcs.has(cand[k] % 12)) { const d = Math.abs(k - target); if (d < bd) { bd = d; best = k; } } return best; };
    names.forEach((nm, bi) => {
        const ch = parseChord(nm), pos = bi % 4, last = bi === names.length - 1, endPhrase = pos === 3, plan = bi >= 4 ? planB : planA;   // second phrase answers with the other motif order, a step higher
        const arc = [mid + 1, mid + 3, mid + 2, mid][pos] + (bi >= 4 ? 1 : 0);           // phrase contour: lift, answer higher, settle, land
        const bar = new Array(16).fill(0);
        let notes;
        if (endPhrase) {   // cadence bar: three stepwise notes then one long chord tone (home root on the final bar of a section)
            const ai = nearest(ch, last ? mid - 1 : mid + 1);
            notes = [[0, 2, 2], [2, 1, 2], [4, 0, 4], [8, last ? 0 : -1, 8]];
            notes.forEach(([sl, off, len], k) => { const idx = clamp((k === 3 ? ai : ai) + (k === 3 ? 0 : off), 0, cand.length - 1); bar[sl] = cand[idx]; for (let t = 1; t < len; t++) bar[sl + t] = -1; });
        } else {
            const motif = plan[pos === 0 ? 0 : pos === 1 ? 1 : 2], ai = nearest(ch, arc);
            motif.forEach(([sl, off, len]) => { bar[sl] = cand[clamp(ai + off, 0, cand.length - 1)]; for (let t = 1; t < len; t++) bar[sl + t] = -1; });
        }
        out.push(...bar);
    });
    return out;
}
// ---- the victory song's words. Each line is [first bar, 'syllable:step:length:note ...'] (steps are 16ths from the line's first bar; the voice sings
//      the notes, and the lead instrument doubles them an octave up so the band and the words are one tune). Every note is a tone of that bar's chord, passing notes aside.
function nn(s) { const m = /^([A-G])(#?)(\d)$/.exec(s); return NOTE_PC[m[1]] + (m[2] ? 1 : 0) + 12 * (+m[3] + 1); }
function lyr(str) { return str.trim().split(/\s+/).map(t => { const [w, st, ln, no] = t.split(':'); return [w, +st, +ln, nn(no)]; }); }
const PAIR_C = 'Jeff:0:2:G4 is:2:2:G4 gay:4:4:C5 so:8:2:G4 gay:10:6:E4', PAIR_G = 'Jeff:0:2:B4 is:2:2:B4 gay:4:4:D5 so:8:2:D5 gay:10:6:G4', PAIR_D = 'Jeff:0:2:A4 is:2:2:A4 gay:4:4:D5 so:8:2:D5 gay:10:6:F#4';
const VIC_LYR = {
    'v-A': [   // verse 1 + pre-chorus (G D Em C | G D C D)
        [0, lyr("I:0:3:G4 am:3:3:B4 Jeff:6:6:D5 and:12:4:G4 I'm:16:3:A4 so:19:5:F#4 gay:24:6:D4")],   // gay is cut two steps short so there is a small breath before the next line
        [2, lyr('I:0:2:B4 like:2:3:G4 Jakes:5:3:B4 mom:8.5:3.5:G4 cuz:16:4:C5 of:20:4:G4 Jake:24:8:G4')],
        [4, lyr('Jakes:0:2:B4 mom:3:3:D5 plays:6:4:B4 with:10:6:G4 Jeff:16:4:A4 all:20:4:F#4 day:24:8:D4')],
        [6, lyr("to:0:3:E4 make:3:4:G4 Jeff:7:3:C5 feel:10:6:G4 way:16:3:A4 less:19:5:F#4 gay:24:8:D5")],
    ],
    'v-B': [   // chorus (C G Am D | C G D G)
        [0, lyr(PAIR_C)], [1, lyr(PAIR_G)],
        [2, lyr("Gay:0:4:A4 gay:4:4:C5 gay:8:4:B4 gay:12:4:A4 Jeff's:16:4:A4 so:20:4:A4 gay:24:8:D5")],
        [4, lyr(PAIR_C)], [5, lyr(PAIR_G)], [6, lyr(PAIR_D)],
        [7, lyr('Gay:0:3:G4 gay:3:3:B4 gay:6:3:D5 gay:9:7:D5')],
    ],
    'v-C': [   // verse 2 (G Em C D | G Em Am D) - same rhythms as verse 1: lines 1-2 use v-A's 7-syllable bars, line 4 its 6-syllable bar
        [0, lyr("Jake:0:3:G4 is:3:3:B4 baked:6:6:D5 Jeff:12:4:B4 wants:16:3:B4 to:19:5:G4 bate:24:8:E4")],
        [2, lyr('Jeff:0:3:G4 has:3:3:C5 done:6:4:G4 that:10:6:C5 most:16:4:A4 the:20:4:F#4 day:24:8:D5')],
        [4, lyr("He'll:0:3:G4 fuck:3:3:B4 Jake:6:4:D5 on:10:6:B4 their:16:4:G4 next:20:4:B4 date:24:8:E4")],
        [6, lyr('What:0:2:E4 a:2:2:E4 shame:4:3:A4 that:7:3:C5 Jake:10:6:A4 is:16:4:A4 straight:20:12:D5')],
    ],
    'v-F': [   // the final chorus, cut to its last four lines (C G D G): the song ends on the last "gay gay gay gay"
        [0, lyr(PAIR_C)], [1, lyr(PAIR_G)], [2, lyr(PAIR_D)],
        [3, lyr('Gay:0:3:G4 gay:3:3:B4 gay:6:3:D5 gay:9:7:D5')],
    ],
    'v-tag': [   // the tag (C D G G)
        [0, lyr('Jeff:0:2:G4 is:2:2:G4 gay:4:10:C5 so:16:4:D5 gay:20:12:F#4')],
        [2, lyr('Fun:0:3:B4 for:3:3:B4 all:6:3:D5 come:9:3:D5 on:12:4:B4 hey:16:16:D5')],
    ],
};
function lyrMel(sec, nBars) { const m = new Array(16 * nBars).fill(0); (VIC_LYR[sec] || []).forEach(([bar, syls]) => syls.forEach(([w, st, ln, no]) => { const i = bar * 16 + st; if (i < m.length) { m[i] = no + 12; for (let t = 1; t < ln && i + t < m.length; t++) m[i + t] = -1; } })); return m; }
function mkSong(secs) {   // secs: [{name, prog, scale, lo, hi, seed, rhy, lead, tr}]
    const song = [];
    for (const S of secs) {
        const names = S.prog.split(/\s+/).filter(Boolean), mel = S.rest || S.hold ? null : (S.mel ? S.mel : S.fin != null ? finaleMel(names, S.scale, S.lo, S.hi, S.fin) : seqMel(names, S.scale, S.lo, S.hi, S.seed, S.rhy));
        names.forEach((nm, i) => song.push({ ch: parseChord(nm), nx: null, m: mel ? mel.slice(i * 16, i * 16 + 16) : new Array(16).fill(0), sec: S.name, i, n: names.length, lead: S.lead, end: i === names.length - 1 && !S.hold, first: i === 0 && !S.hold, hype: S.hype || 0, hold: !!S.hold, half: !!S.hold, of: S.of }));
    }
    song.forEach((b, k) => b.nx = song[(k + 1) % song.length].ch);
    return song;
}
const RH_FAST = ['x.xx.xx.x.xx.xx.', 'x.x.xxx.x.x.xxxx', 'xx.xx.x.xx.xx.x.', 'x..xx.x.x..xx.x.'];
const RH_MID  = ['x...x.x.x...x...', 'x..x..x.x..x..x.', 'x.x...x.x...x.x.', 'x...x...x.x.x...'];
const RH_BOSS = ['xxxxxxxxxxxxxxxx', 'x.xxx.xxx.xxx.xx', 'xx.xx.xxxx.xx.xx', 'x.x.xxxxx.x.xxxx'];
const AM = [9, 11, 0, 2, 4, 5, 7], DM = [2, 4, 5, 7, 9, 10, 0], EPH = [4, 5, 8, 9, 11, 0, 3];
const SONG_RACE = mkSong([
    { name: 'r-intro', prog: 'Am Am F E7', scale: AM, lo: 69, hi: 84, seed: 11, rhy: RH_MID, lead: 'horn', hype: 0 },
    { name: 'r-A',     prog: 'Am F C G Am F E7 E7', scale: AM, lo: 69, hi: 88, seed: 23, rhy: RH_FAST, lead: 'horn', hype: 1 },
    { name: 'r-B',     prog: 'F G Am Am F G E7 E7', scale: AM, lo: 72, hi: 91, seed: 37, rhy: RH_FAST, lead: 'duet', hype: 1 },
    { name: 'r-break', prog: 'Am Am E7 E7', scale: AM, lo: 69, hi: 84, seed: 41, rhy: RH_MID, lead: 'gtr', hype: 0 },
    { name: 'r-C',     prog: 'Am F C G Am F E7 Am', scale: AM, lo: 72, hi: 93, seed: 53, rhy: RH_FAST, lead: 'duet', hype: 2 },
]);
const SONG_RPG = mkSong([
    { name: 'p-intro', prog: 'Dm Dm Gm A', scale: DM, lo: 62, hi: 77, seed: 5, rhy: RH_MID, lead: 'accord', hype: 0 },
    { name: 'p-A',     prog: 'Dm Gm A Dm Bb C A A', scale: DM, lo: 62, hi: 81, seed: 17, rhy: RH_MID, lead: 'accord', hype: 1 },
    { name: 'p-B',     prog: 'Gm Dm Bb A Gm Dm A Dm', scale: DM, lo: 65, hi: 84, seed: 29, rhy: RH_FAST, lead: 'trump', hype: 1 },
    { name: 'p-break', prog: 'Bb A Bb A', scale: DM, lo: 65, hi: 79, seed: 31, rhy: RH_MID, lead: 'violin', hype: 0 },
    { name: 'p-C',     prog: 'Dm Gm A Dm Bb C A Dm', scale: DM, lo: 67, hi: 86, seed: 47, rhy: RH_FAST, lead: 'duet', hype: 2 },
]);
const SONG_BOSS = mkSong([
    { name: 'b-intro', prog: 'Em F Em B7', scale: EPH, lo: 64, hi: 80, seed: 7, rhy: RH_BOSS, lead: 'horn', hype: 1 },
    { name: 'b-A',     prog: 'Em F Em F Am B7 Em Em', scale: EPH, lo: 64, hi: 88, seed: 19, rhy: RH_BOSS, lead: 'horn', hype: 2 },
    { name: 'b-B',     prog: 'C B7 Em F C B7 Em B7', scale: EPH, lo: 67, hi: 91, seed: 33, rhy: RH_BOSS, lead: 'duet', hype: 2 },
    { name: 'b-break', prog: 'F F B7 B7', scale: EPH, lo: 64, hi: 80, seed: 43, rhy: RH_MID, lead: 'choir', hype: 1 },
    { name: 'b-C',     prog: 'Em F Em F Am B7 Em B7', scale: EPH, lo: 69, hi: 93, seed: 59, rhy: RH_BOSS, lead: 'duet', hype: 3 },
]);
const GM = [7, 9, 11, 0, 2, 4, 6], AMAJ = [9, 11, 1, 2, 4, 6, 8];
const SONG_FINALE = mkSong([
    { name: 'f-intro', prog: 'G Em C D', scale: GM, lo: 67, hi: 83, seed: 71, rhy: RH_MID, lead: 'gtr', fin: 3, hype: 0 },
    { name: 'f-A', prog: 'G D Em C G D C D', scale: GM, lo: 67, hi: 86, seed: 73, rhy: RH_MID, lead: 'violin', fin: 0, hype: 1 },
    { name: 'f-B', prog: 'C G Am D C G D G', scale: GM, lo: 69, hi: 88, seed: 79, rhy: RH_FAST, lead: 'horn', fin: 1, hype: 1 },
    { name: 'f-A2', prog: 'G D Em C G D C D', scale: GM, lo: 67, hi: 86, seed: 73, rhy: RH_MID, lead: 'duet', fin: 0, hype: 1 },
    { name: 'f-C', prog: 'G Em C D G Em Am D', scale: GM, lo: 71, hi: 91, seed: 83, rhy: RH_FAST, lead: 'duet', fin: 2, hype: 2 },
    { name: 'f-bridge', prog: 'Em Am D G', scale: GM, lo: 67, hi: 83, seed: 89, rhy: RH_MID, lead: 'gtr', fin: 3, hype: 0 },
    { name: 'f-B2', prog: 'C G Am D C G D G', scale: GM, lo: 69, hi: 88, seed: 79, rhy: RH_FAST, lead: 'horn', fin: 1, hype: 2 },
    { name: 'f-C2', prog: 'G Em C D G Em Am D', scale: GM, lo: 71, hi: 91, seed: 83, rhy: RH_FAST, lead: 'duet', fin: 2, hype: 2 },
    { name: 'f-D', prog: 'A F#m D E A F#m D E', scale: AMAJ, lo: 74, hi: 93, seed: 97, rhy: RH_FAST, lead: 'duet', fin: 2, hype: 3 },
    { name: 'f-D2', prog: 'A F#m D E A F#m D E', scale: AMAJ, lo: 74, hi: 93, seed: 97, rhy: RH_FAST, lead: 'duet', fin: 2, hype: 3 },
    { name: 'f-coda', prog: 'D E A A', scale: AMAJ, lo: 74, hi: 93, seed: 101, rhy: RH_MID, lead: 'horn', fin: 3, hype: 3 },
]);
const APH = [9, 10, 0, 2, 4, 5, 7];   // A phrygian: the flat 2nd is what makes it menacing
const SONG_MAP = mkSong([   // short, tight loop: a level-select screen gets revisited constantly
    { name: 'm-intro', prog: 'Am Am Bb E7', scale: APH, lo: 62, hi: 79, seed: 301, rhy: RH_MID, lead: 'gtr', hype: 0 },
    { name: 'm-A',     prog: 'Am Bb Am E7', scale: APH, lo: 64, hi: 83, seed: 303, rhy: RH_MID, lead: 'horn', hype: 1 },
    { name: 'm-B',     prog: 'F E7 Am Bb', scale: APH, lo: 65, hi: 84, seed: 307, rhy: RH_MID, lead: 'violin', hype: 1 },
    { name: 'm-A2',    prog: 'Am Bb Am E7', scale: APH, lo: 64, hi: 83, seed: 303, rhy: RH_MID, lead: 'duet', hype: 2 },
    { name: 'm-turn',  prog: 'Dm Bb E7 E7', scale: APH, lo: 62, hi: 79, seed: 311, rhy: RH_MID, lead: 'gtr', hype: 1 },
]);
const SONG_VICTORY = mkSong([   // intro (the call) -> verse 1 -> chorus -> verse 2 -> tag -> final chorus (rings out at the end); sections join with a fill, a pickup and an arrival (see victoryFlow)
    { name: 'v-intro', prog: 'G C D D', scale: GM, lo: 67, hi: 83, seed: 401, rhy: RH_MID, lead: 'trump', fin: 3, hype: 0 },
    { name: 'v-A', prog: 'G D Em C G D C D', scale: GM, lo: 67, hi: 86, seed: 403, rhy: RH_FAST, lead: 'horn', mel: lyrMel('v-A', 8), hype: 1 },
    { name: 'v-hold', of: 'v-A', hold: true, prog: 'D', scale: GM, lo: 69, hi: 88, seed: 1, rhy: RH_MID, lead: 'horn', hype: 1 },
    { name: 'v-B', prog: 'C G Am D C G D G', scale: GM, lo: 69, hi: 88, seed: 409, rhy: RH_FAST, lead: 'violin', mel: lyrMel('v-B', 8), hype: 2 },
    { name: 'v-hold', of: 'v-B', hold: true, prog: 'G', scale: GM, lo: 69, hi: 88, seed: 1, rhy: RH_MID, lead: 'violin', hype: 2 },
    { name: 'v-C', prog: 'G Em C D G Em Am D', scale: GM, lo: 71, hi: 91, seed: 413, rhy: RH_FAST, lead: 'duet', mel: lyrMel('v-C', 8), hype: 3 },
    { name: 'v-hold', of: 'v-C', hold: true, prog: 'D', scale: GM, lo: 69, hi: 88, seed: 1, rhy: RH_MID, lead: 'duet', hype: 3 },
    { name: 'v-tag', prog: 'C D G G', scale: GM, lo: 71, hi: 91, seed: 419, rhy: RH_FAST, lead: 'horn', mel: lyrMel('v-tag', 4), hype: 3 },
    { name: 'v-hold', of: 'v-tag', hold: true, prog: 'G', scale: GM, lo: 69, hi: 88, seed: 1, rhy: RH_MID, lead: 'horn', hype: 3 },
    { name: 'v-F', prog: 'C G D G', scale: GM, lo: 69, hi: 91, seed: 409, rhy: RH_FAST, lead: 'duet', mel: lyrMel('v-F', 4), hype: 3, fin2: true },   // the final chorus: the first chorus's last four lines, with the whole band; the last word is the end of the song
    { name: 'v-hold', of: 'v-F', hold: true, prog: 'G', scale: GM, lo: 69, hi: 88, seed: 1, rhy: RH_MID, lead: 'duet', hype: 3 },
]);
SONG_VICTORY.slice(-5).forEach(b => { b.fin2 = true; });   // the final chorus's four bars and its hold (v-F)
SONG_VICTORY[SONG_VICTORY.length - 1].last = true;   // the very last bar: the song lands and rings out

// ---- the title theme: a bouncy ranchera polka in D major, 120 bpm. Intro call, hook, bridge, hook again with the full band, a quiet breakdown, then the last hook a whole step higher. ----
const T_RAISE = (arr, n) => arr.map(x => x > 0 ? x + n : x);
const T_INTRO = [74,-1,-1,-1,74,-1,78,-1,81,-1,-1,-1,-1,-1,-1,-1,  76,-1,-1,-1,76,-1,81,-1,85,-1,-1,-1,-1,-1,-1,-1,  74,-1,78,-1,81,-1,86,-1,-1,-1,-1,-1,86,-1,81,-1,  85,-1,-1,-1,81,-1,-1,-1,76,-1,-1,-1,0,0,0,0];
const T_HOOK = [74,-1,-1,-1,78,-1,81,-1,-1,-1,78,-1,74,-1,-1,-1,  76,-1,-1,-1,81,-1,-1,-1,79,-1,76,-1,73,-1,-1,-1,  74,-1,-1,-1,78,-1,-1,-1,83,-1,81,-1,78,-1,74,-1,  79,-1,-1,-1,-1,-1,76,-1,71,-1,74,-1,79,-1,-1,-1,
                78,-1,81,-1,86,-1,-1,-1,83,-1,81,-1,78,-1,-1,-1,  76,-1,79,-1,81,-1,-1,-1,76,-1,73,-1,69,-1,-1,-1,  71,-1,74,-1,79,-1,78,-1,79,-1,81,-1,83,-1,-1,-1,  81,-1,-1,-1,-1,-1,79,-1,76,-1,-1,-1,73,-1,-1,-1];
const T_BRIDGE = [78,-1,-1,78,-1,-1,81,-1,83,-1,-1,-1,81,-1,78,-1,  79,-1,-1,79,-1,-1,83,-1,86,-1,-1,-1,83,-1,79,-1,  81,-1,-1,81,-1,-1,78,-1,74,-1,-1,-1,78,-1,81,-1,  76,-1,-1,76,-1,-1,79,-1,81,-1,-1,-1,85,-1,-1,-1,
                83,-1,-1,83,-1,-1,86,-1,83,-1,81,-1,78,-1,-1,-1,  79,-1,81,-1,83,-1,-1,-1,79,-1,76,-1,71,-1,-1,-1,  73,-1,76,-1,81,-1,-1,-1,79,-1,76,-1,73,-1,-1,-1,  81,-1,-1,-1,-1,-1,-1,-1,0,0,0,0,0,0,0,0];
const T_BREAK = [71,-1,74,-1,78,-1,74,-1,71,-1,74,-1,78,-1,74,-1,  71,-1,74,-1,78,-1,74,-1,71,-1,74,-1,78,-1,74,-1,  69,-1,73,-1,76,-1,73,-1,69,-1,73,-1,76,-1,73,-1,  69,-1,73,-1,76,-1,73,-1,69,-1,73,-1,76,-1,73,-1];
const SONG_TITLE = mkSong([
    { name: 't-intro', prog: 'D A D A', mel: T_INTRO, lead: 'trump', hype: 0 },
    { name: 't-A', prog: 'D A Bm G D A G A', mel: T_HOOK, lead: 'horn', hype: 1 },
    { name: 't-B', prog: 'Bm G D A Bm G A A', mel: T_BRIDGE, lead: 'violin', hype: 1 },
    { name: 't-A2', prog: 'D A Bm G D A G A', mel: T_HOOK, lead: 'duet', hype: 2 },
    { name: 't-break', prog: 'Bm Bm A A', mel: T_BREAK, lead: 'gtr', hype: 0 },
    { name: 't-C', prog: 'E B C#m A E B A B', mel: T_RAISE(T_HOOK, 2), lead: 'duet', hype: 3 },
]);
SONG_TITLE.forEach(b => { b.cue = ({ 't-intro:0': 'grito', 't-A:0': 'arriba', 't-A:4': 'si', 't-B:0': 'andale', 't-B:4': 'porque', 't-A2:0': 'arriba', 't-A2:4': 'si', 't-C:0': 'grito', 't-C:4': 'arriba' })[b.sec + ':' + b.i] || null; });
TRACKS.menu = { song: SONG_TITLE, mel: null, e: 0.125, kind: 'seq', sty: 'title' };
