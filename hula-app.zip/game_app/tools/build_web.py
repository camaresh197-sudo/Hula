#!/usr/bin/env python3
"""Builds the game into www/index.html (minified) and injects the updater. Env: UPDATE_URL, ESBUILD."""
import os, subprocess, sys, re
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('ESBUILD', os.path.join(root, 'node_modules/.bin/esbuild'))
os.makedirs(os.path.join(root, 'www'), exist_ok=True)
subprocess.run([sys.executable, 'build.py', '--min', os.path.join(root, 'www/index.html')], cwd=os.path.join(root, 'game'), check=True)
p = os.path.join(root, 'www/index.html'); h = open(p).read()
js = open(os.path.join(root, 'tools/updater.js')).read().replace('__UPDATE_URL__', os.environ.get('UPDATE_URL', '__UPDATE_URL__'))
assert '</body>' in h
h = h.replace('</body>', '<script>\n' + js + '\n</script>\n</body>', 1)
open(p, 'w').write(h); print('www/index.html', len(h))
