// Zips www/ into dist/bundle-<version>.zip and writes dist/latest.json (what the app polls).
import fs from 'fs'; import crypto from 'crypto'; import archiver from 'archiver';
const version = process.env.APP_VERSION || new Date().toISOString().replace(/[-:T]/g, '').slice(0, 12);
fs.mkdirSync('dist', { recursive: true });
const name = `bundle-${version}.zip`, out = fs.createWriteStream(`dist/${name}`), z = archiver('zip', { zlib: { level: 9 } });
out.on('close', () => {
  const sum = crypto.createHash('sha256').update(fs.readFileSync(`dist/${name}`)).digest('hex');
  fs.writeFileSync('dist/latest.json', JSON.stringify({ version, url: name, checksum: sum }));
  console.log('bundle', name, fs.statSync(`dist/${name}`).size, 'bytes');
});
z.pipe(out); z.directory('www/', false); z.finalize();
