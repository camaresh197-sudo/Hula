# Hula Vaquero – Android app with self-updating patches

* `game/` – the game source (same files as the Cide project). Edit these (or ask Claude to) and push.
* `tools/` – `build_web.py` builds the game into `www/`, `updater.js` is the in-app updater, `make_bundle.mjs` zips a patch.
* `android/` – the Capacitor shell. Rarely changes.

## How it works
1. Push to `main` → GitHub Actions builds the game, publishes `latest.json` + `bundle-N.zip` to GitHub Pages, and builds `app-debug.apk`.
2. The app checks `latest.json` a few seconds after launch. If the version is new it downloads the zip and applies it on the next launch.
3. If a new version fails to start within 15 s the updater rolls back to the previous one automatically.

## One-time setup
1. Create a GitHub repo and push this folder to `main`.
2. Repo Settings → Pages → Source: **GitHub Actions**.
3. Actions tab → latest run → download the **HulaVaquero-apk** artifact, unzip, and install `app-debug.apk` on your Android phone (allow "install unknown apps").

Only a new APK is needed when the shell changes (new native plugin, permissions, icon, name). Everything else ships as a patch.
